> ## Documentation Index
> Fetch the complete documentation index at: https://docs.coreweave.com/llms.txt
> Use this file to discover all available pages before exploring further.

# HttpResponse<D, E>

> TypeScript SDK reference

[GitHub source](https://github.com/wandb/weave/blob/7c9efdc9fe05ffcaf2430dd652ef9bc5b3ffdfaa/sdks/node/src/generated/traceServerApi.ts#L6479)

## Extends

* `Response`

## Type Parameters

**D** `extends unknown`

**E** `extends unknown = unknown`

## Properties

### body

> `readonly` **body**: `ReadableStream`\<`Uint8Array`\<`ArrayBuffer`>> | `null`

[MDN Reference](https://developer.mozilla.org/docs/Web/API/Request/body)

#### Inherited from

`Response.body`

***

### bodyUsed

> `readonly` **bodyUsed**: `boolean`

[MDN Reference](https://developer.mozilla.org/docs/Web/API/Request/bodyUsed)

#### Inherited from

`Response.bodyUsed`

***

### data

> **data**: `D`

***

### error

> **error**: `E`

***

### headers

> `readonly` **headers**: `Headers`

The `headers` read-only property of the with the response.

[MDN Reference](https://developer.mozilla.org/docs/Web/API/Response/headers)

#### Inherited from

`Response.headers`

***

### ok

> `readonly` **ok**: `boolean`

The `ok` read-only property of the Response interface contains a Boolean stating whether the response was successful (status in the range 200-299) or not.

[MDN Reference](https://developer.mozilla.org/docs/Web/API/Response/ok)

#### Inherited from

`Response.ok`

***

### redirected

> `readonly` **redirected**: `boolean`

The `redirected` read-only property of the Response interface indicates whether or not the response is the result of a request you made which was redirected.

[MDN Reference](https://developer.mozilla.org/docs/Web/API/Response/redirected)

#### Inherited from

`Response.redirected`

***

### status

> `readonly` **status**: `number`

The `status` read-only property of the Response interface contains the HTTP status codes of the response.

[MDN Reference](https://developer.mozilla.org/docs/Web/API/Response/status)

#### Inherited from

`Response.status`

***

### statusText

> `readonly` **statusText**: `string`

The `statusText` read-only property of the Response interface contains the status message corresponding to the HTTP status code in Response.status.

[MDN Reference](https://developer.mozilla.org/docs/Web/API/Response/statusText)

#### Inherited from

`Response.statusText`

***

### type

> `readonly` **type**: `ResponseType`

The `type` read-only property of the Response interface contains the type of the response.

[MDN Reference](https://developer.mozilla.org/docs/Web/API/Response/type)

#### Inherited from

`Response.type`

***

### url

> `readonly` **url**: `string`

The `url` read-only property of the Response interface contains the URL of the response.

[MDN Reference](https://developer.mozilla.org/docs/Web/API/Response/url)

#### Inherited from

`Response.url`

## Methods

### arrayBuffer()

> **arrayBuffer**(): `Promise`\<`ArrayBuffer`>

[MDN Reference](https://developer.mozilla.org/docs/Web/API/Request/arrayBuffer)

#### Returns

`Promise`\<`ArrayBuffer`>

#### Inherited from

`Response.arrayBuffer`

***

### blob()

> **blob**(): `Promise`\<`Blob`>

[MDN Reference](https://developer.mozilla.org/docs/Web/API/Request/blob)

#### Returns

`Promise`\<`Blob`>

#### Inherited from

`Response.blob`

***

### bytes()

> **bytes**(): `Promise`\<`Uint8Array`\<`ArrayBuffer`>>

[MDN Reference](https://developer.mozilla.org/docs/Web/API/Request/bytes)

#### Returns

`Promise`\<`Uint8Array`\<`ArrayBuffer`>>

#### Inherited from

`Response.bytes`

***

### clone()

> **clone**(): `Response`

The `clone()` method of the Response interface creates a clone of a response object, identical in every way, but stored in a different variable.

[MDN Reference](https://developer.mozilla.org/docs/Web/API/Response/clone)

#### Returns

`Response`

#### Inherited from

`Response.clone`

***

### formData()

> **formData**(): `Promise`\<`FormData`>

[MDN Reference](https://developer.mozilla.org/docs/Web/API/Request/formData)

#### Returns

`Promise`\<`FormData`>

#### Inherited from

`Response.formData`

***

### json()

> **json**(): `Promise`\<`any`>

[MDN Reference](https://developer.mozilla.org/docs/Web/API/Request/json)

#### Returns

`Promise`\<`any`>

#### Inherited from

`Response.json`

***

### text()

> **text**(): `Promise`\<`string`>

[MDN Reference](https://developer.mozilla.org/docs/Web/API/Request/text)

#### Returns

`Promise`\<`string`>

#### Inherited from

`Response.text`
