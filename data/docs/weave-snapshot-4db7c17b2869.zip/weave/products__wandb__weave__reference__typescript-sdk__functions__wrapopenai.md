> ## Documentation Index
> Fetch the complete documentation index at: https://docs.coreweave.com/llms.txt
> Use this file to discover all available pages before exploring further.

# wrapOpenAI

> TypeScript SDK reference

```ts theme={"system"}
wrapOpenAI<T>(openai: T): T
```

[GitHub source](https://github.com/wandb/weave/blob/7c9efdc9fe05ffcaf2430dd652ef9bc5b3ffdfaa/sdks/node/src/integrations/openai.ts#L760)

Wraps the OpenAI API to enable function tracing for OpenAI calls.

## Type Parameters

**T** `extends object`

## Parameters

**openai** `T` *required*

## Returns

`T`

## Example

```ts twoslash theme={"system"}
// @noErrors
const openai = wrapOpenAI(new OpenAI());
const result = await openai.chat.completions.create({
  model: 'gpt-3.5-turbo',
  messages: [{ role: 'user', content: 'Hello, world!' }]
});
```
