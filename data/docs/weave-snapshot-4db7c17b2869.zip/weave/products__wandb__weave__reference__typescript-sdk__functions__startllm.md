> ## Documentation Index
> Fetch the complete documentation index at: https://docs.coreweave.com/llms.txt
> Use this file to discover all available pages before exploring further.

# startLLM

> TypeScript SDK reference

```ts theme={"system"}
startLLM(opts: LLMInit): LLM
```

[GitHub source](https://github.com/wandb/weave/blob/7c9efdc9fe05ffcaf2430dd652ef9bc5b3ffdfaa/sdks/node/src/genai/api.ts#L77)

Start an LLM span as a child of the current Turn. Throws if no Turn is
active.

## Parameters

**opts** `LLMInit` *required*

See [`LLMInit`](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/interfaces/llminit).

## Returns

[`LLM`](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/interfaces/llm)

## Examples

```ts twoslash theme={"system"}
// @noErrors
weave.startLLM({model: 'gpt-4o-mini', providerName: 'openai'});
```

```ts twoslash theme={"system"}
// @noErrors
weave.startLLM({
  model: 'gpt-4o-mini',
  providerName: 'openai',
  systemInstructions: ['You are a helpful weather bot.'],
  startTime: new Date('2026-05-29T10:00:00.000Z'),
});
```
