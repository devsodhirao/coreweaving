> ## Documentation Index
> Fetch the complete documentation index at: https://docs.coreweave.com/llms.txt
> Use this file to discover all available pages before exploring further.

# Service API overview

> Use the Weave Service API, which provides REST endpoints for programmatic access to Weave functionality.

## Base URL

For [W\&B Multi-tenant Cloud](https://docs.coreweave.com/products/wandb/platform/hosting/hosting-options/multi_tenant_cloud.md) and [W\&B Dedicated Cloud](https://docs.coreweave.com/products/wandb/platform/hosting/hosting-options/dedicated-cloud.md), use the following base URL:

```
https://trace.wandb.ai
```

For [W\&B Self-Managed instances](https://docs.coreweave.com/products/wandb/weave/guides/platform/weave-self-managed.md), use:

```
https://<your-subdomain>.wandb.io/traces
```

## Authentication

Include your W\&B API key in the request headers:

```bash theme={"system"}
curl -H "Authorization: Bearer YOUR_API_KEY" https://trace.wandb.ai/...
```

## Available Endpoints

### Calls

* **[POST `/call/end`](https://docs.coreweave.com/products/wandb/weave/reference/service-api/calls/call-end)** - Call End
* **[POST `/call/read`](https://docs.coreweave.com/products/wandb/weave/reference/service-api/calls/call-read)** - Call Read
* **[POST `/call/start`](https://docs.coreweave.com/products/wandb/weave/reference/service-api/calls/call-start)** - Call Start
* **[POST `/call/update`](https://docs.coreweave.com/products/wandb/weave/reference/service-api/calls/call-update)** - Call Update
* **[POST `/call/upsert_batch`](https://docs.coreweave.com/products/wandb/weave/reference/service-api/calls/call-start-batch)** - Call Start Batch
* **[POST `/calls/delete`](https://docs.coreweave.com/products/wandb/weave/reference/service-api/calls/calls-delete)** - Calls Delete
* **[POST `/calls/query_stats`](https://docs.coreweave.com/products/wandb/weave/reference/service-api/calls/calls-query-stats)** - Calls Query Stats
* **[POST `/calls/stats`](https://docs.coreweave.com/products/wandb/weave/reference/service-api/calls/call-stats)** - Call Stats
* **[POST `/calls/stream_query`](https://docs.coreweave.com/products/wandb/weave/reference/service-api/calls/calls-query-stream)** - Calls Query Stream
* **[POST `/calls/usage`](https://docs.coreweave.com/products/wandb/weave/reference/service-api/calls/calls-usage)** - Calls Usage
* **[POST `/trace/usage`](https://docs.coreweave.com/products/wandb/weave/reference/service-api/calls/trace-usage)** - Trace Usage
* **[POST `/v2/{entity}/{project}/calls/complete`](https://docs.coreweave.com/products/wandb/weave/reference/service-api/calls/calls-complete)** - Calls Complete

### Costs

* **[POST `/cost/create`](https://docs.coreweave.com/products/wandb/weave/reference/service-api/costs/cost-create)** - Cost Create
* **[POST `/cost/purge`](https://docs.coreweave.com/products/wandb/weave/reference/service-api/costs/cost-purge)** - Cost Purge
* **[POST `/cost/query`](https://docs.coreweave.com/products/wandb/weave/reference/service-api/costs/cost-query)** - Cost Query

### Feedback

* **[POST `/feedback/aggregate`](https://docs.coreweave.com/products/wandb/weave/reference/service-api/feedback/feedback-aggregate)** - Feedback Aggregate
* **[POST `/feedback/batch/create`](https://docs.coreweave.com/products/wandb/weave/reference/service-api/feedback/feedback-create-batch)** - Feedback Create Batch
* **[POST `/feedback/create`](https://docs.coreweave.com/products/wandb/weave/reference/service-api/feedback/feedback-create)** - Feedback Create
* **[POST `/feedback/payload_schema`](https://docs.coreweave.com/products/wandb/weave/reference/service-api/feedback/feedback-payload-schema)** - Feedback Payload Schema
* **[POST `/feedback/purge`](https://docs.coreweave.com/products/wandb/weave/reference/service-api/feedback/feedback-purge)** - Feedback Purge
* **[POST `/feedback/query`](https://docs.coreweave.com/products/wandb/weave/reference/service-api/feedback/feedback-query)** - Feedback Query
* **[POST `/feedback/replace`](https://docs.coreweave.com/products/wandb/weave/reference/service-api/feedback/feedback-replace)** - Feedback Replace
* **[POST `/feedback/stats`](https://docs.coreweave.com/products/wandb/weave/reference/service-api/feedback/feedback-stats)** - Feedback Stats

### Files

* **[POST `/file/content`](https://docs.coreweave.com/products/wandb/weave/reference/service-api/files/file-content)** - File Content
* **[POST `/file/create`](https://docs.coreweave.com/products/wandb/weave/reference/service-api/files/file-create)** - File Create
* **[POST `/files/query_stats`](https://docs.coreweave.com/products/wandb/weave/reference/service-api/files/files-stats)** - Files Stats

### Objects

* **[GET `/aliases`](https://docs.coreweave.com/products/wandb/weave/reference/service-api/objects/aliases-list)** - Aliases List
* **[POST `/obj/create`](https://docs.coreweave.com/products/wandb/weave/reference/service-api/objects/obj-create)** - Obj Create
* **[POST `/obj/delete`](https://docs.coreweave.com/products/wandb/weave/reference/service-api/objects/obj-delete)** - Obj Delete
* **[POST `/obj/read`](https://docs.coreweave.com/products/wandb/weave/reference/service-api/objects/obj-read)** - Obj Read
* **[POST `/objs/query`](https://docs.coreweave.com/products/wandb/weave/reference/service-api/objects/objs-query)** - Objs Query
* **[PUT `/objs/{object_id}/aliases`](https://docs.coreweave.com/products/wandb/weave/reference/service-api/objects/obj-set-aliases)** - Obj Set Aliases
* **[POST `/objs/{object_id}/aliases/remove`](https://docs.coreweave.com/products/wandb/weave/reference/service-api/objects/obj-remove-aliases)** - Obj Remove Aliases
* **[PUT `/objs/{object_id}/versions/{digest}/tags`](https://docs.coreweave.com/products/wandb/weave/reference/service-api/objects/obj-add-tags)** - Obj Add Tags
* **[POST `/objs/{object_id}/versions/{digest}/tags/remove`](https://docs.coreweave.com/products/wandb/weave/reference/service-api/objects/obj-remove-tags)** - Obj Remove Tags
* **[GET `/tags`](https://docs.coreweave.com/products/wandb/weave/reference/service-api/objects/tags-list)** - Tags List

### OpenTelemetry

* **[POST `/otel/v1/traces`](https://docs.coreweave.com/products/wandb/weave/reference/service-api/opentelemetry/export-trace)** - Export Trace

### Refs

* **[POST `/refs/read_batch`](https://docs.coreweave.com/products/wandb/weave/reference/service-api/refs/refs-read-batch)** - Refs Read Batch

### Service

* **[GET `/geolocate`](https://docs.coreweave.com/products/wandb/weave/reference/service-api/service/get-caller-location)** - Get Caller Location
* **[GET `/health`](https://docs.coreweave.com/products/wandb/weave/reference/service-api/service/read-root)** - Read Root
* **[GET `/server_info`](https://docs.coreweave.com/products/wandb/weave/reference/service-api/service/server-info)** - Server Info
* **[POST `/service/projects_info`](https://docs.coreweave.com/products/wandb/weave/reference/service-api/service/projects-info)** - Projects Info
* **[GET `/version`](https://docs.coreweave.com/products/wandb/weave/reference/service-api/service/read-version)** - Read Version

### Tables

* **[POST `/table/create`](https://docs.coreweave.com/products/wandb/weave/reference/service-api/tables/table-create)** - Table Create
* **[POST `/table/create_from_digests`](https://docs.coreweave.com/products/wandb/weave/reference/service-api/tables/table-create-from-digests)** - Table Create From Digests
* **[POST `/table/query`](https://docs.coreweave.com/products/wandb/weave/reference/service-api/tables/table-query)** - Table Query
* **[POST `/table/query_stats`](https://docs.coreweave.com/products/wandb/weave/reference/service-api/tables/table-query-stats)** - Table Query Stats
* **[POST `/table/query_stats_batch`](https://docs.coreweave.com/products/wandb/weave/reference/service-api/tables/table-query-stats-batch)** - Table Query Stats Batch
* **[POST `/table/update`](https://docs.coreweave.com/products/wandb/weave/reference/service-api/tables/table-update)** - Table Update

### Threads

* **[POST `/threads/stream_query`](https://docs.coreweave.com/products/wandb/weave/reference/service-api/threads/threads-query-stream)** - Threads Query Stream

### Inference

* **[GET `/inference/analysis/artificialanalysis/models`](https://docs.coreweave.com/products/wandb/weave/reference/service-api/inference/inference-analysis-artificialanalysis-models)** - Inference Analysis Artificialanalysis Models
* **[GET `/inference/catalog/models`](https://docs.coreweave.com/products/wandb/weave/reference/service-api/inference/inference-catalog-models)** - Inference Catalog Models
* **[GET `/inference/modelsdev/models`](https://docs.coreweave.com/products/wandb/weave/reference/service-api/inference/inference-modelsdev-models)** - Inference Modelsdev Models
* **[GET `/inference/nvidia/v2/hardware`](https://docs.coreweave.com/products/wandb/weave/reference/service-api/inference/nvidia-hardware)** - Nvidia Hardware
* **[GET `/inference/router/openrouter/models`](https://docs.coreweave.com/products/wandb/weave/reference/service-api/inference/inference-router-openrouter-models)** - Inference Router Openrouter Models

### Agents

* **[POST `/agents/agent-versions/query`](https://docs.coreweave.com/products/wandb/weave/reference/service-api/agents/genai-agent-versions-query)** - GenAI Agent Versions Query
* **[POST `/agents/conversations/chat`](https://docs.coreweave.com/products/wandb/weave/reference/service-api/agents/genai-conversation-chat)** - GenAI Conversation Chat
* **[POST `/agents/conversations/spans`](https://docs.coreweave.com/products/wandb/weave/reference/service-api/agents/genai-conversation-spans)** - GenAI Conversation Spans
* **[POST `/agents/otel/v1/traces`](https://docs.coreweave.com/products/wandb/weave/reference/service-api/agents/export-genai-trace)** - Export GenAI Trace
* **[POST `/agents/query`](https://docs.coreweave.com/products/wandb/weave/reference/service-api/agents/genai-agents-query)** - GenAI Agents Query
* **[POST `/agents/search`](https://docs.coreweave.com/products/wandb/weave/reference/service-api/agents/genai-search)** - GenAI Search
* **[POST `/agents/spans/custom-attrs/schema`](https://docs.coreweave.com/products/wandb/weave/reference/service-api/agents/genai-custom-attrs-schema)** - GenAI Custom Attrs Schema
* **[POST `/agents/spans/query`](https://docs.coreweave.com/products/wandb/weave/reference/service-api/agents/genai-spans-query)** - GenAI Spans Query
* **[POST `/agents/spans/stats`](https://docs.coreweave.com/products/wandb/weave/reference/service-api/agents/genai-spans-stats)** - GenAI Spans Stats
* **[POST `/agents/traces/chat`](https://docs.coreweave.com/products/wandb/weave/reference/service-api/agents/genai-traces-chat)** - GenAI Traces Chat

### Annotation Queues

* **[POST `/annotation_queues`](https://docs.coreweave.com/products/wandb/weave/reference/service-api/annotation-queues/annotation-queue-create)** - Annotation Queue Create
* **[POST `/annotation_queues/query`](https://docs.coreweave.com/products/wandb/weave/reference/service-api/annotation-queues/annotation-queues-query-stream)** - Annotation Queues Query Stream
* **[POST `/annotation_queues/stats`](https://docs.coreweave.com/products/wandb/weave/reference/service-api/annotation-queues/annotation-queues-stats)** - Annotation Queues Stats
* **[DELETE `/annotation_queues/{queue_id}`](https://docs.coreweave.com/products/wandb/weave/reference/service-api/annotation-queues/annotation-queue-delete)** - Annotation Queue Delete
* **[GET `/annotation_queues/{queue_id}`](https://docs.coreweave.com/products/wandb/weave/reference/service-api/annotation-queues/annotation-queue-read)** - Annotation Queue Read
* **[PUT `/annotation_queues/{queue_id}`](https://docs.coreweave.com/products/wandb/weave/reference/service-api/annotation-queues/annotation-queue-update)** - Annotation Queue Update
* **[POST `/annotation_queues/{queue_id}/items`](https://docs.coreweave.com/products/wandb/weave/reference/service-api/annotation-queues/annotation-queue-add-calls)** - Annotation Queue Add Calls
* **[POST `/annotation_queues/{queue_id}/items/query`](https://docs.coreweave.com/products/wandb/weave/reference/service-api/annotation-queues/annotation-queue-items-query)** - Annotation Queue Items Query
* **[POST `/annotation_queues/{queue_id}/items/{item_id}/progress`](https://docs.coreweave.com/products/wandb/weave/reference/service-api/annotation-queues/annotation-queue-item-progress-update)** - Annotation Queue Item Progress Update

### Custom Runtimes

* **[PUT `/v2/{entity}/{project}/runtimes/{runtime_name}`](https://docs.coreweave.com/products/wandb/weave/reference/service-api/custom-runtimes/custom-runtime-apply)** - Custom Runtime Apply

### Datasets

* **[GET `/v2/{entity}/{project}/datasets`](https://docs.coreweave.com/products/wandb/weave/reference/service-api/datasets/dataset-list)** - Dataset List
* **[POST `/v2/{entity}/{project}/datasets`](https://docs.coreweave.com/products/wandb/weave/reference/service-api/datasets/dataset-create)** - Dataset Create
* **[DELETE `/v2/{entity}/{project}/datasets/{object_id}`](https://docs.coreweave.com/products/wandb/weave/reference/service-api/datasets/dataset-delete)** - Dataset Delete
* **[GET `/v2/{entity}/{project}/datasets/{object_id}/versions/{digest}`](https://docs.coreweave.com/products/wandb/weave/reference/service-api/datasets/dataset-read)** - Dataset Read

### Eval Results

* **[POST `/v2/{entity}/{project}/eval_results/query`](https://docs.coreweave.com/products/wandb/weave/reference/service-api/eval-results/eval-results-query)** - Eval Results Query

### Evaluation Runs

* **[DELETE `/v2/{entity}/{project}/evaluation_runs`](https://docs.coreweave.com/products/wandb/weave/reference/service-api/evaluation-runs/evaluation-run-delete)** - Evaluation Run Delete
* **[GET `/v2/{entity}/{project}/evaluation_runs`](https://docs.coreweave.com/products/wandb/weave/reference/service-api/evaluation-runs/evaluation-run-list)** - Evaluation Run List
* **[POST `/v2/{entity}/{project}/evaluation_runs`](https://docs.coreweave.com/products/wandb/weave/reference/service-api/evaluation-runs/evaluation-run-create)** - Evaluation Run Create
* **[GET `/v2/{entity}/{project}/evaluation_runs/{evaluation_run_id}`](https://docs.coreweave.com/products/wandb/weave/reference/service-api/evaluation-runs/evaluation-run-read)** - Evaluation Run Read
* **[POST `/v2/{entity}/{project}/evaluation_runs/{evaluation_run_id}/finish`](https://docs.coreweave.com/products/wandb/weave/reference/service-api/evaluation-runs/evaluation-run-finish)** - Evaluation Run Finish

### Evaluations

* **[POST `/evaluations/evaluate_model`](https://docs.coreweave.com/products/wandb/weave/reference/service-api/evaluations/evaluate-model)** - Evaluate Model
* **[POST `/evaluations/rescore`](https://docs.coreweave.com/products/wandb/weave/reference/service-api/evaluations/rescore-evaluation)** - Rescore Evaluation
* **[POST `/evaluations/status`](https://docs.coreweave.com/products/wandb/weave/reference/service-api/evaluations/evaluation-status)** - Evaluation Status
* **[GET `/v2/{entity}/{project}/evaluations`](https://docs.coreweave.com/products/wandb/weave/reference/service-api/evaluations/evaluation-list)** - Evaluation List
* **[POST `/v2/{entity}/{project}/evaluations`](https://docs.coreweave.com/products/wandb/weave/reference/service-api/evaluations/evaluation-create)** - Evaluation Create
* **[DELETE `/v2/{entity}/{project}/evaluations/{object_id}`](https://docs.coreweave.com/products/wandb/weave/reference/service-api/evaluations/evaluation-delete)** - Evaluation Delete
* **[GET `/v2/{entity}/{project}/evaluations/{object_id}/versions/{digest}`](https://docs.coreweave.com/products/wandb/weave/reference/service-api/evaluations/evaluation-read)** - Evaluation Read

### Images

* **[POST `/image/create`](https://docs.coreweave.com/products/wandb/weave/reference/service-api/images/image-create)** - Image Create

### Models

* **[GET `/v2/{entity}/{project}/models`](https://docs.coreweave.com/products/wandb/weave/reference/service-api/models/model-list)** - Model List
* **[POST `/v2/{entity}/{project}/models`](https://docs.coreweave.com/products/wandb/weave/reference/service-api/models/model-create)** - Model Create
* **[DELETE `/v2/{entity}/{project}/models/{object_id}`](https://docs.coreweave.com/products/wandb/weave/reference/service-api/models/model-delete)** - Model Delete
* **[GET `/v2/{entity}/{project}/models/{object_id}/versions/{digest}`](https://docs.coreweave.com/products/wandb/weave/reference/service-api/models/model-read)** - Model Read

### Ops

* **[GET `/v2/{entity}/{project}/ops`](https://docs.coreweave.com/products/wandb/weave/reference/service-api/ops/op-list)** - Op List
* **[POST `/v2/{entity}/{project}/ops`](https://docs.coreweave.com/products/wandb/weave/reference/service-api/ops/op-create)** - Op Create
* **[DELETE `/v2/{entity}/{project}/ops/{object_id}`](https://docs.coreweave.com/products/wandb/weave/reference/service-api/ops/op-delete)** - Op Delete
* **[GET `/v2/{entity}/{project}/ops/{object_id}/versions/{digest}`](https://docs.coreweave.com/products/wandb/weave/reference/service-api/ops/op-read)** - Op Read

### Predictions

* **[DELETE `/v2/{entity}/{project}/predictions`](https://docs.coreweave.com/products/wandb/weave/reference/service-api/predictions/prediction-delete)** - Prediction Delete
* **[GET `/v2/{entity}/{project}/predictions`](https://docs.coreweave.com/products/wandb/weave/reference/service-api/predictions/prediction-list)** - Prediction List
* **[POST `/v2/{entity}/{project}/predictions`](https://docs.coreweave.com/products/wandb/weave/reference/service-api/predictions/prediction-create)** - Prediction Create
* **[GET `/v2/{entity}/{project}/predictions/{prediction_id}`](https://docs.coreweave.com/products/wandb/weave/reference/service-api/predictions/prediction-read)** - Prediction Read
* **[POST `/v2/{entity}/{project}/predictions/{prediction_id}/finish`](https://docs.coreweave.com/products/wandb/weave/reference/service-api/predictions/prediction-finish)** - Prediction Finish

### Registry

* **[POST `/link_to_registry`](https://docs.coreweave.com/products/wandb/weave/reference/service-api/registry/link-to-registry)** - Link To Registry

### Scorers

* **[GET `/v2/{entity}/{project}/scorers`](https://docs.coreweave.com/products/wandb/weave/reference/service-api/scorers/scorer-list)** - Scorer List
* **[POST `/v2/{entity}/{project}/scorers`](https://docs.coreweave.com/products/wandb/weave/reference/service-api/scorers/scorer-create)** - Scorer Create
* **[DELETE `/v2/{entity}/{project}/scorers/{object_id}`](https://docs.coreweave.com/products/wandb/weave/reference/service-api/scorers/scorer-delete)** - Scorer Delete
* **[GET `/v2/{entity}/{project}/scorers/{object_id}/versions/{digest}`](https://docs.coreweave.com/products/wandb/weave/reference/service-api/scorers/scorer-read)** - Scorer Read

### Scores

* **[POST `/calls/score`](https://docs.coreweave.com/products/wandb/weave/reference/service-api/scores/calls-score)** - Calls Score
* **[DELETE `/v2/{entity}/{project}/scores`](https://docs.coreweave.com/products/wandb/weave/reference/service-api/scores/score-delete)** - Score Delete
* **[GET `/v2/{entity}/{project}/scores`](https://docs.coreweave.com/products/wandb/weave/reference/service-api/scores/score-list)** - Score List
* **[POST `/v2/{entity}/{project}/scores`](https://docs.coreweave.com/products/wandb/weave/reference/service-api/scores/score-create)** - Score Create
* **[GET `/v2/{entity}/{project}/scores/{score_id}`](https://docs.coreweave.com/products/wandb/weave/reference/service-api/scores/score-read)** - Score Read
