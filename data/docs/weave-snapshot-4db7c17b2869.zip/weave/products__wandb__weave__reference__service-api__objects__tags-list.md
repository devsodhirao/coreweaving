> ## Documentation Index
> Fetch the complete documentation index at: https://docs.coreweave.com/llms.txt
> Use this file to discover all available pages before exploring further.

# Tags List

> List all tags in a project.



## OpenAPI

````yaml products/wandb/weave/reference/service-api/openapi.json GET /tags
openapi: 3.1.0
info:
  title: FastAPI
  version: 0.1.0
servers: []
security: []
paths:
  /tags:
    get:
      tags:
        - Objects
      summary: Tags List
      description: List all tags in a project.
      operationId: tags_list_tags_get
      parameters:
        - name: project_id
          in: query
          required: true
          schema:
            type: string
            title: Project Id
      responses:
        '200':
          description: Successful Response
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/TagsListRes'
        '422':
          description: Validation Error
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/HTTPValidationError'
components:
  schemas:
    TagsListRes:
      properties:
        tags:
          items:
            type: string
          type: array
          title: Tags
      type: object
      required:
        - tags
      title: TagsListRes
    HTTPValidationError:
      properties:
        detail:
          items:
            $ref: '#/components/schemas/ValidationError'
          type: array
          title: Detail
      type: object
      title: HTTPValidationError
    ValidationError:
      properties:
        loc:
          items:
            anyOf:
              - type: string
              - type: integer
          type: array
          title: Location
        msg:
          type: string
          title: Message
        type:
          type: string
          title: Error Type
        input:
          title: Input
        ctx:
          type: object
          title: Context
      type: object
      required:
        - loc
        - msg
        - type
      title: ValidationError

````