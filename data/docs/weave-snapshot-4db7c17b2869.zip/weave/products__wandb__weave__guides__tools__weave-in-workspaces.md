> ## Documentation Index
> Fetch the complete documentation index at: https://docs.coreweave.com/llms.txt
> Use this file to discover all available pages before exploring further.

# Use Weave with Weights & Biases training runs

> Integrate Weave traces with Weights & Biases training runs to inspect function calls alongside ML metrics.

# Log traces during model training runs

You can log Weave traces during model training runs and view them in your personal workspace.

![A W\&B workspace showing a Weave trace panel alongside training run metrics.](https://mintcdn.com/coreweave-dbfa0e8d/3Dv_sw2eg8feUJlx/products/wandb/weave/_media/traces-in-workspace.png?fit=max\&auto=format\&n=3Dv_sw2eg8feUJlx\&q=85\&s=1882d33c4a90bd8a481d7bbae626061f)

Personal workspaces are customizable dashboards in the UI that let you view in-depth analysis and data visualizations of your model training runs. When you add Weave panels to your workspace, you can view and access trace data logged during model runs to gain insight into how your models perform during training.

For example, if you're fine-tuning an LLM model and your Weights & Biases workspace shows that accuracy drops at step 500, the integrated Weave traces can reveal exactly what happened. For instance, your model started generating overly verbose responses that failed the evaluation criteria.

## Use Weave panels

When you [decorate the functions with `@weave.op`](https://docs.coreweave.com/products/wandb/weave/quickstart) in your ML pipelines, you automatically capture their execution information and access it in a personal workspace.

For example, the following script demonstrates how Weave traces integrate with Weights & Biases training runs. It simulates a machine learning training loop where each training step logs metrics to Weights & Biases while simultaneously creating detailed Weave traces. The `@weave.op` decorators on the functions automatically capture inputs, outputs, and execution details. When the training loop logs metrics with `wandb.log()`, it also logs Weave trace information to your project.

```python lines theme={"system"}
import wandb
import weave
import random

# Initialize both W&B and Weave with the same project
project = "my-workspace-project"
weave.init(project)

@weave.op
def evaluate_model(model_state, epoch):
    # Simulate evaluation metrics
    accuracy = 0.7 + epoch * 0.02 + random.uniform(-0.05, 0.05)
    
    # Track specific model behaviors
    test_responses = {
        "conciseness_check": "Model generated 500 words for simple question",
        "accuracy_check": "Model answered 8/10 questions correctly",
        "hallucination_check": "No factual errors detected"
    }
    
    return {
        "accuracy": accuracy,
        "diagnostic_results": test_responses
    }

@weave.op
def training_step(epoch, lr):
    # Simulate Training logic
    loss = 1.0 / (epoch + 1) + random.uniform(-0.1, 0.1)
    
    # Evaluation with traces
    eval_results = evaluate_model(f"checkpoint_{epoch}", epoch)
    
    return {
        "loss": loss,
        "accuracy": eval_results["accuracy"],
        "diagnostics": eval_results["diagnostic_results"]
    }

# Training loop
with wandb.init(project=project, config={"lr": 0.01}) as run:
    for epoch in range(5):
        # Execute training with Weave tracing
        results = training_step(epoch, run.config.lr)
        
        # Log to W&B - creates the integration point
        run.log({
            "epoch": epoch,
            "loss": results["loss"],
            "accuracy": results["accuracy"]
        })
```

You can run this example script to see how traces get logged with the rest of your run information.

After the run starts, you can view the trace information in your workspace either during or after the run. Open the link provided in the terminal at the start of a run (it looks like this: `wandb: 🚀 View run at https://forge.coreweave.com/wandb/wandb/my-project/runs/[RUN-ID]`), or navigate to the workspace in the UI.

To navigate to a workspace from the UI:

1. Open the Weights & Biases UI and click the **Projects** tab. This opens a list of your projects.
2. From the list of projects, click the project that you logged your run to. This opens the **Workspaces** page.
3. If you've set up your workspace as an automatic workspace, the workspace automatically populates with data visualizations and information about your run. The trace data for your run is under the **Weave** section of the workspace. If your workspace is a manual workspace, you can add Weave panels by clicking **Add panels** and selecting panels from the **Weave** section of the Add Panels menu.

For more information about workspaces, see [View experiments results](https://docs.coreweave.com/products/wandb/track/workspaces.md).

## View a linked run in the Traces table

When you call a function decorated with `@weave.op` inside a `wandb.init()` context of your ML pipeline, Weave automatically associates the trace with the active [Weights & Biases run](https://docs.coreweave.com/products/wandb/runs.md). The **Traces** table in the Weave UI links each trace to its associated runs.

To view the runs linked to your traces:

1. Run a script that calls traced functions inside a `wandb.init()` context, such as the training example in [Use Weave panels](#use-weave-panels).
2. Open the [Weights & Biases UI](https://forge.coreweave.com/wandb) and select your project.
3. In the **Weave** project sidebar, click **Traces**. The **Traces** table displays links to any associated runs.
4. Open a trace from the **Traces** table to inspect the linked run and review its experiment context.

> [!NOTE]
>
> The Weave TypeScript SDK doesn't support linking traces to Weights & Biases runs.

## Associate traces with a specific W\&B run

In some cases, you may want to attach traces to a run other than the one Weave detects automatically. By default, Weave automatically detects and associates traces with the active `wandb.run`. If you need to associate traces with a specific run that isn't the global `wandb.run`, use `set_wandb_run_context`. To associate traces with a specific run and run step, define values for the method's `run_id` and `step` arguments:

```python lines highlight={6} theme={"system"}
import weave

client = weave.init("[YOUR-TEAM-NAME]/[YOUR-PROJECT-NAME]")

# Associate all subsequent traces with a specific run.
client.set_wandb_run_context(run_id="[YOUR-RUN-ID]", step=[INTEGER])

@weave.op
def my_function(x):
    return x * 2

my_function(10)  # This trace is linked to "my-run-id" at step 5.
```

The `run_id` is the run's short ID (for example, `38m4t5ja`), not the full `entity/project/run_id` path. You can find a run's short ID in the run URL (`https://forge.coreweave.com/wandb/team/project/runs/[RUN-ID]`) or by [accessing `wandb.run.id` in code](https://docs.coreweave.com/products/wandb/runs/run-identifiers#find-and-customize-a-runs-id-or-name).

To stop the override and fall back to the global `wandb.run`, call `clear_wandb_run_context`:

```python lines theme={"system"}
client.clear_wandb_run_context()

my_function(20)  # This trace uses the global wandb.run (if any).
```

## Reference W\&B artifacts in a Weave trace

You can reference [W\&B artifacts](https://docs.coreweave.com/products/wandb/artifacts.md) (such as models, datasets, and checkpoints) in your Weave traces. This creates a clickable link in the Weights & Biases UI that navigates directly to the artifact's details page, which helps you track which artifact versions you used during specific operations.

For example, if you've trained two versions of a model (`v1` and `v2`), you can add the `v1` artifact reference as an attribute of the trace when you query that model. This helps you trace exactly which artifact version produced a given output.

To associate an artifact with a trace, construct the artifact's URL by concatenating the `wandb-artifact:///` prefix with the artifact's full name using the following syntax: `wandb-artifact:///[FULL-NAME-OF-ARTIFACT]`. Then pass it to Weave in one of two ways:

* As an arbitrary attribute
* As an attribute of a `Model`

You can locate the artifact's full name on its details page in the Weights & Biases UI. It looks like this: `[ENTITY]/[PROJECT]/[ARTIFACT-NAME]:[VERSION]`. You can copy the full name from the artifact's details page in the Weights & Biases UI.

The following sections show each approach.

### Add an artifact as an attribute of a trace

To add an artifact as an attribute of a trace, pass it as a key-value pair to the `weave.attributes()` context manager:

**Python**

```python lines {10} theme={"system"}
import weave

weave.init("[YOUR-TEAM-NAME]/[YOUR-PROJECT-NAME]")

@weave.op
def my_function(name: str):
    return f"Hello, {name}!"

# Add an arbitrary key-name and the artifact's URL as the value
with weave.attributes({'artifact_id': 'wandb-artifact:///team-name/project-name/run-38m4t5ja-history:v0'}):
    result = my_function("World")
```

**TypeScript**

```typescript twoslash lines {12} theme={"system"}
// @noErrors
import {init, op, withAttributes} from 'weave';

async function main() {
  await init('wandb/docs');

  const myFunction = op(async function myFunction(name: string) {
    return `Hello, ${name}!`;
  });

  // Add an arbitrary key-name and the artifact's URL as the value
  const result = await withAttributes(
    {artifact_id: "wandb-artifact:///team-name/project-name/run-38m4t5ja-history:v0"},
    async () => myFunction('World')
  );

  console.log('Result:', result);
}

main().catch(console.error);
```

### Add an artifact as an attribute of a `Model`

To add an artifact as an attribute of a `Model`, pass the artifact URL when you instantiate the model:

> [!NOTE]
>
> The `Model` class is only supported in the Weave Python SDK.

```python lines {7,17} theme={"system"}
import weave

weave.init("[YOUR-TEAM-NAME]/[YOUR-PROJECT-NAME]")

class MyModel(weave.Model):
    # Store the artifact reference as a model attribute
    artifact_id: str
    temperature: float = 0.7
    
    @weave.op
    def predict(self, query: str) -> str:
        # Your model inference logic here
        return f"Response to: {query}"

# Pass the artifact's URL as an attribute of the model
model = MyModel(
    artifact_id="wandb-artifact:///team-name/project-name/run-38m4t5ja-history:v0"
)

result = model.predict("Hello, World!")
```
