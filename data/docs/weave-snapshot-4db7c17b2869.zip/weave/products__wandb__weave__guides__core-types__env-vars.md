> ## Documentation Index
> Fetch the complete documentation index at: https://docs.coreweave.com/llms.txt
> Use this file to discover all available pages before exploring further.

# Configure Weave environment variables

> Configure Weave's behavior at runtime using environment variables

Weave provides a set of environment variables to configure and optimize its behavior. This page is for developers using the Weave SDK who want to adjust runtime behavior such as tracing, logging, caching, and retries without modifying application code. You can set these variables in your shell or within scripts to control specific functionality.

The following examples show two common ways to set Weave environment variables. Use the shell approach to configure Weave for an entire session, or the Python approach to set values from within your script.

```bash theme={"system"}
# Example of setting environment variables in the shell
export WEAVE_PARALLELISM=10  # Controls the number of parallel workers
export WEAVE_PRINT_CALL_LINK=false  # Disables call link output
```

```python lines theme={"system"}
# Example of setting environment variables in Python
import os

os.environ["WEAVE_PARALLELISM"] = "10"
os.environ["WEAVE_PRINT_CALL_LINK"] = "false"
```

## Available environment variables

The following table lists each supported environment variable, its type, default value, and the behavior it controls. For accepted values when setting boolean variables, see the note about boolean values.

| Variable | Type | Default | Description |
| - | - | - | - |
| `WANDB_API_KEY` | `string` | `None` | If set, automatically logs you into Weights & Biases without prompting for your API key. To generate an API key, log in to your CoreWeave Forge account and go to [User settings](https://forge.coreweave.com/settings). |
| `WEAVE_DISABLED` | `bool` | `false` | When set to `true`, disables all Weave tracing. Weave ops behave like regular functions. |
| `WEAVE_PRINT_CALL_LINK` | `bool` | `true` | Controls whether to print a link to the Weights & Biases UI when calling a Weave op. You can also set this directly in your code by configuring the `settings` argument for `weave.init()` like this: `weave.init("your-project-name", settings={"print_call_link": False})` |
| `WEAVE_LOG_LEVEL` | `str` | `INFO` | Controls the log level of the Weave logger. |
| `WEAVE_CAPTURE_CODE` | `bool` | `true` | Controls whether to save code for ops so you can reload it for later use. |
| `WEAVE_DEBUG_HTTP` | `bool` | `false` | When set to `true`, turns on HTTP request and response logging for debugging. |
| `WEAVE_PARALLELISM` | `int` | `20` | In evaluations, controls the number of examples to evaluate in parallel. Set to `1` to run examples sequentially. |
| `WEAVE_TRACE_LANGCHAIN` | `bool` | `true` | Controls global tracing for LangChain. Set to `false` to explicitly disable LangChain tracing. |
| `WEAVE_USE_SERVER_CACHE` | `bool` | `true` | Enables server response caching. When enabled, Weave caches server responses to disk so repeated queries can be served from the cache instead of refetching from the server. |
| `WEAVE_SERVER_CACHE_SIZE_LIMIT` | `int` | `1,000,000,000` | Sets the maximum size limit for the server cache in bytes. When the cache reaches this size, Weave automatically removes older entries to make space for new ones. Important: the underlying implementation uses SQLite, which has a Write-Ahead Log (WAL) that grows to 4 MB regardless of this setting. Weave removes this WAL when the program exits. |
| `WEAVE_SERVER_CACHE_DIR` | `str` | `None` | Specifies the directory where Weave stores cache files. If not set, Weave uses a temporary directory. |
| `WEAVE_MAX_CALLS_QUEUE_SIZE` | `int` | `100000` | Sets the maximum size of the calls queue. Defaults to `100000`. Setting a value of `0` lets the queue grow unbounded. |
| `WEAVE_ENABLE_WAL` | `bool` | `false` | Enables the Weave [Write-Ahead Log (WAL)](https://docs.coreweave.com/products/wandb/weave/guides/tracking/write-ahead-log.md). When set to `true`, Weave writes API requests to disk before sending them to the server, so requests can be recovered if the process exits before they are sent. |
| `WEAVE_DISABLE_WAL_SENDER` | `bool` | `false` | Disables the Weave Write-Ahead Log (WAL) sender. When set to `true`, Weave writes requests to disk but doesn't flush them to the server. Useful for debugging. |
| `WEAVE_RETRY_MAX_ATTEMPTS` | `int` | `3` | Sets the maximum number of retry attempts for failed requests. |
| `WEAVE_RETRY_MAX_INTERVAL` | `float` | `300.0` | Sets the maximum interval between retry attempts in seconds. |
| `WANDB_BASE_URL` | `string` | `None` | Sets the Weave host URL. Equivalent to entering the host URL when prompted by `wandb.login()`. You can specify `WANDB_BASE_URL` and `WANDB_API_KEY` before using `weave.init()` to automatically log in and authenticate to Weave. |

> [!NOTE]
>
> All boolean environment variables accept the following values (case-insensitive):
>
> * `true`, `1`, `yes`, `on` for `True`
> * `false`, `0`, `no`, `off` for `False`
