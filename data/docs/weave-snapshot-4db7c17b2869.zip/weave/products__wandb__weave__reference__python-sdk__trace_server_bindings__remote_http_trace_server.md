> ## Documentation Index
> Fetch the complete documentation index at: https://docs.coreweave.com/llms.txt
> Use this file to discover all available pages before exploring further.

# remote_http_trace_server

> Python SDK reference for weave.trace_server_bindings.remote_http_trace_server

# API Overview

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server_bindings/remote_http_trace_server.py#L58)

## <kbd>class</kbd> `RemoteHTTPTraceServer`

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server_bindings/remote_http_trace_server.py#L62)

### <kbd>method</kbd> `__init__`

```python theme={"system"}
__init__(
    trace_server_url: str,
    should_batch: bool = False,
    remote_request_bytes_limit: int = 32505856,
    auth: tuple[str, str] | None = None,
    extra_headers: dict[str, str] | None = None
)
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/pydantic/_internal/_validate_call.py#L665)

### <kbd>method</kbd> `agent_agents_query`

```python theme={"system"}
agent_agents_query(req: AgentsQueryReq) → AgentsQueryRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/pydantic/_internal/_validate_call.py#L654)

### <kbd>method</kbd> `agent_conversation_chat`

```python theme={"system"}
agent_conversation_chat(
    req: AgentConversationChatReq
) → AgentConversationChatRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/pydantic/_internal/_validate_call.py#L698)

### <kbd>method</kbd> `agent_custom_attrs_schema`

```python theme={"system"}
agent_custom_attrs_schema(
    req: AgentCustomAttrsSchemaReq
) → AgentCustomAttrsSchemaRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/pydantic/_internal/_validate_call.py#L709)

### <kbd>method</kbd> `agent_search`

```python theme={"system"}
agent_search(req: AgentSearchReq) → AgentSearchRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/pydantic/_internal/_validate_call.py#L632)

### <kbd>method</kbd> `agent_spans_query`

```python theme={"system"}
agent_spans_query(req: AgentSpansQueryReq) → AgentSpansQueryRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/pydantic/_internal/_validate_call.py#L687)

### <kbd>method</kbd> `agent_spans_stats`

```python theme={"system"}
agent_spans_stats(req: AgentSpanStatsReq) → AgentSpanStatsRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/pydantic/_internal/_validate_call.py#L643)

### <kbd>method</kbd> `agent_traces_chat`

```python theme={"system"}
agent_traces_chat(req: AgentTraceChatReq) → AgentTraceChatRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/pydantic/_internal/_validate_call.py#L676)

### <kbd>method</kbd> `agent_versions_query`

```python theme={"system"}
agent_versions_query(req: AgentVersionsQueryReq) → AgentVersionsQueryRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server_bindings/remote_http_trace_server.py#L882)

### <kbd>method</kbd> `aliases_list`

```python theme={"system"}
aliases_list(req: AliasesListReq) → AliasesListRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server_bindings/remote_http_trace_server.py#L1230)

### <kbd>method</kbd> `annotation_queue_add_calls`

```python theme={"system"}
annotation_queue_add_calls(
    req: AnnotationQueueAddCallsReq
) → AnnotationQueueAddCallsRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server_bindings/remote_http_trace_server.py#L1168)

### <kbd>method</kbd> `annotation_queue_create`

```python theme={"system"}
annotation_queue_create(
    req: AnnotationQueueCreateReq
) → AnnotationQueueCreateRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server_bindings/remote_http_trace_server.py#L1200)

### <kbd>method</kbd> `annotation_queue_delete`

```python theme={"system"}
annotation_queue_delete(
    req: AnnotationQueueDeleteReq
) → AnnotationQueueDeleteRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server_bindings/remote_http_trace_server.py#L1246)

### <kbd>method</kbd> `annotation_queue_items_query`

```python theme={"system"}
annotation_queue_items_query(
    req: AnnotationQueueItemsQueryReq
) → AnnotationQueueItemsQueryRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server_bindings/remote_http_trace_server.py#L1188)

### <kbd>method</kbd> `annotation_queue_read`

```python theme={"system"}
annotation_queue_read(req: AnnotationQueueReadReq) → AnnotationQueueReadRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server_bindings/remote_http_trace_server.py#L1212)

### <kbd>method</kbd> `annotation_queue_update`

```python theme={"system"}
annotation_queue_update(
    req: AnnotationQueueUpdateReq
) → AnnotationQueueUpdateRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server_bindings/remote_http_trace_server.py#L1178)

### <kbd>method</kbd> `annotation_queues_query_stream`

```python theme={"system"}
annotation_queues_query_stream(
    req: AnnotationQueuesQueryReq
) → Iterator[AnnotationQueueSchema]
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server_bindings/remote_http_trace_server.py#L1265)

### <kbd>method</kbd> `annotation_queues_stats`

```python theme={"system"}
annotation_queues_stats(
    req: AnnotationQueuesStatsReq
) → AnnotationQueuesStatsRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server_bindings/remote_http_trace_server.py#L1275)

### <kbd>method</kbd> `annotator_queue_items_progress_update`

```python theme={"system"}
annotator_queue_items_progress_update(
    req: AnnotatorQueueItemsProgressUpdateReq
) → AnnotatorQueueItemsProgressUpdateRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/pydantic/_internal/_validate_call.py#L745)

### <kbd>method</kbd> `call_end`

```python theme={"system"}
call_end(req: CallEndReq) → CallEndRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server_bindings/remote_http_trace_server.py#L1956)

### <kbd>method</kbd> `call_end_v2`

```python theme={"system"}
call_end_v2(req: CallEndV2Req) → CallEndV2Res
```

Single call end endpoint (v2).

This endpoint is used for eager ops that need their end sent separately.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/pydantic/_internal/_validate_call.py#L760)

### <kbd>method</kbd> `call_read`

```python theme={"system"}
call_read(req: CallReadReq) → CallReadRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/pydantic/_internal/_validate_call.py#L721)

### <kbd>method</kbd> `call_start`

```python theme={"system"}
call_start(req: CallStartReq) → CallStartRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server_bindings/remote_http_trace_server.py#L740)

### <kbd>method</kbd> `call_start_batch`

```python theme={"system"}
call_start_batch(req: CallCreateBatchReq) → CallCreateBatchRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server_bindings/remote_http_trace_server.py#L1939)

### <kbd>method</kbd> `call_start_v2`

```python theme={"system"}
call_start_v2(req: CallStartV2Req) → CallStartV2Res
```

Single call start endpoint (v2).

This endpoint is used for eager ops that need their start visible immediately.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/pydantic/_internal/_validate_call.py#L801)

### <kbd>method</kbd> `call_update`

```python theme={"system"}
call_update(req: CallUpdateReq) → CallUpdateRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server_bindings/remote_http_trace_server.py#L1916)

### <kbd>method</kbd> `calls_complete`

```python theme={"system"}
calls_complete(req: CallsUpsertCompleteReq) → CallsUpsertCompleteRes
```

Batch complete calls endpoint (v2).

This endpoint is used when use\_calls\_complete is enabled to send complete calls (with both start and end information) in batches.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/pydantic/_internal/_validate_call.py#L795)

### <kbd>method</kbd> `calls_delete`

```python theme={"system"}
calls_delete(req: CallsDeleteReq) → CallsDeleteRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/pydantic/_internal/_validate_call.py#L766)

### <kbd>method</kbd> `calls_query`

```python theme={"system"}
calls_query(req: CallsQueryReq) → CallsQueryRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/pydantic/_internal/_validate_call.py#L777)

### <kbd>method</kbd> `calls_query_stats`

```python theme={"system"}
calls_query_stats(req: CallsQueryStatsReq) → CallsQueryStatsRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/pydantic/_internal/_validate_call.py#L771)

### <kbd>method</kbd> `calls_query_stream`

```python theme={"system"}
calls_query_stream(req: CallsQueryReq) → Iterator[CallSchema]
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server_bindings/remote_http_trace_server.py#L1343)

### <kbd>method</kbd> `calls_score`

```python theme={"system"}
calls_score(req: CallsScoreReq) → CallsScoreRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/pydantic/_internal/_validate_call.py#L789)

### <kbd>method</kbd> `calls_usage`

```python theme={"system"}
calls_usage(req: CallsUsageReq) → CallsUsageRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server_bindings/remote_http_trace_server.py#L1107)

### <kbd>method</kbd> `completions_create`

```python theme={"system"}
completions_create(req: CompletionsCreateReq) → CompletionsCreateRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server_bindings/remote_http_trace_server.py#L1117)

### <kbd>method</kbd> `completions_create_stream`

```python theme={"system"}
completions_create_stream(req: CompletionsCreateReq) → Iterator[dict[str, Any]]
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/pydantic/_internal/_validate_call.py#L1095)

### <kbd>method</kbd> `cost_create`

```python theme={"system"}
cost_create(req: CostCreateReq) → CostCreateRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/pydantic/_internal/_validate_call.py#L1101)

### <kbd>method</kbd> `cost_purge`

```python theme={"system"}
cost_purge(req: CostPurgeReq) → CostPurgeRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/pydantic/_internal/_validate_call.py#L1089)

### <kbd>method</kbd> `cost_query`

```python theme={"system"}
cost_query(req: CostQueryReq) → CostQueryRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/pydantic/_internal/_validate_call.py#L1413)

### <kbd>method</kbd> `dataset_create`

```python theme={"system"}
dataset_create(req: DatasetCreateReq) → DatasetCreateRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/pydantic/_internal/_validate_call.py#L1459)

### <kbd>method</kbd> `dataset_delete`

```python theme={"system"}
dataset_delete(req: DatasetDeleteReq) → DatasetDeleteRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/pydantic/_internal/_validate_call.py#L1440)

### <kbd>method</kbd> `dataset_list`

```python theme={"system"}
dataset_list(req: DatasetListReq) → Iterator[DatasetReadRes]
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/pydantic/_internal/_validate_call.py#L1428)

### <kbd>method</kbd> `dataset_read`

```python theme={"system"}
dataset_read(req: DatasetReadReq) → DatasetReadRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server_bindings/remote_http_trace_server.py#L1292)

### <kbd>method</kbd> `dataset_sources_link`

```python theme={"system"}
dataset_sources_link(req: DatasetSourcesLinkReq) → DatasetSourcesLinkRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server_bindings/remote_http_trace_server.py#L1302)

### <kbd>method</kbd> `dataset_sources_link_delete`

```python theme={"system"}
dataset_sources_link_delete(
    req: DatasetSourcesLinkDeleteReq
) → DatasetSourcesLinkDeleteRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server_bindings/remote_http_trace_server.py#L1312)

### <kbd>method</kbd> `dataset_sources_query`

```python theme={"system"}
dataset_sources_query(req: DatasetSourcesQueryReq) → DatasetSourcesQueryRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server_bindings/remote_http_trace_server.py#L170)

### <kbd>method</kbd> `delete`

```python theme={"system"}
delete(url: str, *args: Any, **kwargs: Any) → Response
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server_bindings/remote_http_trace_server.py#L100)

### <kbd>method</kbd> `ensure_project_exists`

```python theme={"system"}
ensure_project_exists(entity: str, project: str) → EnsureProjectExistsRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server_bindings/remote_http_trace_server.py#L1332)

### <kbd>method</kbd> `evaluate_model`

```python theme={"system"}
evaluate_model(req: EvaluateModelReq) → EvaluateModelRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/pydantic/_internal/_validate_call.py#L1539)

### <kbd>method</kbd> `evaluation_create`

```python theme={"system"}
evaluation_create(req: EvaluationCreateReq) → EvaluationCreateRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/pydantic/_internal/_validate_call.py#L1591)

### <kbd>method</kbd> `evaluation_delete`

```python theme={"system"}
evaluation_delete(req: EvaluationDeleteReq) → EvaluationDeleteRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/pydantic/_internal/_validate_call.py#L1570)

### <kbd>method</kbd> `evaluation_list`

```python theme={"system"}
evaluation_list(req: EvaluationListReq) → Iterator[EvaluationReadRes]
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/pydantic/_internal/_validate_call.py#L1556)

### <kbd>method</kbd> `evaluation_read`

```python theme={"system"}
evaluation_read(req: EvaluationReadReq) → EvaluationReadRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/pydantic/_internal/_validate_call.py#L1675)

### <kbd>method</kbd> `evaluation_run_create`

```python theme={"system"}
evaluation_run_create(req: EvaluationRunCreateReq) → EvaluationRunCreateRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/pydantic/_internal/_validate_call.py#L1733)

### <kbd>method</kbd> `evaluation_run_delete`

```python theme={"system"}
evaluation_run_delete(req: EvaluationRunDeleteReq) → EvaluationRunDeleteRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/pydantic/_internal/_validate_call.py#L1750)

### <kbd>method</kbd> `evaluation_run_finish`

```python theme={"system"}
evaluation_run_finish(req: EvaluationRunFinishReq) → EvaluationRunFinishRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/pydantic/_internal/_validate_call.py#L1705)

### <kbd>method</kbd> `evaluation_run_list`

```python theme={"system"}
evaluation_run_list(req: EvaluationRunListReq) → Iterator[EvaluationRunReadRes]
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/pydantic/_internal/_validate_call.py#L1691)

### <kbd>method</kbd> `evaluation_run_read`

```python theme={"system"}
evaluation_run_read(req: EvaluationRunReadReq) → EvaluationRunReadRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server_bindings/remote_http_trace_server.py#L1335)

### <kbd>method</kbd> `evaluation_status`

```python theme={"system"}
evaluation_status(req: EvaluationStatusReq) → EvaluationStatusRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/pydantic/_internal/_validate_call.py#L1065)

### <kbd>method</kbd> `feedback_aggregate`

```python theme={"system"}
feedback_aggregate(req: FeedbackAggregateReq) → FeedbackAggregateRes
```

Query the feedback table for aggregate scores over time.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/pydantic/_internal/_validate_call.py#L1010)

### <kbd>method</kbd> `feedback_create`

```python theme={"system"}
feedback_create(req: FeedbackCreateReq) → FeedbackCreateRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server_bindings/remote_http_trace_server.py#L1031)

### <kbd>method</kbd> `feedback_create_batch`

```python theme={"system"}
feedback_create_batch(req: FeedbackCreateBatchReq) → FeedbackCreateBatchRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/pydantic/_internal/_validate_call.py#L1077)

### <kbd>method</kbd> `feedback_payload_schema`

```python theme={"system"}
feedback_payload_schema(
    req: FeedbackPayloadSchemaReq
) → FeedbackPayloadSchemaRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/pydantic/_internal/_validate_call.py#L1047)

### <kbd>method</kbd> `feedback_purge`

```python theme={"system"}
feedback_purge(req: FeedbackPurgeReq) → FeedbackPurgeRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/pydantic/_internal/_validate_call.py#L1041)

### <kbd>method</kbd> `feedback_query`

```python theme={"system"}
feedback_query(req: FeedbackQueryReq) → FeedbackQueryRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/pydantic/_internal/_validate_call.py#L1053)

### <kbd>method</kbd> `feedback_replace`

```python theme={"system"}
feedback_replace(req: FeedbackReplaceReq) → FeedbackReplaceRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/pydantic/_internal/_validate_call.py#L1059)

### <kbd>method</kbd> `feedback_stats`

```python theme={"system"}
feedback_stats(req: FeedbackStatsReq) → FeedbackStatsRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/utils/retry.py#L992)

### <kbd>method</kbd> `file_content_read`

```python theme={"system"}
file_content_read(req: FileContentReadReq) → FileContentReadRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/utils/retry.py#L979)

### <kbd>method</kbd> `file_create`

```python theme={"system"}
file_create(req: FileCreateReq) → FileCreateRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server_bindings/remote_http_trace_server.py#L1005)

### <kbd>method</kbd> `files_stats`

```python theme={"system"}
files_stats(req: FilesStatsReq) → FilesStatsRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server_bindings/remote_http_trace_server.py#L109)

### <kbd>classmethod</kbd> `from_env`

```python theme={"system"}
from_env(should_batch: bool = False) → Self
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server_bindings/remote_http_trace_server.py#L135)

### <kbd>method</kbd> `get`

```python theme={"system"}
get(url: str, *args: Any, **kwargs: Any) → Response
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server_bindings/remote_http_trace_server.py#L411)

### <kbd>method</kbd> `get_call_processor`

```python theme={"system"}
get_call_processor() → AsyncBatchProcessor | CallBatchProcessor | None
```

Custom method not defined on the formal TraceServerInterface to expose the underlying call processor. Should be formalized in a client-side interface.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server_bindings/remote_http_trace_server.py#L501)

### <kbd>method</kbd> `get_feedback_processor`

```python theme={"system"}
get_feedback_processor() → AsyncBatchProcessor | None
```

Custom method not defined on the formal TraceServerInterface to expose the underlying feedback processor. Should be formalized in a client-side interface.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server_bindings/remote_http_trace_server.py#L1125)

### <kbd>method</kbd> `image_create`

```python theme={"system"}
image_create(req: ImageGenerationCreateReq) → ImageGenerationCreateRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/pydantic/_internal/_validate_call.py#L1612)

### <kbd>method</kbd> `model_create`

```python theme={"system"}
model_create(req: ModelCreateReq) → ModelCreateRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/pydantic/_internal/_validate_call.py#L1658)

### <kbd>method</kbd> `model_delete`

```python theme={"system"}
model_delete(req: ModelDeleteReq) → ModelDeleteRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/pydantic/_internal/_validate_call.py#L1639)

### <kbd>method</kbd> `model_list`

```python theme={"system"}
model_list(req: ModelListReq) → Iterator[ModelReadRes]
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/pydantic/_internal/_validate_call.py#L1627)

### <kbd>method</kbd> `model_read`

```python theme={"system"}
model_read(req: ModelReadReq) → ModelReadRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server_bindings/remote_http_trace_server.py#L830)

### <kbd>method</kbd> `obj_add_tags`

```python theme={"system"}
obj_add_tags(req: ObjAddTagsReq) → ObjAddTagsRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/pydantic/_internal/_validate_call.py#L809)

### <kbd>method</kbd> `obj_create`

```python theme={"system"}
obj_create(req: ObjCreateReq) → ObjCreateRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server_bindings/remote_http_trace_server.py#L825)

### <kbd>method</kbd> `obj_delete`

```python theme={"system"}
obj_delete(req: ObjDeleteReq) → ObjDeleteRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/pydantic/_internal/_validate_call.py#L815)

### <kbd>method</kbd> `obj_read`

```python theme={"system"}
obj_read(req: ObjReadReq) → ObjReadRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server_bindings/remote_http_trace_server.py#L861)

### <kbd>method</kbd> `obj_remove_aliases`

```python theme={"system"}
obj_remove_aliases(req: ObjRemoveAliasesReq) → ObjRemoveAliasesRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server_bindings/remote_http_trace_server.py#L840)

### <kbd>method</kbd> `obj_remove_tags`

```python theme={"system"}
obj_remove_tags(req: ObjRemoveTagsReq) → ObjRemoveTagsRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server_bindings/remote_http_trace_server.py#L849)

### <kbd>method</kbd> `obj_set_aliases`

```python theme={"system"}
obj_set_aliases(req: ObjSetAliasesReq) → ObjSetAliasesRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/pydantic/_internal/_validate_call.py#L819)

### <kbd>method</kbd> `objs_query`

```python theme={"system"}
objs_query(req: ObjQueryReq) → ObjQueryRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/pydantic/_internal/_validate_call.py#L1348)

### <kbd>method</kbd> `op_create`

```python theme={"system"}
op_create(req: OpCreateReq) → OpCreateRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/pydantic/_internal/_validate_call.py#L1396)

### <kbd>method</kbd> `op_delete`

```python theme={"system"}
op_delete(req: OpDeleteReq) → OpDeleteRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/pydantic/_internal/_validate_call.py#L1375)

### <kbd>method</kbd> `op_list`

```python theme={"system"}
op_list(req: OpListReq) → Iterator[OpReadRes]
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/pydantic/_internal/_validate_call.py#L1363)

### <kbd>method</kbd> `op_read`

```python theme={"system"}
op_read(req: OpReadReq) → OpReadRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server_bindings/remote_http_trace_server.py#L626)

### <kbd>method</kbd> `otel_export`

```python theme={"system"}
otel_export(req: OTelExportReq) → OTelExportRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server_bindings/remote_http_trace_server.py#L146)

### <kbd>method</kbd> `post`

```python theme={"system"}
post(
    url: str,
    *args: Any,
    trace_id: str | None = None,
    **kwargs: Any
) → Response
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/pydantic/_internal/_validate_call.py#L1766)

### <kbd>method</kbd> `prediction_create`

```python theme={"system"}
prediction_create(req: PredictionCreateReq) → PredictionCreateRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/pydantic/_internal/_validate_call.py#L1818)

### <kbd>method</kbd> `prediction_delete`

```python theme={"system"}
prediction_delete(req: PredictionDeleteReq) → PredictionDeleteRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/pydantic/_internal/_validate_call.py#L1835)

### <kbd>method</kbd> `prediction_finish`

```python theme={"system"}
prediction_finish(req: PredictionFinishReq) → PredictionFinishRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/pydantic/_internal/_validate_call.py#L1795)

### <kbd>method</kbd> `prediction_list`

```python theme={"system"}
prediction_list(req: PredictionListReq) → Iterator[PredictionReadRes]
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/pydantic/_internal/_validate_call.py#L1783)

### <kbd>method</kbd> `prediction_read`

```python theme={"system"}
prediction_read(req: PredictionReadReq) → PredictionReadRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server_bindings/remote_http_trace_server.py#L1135)

### <kbd>method</kbd> `project_stats`

```python theme={"system"}
project_stats(req: ProjectStatsReq) → ProjectStatsRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server_bindings/remote_http_trace_server.py#L1140)

### <kbd>method</kbd> `project_ttl_settings_read`

```python theme={"system"}
project_ttl_settings_read(
    req: ProjectTTLSettingsReadReq
) → ProjectTTLSettingsReadRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server_bindings/remote_http_trace_server.py#L1150)

### <kbd>method</kbd> `project_ttl_settings_update`

```python theme={"system"}
project_ttl_settings_update(
    req: ProjectTTLSettingsUpdateReq
) → ProjectTTLSettingsUpdateRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/pydantic/_internal/_validate_call.py#L620)

### <kbd>method</kbd> `projects_info`

```python theme={"system"}
projects_info(req: ProjectsInfoReq) → list[ProjectsInfoRes]
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server_bindings/remote_http_trace_server.py#L159)

### <kbd>method</kbd> `put`

```python theme={"system"}
put(url: str, *args: Any, **kwargs: Any) → Response
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/pydantic/_internal/_validate_call.py#L973)

### <kbd>method</kbd> `refs_read_batch`

```python theme={"system"}
refs_read_batch(req: RefsReadBatchReq) → RefsReadBatchRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server_bindings/remote_http_trace_server.py#L1340)

### <kbd>method</kbd> `rescore`

```python theme={"system"}
rescore(req: RescoreReq) → RescoreRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/pydantic/_internal/_validate_call.py#L1851)

### <kbd>method</kbd> `score_create`

```python theme={"system"}
score_create(req: ScoreCreateReq) → ScoreCreateRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/pydantic/_internal/_validate_call.py#L1899)

### <kbd>method</kbd> `score_delete`

```python theme={"system"}
score_delete(req: ScoreDeleteReq) → ScoreDeleteRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/pydantic/_internal/_validate_call.py#L1878)

### <kbd>method</kbd> `score_list`

```python theme={"system"}
score_list(req: ScoreListReq) → Iterator[ScoreReadRes]
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/pydantic/_internal/_validate_call.py#L1866)

### <kbd>method</kbd> `score_read`

```python theme={"system"}
score_read(req: ScoreReadReq) → ScoreReadRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/pydantic/_internal/_validate_call.py#L1476)

### <kbd>method</kbd> `scorer_create`

```python theme={"system"}
scorer_create(req: ScorerCreateReq) → ScorerCreateRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/pydantic/_internal/_validate_call.py#L1522)

### <kbd>method</kbd> `scorer_delete`

```python theme={"system"}
scorer_delete(req: ScorerDeleteReq) → ScorerDeleteRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/pydantic/_internal/_validate_call.py#L1503)

### <kbd>method</kbd> `scorer_list`

```python theme={"system"}
scorer_list(req: ScorerListReq) → Iterator[ScorerReadRes]
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/pydantic/_internal/_validate_call.py#L1491)

### <kbd>method</kbd> `scorer_read`

```python theme={"system"}
scorer_read(req: ScorerReadReq) → ScorerReadRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/utils/retry.py#L612)

### <kbd>method</kbd> `server_info`

```python theme={"system"}
server_info() → ServerInfoRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server_bindings/remote_http_trace_server.py#L113)

### <kbd>method</kbd> `set_auth`

```python theme={"system"}
set_auth(auth: tuple[str, str]) → None
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server_bindings/remote_http_trace_server.py#L1322)

### <kbd>method</kbd> `source_datasets_query`

```python theme={"system"}
source_datasets_query(req: SourceDatasetsQueryReq) → SourceDatasetsQueryRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/pydantic/_internal/_validate_call.py#L892)

### <kbd>method</kbd> `table_create`

```python theme={"system"}
table_create(req: TableCreateReq) → TableCreateRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/pydantic/_internal/_validate_call.py#L950)

### <kbd>method</kbd> `table_create_from_digests`

```python theme={"system"}
table_create_from_digests(
    req: TableCreateFromDigestsReq
) → TableCreateFromDigestsRes
```

Create a table by specifying row digests instead of actual rows.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/pydantic/_internal/_validate_call.py#L930)

### <kbd>method</kbd> `table_query`

```python theme={"system"}
table_query(req: TableQueryReq) → TableQueryRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/pydantic/_internal/_validate_call.py#L944)

### <kbd>method</kbd> `table_query_stats`

```python theme={"system"}
table_query_stats(req: TableQueryStatsReq) → TableQueryStatsRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/pydantic/_internal/_validate_call.py#L962)

### <kbd>method</kbd> `table_query_stats_batch`

```python theme={"system"}
table_query_stats_batch(req: TableQueryStatsReq) → TableQueryStatsRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/pydantic/_internal/_validate_call.py#L936)

### <kbd>method</kbd> `table_query_stream`

```python theme={"system"}
table_query_stream(req: TableQueryReq) → Iterator[TableRowSchema]
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/pydantic/_internal/_validate_call.py#L898)

### <kbd>method</kbd> `table_update`

```python theme={"system"}
table_update(req: TableUpdateReq) → TableUpdateRes
```

Similar to `calls/batch_upsert`, we can dynamically adjust the payload size due to the property that table updates can be decomposed into a series of updates.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server_bindings/remote_http_trace_server.py#L872)

### <kbd>method</kbd> `tags_list`

```python theme={"system"}
tags_list(req: TagsListReq) → TagsListRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server_bindings/remote_http_trace_server.py#L1160)

### <kbd>method</kbd> `threads_query_stream`

```python theme={"system"}
threads_query_stream(req: ThreadsQueryReq) → Iterator[ThreadSchema]
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/pydantic/_internal/_validate_call.py#L783)

### <kbd>method</kbd> `trace_usage`

```python theme={"system"}
trace_usage(req: TraceUsageReq) → TraceUsageRes
```
