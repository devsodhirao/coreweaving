> ## Documentation Index
> Fetch the complete documentation index at: https://docs.coreweave.com/llms.txt
> Use this file to discover all available pages before exploring further.

# SessionInit

> TypeScript SDK reference

> [!WARNING]
>
> **Deprecated.** Use [ConversationInit](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/interfaces/conversationinit.md) instead.

> **SessionInit** = [`ConversationInit`](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/interfaces/conversationinit)

[GitHub source](https://github.com/wandb/weave/blob/7c9efdc9fe05ffcaf2430dd652ef9bc5b3ffdfaa/sdks/node/src/genai/conversation.ts#L193)
