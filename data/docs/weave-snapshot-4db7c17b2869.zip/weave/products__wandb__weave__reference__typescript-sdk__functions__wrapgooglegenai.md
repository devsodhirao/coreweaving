> ## Documentation Index
> Fetch the complete documentation index at: https://docs.coreweave.com/llms.txt
> Use this file to discover all available pages before exploring further.

# wrapGoogleGenAI

> TypeScript SDK reference

```ts theme={"system"}
wrapGoogleGenAI<T>(googleGenAI: T): T
```

[GitHub source](https://github.com/wandb/weave/blob/7c9efdc9fe05ffcaf2430dd652ef9bc5b3ffdfaa/sdks/node/src/integrations/googleGenAI.ts#L241)

## Type Parameters

**T** `extends object`

## Parameters

**googleGenAI** `T` *required*

## Returns

`T`
