> ## Documentation Index
> Fetch the complete documentation index at: https://docs.coreweave.com/llms.txt
> Use this file to discover all available pages before exploring further.

# GenAI Search



## OpenAPI

````yaml products/wandb/weave/reference/service-api/openapi.json POST /agents/search
openapi: 3.1.0
info:
  title: FastAPI
  version: 0.1.0
servers: []
security: []
paths:
  /agents/search:
    post:
      tags:
        - Agents
      summary: Genai Search
      operationId: genai_search_agents_search_post
      requestBody:
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/AgentSearchReq'
        required: true
      responses:
        '200':
          description: Successful Response
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/AgentSearchRes'
        '422':
          description: Validation Error
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/HTTPValidationError'
components:
  schemas:
    AgentSearchReq:
      properties:
        project_id:
          type: string
          title: Project Id
        query:
          type: string
          title: Query
          default: ''
        trace_id:
          anyOf:
            - type: string
            - type: 'null'
          title: Trace Id
        roles:
          anyOf:
            - items:
                type: string
                enum:
                  - ''
                  - user
                  - assistant
                  - system
                  - tool
                  - tool_call
                  - tool_result
              type: array
            - type: 'null'
          title: Roles
        conversation_id:
          anyOf:
            - type: string
            - type: 'null'
          title: Conversation Id
        agent_name:
          anyOf:
            - type: string
            - type: 'null'
          title: Agent Name
        provider_name:
          anyOf:
            - type: string
            - type: 'null'
          title: Provider Name
        request_model:
          anyOf:
            - type: string
            - type: 'null'
          title: Request Model
        truncate_content:
          type: boolean
          title: Truncate Content
          default: true
        started_after:
          anyOf:
            - type: string
              format: date-time
            - type: 'null'
          title: Started After
        started_before:
          anyOf:
            - type: string
              format: date-time
            - type: 'null'
          title: Started Before
        limit:
          type: integer
          maximum: 1000
          minimum: 0
          title: Limit
          default: 20
        offset:
          type: integer
          minimum: 0
          title: Offset
          default: 0
      type: object
      required:
        - project_id
      title: AgentSearchReq
      description: >-
        Query the `messages` table by content and/or span-level filters.


        Scans the `messages` table (one row per message occurrence, populated by
        an

        MV from spans) and returns matching span-level hits. Full-text search
        sets

        `query`; structured retrieval (e.g. all messages in a trace) leaves
        `query`

        empty and uses the filters below. The caller groups by conversation for
        the

        response shape.
    AgentSearchRes:
      properties:
        results:
          items:
            $ref: '#/components/schemas/AgentSearchConversationResult'
          type: array
          title: Results
        total_conversations:
          type: integer
          title: Total Conversations
          default: 0
      type: object
      required:
        - results
        - total_conversations
      title: AgentSearchRes
      description: Response from a full-text search across agent messages.
    HTTPValidationError:
      properties:
        detail:
          items:
            $ref: '#/components/schemas/ValidationError'
          type: array
          title: Detail
      type: object
      title: HTTPValidationError
    AgentSearchConversationResult:
      properties:
        conversation_id:
          type: string
          title: Conversation Id
        conversation_name:
          type: string
          title: Conversation Name
        agent_name:
          type: string
          title: Agent Name
        matched_messages:
          items:
            $ref: '#/components/schemas/AgentSearchMatchedMessage'
          type: array
          title: Matched Messages
        last_activity:
          type: string
          format: date-time
          title: Last Activity
      type: object
      required:
        - conversation_id
        - conversation_name
        - agent_name
        - matched_messages
        - last_activity
      title: AgentSearchConversationResult
      description: A conversation containing messages that matched the search query.
    ValidationError:
      properties:
        loc:
          items:
            anyOf:
              - type: string
              - type: integer
          type: array
          title: Location
        msg:
          type: string
          title: Message
        type:
          type: string
          title: Error Type
        input:
          title: Input
        ctx:
          type: object
          title: Context
      type: object
      required:
        - loc
        - msg
        - type
      title: ValidationError
    AgentSearchMatchedMessage:
      properties:
        span_id:
          type: string
          title: Span Id
        trace_id:
          type: string
          title: Trace Id
        role:
          anyOf:
            - type: string
              enum:
                - ''
                - user
                - assistant
                - system
                - tool
                - tool_call
                - tool_result
            - type: string
          title: Role
        content_preview:
          type: string
          title: Content Preview
        content_digest:
          type: string
          title: Content Digest
        started_at:
          type: string
          format: date-time
          title: Started At
      type: object
      required:
        - span_id
        - trace_id
        - role
        - content_preview
        - content_digest
        - started_at
      title: AgentSearchMatchedMessage
      description: A single message that matched the search query.

````