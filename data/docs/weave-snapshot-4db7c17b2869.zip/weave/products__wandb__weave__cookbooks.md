> ## Documentation Index
> Fetch the complete documentation index at: https://docs.coreweave.com/llms.txt
> Use this file to discover all available pages before exploring further.

# Overview

> Practical guides and examples for building with Weights & Biases Weave

Welcome to the W\&B Weave cookbook collection. These hands-on guides provide practical examples and best practices for building applications with Weave. Use this page to browse cookbooks by topic and jump into the example that matches what you're trying to build.

> **[Getting started](https://docs.coreweave.com/products/wandb/weave/cookbooks/Intro_to_Weave_Hello_Trace.md)**
>
> Start with Weave through practical, hands-on examples covering tracing and evaluation basics.

> **[Evaluations and datasets](https://docs.coreweave.com/products/wandb/weave/cookbooks/leaderboard_quickstart.md)**
>
> Learn how to create evaluations, work with datasets, and build leaderboards for model comparison.

> **[Models and prompts](https://docs.coreweave.com/products/wandb/weave/cookbooks/Models_and_Weave_Integration_Demo.md)**
>
> Explore model management, prompt engineering, and optimization techniques with real-world examples.

> **[Advanced topics](https://docs.coreweave.com/products/wandb/weave/cookbooks/multi-agent-structured-output.md)**
>
> Explore complex use cases including multi-agent systems, code generation, and specialized pipelines.

> **[Production and monitoring](https://docs.coreweave.com/products/wandb/weave/cookbooks/online_monitoring.md)**
>
> Implement production-ready patterns for monitoring, feedback collection, and safety guardrails.

> **[API and integration](https://docs.coreweave.com/products/wandb/weave/cookbooks/weave_via_service_api.md)**
>
> Learn how to integrate Weave using the service API and connect with external systems.

## Featured cookbooks

The following sections list featured cookbooks grouped by topic, from getting started through production and API integration.

### Getting started

* [Hello Trace](https://docs.coreweave.com/products/wandb/weave/cookbooks/Intro_to_Weave_Hello_Trace.md) - Take your first steps with Weave tracing.
* [Hello Eval](https://docs.coreweave.com/products/wandb/weave/cookbooks/Intro_to_Weave_Hello_Eval.md) - Get introduced to evaluation concepts.

### Evaluations and datasets

* [Leaderboard Quickstart](https://docs.coreweave.com/products/wandb/weave/cookbooks/leaderboard_quickstart.md) - Build model comparison leaderboards.
* [Hugging Face Datasets](https://docs.coreweave.com/products/wandb/weave/cookbooks/hf_dataset_evals.md) - Evaluate models using Hugging Face datasets.
* [Import from CSV](https://docs.coreweave.com/products/wandb/weave/cookbooks/import_from_csv.md) - Load and work with CSV data.

### Models and prompts

* [Models and Weave Integration](https://docs.coreweave.com/products/wandb/weave/cookbooks/Models_and_Weave_Integration_Demo.md) - Integrate models with Weave.
* [Chain of Density](https://docs.coreweave.com/products/wandb/weave/cookbooks/chain_of_density.md) - Apply advanced prompting techniques.
* [DSPy Prompt Optimization](https://docs.coreweave.com/products/wandb/weave/cookbooks/dspy_prompt_optimization.md) - Optimize prompts programmatically.
* [NotDiamond Custom Routing](https://docs.coreweave.com/products/wandb/weave/cookbooks/notdiamond_custom_routing.md) - Implement intelligent model routing.

### Advanced topics

* [Multi-Agent Structured Output](https://docs.coreweave.com/products/wandb/weave/cookbooks/multi-agent-structured-output.md) - Build complex multi-agent systems.
* [Code Generation](https://docs.coreweave.com/products/wandb/weave/cookbooks/codegen.md) - Build code generation pipelines.
* [OCR Pipeline](https://docs.coreweave.com/products/wandb/weave/cookbooks/ocr-pipeline.md) - Process documents with OCR.
* [Audio Processing](https://docs.coreweave.com/products/wandb/weave/cookbooks/audio_with_weave.md) - Work with audio data in Weave.

### Production and monitoring

* [Online Monitoring](https://docs.coreweave.com/products/wandb/weave/cookbooks/online_monitoring.md) - Monitor systems in real time.
* [Production Feedback](https://docs.coreweave.com/products/wandb/weave/cookbooks/feedback_prod.md) - Collect and analyze user feedback.
* [Scorers as Guardrails](https://docs.coreweave.com/products/wandb/weave/cookbooks/scorers_as_guardrails.md) - Implement safety measures.
* [Custom Model Costs](https://docs.coreweave.com/products/wandb/weave/cookbooks/custom_model_cost.md) - Track and optimize costs.
* [PII Protection](https://docs.coreweave.com/products/wandb/weave/cookbooks/pii.md) - Handle sensitive data safely.

### API and integration

* [Service API Usage](https://docs.coreweave.com/products/wandb/weave/cookbooks/weave_via_service_api.md) - Integrate directly with the service API.
