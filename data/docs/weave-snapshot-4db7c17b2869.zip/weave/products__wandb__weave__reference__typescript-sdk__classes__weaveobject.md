> ## Documentation Index
> Fetch the complete documentation index at: https://docs.coreweave.com/llms.txt
> Use this file to discover all available pages before exploring further.

# WeaveObject

> TypeScript SDK reference

[GitHub source](https://github.com/wandb/weave/blob/7c9efdc9fe05ffcaf2430dd652ef9bc5b3ffdfaa/sdks/node/src/weaveObject.ts#L71)

## Extended by

* [`Dataset`](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/classes/dataset)
* [`Evaluation`](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/classes/evaluation)

## Constructor

> **new WeaveObject**(`_baseParameters`): `WeaveObject`

### Parameters

**\_baseParameters** `object` *required*

**properties**

**description** `string`

**name** `string`

### Returns

`WeaveObject`

## Properties

### \_\_savedRef

> `optional` **\_\_savedRef**: [`ObjectRef`](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/classes/objectref) | `Promise`\<[`ObjectRef`](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/classes/objectref)>

## Accessors

### description

#### Get Signature

> **get** **description**(): `string` | `undefined`

##### Returns

`string` | `undefined`

***

### name

#### Get Signature

> **get** **name**(): `string`

##### Returns

`string`

## Methods

### saveAttrs()

> **saveAttrs**(): `object`

#### Returns

`object`
