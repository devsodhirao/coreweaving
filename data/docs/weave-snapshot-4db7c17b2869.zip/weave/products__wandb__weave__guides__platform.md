> ## Documentation Index
> Fetch the complete documentation index at: https://docs.coreweave.com/llms.txt
> Use this file to discover all available pages before exploring further.

# Deployment options and security features

> Learn about Weave's deployment options, IAM management, and data security features.

This page describes how to deploy Weave, manage access, and protect data, so you can choose the deployment option and security controls that fit your organization's needs.

Weave is available on the following deployment options:

* **[W\&B Multi-tenant Cloud](https://docs.coreweave.com/products/wandb/platform/hosting/hosting-options/multi_tenant_cloud.md):** A multi-tenant, fully managed platform deployed in the Google Cloud Platform (Google Cloud) account of Weights & Biases in a North America region.
* **[W\&B Dedicated Cloud](https://docs.coreweave.com/products/wandb/platform/hosting/hosting-options/dedicated-cloud.md):** Generally available on AWS, Google Cloud, and Azure.
* **[Self-Managed instances](https://docs.coreweave.com/products/wandb/weave/guides/platform/weave-self-managed.md):** For teams that prefer to host Weave independently, your CoreWeave account representatives provide guidance to evaluate deployment options. Self-managed instances can use [ingest sampling](https://docs.coreweave.com/products/wandb/weave/guides/platform/ingest-sampling.md) to control costs at high trace volume.

## Identity and access management

Use the identity and access management capabilities for secure authentication and effective authorization in your [Forge team](https://docs.coreweave.com/products/wandb/platform/hosting/iam/org_team_struct.md#organization). The following capabilities are available for Weave users depending on your deployment option and [pricing plan](https://coreweave.com/forge-pricing):

* **Authenticate using single sign-on (SSO):** Options include public identity providers like Google and GitHub, and enterprise providers such as Okta and Azure Active Directory, [using OIDC](https://docs.coreweave.com/products/wandb/platform/hosting/iam/sso.md).
* **[Team-based logical separation](https://docs.coreweave.com/products/wandb/platform/app/settings-page/teams.md):** Each team may correspond to a business unit, department, or project team within your organization.
* **Use Weights & Biases projects to organize initiatives:** Organize initiatives within teams and configure the required [visibility scope](https://docs.coreweave.com/products/wandb/platform/hosting/iam/access-management/restricted-projects.md), including the `restricted` scope for sensitive collaborations.
* **Role-based access control:** Configure access at the [team](https://docs.coreweave.com/products/wandb/platform/hosting/iam/access-management/restricted-projects.md#assign-project-level-role-to-a-user) or [project](https://docs.coreweave.com/products/wandb/platform/hosting/iam/access-management/restricted-projects.md#assign-project-level-role-to-a-user) level to ensure users access data on a need-to-know basis.
* **Scoped service accounts:** Automate generative AI workflows using service accounts scoped to your organization or team.
* **[SCIM API and Python SDK](https://docs.coreweave.com/products/wandb/platform/hosting/iam/automate_iam.md):** Manage users and teams with the SCIM API and the Python SDK.

## Data security

The data security protections available to you depend on your deployment option.

* **Multi-tenant Cloud:** Weights & Biases stores data for all Weave users in a shared ClickHouse Cloud cluster, encrypted with cloud-native encryption. Shared compute services process the data and ensure isolation through a security context that comprises your Weights & Biases organization, team, and project.

* **Dedicated Cloud:** Weights & Biases stores data in a unique ClickHouse Cloud cluster in the cloud and region of your choice. A unique compute environment processes the data, with the following additional protections:
  * **[IP allowlisting](https://docs.coreweave.com/products/wandb/platform/hosting/data-security/ip-allowlisting.md):** Authorize access to your instance from specific IP addresses. This is an optional capability.
  * **[Private connectivity](https://docs.coreweave.com/products/wandb/platform/hosting/data-security/private-connectivity.md):** Route data securely through the cloud provider's private network. This is an optional capability.
  * **[Data encryption](https://docs.coreweave.com/products/wandb/platform/hosting/data-security/data-encryption.md):** Weights & Biases encrypts data at rest using a unique encryption key managed by Weights & Biases.
  * **ClickHouse cluster security:** Weights & Biases connects to the unique ClickHouse Cloud cluster for your Dedicated Cloud instance over the cloud provider's private network. Weights & Biases also encrypts the cluster with a unique encryption key managed by Weights & Biases and uses ClickHouse's file-level encryption.

> [!WARNING]
>
> This page is for the W\&B platform secure storage connector or BYOB and does not apply to Weave. To render images and video that live in your own cloud bucket in Weave without importing the bytes into Weave, see the [Weave BYOB reference](https://docs.coreweave.com/products/wandb/weave/guides/tracking/byob-references.md#reference-media-in-your-own-bucket-byob-using-weave-op).

## Maintenance

If you're using Weave on Multi-tenant Cloud or Dedicated Cloud, you avoid the overhead and costs of provisioning, operating, and maintaining the Weights & Biases platform, because Weights & Biases fully manages it for you.

## Compliance

Security controls for both Multi-tenant Cloud and Dedicated Cloud are periodically audited internally and externally. Both platforms are SOC 2 Type II compliant. Dedicated Cloud is also HIPAA-compliant for organizations managing PHI data while building generative AI applications.
