> ## Documentation Index
> Fetch the complete documentation index at: https://docs.coreweave.com/llms.txt
> Use this file to discover all available pages before exploring further.

# Feedback Stats

> Return aggregated feedback statistics over time buckets.



## OpenAPI

````yaml products/wandb/weave/reference/service-api/openapi.json POST /feedback/stats
openapi: 3.1.0
info:
  title: FastAPI
  version: 0.1.0
servers: []
security: []
paths:
  /feedback/stats:
    post:
      tags:
        - Feedback
      summary: Feedback Stats
      description: Return aggregated feedback statistics over time buckets.
      operationId: feedback_stats_feedback_stats_post
      requestBody:
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/FeedbackStatsReq'
        required: true
      responses:
        '200':
          description: Successful Response
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/FeedbackStatsRes'
        '422':
          description: Validation Error
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/HTTPValidationError'
components:
  schemas:
    FeedbackStatsReq:
      properties:
        project_id:
          type: string
          title: Project Id
        start:
          type: string
          format: date-time
          title: Start
          description: Inclusive start time (UTC, ISO 8601).
        end:
          anyOf:
            - type: string
              format: date-time
            - type: 'null'
          title: End
          description: Exclusive end time (UTC, ISO 8601). Defaults to now if omitted.
        feedback_type:
          anyOf:
            - type: string
            - type: 'null'
          title: Feedback Type
          description: Filter by feedback_type.
        trigger_ref:
          anyOf:
            - type: string
            - type: 'null'
          title: Trigger Ref
          description: Filter by trigger_ref (exact or prefix match for all-versions).
        granularity:
          anyOf:
            - type: integer
            - type: 'null'
          title: Granularity
          description: >-
            Bucket size in seconds. If omitted, auto-selected based on time
            range.
        timezone:
          type: string
          title: Timezone
          description: IANA timezone for bucket alignment.
          default: UTC
        metrics:
          items:
            $ref: '#/components/schemas/FeedbackMetricSpec'
          type: array
          title: Metrics
          description: Metrics to aggregate from payload_dump.
      type: object
      required:
        - project_id
        - start
      title: FeedbackStatsReq
      description: Request for aggregated feedback statistics over time buckets.
    FeedbackStatsRes:
      properties:
        start:
          type: string
          format: date-time
          title: Start
          description: >-
            Resolved start time (always UTC, regardless of the requested
            timezone).
        end:
          type: string
          format: date-time
          title: End
          description: >-
            Resolved end time (always UTC, regardless of the requested
            timezone).
        granularity:
          type: integer
          title: Granularity
          description: Bucket size used (in seconds)
        timezone:
          type: string
          title: Timezone
          description: Timezone used for bucket alignment
        buckets:
          items:
            additionalProperties: true
            type: object
          type: array
          title: Buckets
          description: >-
            Time-bucketed aggregations. Each dict has 'timestamp' (ISO string),
            'count' (int), and '{agg}_{slug}' keys for each requested
            metric+aggregation.
        window_stats:
          anyOf:
            - additionalProperties:
                additionalProperties:
                  anyOf:
                    - type: number
                    - type: 'null'
                type: object
              type: object
            - type: 'null'
          title: Window Stats
          description: >-
            Aggregations over the full query window, keyed by metric slug (e.g.
            'output_score'). Each value maps agg name to result.
      type: object
      required:
        - start
        - end
        - granularity
        - timezone
      title: FeedbackStatsRes
      description: Response with time-series feedback statistics.
    HTTPValidationError:
      properties:
        detail:
          items:
            $ref: '#/components/schemas/ValidationError'
          type: array
          title: Detail
      type: object
      title: HTTPValidationError
    FeedbackMetricSpec:
      properties:
        json_path:
          type: string
          title: Json Path
          description: Dot path into payload_dump (e.g. 'output', 'output.score').
        value_type:
          type: string
          enum:
            - numeric
            - boolean
            - categorical
          title: Value Type
          description: >-
            Type of value at path. numeric: avg/min/max; boolean:
            count_true/count_false.
          default: numeric
        aggregations:
          items:
            $ref: '#/components/schemas/AggregationType'
          type: array
          title: Aggregations
          description: >-
            Aggregation functions to compute. If empty, defaults are chosen
            based on value_type: numeric->avg/min/max,
            boolean->count_true/count_false.
        percentiles:
          items:
            type: number
          type: array
          title: Percentiles
          description: >-
            Percentile values to compute (0–100), e.g. [5, 50, 95]. Only
            applicable for numeric value_type fields; ignored for
            boolean/categorical.
      type: object
      required:
        - json_path
      title: FeedbackMetricSpec
      description: Specification for a feedback payload metric to aggregate.
    ValidationError:
      properties:
        loc:
          items:
            anyOf:
              - type: string
              - type: integer
          type: array
          title: Location
        msg:
          type: string
          title: Message
        type:
          type: string
          title: Error Type
        input:
          title: Input
        ctx:
          type: object
          title: Context
      type: object
      required:
        - loc
        - msg
        - type
      title: ValidationError
    AggregationType:
      type: string
      enum:
        - sum
        - avg
        - min
        - max
        - count
        - count_true
        - count_false
      title: AggregationType
      description: Aggregation functions supported by feedback and call stats metrics.

````