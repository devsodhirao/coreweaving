> ## Documentation Index
> Fetch the complete documentation index at: https://docs.coreweave.com/llms.txt
> Use this file to discover all available pages before exploring further.

# startSubagent

> TypeScript SDK reference

```ts theme={"system"}
startSubagent(opts: SubAgentInit): SubAgent
```

[GitHub source](https://github.com/wandb/weave/blob/7c9efdc9fe05ffcaf2430dd652ef9bc5b3ffdfaa/sdks/node/src/genai/api.ts#L137)

Start a SubAgent span. Same parent-resolution rules as `startTool`.

## Parameters

**opts** `SubAgentInit` *required*

See [`SubAgentInit`](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/interfaces/subagentinit).

## Returns

[`SubAgent`](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/interfaces/subagent)

## Examples

```ts twoslash theme={"system"}
// @noErrors
weave.startSubagent({name: 'critic'});
```

```ts twoslash theme={"system"}
// @noErrors
weave.startSubagent({
  name: 'critic',
  model: 'gpt-4o',
  systemInstructions: ['Critique the proposed plan.'],
  startTime: new Date('2026-05-29T10:00:00.000Z'),
});
```
