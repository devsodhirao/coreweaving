> ## Documentation Index
> Fetch the complete documentation index at: https://docs.coreweave.com/llms.txt
> Use this file to discover all available pages before exploring further.

# Quickstart: Instrument and trace functions

> Get started with W&B Weave by adding tracing to your LLM application to debug and monitor model interactions.

[Try in Colab](https://colab.research.google.com/github/wandb/examples/blob/main/colabs/weave/quickstart.ipynb)

[GitHub source](https://github.com/wandb/examples/blob/main/colabs/weave/quickstart.ipynb)

Learn how to track LLM calls with Weave by adding tracing to your code. This quickstart walks you through tracing a request to OpenAI and viewing the results in the Weights & Biases UI. It's for developers who are new to Weave and want to instrument an LLM application for debugging and monitoring.

## What you'll learn

This guide shows you how to:

* Import and configure Weave in your code.
* Use the `weave.op` decorator to track your code.
* View traces in the Weights & Biases UI.

## Prerequisites

* A [CoreWeave Forge account](https://id.coreweave.com/signup)
* Python 3.10+ or Node.js 18+
* Required packages installed:
  * **Python**: `pip install weave openai`
  * **TypeScript**: `npm install weave openai`
* An [OpenAI API key](https://platform.openai.com/api-keys) set as an environment variable.

## Log a trace to a new project

In this section, you instrument a small application so that Weave can record its inputs, outputs, and code. To begin tracking your code and logging traces to Weave:

1. Import the `weave` library into your code.
2. Call `weave.init('your_wb_team/project_name')` in your code to send tracking information to your Forge [team](https://docs.coreweave.com/products/wandb/platform/app/settings-page/teams.md) and [project](https://docs.coreweave.com/products/wandb/platform/hosting/iam/org_team_struct.md#project). If you don't set a team, Weave sends the traces to your [default team](https://docs.coreweave.com/products/wandb/platform/app/settings-page/user-settings.md#default-team). If the specified project doesn't exist in your team, Weave creates it.
3. Add the [`@weave.op()` decorator](https://docs.coreweave.com/products/wandb/weave/guides/tracking/ops) to functions you want to track. Although Weave automatically tracks calls to supported LLMs, the decorator lets you track the inputs, outputs, and code of specific functions. The decorator uses the following syntax in TypeScript: `weave.op(your_function)`.

The following example code sends a request to OpenAI (requires an [OpenAI API key](https://platform.openai.com/docs/quickstart)), and Weave records the request's tracing information. The request asks the OpenAI model to extract dinosaur names from the input and identify each dinosaur's diet (herbivore or carnivore).

The following example code tracks your first project with Weave:

**Python**

```python lines {1-2,7-8,27-28} theme={"system"}
# Imports the Weave library
import weave
from openai import OpenAI

client = OpenAI()

# Weave automatically tracks the inputs, outputs and code of this function
@weave.op()
def extract_dinos(sentence: str) -> dict:
    response = client.chat.completions.create(
        model="gpt-4o",
        messages=[
            {
                "role": "system",
                "content": """In JSON format extract a list of `dinosaurs`, with their `name`,
their `common_name`, and whether its `diet` is a herbivore or carnivore"""
            },
            {
                "role": "user",
                "content": sentence
            }
            ],
            response_format={ "type": "json_object" }
        )
    return response.choices[0].message.content

# Initializes Weave, and sets the team and project to log data to
weave.init('your-team/traces-quickstart')

sentence = """I watched as a Tyrannosaurus rex (T. rex) chased after a Triceratops (Trike), \
both carnivore and herbivore locked in an ancient dance. Meanwhile, a gentle giant \
Brachiosaurus (Brachi) calmly munched on treetops, blissfully unaware of the chaos below."""

result = extract_dinos(sentence)
print(result)
```

**TypeScript**

```typescript twoslash lines {1-2,7-8,20,24-25} theme={"system"}
// @noErrors
// Imports the Weave library
import * as weave from 'weave';
import OpenAI from 'openai';

const openai = new OpenAI();

// Weave automatically tracks the inputs, outputs and code of this function  
async function extractDinos(input: string) {
  const response = await openai.chat.completions.create({
    model: 'gpt-4o',
    messages: [
      {
        role: 'user',
        content: `In JSON format extract a list of 'dinosaurs', with their 'name', their 'common_name', and whether its 'diet' is a herbivore or carnivore: ${input}`,
      },
    ],
  });
  return response.choices[0].message.content;
}
const extractDinosOp = weave.op(extractDinos);

async function main() {

  // Initializes Weave, and sets the team and project to log data to
  await weave.init('your-team/traces-quickstart');

  const result = await extractDinosOp(
    'I watched as a Tyrannosaurus rex (T. rex) chased after a Triceratops (Trike), both carnivore and herbivore locked in an ancient dance. Meanwhile, a gentle giant Brachiosaurus (Brachi) calmly munched on treetops, blissfully unaware of the chaos below.'
  );
  console.log(result);
}

main();

```

When you call the `extract_dinos` function, Weave outputs links in the terminal to view your traces. The output looks like this:

```text theme={"system"}
weave:  $ pip install weave --upgrade
weave: Logged in as Weights & Biases user: example-username.
weave: View Weave data at https://wandb.ai/your-team/traces-quickstart/weave
weave: 🍩 https://wandb.ai/your-team/traces-quickstart/r/call/019ae171-7f32-7c96-8b42-931a32f900b7
{
  "dinosaurs": [
    {
      "name": "Tyrannosaurus rex",
      "common_name": "T. rex",
      "diet": "carnivore"
    },
    {
      "name": "Triceratops",
      "common_name": "Trike",
      "diet": "herbivore"
    },
    {
      "name": "Brachiosaurus",
      "common_name": "Brachi",
      "diet": "herbivore"
    }
  ]
}
```

## See traces of your application in your project

Now that your code has produced a trace, you can inspect it in the Weights & Biases UI. Click the link in your terminal or paste it into your browser to open the Weights & Biases UI. In the **Traces** panel of the Weights & Biases UI, click the trace to see its data, such as its input, output, latency, and token usage.

![The trace for the extract\_dinos function in Forge, showing the call tree with cost and latency, and the call's input and output.](https://mintcdn.com/coreweave-dbfa0e8d/3Dv_sw2eg8feUJlx/products/wandb/weave/_media/tutorial_trace_1.png?fit=max\&auto=format\&n=3Dv_sw2eg8feUJlx\&q=85\&s=a75c0233212fddd3f500215ca4532035)

You have now logged and viewed your first Weave trace.

## Learn more about traces

* Learn how to [decorate your functions and retrieve call information](https://docs.coreweave.com/products/wandb/weave/guides/tracking/tracing.md).
* Try the [Playground](https://docs.coreweave.com/products/wandb/weave/guides/tools/playground.md) to test different models on logged traces.
* [Explore integrations](https://docs.coreweave.com/products/wandb/weave/guides/integrations.md). Weave automatically tracks calls made to OpenAI, Anthropic, and many more LLM libraries. If your LLM library isn't one of the Weave integrations, you can track calls to other LLM libraries or frameworks by wrapping them with `@weave.op()`.

## Next steps

[Get started evaluating your app](https://docs.coreweave.com/products/wandb/weave/tutorial-eval.md) and then see how to [evaluate a RAG application](https://docs.coreweave.com/products/wandb/weave/tutorial-rag.md).
