> ## Documentation Index
> Fetch the complete documentation index at: https://docs.coreweave.com/llms.txt
> Use this file to discover all available pages before exploring further.

# wrapClaudeAgentSdk

> TypeScript SDK reference

```ts theme={"system"}
wrapClaudeAgentSdk<T>(sdk: T): T
```

[GitHub source](https://github.com/wandb/weave/blob/7c9efdc9fe05ffcaf2430dd652ef9bc5b3ffdfaa/sdks/node/src/integrations/claudeAgentSdk.ts#L232)

Manually instrument the `@anthropic-ai/claude-agent-sdk` module.

Reach for this when automatic instrumentation doesn't apply — e.g. a bundler
whose module loading the CJS/ESM hooks can't observe, or an import path they
don't cover. Requires `@anthropic-ai/claude-agent-sdk` >= 0.3.178. Returns a
view of the module whose `query` export is traced; use the returned object
rather than the original import (the SDK's `query` is a getter-only export,
so the original binding can't be patched in place):

## Type Parameters

**T**

## Parameters

**sdk** `T` *required*

## Returns

`T`

## Example

```ts twoslash theme={"system"}
// @noErrors
import * as claudeAgentSdk from '@anthropic-ai/claude-agent-sdk';
import { wrapClaudeAgentSdk } from 'weave';

const { query } = wrapClaudeAgentSdk(claudeAgentSdk);
for await (const message of query({ prompt: 'hi' })) {
  // ...traced
}
```
