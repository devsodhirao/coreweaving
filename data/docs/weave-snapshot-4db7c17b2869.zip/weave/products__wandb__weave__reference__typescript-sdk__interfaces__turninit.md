> ## Documentation Index
> Fetch the complete documentation index at: https://docs.coreweave.com/llms.txt
> Use this file to discover all available pages before exploring further.

# TurnInit

> TypeScript SDK reference

[GitHub source](https://github.com/wandb/weave/blob/7c9efdc9fe05ffcaf2430dd652ef9bc5b3ffdfaa/sdks/node/src/genai/turn.ts#L32)

## Extends

* `SpanInitBase`

## Properties

### agentDescription

> `optional` **agentDescription**: `string`

***

### agentId

> `optional` **agentId**: `string`

***

### agentName

> `optional` **agentName**: `string`

***

### agentVersion

> `optional` **agentVersion**: `string`

***

### attributes

> `optional` **attributes**: `Attributes`

Custom attributes set on this turn and passed to every child span.
Normally seeded from the conversation via `startConversation({ attributes })`;
set here for a rootless `startTurn({ attributes })` with no conversation.

***

### model

> `optional` **model**: `string`

***

### startTime

> `optional` **startTime**: `TimeInput`

#### Inherited from

`SpanInitBase.startTime`

***

### systemInstructions

> `optional` **systemInstructions**: `string`\[]

***

### userMessage

> `optional` **userMessage**: `string`
