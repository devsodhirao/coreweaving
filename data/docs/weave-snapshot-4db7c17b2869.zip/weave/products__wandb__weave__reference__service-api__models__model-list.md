> ## Documentation Index
> Fetch the complete documentation index at: https://docs.coreweave.com/llms.txt
> Use this file to discover all available pages before exploring further.

# Model List

> List model objects.



## OpenAPI

````yaml products/wandb/weave/reference/service-api/openapi.json GET /v2/{entity}/{project}/models
openapi: 3.1.0
info:
  title: FastAPI
  version: 0.1.0
servers: []
security: []
paths:
  /v2/{entity}/{project}/models:
    get:
      tags:
        - Models
      summary: Model List
      description: List model objects.
      operationId: model_list_v2__entity___project__models_get
      parameters:
        - name: entity
          in: path
          required: true
          schema:
            type: string
            title: Entity
        - name: project
          in: path
          required: true
          schema:
            type: string
            title: Project
        - name: limit
          in: query
          required: false
          schema:
            anyOf:
              - type: integer
              - type: 'null'
            description: Maximum number of models to return
            title: Limit
          description: Maximum number of models to return
        - name: offset
          in: query
          required: false
          schema:
            anyOf:
              - type: integer
              - type: 'null'
            description: Number of models to skip
            title: Offset
          description: Number of models to skip
      responses:
        '200':
          description: Stream of data in JSONL format
          content:
            application/x-ndjson:
              schema:
                $ref: '#/components/schemas/ModelReadRes'
        '422':
          description: Validation Error
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/HTTPValidationError'
components:
  schemas:
    ModelReadRes:
      properties:
        object_id:
          type: string
          title: Object Id
          description: The model ID
        digest:
          type: string
          title: Digest
          description: The digest of the model
        version_index:
          type: integer
          title: Version Index
          description: The version index of the object
        created_at:
          type: string
          format: date-time
          title: Created At
          description: When the model was created
        name:
          type: string
          title: Name
          description: The name of the model
        description:
          anyOf:
            - type: string
            - type: 'null'
          title: Description
          description: Description of the model
        source_code:
          type: string
          title: Source Code
          description: The source code of the model
        attributes:
          anyOf:
            - additionalProperties: true
              type: object
            - type: 'null'
          title: Attributes
          description: Additional attributes stored with the model
      type: object
      required:
        - object_id
        - digest
        - version_index
        - created_at
        - name
        - source_code
      title: ModelReadRes
    HTTPValidationError:
      properties:
        detail:
          items:
            $ref: '#/components/schemas/ValidationError'
          type: array
          title: Detail
      type: object
      title: HTTPValidationError
    ValidationError:
      properties:
        loc:
          items:
            anyOf:
              - type: string
              - type: integer
          type: array
          title: Location
        msg:
          type: string
          title: Message
        type:
          type: string
          title: Error Type
        input:
          title: Input
        ctx:
          type: object
          title: Context
      type: object
      required:
        - loc
        - msg
        - type
      title: ValidationError

````