> ## Documentation Index
> Fetch the complete documentation index at: https://docs.coreweave.com/llms.txt
> Use this file to discover all available pages before exploring further.

# MessagePart

> TypeScript SDK reference

> **MessagePart** = \{ `content`: `string`; `type`: `"text"`; } | \{ `content`: `string`; `type`: `"reasoning"`; } | \{ `arguments?`: `string`; `toolCallId`: `string`; `toolName`: `string`; `type`: `"tool_call"`; } | \{ `result?`: `string`; `toolCallId`: `string`; `type`: `"tool_result"`; } | \{ `fileId`: `string`; `mimeType?`: `string`; `modality`: [`Modality`](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/type-aliases/modality); `type`: `"file"`; } | \{ `content`: `string`; `mimeType`: `string`; `modality`: [`Modality`](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/type-aliases/modality); `type`: `"blob"`; } | \{ `modality`: [`Modality`](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/type-aliases/modality); `type`: `"uri"`; `uri`: `string`; }

[GitHub source](https://github.com/wandb/weave/blob/7c9efdc9fe05ffcaf2430dd652ef9bc5b3ffdfaa/sdks/node/src/genai/types.ts#L35)
