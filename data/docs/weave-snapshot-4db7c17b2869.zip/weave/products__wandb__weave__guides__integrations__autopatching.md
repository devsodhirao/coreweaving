> ## Documentation Index
> Fetch the complete documentation index at: https://docs.coreweave.com/llms.txt
> Use this file to discover all available pages before exploring further.

# Control automatic LLM call tracking

> Control how Weave automatically records calls to OpenAI, Anthropic, and other LLM libraries

If you use LLM provider libraries (such as OpenAI, Anthropic, Cohere, or Mistral) in your application, autopatching is how Weave traces your LLM calls for you. When you call `weave.init()`, Weave intercepts (patches) supported LLM client libraries. Your application code stays unchanged. You use the provider SDK as usual, and Weave records each request as a Weave Call.

This page describes when and how to change that behavior: turn off automatic tracking, limit it to specific providers, or post-process inputs and outputs (for example, to redact PII).

## Default behavior

By default, Weave automatically patches and tracks calls to common LLM libraries such as `openai` and `anthropic`. Call `weave.init(...)` at the start of your program and use those libraries normally. Their calls appear in your project's Traces.

## Configure autopatching

The following sections describe how to enable, disable, or fine-tune autopatching in Python and TypeScript. Choose the tab for your SDK.

**Python**

> [!WARNING]
>
> The `autopatch_settings` argument is deprecated. Use `implicitly_patch_integrations=False` to disable implicit patching, or call specific patch functions like `patch_openai(settings={...})` to configure settings per integration.

Weave provides automatic implicit patching for all supported integrations by default.

Implicit patching (automatic): Weave automatically patches libraries regardless of when you import them.

```python lines theme={"system"}
# Option 1: Import before weave.init()
import openai
import weave
weave.init('your-team-name/your-project-name')  # OpenAI is automatically patched.

# Option 2: Import after weave.init()
import weave
weave.init('your-team-name/your-project-name')
import anthropic  # Automatically patched via import hook.
```

Disabling implicit patching: You can turn off automatic patching if you prefer explicit control.

```python lines theme={"system"}
import weave

# Option 1: Via settings parameter
weave.init('your-team-name/your-project-name', settings={'implicitly_patch_integrations': False})

# Option 2: Via environment variable
# Set WEAVE_IMPLICITLY_PATCH_INTEGRATIONS=false before running your script

# When implicit patching is disabled, you must explicitly patch integrations
import openai
weave.patch_openai()  # Now required for OpenAI tracing
```

Explicit patching (manual): You can explicitly patch integrations for fine-grained control. This is useful when implicit patching is off or when you only want to trace a subset of providers.

```python lines theme={"system"}
import weave
weave.init('your-team-name/your-project-name')
weave.integrations.patch_openai()  # Enable OpenAI tracing
weave.integrations.patch_anthropic()  # Enable Anthropic tracing
```

After you run the preceding code, Weave only traces the providers you explicitly patched.

### Post-process inputs and outputs

In addition to turning patching on or off, you can transform what Weave records for each call. You can customize how Weave records inputs and outputs (for example, to redact PII or secrets) by passing settings to the patch function:

```python lines theme={"system"}
import weave.integrations

def redact_inputs(inputs: dict) -> dict:
    if "email" in inputs:
        inputs["email"] = "[REDACTED]"
    return inputs

weave.init(...)
weave.integrations.patch_openai(
    settings={
        "op_settings": {"postprocess_inputs": redact_inputs}
    }
)
```

For more information about handling sensitive data, see [How to use Weave with PII data](https://docs.coreweave.com/products/wandb/weave/cookbooks/pii.md).

**TypeScript**

The TypeScript SDK only supports autopatching for OpenAI and Anthropic. Weave patches OpenAI when you import Weave, and it doesn't require any additional configuration.

Additionally, the TypeScript SDK doesn't support:

* Autopatching configuration or disabling.
* Input and output post-processing.

For edge cases where automatic patching doesn't work (ESM, bundlers like Next.js), use explicit wrapping to ensure Weave traces your OpenAI client:

```typescript twoslash theme={"system"}
// @noErrors
import OpenAI from 'openai'
import * as weave from 'weave'
import { wrapOpenAI } from 'weave'

const client = wrapOpenAI(new OpenAI())
await weave.init('your-team-name/your-project-name')
```

For more information about ESM setup and troubleshooting, see the [TypeScript SDK Integration Guide](https://docs.coreweave.com/products/wandb/weave/guides/integrations/js.md).
