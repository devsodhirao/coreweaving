> ## Documentation Index
> Fetch the complete documentation index at: https://docs.coreweave.com/llms.txt
> Use this file to discover all available pages before exploring further.

# runIsolated

> TypeScript SDK reference

```ts theme={"system"}
runIsolated<T>(fn: () => T): T
```

[GitHub source](https://github.com/wandb/weave/blob/7c9efdc9fe05ffcaf2430dd652ef9bc5b3ffdfaa/sdks/node/src/genai/context.ts#L54)

Run `fn` in a fresh, isolated GenAI state frame. Any Conversation / Turn / LLM
started inside `fn` lives in this frame only — it does not clash with
sibling `runIsolated` frames running concurrently, and it does not leak
to the outer async chain.

Use this to safely run parallel GenAI work:

```typescript theme={"system"}
await Promise.all([
  weave.runIsolated(async () => { ... }),
  weave.runIsolated(async () => { ... }),
]);
```

Sequential single-flight usage doesn't require this wrapper — the
process-wide default state handles it.

## Type Parameters

**T**

## Parameters

**fn** `() =\> T` *required*

## Returns

`T`
