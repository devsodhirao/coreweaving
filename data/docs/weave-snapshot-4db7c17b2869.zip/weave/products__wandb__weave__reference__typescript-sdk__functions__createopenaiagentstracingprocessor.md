> ## Documentation Index
> Fetch the complete documentation index at: https://docs.coreweave.com/llms.txt
> Use this file to discover all available pages before exploring further.

# createOpenAIAgentsTracingProcessor

> TypeScript SDK reference

```ts theme={"system"}
createOpenAIAgentsTracingProcessor(): TracingProcessor
```

[GitHub source](https://github.com/wandb/weave/blob/7c9efdc9fe05ffcaf2430dd652ef9bc5b3ffdfaa/sdks/node/src/integrations/openai.agent.ts#L102)

Create a new Weave tracing processor for OpenAI Agents.

## Returns

`TracingProcessor`

A TracingProcessor instance that can be registered with OpenAI Agents

## Example

```typescript twoslash theme={"system"}
// @noErrors
import { addTraceProcessor } from '@openai/agents';
import { createOpenAIAgentsTracingProcessor } from 'weave';

const processor = createOpenAIAgentsTracingProcessor();
addTraceProcessor(processor);
```
