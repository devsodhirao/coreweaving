> ## Documentation Index
> Fetch the complete documentation index at: https://docs.coreweave.com/llms.txt
> Use this file to discover all available pages before exploring further.

# endTurn

> TypeScript SDK reference

```ts theme={"system"}
endTurn(opts?: object): void
```

[GitHub source](https://github.com/wandb/weave/blob/7c9efdc9fe05ffcaf2430dd652ef9bc5b3ffdfaa/sdks/node/src/genai/api.ts#L183)

End the current Turn. No-op if no Turn is active.

## Parameters

**opts** `object`

**properties**

**endTime** `TimeInput`

**error** `Error`

## Returns

`void`

## Examples

```ts twoslash theme={"system"}
// @noErrors
weave.endTurn();
```

```ts twoslash theme={"system"}
// @noErrors
weave.endTurn({endTime: new Date('2026-05-29T10:00:01.700Z')});
```

```ts twoslash theme={"system"}
// @noErrors
weave.endTurn({error: new Error('agent loop diverged')});
```
