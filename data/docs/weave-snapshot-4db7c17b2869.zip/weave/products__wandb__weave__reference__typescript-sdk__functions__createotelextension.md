> ## Documentation Index
> Fetch the complete documentation index at: https://docs.coreweave.com/llms.txt
> Use this file to discover all available pages before exploring further.

# createOtelExtension

> TypeScript SDK reference

```ts theme={"system"}
createOtelExtension(opts?: object): (pi) => void
```

[GitHub source](https://github.com/wandb/weave/blob/7c9efdc9fe05ffcaf2430dd652ef9bc5b3ffdfaa/sdks/node/src/integrations/piCodingAgent.ts#L658)

Creates a pi coding agent extension that emits OTEL spans for the full
agent lifecycle, conforming to the GenAI semantic conventions.

When `weave.init(...)` has been called, spans are automatically exported
to the Weave trace server at `/agents/otel/v1/traces`. Otherwise, pass a
custom `tracer` in `opts`.

## Parameters

**opts** `object`

**properties**

**captureContent** `boolean`

**tracer** `Tracer`

## Returns

(`pi`) => `void`

## Example

```typescript twoslash theme={"system"}
// @noErrors
const resourceLoader = new DefaultResourceLoader({
  extensionFactories: [createOtelExtension()],
});
```
