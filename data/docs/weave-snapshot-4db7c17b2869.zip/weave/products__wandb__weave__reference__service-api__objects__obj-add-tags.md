> ## Documentation Index
> Fetch the complete documentation index at: https://docs.coreweave.com/llms.txt
> Use this file to discover all available pages before exploring further.

# Obj Add Tags

> Add tags to an object version.



## OpenAPI

````yaml products/wandb/weave/reference/service-api/openapi.json PUT /objs/{object_id}/versions/{digest}/tags
openapi: 3.1.0
info:
  title: FastAPI
  version: 0.1.0
servers: []
security: []
paths:
  /objs/{object_id}/versions/{digest}/tags:
    put:
      tags:
        - Objects
      summary: Obj Add Tags
      description: Add tags to an object version.
      operationId: obj_add_tags_objs__object_id__versions__digest__tags_put
      parameters:
        - name: object_id
          in: path
          required: true
          schema:
            type: string
            title: Object Id
        - name: digest
          in: path
          required: true
          schema:
            type: string
            title: Digest
      requestBody:
        required: true
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/ObjTagsBody'
      responses:
        '200':
          description: Successful Response
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/ObjAddTagsRes'
        '422':
          description: Validation Error
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/HTTPValidationError'
components:
  schemas:
    ObjTagsBody:
      properties:
        project_id:
          type: string
          title: Project Id
          examples:
            - entity/project
        tags:
          items:
            type: string
          type: array
          title: Tags
          examples:
            - - production
              - reviewed
      type: object
      required:
        - project_id
        - tags
      title: ObjTagsBody
      description: >-
        Request body for adding/removing tags (object_id and digest come from
        path).
    ObjAddTagsRes:
      properties: {}
      type: object
      title: ObjAddTagsRes
    HTTPValidationError:
      properties:
        detail:
          items:
            $ref: '#/components/schemas/ValidationError'
          type: array
          title: Detail
      type: object
      title: HTTPValidationError
    ValidationError:
      properties:
        loc:
          items:
            anyOf:
              - type: string
              - type: integer
          type: array
          title: Location
        msg:
          type: string
          title: Message
        type:
          type: string
          title: Error Type
        input:
          title: Input
        ctx:
          type: object
          title: Context
      type: object
      required:
        - loc
        - msg
        - type
      title: ValidationError

````