> ## Documentation Index
> Fetch the complete documentation index at: https://docs.coreweave.com/llms.txt
> Use this file to discover all available pages before exploring further.

# op

> Python SDK reference for weave.trace.op

# API Overview

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace/op.py#L96)

## <kbd>class</kbd> `DisplayNameFuncError`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace/op.py#L99)

## <kbd>class</kbd> `OpCallError`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace/op.py#L215)

## <kbd>class</kbd> `OpKwargs`

TypedDict for op() keyword arguments.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace/op.py#L120)

## <kbd>class</kbd> `Sentinel`

Sentinel(package: 'str', path: 'str', name: 'str')

[Source](https://github.com/wandb/weave/blob/v0.53.1/../../../../weave/trace/op/__init__)

### <kbd>method</kbd> `__init__`

```python theme={"system"}
__init__(package: 'str', path: 'str', name: 'str') → None
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace/op.py#L209)

## <kbd>class</kbd> `WeaveKwargs`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace/op.py#L1477)

### <kbd>function</kbd> `as_op`

```python theme={"system"}
as_op(fn: 'Callable[P, R]') → Op[P, R]
```

Given a @weave.op decorated function, return its Op.

@weave.op decorated functions are instances of Op already, so this function should be a no-op at runtime. But you can use it to satisfy type checkers if you need to access OpDef attributes in a typesafe way.

**Args:**

* **`fn`**: A weave.op decorated function.

**Returns:**
The Op of the function.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace/op.py#L1170)

### <kbd>function</kbd> `call`

```python theme={"system"}
call(
    op: 'Op',
    *args: 'Any',
    __weave: 'WeaveKwargs | None' = None,
    __should_raise: 'bool' = False,
    __require_explicit_finish: 'bool' = False,
    **kwargs: 'Any'
) → tuple[Any, Call] | Coroutine[Any, Any, tuple[Any, Call]]
```

Executes the op and returns both the result and a Call representing the execution.

This function will never raise.  Any errors are captured in the Call object.

This method is automatically bound to any function decorated with `@weave.op`, allowing for usage like:

```python theme={"system"}
@weave.op
def add(a: int, b: int) -> int:
     return a + b

result, call = add.call(1, 2)
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace/op.py#L1216)

### <kbd>function</kbd> `calls`

```python theme={"system"}
calls(op: 'Op') → CallsIter
```

Get an iterator over all calls to this op.

This method is automatically bound to any function decorated with `@weave.op`, allowing for usage like:

```python theme={"system"}
@weave.op
def add(a: int, b: int) -> int:
     return a + b

calls = add.calls()
for call in calls:
     print(call)
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace/op.py#L1423)

### <kbd>function</kbd> `get_captured_code`

```python theme={"system"}
get_captured_code(op: 'Op') → str
```

Get the captured code of the op.

This only works when you get an op back from a ref.  The pattern is:

ref = weave.publish(func) op = ref.get() captured\_code = op.get\_captured\_code()

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace/op.py#L1469)

### <kbd>function</kbd> `is_op`

```python theme={"system"}
is_op(obj: 'Any') → TypeIs[Op]
```

Check if an object is an Op.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace/op.py#L443)

### <kbd>function</kbd> `is_placeholder_call`

```python theme={"system"}
is_placeholder_call(call: 'Call') → TypeIs[NoOpCall]
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace/op.py#L411)

### <kbd>function</kbd> `is_tracing_setting_disabled`

```python theme={"system"}
is_tracing_setting_disabled() → bool
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace/op.py#L1440)

### <kbd>function</kbd> `maybe_bind_method`

```python theme={"system"}
maybe_bind_method(func: 'Callable', self: 'Any' = None) → Callable | MethodType
```

Bind a function to any object (even if it's not a class).

If self is None, return the function as is.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace/op.py#L1452)

### <kbd>function</kbd> `maybe_unbind_method`

```python theme={"system"}
maybe_unbind_method(oplike: 'Op | MethodType | partial') → Op
```

Unbind an Op-like method or partial to a plain Op function.

For:

* methods, remove set `self` param
* partials, remove any preset params

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace/op.py#L1240)

### <kbd>function</kbd> `op`

```python theme={"system"}
op(
    func: 'Callable[P, R] | None' = None,
    name: 'str | None' = None,
    call_display_name: 'str | CallDisplayNameFunc | None' = None,
    postprocess_inputs: 'PostprocessInputsFunc | None' = None,
    postprocess_output: 'PostprocessOutputFunc | None' = None,
    tracing_sample_rate: 'float' = 1.0,
    enable_code_capture: 'bool' = True,
    accumulator: 'Callable[[Any | None, Any], Any] | None' = None,
    kind: 'OpKind | None' = None,
    color: 'OpColor | None' = None,
    attributes: 'dict[str, Any] | None' = None,
    eager_call_start: 'bool' = False
) → Callable[[Callable[P, R]], Op[P, R]] | Op[P, R]
```

A decorator to weave op-ify a function or method. Works for both sync and async. Automatically detects iterator functions and applies appropriate behavior.

**Args:**

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace/op.py#L436)

### <kbd>function</kbd> `placeholder_call`

```python theme={"system"}
placeholder_call() → Call
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace/op.py#L231)

### <kbd>function</kbd> `setup_dunder_weave_dict`

```python theme={"system"}
setup_dunder_weave_dict(op: 'Op', d: 'WeaveKwargs | None' = None) → WeaveKwargs
```

Sets up a \_\_weave dict used to pass WeaveKwargs to ops.

* **`func`**: The function to decorate.
* **`name`**: Custom name for the op. Defaults to the function name.
* **`call_display_name`**: Display name for calls, can be a string or callable.
* **`postprocess_inputs`**: Function to transform inputs before logging.
* **`postprocess_output`**: Function to transform output before logging.
* **`tracing_sample_rate`**: Fraction of calls to trace (0.0 to 1.0).
* **`enable_code_capture`**: Whether to capture source code for this op.
* **`accumulator`**: Function to accumulate results for streaming ops.
* **`attributes`**: Default attributes merged into every call this op creates,  at the lowest precedence. A `weave.attributes()` context and explicit  per-call attributes override them on key collision. The reserved  "weave" key may not be set here.
* **`eager_call_start`**: If True, call starts are sent immediately rather than batched.  Useful for long-running operations like evaluations that should  be visible in the UI immediately.

**Args:**

* **`d`**: Optional existing WeaveKwargs dict to update.
* **`op`**: Op to extract kind and color from.

**Returns:**
WeaveKwargs dict with attributes, display\_name, and optionally kind/color set.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace/op.py#L422)

### <kbd>function</kbd> `should_skip_tracing_for_op`

```python theme={"system"}
should_skip_tracing_for_op(op: 'Op') → bool
```
