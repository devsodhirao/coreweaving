> ## Documentation Index
> Fetch the complete documentation index at: https://docs.coreweave.com/llms.txt
> Use this file to discover all available pages before exploring further.

# withAttributes

> TypeScript SDK reference

```ts theme={"system"}
withAttributes<T>(attrs: Record<string, any>, fn: () => T | Promise<T>): T | Promise<T>
```

[GitHub source](https://github.com/wandb/weave/blob/7c9efdc9fe05ffcaf2430dd652ef9bc5b3ffdfaa/sdks/node/src/clientApi.ts#L238)

Attach attributes to the current execution context so that any calls created
inside `fn` automatically inherit them. Attributes are written to the call
record on the trace server and surface in the Weave UI/filtering, so they’re
ideal for tagging runs with request IDs, tenants, experiments, etc.

Example:

```ts twoslash theme={"system"}
// @noErrors
await withAttributes({requestId: 'abc'}, async () => {
  await myOp();
});
```

## Type Parameters

**T**

## Parameters

**attrs** `Record\<string, any\>` *required*

**fn** `() =\> T | Promise\<T\>` *required*

## Returns

`T` | `Promise`\<`T`>
