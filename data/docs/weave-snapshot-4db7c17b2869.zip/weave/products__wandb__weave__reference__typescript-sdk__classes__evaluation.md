> ## Documentation Index
> Fetch the complete documentation index at: https://docs.coreweave.com/llms.txt
> Use this file to discover all available pages before exploring further.

# Evaluation<R, E, M>

> TypeScript SDK reference

[GitHub source](https://github.com/wandb/weave/blob/7c9efdc9fe05ffcaf2430dd652ef9bc5b3ffdfaa/sdks/node/src/evaluation.ts#L145)

Sets up an evaluation which includes a set of scorers and a dataset.

Calling evaluation.evaluate(model) will pass in rows form a dataset into a model matching
the names of the columns of the dataset to the argument names in model.predict.

Then it will call all of the scorers and save the results in weave.

## Example

```ts twoslash theme={"system"}
// @noErrors
// Collect your examples into a dataset
const dataset = new weave.Dataset({
  id: 'my-dataset',
  rows: [
    { question: 'What is the capital of France?', expected: 'Paris' },
    { question: 'Who wrote "To Kill a Mockingbird"?', expected: 'Harper Lee' },
    { question: 'What is the square root of 64?', expected: '8' },
  ],
});

// Define any custom scoring function
const scoringFunction = weave.op(function isEqual({ modelOutput, datasetRow }) {
  return modelOutput == datasetRow.expected;
});

// Define the function to evaluate
const model = weave.op(async function alwaysParisModel({ question }) {
  return 'Paris';
});

// Start evaluating
const evaluation = new weave.Evaluation({
  id: 'my-evaluation',
  dataset: dataset,
  scorers: [scoringFunction],
});

const results = await evaluation.evaluate({ model });
```

## Extends

* [`WeaveObject`](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/classes/weaveobject)

## Type Parameters

**R** `extends DatasetRow`

**E** `extends DatasetRow`

**M**

## Constructor

> **new Evaluation**\<`R`, `E`, `M`>(`parameters`): `Evaluation`\<`R`, `E`, `M`>

### Parameters

**parameters** `object` *required*

**properties**

**columnMapping** `\{[key: string]: keyof R; __savedRef?: keyof R; \}`

**properties**

**\_\_savedRef** `keyof R`

**dataset** `Dataset\<R\>` *required*

See [`Dataset`](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/classes/dataset).

**description** `string`

**maxConcurrency** `number`

**name** `string`

**scorers** `(Op\<(...args) =\> any\> | \{…\})[]` *required*

See [`Op`](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/type-aliases/op).

Full type: `(Op<(...args) => any> | { id: string; invoke: (...args) => any; })[]`

### Returns

`Evaluation`\<`R`, `E`, `M`>

### Overrides

[`WeaveObject`](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/classes/weaveobject).[`constructor`](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/classes/weaveobject#constructor)

## Properties

### \_\_savedRef

> `optional` **\_\_savedRef**: [`ObjectRef`](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/classes/objectref) | `Promise`\<[`ObjectRef`](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/classes/objectref)>

#### Inherited from

[`WeaveObject`](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/classes/weaveobject).[`__savedRef`](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/classes/weaveobject#__savedref)

## Accessors

### description

#### Get Signature

> **get** **description**(): `string` | `undefined`

##### Returns

`string` | `undefined`

#### Inherited from

[`WeaveObject`](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/classes/weaveobject).[`description`](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/classes/weaveobject#description)

***

### name

#### Get Signature

> **get** **name**(): `string`

##### Returns

`string`

#### Inherited from

[`WeaveObject`](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/classes/weaveobject).[`name`](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/classes/weaveobject#name)

## Methods

### evaluate()

> **evaluate**(`__namedParameters`): `Promise`\<`Record`\<`string`, `any`>>

#### Parameters

**\_\_namedParameters** `object` *required*

**properties**

**maxConcurrency** `number = 5`

**model** `Op\<(...args) =\> Promise\<M\>\> | \{…\}` *required*

See [`Op`](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/type-aliases/op).

Full type: `Op<(...args) => Promise<M>> | { id: string; invoke: (...args) => Promise<M>; }`

**nTrials** `number = 1`

#### Returns

`Promise`\<`Record`\<`string`, `any`>>

***

### predictAndScore()

> **predictAndScore**(`__namedParameters`): `Promise`\<\{ `model_latency`: `number`; `model_output`: `any`; `model_success`: `boolean`; `scores`: \{\[`key`: `string`]: `any`; }; }>

#### Parameters

**\_\_namedParameters** `object` *required*

**properties**

**columnMapping** `\{[key: string]: keyof R; __savedRef?: keyof R; \}`

**properties**

**\_\_savedRef** `keyof R`

**example** `R` *required*

**model** `Op\<(...args) =\> Promise\<M\>\> | \{…\}` *required*

See [`Op`](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/type-aliases/op).

Full type: `Op<(...args) => Promise<M>> | { id: string; invoke: (...args) => Promise<M>; }`

#### Returns

`Promise`\<\{ `model_latency`: `number`; `model_output`: `any`; `model_success`: `boolean`; `scores`: \{\[`key`: `string`]: `any`; }; }>

***

### saveAttrs()

> **saveAttrs**(): `object`

#### Returns

`object`

#### Inherited from

[`WeaveObject`](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/classes/weaveobject).[`saveAttrs`](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/classes/weaveobject#saveattrs)
