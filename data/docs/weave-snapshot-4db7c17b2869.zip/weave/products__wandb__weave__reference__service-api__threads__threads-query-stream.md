> ## Documentation Index
> Fetch the complete documentation index at: https://docs.coreweave.com/llms.txt
> Use this file to discover all available pages before exploring further.

# Threads Query Stream



## OpenAPI

````yaml products/wandb/weave/reference/service-api/openapi.json POST /threads/stream_query
openapi: 3.1.0
info:
  title: FastAPI
  version: 0.1.0
servers: []
security: []
paths:
  /threads/stream_query:
    post:
      tags:
        - Threads
      summary: Threads Query Stream
      operationId: threads_query_stream_threads_stream_query_post
      requestBody:
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/ThreadsQueryReq'
        required: true
      responses:
        '200':
          description: Stream of data in JSONL format
          content:
            application/x-ndjson:
              schema:
                $ref: '#/components/schemas/ThreadSchema'
        '422':
          description: Validation Error
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/HTTPValidationError'
components:
  schemas:
    ThreadsQueryReq:
      properties:
        project_id:
          type: string
          title: Project Id
          description: The ID of the project
          examples:
            - my_entity/my_project
        filter:
          anyOf:
            - $ref: '#/components/schemas/ThreadsQueryFilter'
            - type: 'null'
          description: Filter criteria for the threads query
        limit:
          anyOf:
            - type: integer
            - type: 'null'
          title: Limit
          description: Maximum number of threads to return
        offset:
          anyOf:
            - type: integer
            - type: 'null'
          title: Offset
          description: Number of threads to skip
        sort_by:
          anyOf:
            - items:
                $ref: '#/components/schemas/SortBy'
              type: array
            - type: 'null'
          title: Sort By
          description: >-
            Sorting criteria for the threads. Supported fields: 'thread_id',
            'turn_count', 'start_time', 'last_updated', 'p50_turn_duration_ms',
            'p99_turn_duration_ms'.
          examples:
            - - direction: desc
                field: last_updated
      type: object
      required:
        - project_id
      title: ThreadsQueryReq
      description: >-
        Query threads with aggregated statistics based on turn calls only.


        Turn calls are the immediate children of thread contexts (where call.id
        == turn_id).

        This provides meaningful conversation-level statistics rather than
        including all

        nested implementation details.
    ThreadSchema:
      properties:
        thread_id:
          type: string
          title: Thread Id
        turn_count:
          type: integer
          title: Turn Count
          description: Number of turn calls in this thread
        start_time:
          type: string
          format: date-time
          title: Start Time
          description: Earliest start time of turn calls in this thread
        last_updated:
          type: string
          format: date-time
          title: Last Updated
          description: Latest end time of turn calls in this thread
        first_turn_id:
          anyOf:
            - type: string
            - type: 'null'
          title: First Turn Id
          description: Turn ID of the first turn in this thread (earliest start_time)
        last_turn_id:
          anyOf:
            - type: string
            - type: 'null'
          title: Last Turn Id
          description: Turn ID of the latest turn in this thread (latest end_time)
        p50_turn_duration_ms:
          anyOf:
            - type: number
            - type: 'null'
          title: P50 Turn Duration Ms
          description: >-
            50th percentile (median) of turn durations in milliseconds within
            this thread
        p99_turn_duration_ms:
          anyOf:
            - type: number
            - type: 'null'
          title: P99 Turn Duration Ms
          description: 99th percentile of turn durations in milliseconds within this thread
      type: object
      required:
        - thread_id
        - turn_count
        - start_time
        - last_updated
        - first_turn_id
        - last_turn_id
        - p50_turn_duration_ms
        - p99_turn_duration_ms
      title: ThreadSchema
    HTTPValidationError:
      properties:
        detail:
          items:
            $ref: '#/components/schemas/ValidationError'
          type: array
          title: Detail
      type: object
      title: HTTPValidationError
    ThreadsQueryFilter:
      properties:
        after_datetime:
          anyOf:
            - type: string
              format: date-time
            - type: 'null'
          title: After Datetime
          description: Only include threads with start_time after this timestamp
          examples:
            - '2024-01-01T00:00:00Z'
        before_datetime:
          anyOf:
            - type: string
              format: date-time
            - type: 'null'
          title: Before Datetime
          description: Only include threads with last_updated before this timestamp
          examples:
            - '2024-12-31T23:59:59Z'
        thread_ids:
          anyOf:
            - items:
                type: string
              type: array
            - type: 'null'
          title: Thread Ids
          description: Only include threads with thread_ids in this list
          examples:
            - - thread_1
              - thread_2
              - my_thread_id
      type: object
      title: ThreadsQueryFilter
    SortBy:
      properties:
        field:
          type: string
          title: Field
        direction:
          type: string
          enum:
            - asc
            - desc
          title: Direction
      type: object
      required:
        - field
        - direction
      title: SortBy
    ValidationError:
      properties:
        loc:
          items:
            anyOf:
              - type: string
              - type: integer
          type: array
          title: Location
        msg:
          type: string
          title: Message
        type:
          type: string
          title: Error Type
        input:
          title: Input
        ctx:
          type: object
          title: Context
      type: object
      required:
        - loc
        - msg
        - type
      title: ValidationError

````