> ## Documentation Index
> Fetch the complete documentation index at: https://docs.coreweave.com/llms.txt
> Use this file to discover all available pages before exploring further.

# Choose an agent integration

> Pick a built-in Weave integration for your agent SDK or harness and start sending conversations, turns, LLM calls, and tool calls to the Agents view.

> [!TIP]
>
> **This workflow is also available in CoreWeave Agent Lens.** Agent Lens is the Forge experience built for tracing, monitoring, and analyzing AI agents, with automated insights into agent failures and user intents. It uses the same trace data as Weights & Biases Weave, so the traces you already send appear there with nothing to migrate.
> [See how to do this in Agent Lens](https://docs.coreweave.com/products/agent-lens/get-started/integrations.md).

W\&B Weave traces multi-turn agents built with popular SDKs and harnesses without hand-instrumenting each turn. Install a plugin for your agent harness, or call `weave.init()` in code that uses a supported agent SDK, and Weave autopatches the framework. Conversations, turns, LLM calls, and tool calls render in the **Agents** view of your project.

Harness plugins group turns into conversations on their own, because the harness owns the session. Agent SDKs run one turn per call, so your code decides which turns belong to the same conversation. For those integrations, `weave.init()` alone isn't enough.

Choose from one of the following supported integrations.

## Agent harnesses

Agent harnesses are end-user agent runtimes, such as coding agents and developer tools. Install the plugin or extension, then start a session in the harness to begin tracing:

* [Claude Code plugin](https://docs.coreweave.com/products/wandb/weave/guides/integrations/agents/claude-code-harness.md)
* [Codex plugin](https://docs.coreweave.com/products/wandb/weave/guides/integrations/agents/codex-harness.md)
* [OpenClaw plugin](https://docs.coreweave.com/products/wandb/weave/guides/integrations/agents/openclaw-harness.md)
* [Pi extension](https://docs.coreweave.com/products/wandb/weave/guides/integrations/agents/pi-dev-harness.md)

## Agent SDKs

Agent SDKs are libraries for building agents and multi-agent workflows in your own application code. Add `weave.init("[YOUR-TEAM]/[YOUR-PROJECT]")` to your script and Weave autopatches the SDK:

* [OpenAI Agents SDK](https://docs.coreweave.com/products/wandb/weave/guides/integrations/agents/openai-agents-sdk.md)
* [Google Agent Development Kit (ADK)](https://docs.coreweave.com/products/wandb/weave/guides/integrations/agents/google-adk.md)
* [Claude Agent SDK](https://docs.coreweave.com/products/wandb/weave/guides/integrations/agents/claude-agents-sdk.md)

## Custom agents and OpenTelemetry

If your agent isn't built with one of the SDKs above, or it already emits OpenTelemetry spans, use the Weave SDK directly. Weave accepts any OTel span and gives special handling to [GenAI semantic-convention attributes](https://opentelemetry.io/docs/specs/semconv/gen-ai/gen-ai-agent-spans/) so spans render in the **Agents** view:

* [Quickstart: Manually instrument an agent](https://docs.coreweave.com/products/wandb/weave/custom-agents-quickstart.md) — a walkthrough of a small multi-turn agent.
* [Trace your agents](https://docs.coreweave.com/products/wandb/weave/guides/tracking/trace-agents.md) — the full reference of agent helpers and concepts.
* [Send OpenTelemetry spans to the Agents view](https://docs.coreweave.com/products/wandb/weave/guides/tracking/trace-agents-otel.md) — point an existing OTel pipeline at the Weave agents endpoint, with no Weave SDK required.

## Next steps

Once your first conversation reaches Weave, see [View activity in the Agents view](https://docs.coreweave.com/products/wandb/weave/guides/tracking/view-agent-activity.md) to explore conversations, turns, and tool calls.
