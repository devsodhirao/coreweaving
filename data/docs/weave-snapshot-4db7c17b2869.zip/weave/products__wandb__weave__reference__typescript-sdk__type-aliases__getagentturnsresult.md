> ## Documentation Index
> Fetch the complete documentation index at: https://docs.coreweave.com/llms.txt
> Use this file to discover all available pages before exploring further.

# GetAgentTurnsResult

> TypeScript SDK reference

> **GetAgentTurnsResult** = `object`

[GitHub source](https://github.com/wandb/weave/blob/7c9efdc9fe05ffcaf2430dd652ef9bc5b3ffdfaa/sdks/node/src/weaveClient.ts#L283)

Result shape returned by [WeaveClient.getAgentTurns](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/interfaces/weaveclient.md#getagentturns).

## Properties

### conversation\_id

> **conversation\_id**: `string`

***

### feedback

> `optional` **feedback**: `Record`\<`string`, `any`>\[] | `null`

***

### has\_more

> `optional` **has\_more**: `boolean`

***

### limit

> `optional` **limit**: `number`

***

### offset

> `optional` **offset**: `number`

***

### total\_turns

> `optional` **total\_turns**: `number`

***

### turns

> `optional` **turns**: [`AgentTurn`](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/type-aliases/agentturn)\[]
