> ## Documentation Index
> Fetch the complete documentation index at: https://docs.coreweave.com/llms.txt
> Use this file to discover all available pages before exploring further.

# weave

> Python SDK reference for weave

# API Overview

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/agent/agent.py#L17)

## <kbd>class</kbd> `Agent`

**Pydantic Fields:**

* `name`: `str | None`
* `description`: `str | None`
* `ref`: `trace.refs.ObjectRef | None`
* `model_name`: `<class 'str'>`
* `temperature`: `<class 'float'>`
* `system_message`: `<class 'str'>`
* `tools`: `list[typing.Any]`

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace/op.py#L23)

### <kbd>method</kbd> `step`

```python theme={"system"}
step(state: AgentState) → AgentState
```

Run a step of the agent.

**Args:**

* **`state`**: The current state of the environment.
* **`action`**: The action to take.

**Returns:**
The new state of the environment.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/agent/agent.py#L12)

## <kbd>class</kbd> `AgentState`

**Pydantic Fields:**

* `name`: `str | None`
* `description`: `str | None`
* `ref`: `trace.refs.ObjectRef | None`
* `history`: `list[typing.Any]`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/interface/builtin_object_classes/annotation_spec.py#L11)

## <kbd>class</kbd> `AnnotationSpec`

**Pydantic Fields:**

* `name`: `str | None`
* `description`: `str | None`
* `field_schema`: `dict[str, typing.Any]`
* `unique_among_creators`: `<class 'bool'>`
* `op_scope`: `list[str] | None`

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/interface/builtin_object_classes/annotation_spec.py#L46)

### <kbd>classmethod</kbd> `preprocess_field_schema`

```python theme={"system"}
preprocess_field_schema(data: Any) → Any
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/interface/builtin_object_classes/annotation_spec.py#L93)

### <kbd>classmethod</kbd> `validate_field_schema`

```python theme={"system"}
validate_field_schema(schema: dict[str, Any]) → dict[str, Any]
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/interface/builtin_object_classes/annotation_spec.py#L109)

### <kbd>method</kbd> `value_is_valid`

```python theme={"system"}
value_is_valid(payload: Any) → bool
```

Validates a payload against this annotation spec's schema.

**Args:**

* **`payload`**: The data to validate against the schema

**Returns:**

* **`bool`**:  True if validation succeeds, False otherwise

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/type_handlers/Audio/audio.py#L81)

## <kbd>class</kbd> `Audio`

A class representing audio data in a supported format (wav or mp3).

This class handles audio data storage and provides methods for loading from different sources and exporting to files.

**Attributes:**

* **`format`**:  The audio format (currently supports 'wav' or 'mp3')
* **`data`**:  The raw audio data as bytes

**Args:**

* **`data`**: The audio data (bytes or base64 encoded string)
* **`format`**: The audio format ('wav' or 'mp3')
* **`validate_base64`**: Whether to attempt base64 decoding of the input data

**Raises:**

* **`ValueError`**:  If audio data is empty or format is not supported

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/type_handlers/Audio/audio.py#L106)

### <kbd>method</kbd> `__init__`

```python theme={"system"}
__init__(
    data: 'bytes',
    format: 'SUPPORTED_FORMATS_TYPE',
    validate_base64: 'bool' = True
) → None
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/type_handlers/Audio/audio.py#L174)

### <kbd>method</kbd> `export`

```python theme={"system"}
export(path: 'str | bytes | Path | PathLike') → None
```

Export audio data to a file.

**Args:**

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/type_handlers/Audio/audio.py#L121)

### <kbd>classmethod</kbd> `from_data`

```python theme={"system"}
from_data(data: 'str | bytes', format: 'str') → Self
```

Create an Audio object from raw data and specified format.

* **`path`**: Path where the audio file should be written

**Args:**

* **`data`**: Audio data as bytes or base64 encoded string
* **`format`**: Audio format ('wav' or 'mp3')

**Returns:**

* **`Audio`**:  A new Audio instance

**Raises:**

* **`ValueError`**:  If format is not supported

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/type_handlers/Audio/audio.py#L146)

### <kbd>classmethod</kbd> `from_path`

```python theme={"system"}
from_path(path: 'str | bytes | Path | PathLike') → Self
```

Create an Audio object from a file path.

**Args:**

* **`path`**: Path to an audio file (must have .wav or .mp3 extension)

**Returns:**

* **`Audio`**:  A new Audio instance loaded from the file

**Raises:**

* **`ValueError`**:  If file doesn't exist or has unsupported extension

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/flow/monitor.py#L278)

## <kbd>class</kbd> `ClassifierMonitor`

A monitor that merges multiple scorers into a single classifier.

Classifier monitors combine prompts from multiple LLMAsAJudgeScorers targeting the same model into a single scoring call.

**Pydantic Fields:**

* `name`: `str | None`
* `description`: `str | None`
* `ref`: `trace.refs.ObjectRef | None`
* `sampling_rate`: `<class 'float'>`
* `scorers`: `list[flow.scorer.Scorer]`
* `op_names`: `list[typing.Union[typing.Literal['genai.turn_ended'], str]]`
* `query`: `trace_server.interface.query.Query | None`
* `is_traced`: `<class 'bool'>`
* `active`: `<class 'bool'>`
* `scorer_debounce_config`: `flow.monitor.ScorerDebounceConfig | None`
* `prompt_header`: `str | None`
* `prompt_footer`: `str | None`

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/flow/monitor.py#L141)

### <kbd>method</kbd> `activate`

```python theme={"system"}
activate() → ObjectRef
```

Activates the monitor.

**Returns:**
The ref to the monitor.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/flow/monitor.py#L152)

### <kbd>method</kbd> `deactivate`

```python theme={"system"}
deactivate() → ObjectRef
```

Deactivates the monitor.

**Returns:**
The ref to the monitor.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/flow/monitor.py#L203)

### <kbd>classmethod</kbd> `from_obj`

```python theme={"system"}
from_obj(obj: WeaveObject) → Self
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/flow/monitor.py#L302)

### <kbd>method</kbd> `get_prompt_footer`

```python theme={"system"}
get_prompt_footer() → str
```

Text to append after the merged classifier prompts.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/flow/monitor.py#L296)

### <kbd>method</kbd> `get_prompt_header`

```python theme={"system"}
get_prompt_header(op_name: str) → str
```

Text to prepend before the merged classifier prompts.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/flow/monitor.py#L118)

### <kbd>method</kbd> `model_post_init`

```python theme={"system"}
model_post_init(context: Any) → None
```

Normalize `op_names` at construction when a client is available.

Publishing has no per-object hook, so to also cover a bare `weave.publish(monitor)` (no `activate()`), expand short names here: anyone who will publish has typically called `weave.init`, so the client is set when the monitor is constructed.

Several use cases perform construction without a client, such as unit tests, inspection, deserializing a stored monitor in a worker. The guard on `get_weave_client()` allows construction without a client. Normalization won't occur in this case, but that should be ok because stored monitors already hold full refs.

There is an edge case where a monitor can be created using the SDK without normalizing: if the user constructs the monitor, then calls weave.init, and then publishes it. Calling `activate()` or `deactivate()` could be a workaround for this use-case.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/type_wrappers/Content/content.py#L42)

## <kbd>class</kbd> `Content`

A class to represent content from various sources, resolving them to a unified byte-oriented representation with associated metadata.

This class must be instantiated using one of its classmethods:

* from\_path()
* from\_bytes()
* from\_text()
* from\_url()
* from\_base64()
* from\_data\_url()

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/type_wrappers/Content/content.py#L87)

### <kbd>method</kbd> `__init__`

```python theme={"system"}
__init__(*args: 'Any', **kwargs: 'Any') → None
```

Direct initialization is disabled. Please use a classmethod like `Content.from_path()` to create an instance.

**Pydantic Fields:**

* `data`: `<class 'bytes'>`
* `size`: `<class 'int'>`
* `mimetype`: `<class 'str'>`
* `digest`: `<class 'str'>`
* `filename`: `<class 'str'>`
* `content_type`: `typing.Literal['bytes', 'text', 'base64', 'file', 'url', 'data_url', 'data_url:base64', 'data_url:encoding', 'data_url:encoding:base64']`
* `input_type`: `<class 'str'>`
* `encoding`: `<class 'str'>`
* `metadata`: `dict[str, typing.Any] | None`
* `extension`: `str | None`

***

#### <kbd>property</kbd> art

#### <kbd>property</kbd> ref

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/type_wrappers/Content/content.py#L543)

### <kbd>method</kbd> `as_string`

```python theme={"system"}
as_string() → str
```

Display the data as a string. Bytes are decoded using the `encoding` attribute If base64, the data will be re-encoded to base64 bytes then decoded to an ASCII string

**Returns:**
str.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/type_wrappers/Content/content.py#L258)

### <kbd>classmethod</kbd> `from_base64`

```python theme={"system"}
from_base64(
    b64_data: 'str | bytes',
    extension: 'str | None' = None,
    mimetype: 'str | None' = None,
    metadata: 'dict[str, Any] | None' = None
) → Self
```

Initializes Content from a base64 encoded string or bytes.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/type_wrappers/Content/content.py#L168)

### <kbd>classmethod</kbd> `from_bytes`

```python theme={"system"}
from_bytes(
    data: 'bytes',
    extension: 'str | None' = None,
    mimetype: 'str | None' = None,
    metadata: 'dict[str, Any] | None' = None,
    encoding: 'str' = 'utf-8'
) → Self
```

Initializes Content from raw bytes.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/type_wrappers/Content/content.py#L357)

### <kbd>classmethod</kbd> `from_data_url`

```python theme={"system"}
from_data_url(url: 'str', metadata: 'dict[str, Any] | None' = None) → Self
```

Initializes Content from a data URL.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/type_wrappers/Content/content.py#L309)

### <kbd>classmethod</kbd> `from_path`

```python theme={"system"}
from_path(
    path: 'str | Path',
    encoding: 'str' = 'utf-8',
    mimetype: 'str | None' = None,
    metadata: 'dict[str, Any] | None' = None
) → Self
```

Initializes Content from a local file path.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/type_wrappers/Content/content.py#L209)

### <kbd>classmethod</kbd> `from_text`

```python theme={"system"}
from_text(
    text: 'str',
    extension: 'str | None' = None,
    mimetype: 'str | None' = None,
    metadata: 'dict[str, Any] | None' = None,
    encoding: 'str' = 'utf-8'
) → Self
```

Initializes Content from a string of text.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/type_wrappers/Content/content.py#L399)

### <kbd>classmethod</kbd> `from_url`

```python theme={"system"}
from_url(
    url: 'str',
    headers: 'dict[str, Any] | None' = None,
    timeout: 'int | None' = 30,
    metadata: 'dict[str, Any] | None' = None
) → Self
```

Initializes Content by fetching bytes from an HTTP(S) URL.

Downloads the content, infers mimetype/extension from headers, URL path, and data, and constructs a Content object from the resulting bytes.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/type_wrappers/Content/content.py#L97)

### <kbd>classmethod</kbd> `model_validate`

```python theme={"system"}
model_validate(
    obj: 'Any',
    strict: 'bool | None' = None,
    from_attributes: 'bool | None' = None,
    context: 'dict[str, Any] | None' = None,
    extra: 'str | None' = None,
    by_alias: 'bool | None' = None,
    by_name: 'bool | None' = None
) → Self
```

Override model\_validate to handle Content reconstruction from dict.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/type_wrappers/Content/content.py#L148)

### <kbd>classmethod</kbd> `model_validate_json`

```python theme={"system"}
model_validate_json(
    json_data: 'str | bytes | bytearray',
    strict: 'bool | None' = None,
    context: 'dict[str, Any] | None' = None,
    extra: 'str | None' = None,
    by_alias: 'bool | None' = None,
    by_name: 'bool | None' = None
) → Self
```

Override model\_validate\_json to handle Content reconstruction from JSON.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/type_wrappers/Content/content.py#L553)

### <kbd>method</kbd> `open`

```python theme={"system"}
open() → bool
```

Open the file using the operating system's default application.

This method uses the platform-specific mechanism to open the file with the default application associated with the file's type.

**Returns:**

* **`bool`**:  True if the file was successfully opened, False otherwise.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/type_wrappers/Content/content.py#L583)

### <kbd>method</kbd> `save`

```python theme={"system"}
save(dest: 'str | Path') → None
```

Copy the file to the specified destination path. Updates the filename and the path of the content to reflect the last saved copy.

**Args:**

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/type_wrappers/Content/content.py#L535)

### <kbd>method</kbd> `serialize_data`

```python theme={"system"}
serialize_data(data: 'bytes') → str
```

When dumping model in json mode

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/type_wrappers/Content/content.py#L510)

### <kbd>method</kbd> `to_data_url`

```python theme={"system"}
to_data_url(use_base64: 'bool' = True) → str
```

Constructs a data URL from the content.

* **`dest`**: Destination path where the file will be copied to (string or pathlib.Path)  The destination path can be a file or a directory.  If dest has no file extension (e.g. .txt), destination will be considered a directory.

**Args:**

* **`use_base64`**: If True, the data will be base64 encoded.  Otherwise, it will be percent-encoded. Defaults to True.

**Returns:**
A data URL string.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/conversation/conversation.py#L1080)

## <kbd>class</kbd> `Conversation`

A conversation. Groups turns by conversation\_id (no span).

`continue_parent_trace` controls trace isolation for the turns this conversation creates. Default `False` means each turn starts its own OTel trace (the right choice for the standalone Agents tab view). Set `True` when the application has an outer trace (e.g. a fastapi-instrumented request) that should contain the agent invocation.

**Pydantic Fields:**

* `conversation_id`: `<class 'str'>`
* `conversation_name`: `<class 'str'>`
* `agent_name`: `<class 'str'>`
* `model`: `<class 'str'>`
* `agent_id`: `<class 'str'>`
* `agent_description`: `<class 'str'>`
* `agent_version`: `<class 'str'>`
* `include_content`: `<class 'bool'>`
* `continue_parent_trace`: `<class 'bool'>`
* `attributes`: `dict[str, typing.Any]`

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/conversation/conversation.py#L1157)

### <kbd>method</kbd> `end`

```python theme={"system"}
end() → None
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/pydantic/_internal/_model_construction.py#L1112)

### <kbd>method</kbd> `model_post_init`

```python theme={"system"}
model_post_init(context: 'Any') → None
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/conversation/conversation.py#L1116)

### <kbd>method</kbd> `start_turn`

```python theme={"system"}
start_turn(
    user_message: 'str' = '',
    model: 'str' = '',
    agent_name: 'str' = '',
    agent_id: 'str' = '',
    agent_description: 'str' = '',
    agent_version: 'str' = '',
    system_instructions: 'list[str] | None' = None
) → Turn
```

Create a new turn. Auto-ends the previous turn if still open.

Sets the `_current_turn` contextvar so the turn is visible via `get_current_turn()` regardless of whether a context manager is used. Each of `agent_name` / `model` / `agent_id` / `agent_description` / `agent_version` falls back to the conversation's default when left empty; `continue_parent_trace` is inherited. Override any of them later via `turn.record(...)`.

`system_instructions` (the agent's system prompt) is carried on the turn's invoke\_agent span; it can also be set later via attribute assignment on the returned `Turn`, mirroring `start_llm`.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/dataset/dataset.py#L26)

## <kbd>class</kbd> `Dataset`

Dataset object with easy saving and automatic versioning.

**Examples:**

```python theme={"system"}
# Create a dataset
dataset = Dataset(name='grammar', rows=[
     {'id': '0', 'sentence': "He no likes ice cream.", 'correction': "He doesn't like ice cream."},
     {'id': '1', 'sentence': "She goed to the store.", 'correction': "She went to the store."},
     {'id': '2', 'sentence': "They plays video games all day.", 'correction': "They play video games all day."}
])

# Publish the dataset
weave.publish(dataset)

# Retrieve the dataset
dataset_ref = weave.ref('grammar').get()

# Access a specific example
example_label = dataset_ref.rows[2]['sentence']
```

**Pydantic Fields:**

* `name`: `str | None`
* `description`: `str | None`
* `ref`: `trace.refs.ObjectRef | None`
* `rows`: `trace.table.Table | trace.vals.WeaveTable`

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/dataset/dataset.py#L129)

### <kbd>method</kbd> `add_rows`

```python theme={"system"}
add_rows(rows: Iterable[dict]) → Dataset
```

Create a new dataset version by appending rows to the existing dataset.

This is useful for adding examples to large datasets without having to load the entire dataset into memory.

**Args:**

* **`rows`**: The rows to add to the dataset.

**Returns:**
The updated dataset.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/dataset/dataset.py#L173)

### <kbd>classmethod</kbd> `convert_to_table`

```python theme={"system"}
convert_to_table(rows: Any) → Table | WeaveTable
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/dataset/dataset.py#L61)

### <kbd>classmethod</kbd> `from_calls`

```python theme={"system"}
from_calls(calls: Iterable[Call]) → Self
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/dataset/dataset.py#L71)

### <kbd>classmethod</kbd> `from_hf`

```python theme={"system"}
from_hf(hf_dataset: 'HFDataset | HFDatasetDict') → Self
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/dataset/dataset.py#L52)

### <kbd>classmethod</kbd> `from_obj`

```python theme={"system"}
from_obj(obj: WeaveObject) → Self
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/dataset/dataset.py#L66)

### <kbd>classmethod</kbd> `from_pandas`

```python theme={"system"}
from_pandas(df: 'DataFrame') → Self
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/dataset/dataset.py#L220)

### <kbd>method</kbd> `select`

```python theme={"system"}
select(indices: Iterable[int]) → Self
```

Select rows from the dataset based on the provided indices.

**Args:**

* **`indices`**: An iterable of integer indices specifying which rows to select.

**Returns:**
A new Dataset object containing only the selected rows.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/dataset/dataset.py#L115)

### <kbd>method</kbd> `to_hf`

```python theme={"system"}
to_hf() → HFDataset
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/dataset/dataset.py#L107)

### <kbd>method</kbd> `to_pandas`

```python theme={"system"}
to_pandas() → DataFrame
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/prompt/prompt.py#L192)

## <kbd>class</kbd> `EasyPrompt`

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/prompt/prompt.py#L200)

### <kbd>method</kbd> `__init__`

```python theme={"system"}
__init__(
    content: str | dict | list | None = None,
    role: str | None = None,
    dedent: bool = False,
    **kwargs: Any
) → None
```

**Pydantic Fields:**

* `name`: `str | None`
* `description`: `str | None`
* `ref`: `trace.refs.ObjectRef | None`
* `data`: `<class 'list'>`
* `config`: `<class 'dict'>`
* `requirements`: `<class 'dict'>`

***

#### <kbd>property</kbd> as\_str

Join all messages into a single string.

***

#### <kbd>property</kbd> is\_bound

***

#### <kbd>property</kbd> messages

#### <kbd>property</kbd> placeholders

***

#### <kbd>property</kbd> system\_message

Join all messages into a system prompt message.

***

#### <kbd>property</kbd> system\_prompt

Join all messages into a system prompt object.

***

#### <kbd>property</kbd> unbound\_placeholders

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/prompt/prompt.py#L230)

### <kbd>method</kbd> `append`

```python theme={"system"}
append(item: Any, role: str | None = None, dedent: bool = False) → None
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/prompt/prompt.py#L489)

### <kbd>method</kbd> `as_dict`

```python theme={"system"}
as_dict() → dict[str, Any]
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/prompt/prompt.py#L486)

### <kbd>method</kbd> `as_pydantic_dict`

```python theme={"system"}
as_pydantic_dict() → dict[str, Any]
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/prompt/prompt.py#L321)

### <kbd>method</kbd> `bind`

```python theme={"system"}
bind(*args: Any, **kwargs: Any) → Prompt
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/prompt/prompt.py#L341)

### <kbd>method</kbd> `bind_rows`

```python theme={"system"}
bind_rows(dataset: list[dict] | Any) → list['Prompt']
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/prompt/prompt.py#L447)

### <kbd>method</kbd> `config_table`

```python theme={"system"}
config_table(title: str | None = None) → Table
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/prompt/prompt.py#L411)

### <kbd>method</kbd> `configure`

```python theme={"system"}
configure(config: dict | None = None, **kwargs: Any) → Prompt
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/prompt/prompt.py#L527)

### <kbd>method</kbd> `dump`

```python theme={"system"}
dump(fp: <class 'IO'>) → None
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/prompt/prompt.py#L530)

### <kbd>method</kbd> `dump_file`

```python theme={"system"}
dump_file(filepath: str | Path) → None
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/prompt/prompt.py#L84)

### <kbd>method</kbd> `format`

```python theme={"system"}
format(**kwargs: Any) → Any
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/prompt/prompt.py#L496)

### <kbd>classmethod</kbd> `from_obj`

```python theme={"system"}
from_obj(obj: WeaveObject) → Self
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/prompt/prompt.py#L511)

### <kbd>classmethod</kbd> `load`

```python theme={"system"}
load(fp: <class 'IO'>) → Self
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/prompt/prompt.py#L521)

### <kbd>classmethod</kbd> `load_file`

```python theme={"system"}
load_file(filepath: str | Path) → Self
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/prompt/prompt.py#L427)

### <kbd>method</kbd> `messages_table`

```python theme={"system"}
messages_table(title: str | None = None) → Table
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/prompt/prompt.py#L455)

### <kbd>method</kbd> `print`

```python theme={"system"}
print() → str
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/prompt/prompt.py#L417)

### <kbd>method</kbd> `publish`

```python theme={"system"}
publish(
    name: str | None = None,
    tags: list[str] | None = None,
    aliases: list[str] | None = None
) → ObjectRef
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/prompt/prompt.py#L407)

### <kbd>method</kbd> `require`

```python theme={"system"}
require(param_name: str, **kwargs: Any) → Prompt
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace/op.py#L540)

### <kbd>method</kbd> `run`

```python theme={"system"}
run() → Any
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/prompt/prompt.py#L298)

### <kbd>method</kbd> `validate_requirement`

```python theme={"system"}
validate_requirement(key: str, value: Any) → list
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/prompt/prompt.py#L315)

### <kbd>method</kbd> `validate_requirements`

```python theme={"system"}
validate_requirements(values: dict[str, Any]) → list
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/prompt/prompt.py#L439)

### <kbd>method</kbd> `values_table`

```python theme={"system"}
values_table(title: str | None = None) → Table
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/evaluation/eval.py#L147)

## <kbd>class</kbd> `Evaluation`

Sets up an evaluation which includes a set of scorers and a dataset.

Calling evaluation.evaluate(model) will pass in rows from a dataset into a model matching  the names of the columns of the dataset to the argument names in model.predict.

Then it will call all of the scorers and save the results in weave.

If you want to preprocess the rows from the dataset you can pass in a function to preprocess\_model\_input.

**Examples:**

```python theme={"system"}
# Collect your examples
examples = [
     {"question": "What is the capital of France?", "expected": "Paris"},
     {"question": "Who wrote 'To Kill a Mockingbird'?", "expected": "Harper Lee"},
     {"question": "What is the square root of 64?", "expected": "8"},
]

# Define any custom scoring function
@weave.op
def match_score1(expected: str, model_output: dict) -> dict:
     # Here is where you'd define the logic to score the model output
     return {'match': expected == model_output['generated_text']}

@weave.op
def function_to_evaluate(question: str):
     # here's where you would add your LLM call and return the output
     return  {'generated_text': 'Paris'}

# Score your examples using scoring functions
evaluation = Evaluation(
     dataset=examples, scorers=[match_score1]
)

# Start tracking the evaluation
weave.init('intro-example')
# Run the evaluation
asyncio.run(evaluation.evaluate(function_to_evaluate))
```

**Pydantic Fields:**

* `name`: `str | None`
* `description`: `str | None`
* `ref`: `trace.refs.ObjectRef | None`
* `dataset`: `<class 'dataset.dataset.Dataset'>`
* `scorers`: `list[typing.Annotated[trace.op_protocol.Op | flow.scorer.Scorer, BeforeValidator(func=<function cast_to_scorer at 0x7f136d430d60>, json_schema_input_type=PydanticUndefined)]] | None`
* `preprocess_model_input`: `collections.abc.Callable[[dict], dict] | None`
* `trials`: `<class 'int'>`
* `metadata`: `dict[str, typing.Any] | None`
* `evaluation_name`: `str | collections.abc.Callable[trace.call.Call, str] | None`

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace/op.py#L381)

### <kbd>method</kbd> `evaluate`

```python theme={"system"}
evaluate(model: Op | Model) → dict
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/evaluation/eval.py#L205)

### <kbd>classmethod</kbd> `from_obj`

```python theme={"system"}
from_obj(obj: WeaveObject) → Self
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/evaluation/eval.py#L329)

### <kbd>method</kbd> `get_eval_results`

```python theme={"system"}
get_eval_results(model: Op | Model) → EvaluationResults
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/evaluation/eval.py#L397)

### <kbd>method</kbd> `get_evaluate_calls`

```python theme={"system"}
get_evaluate_calls() → PaginatedIterator[CallSchema, WeaveObject]
```

Retrieve all evaluation calls that used this Evaluation object.

Note that this returns a CallsIter instead of a single call because it's possible to have multiple evaluation calls for a single evaluation (e.g. if you run the same evaluation multiple times).

**Returns:**

* **`CallsIter`**:  An iterator over Call objects representing evaluation runs.

**Raises:**

* **`ValueError`**:  If the evaluation has no ref (hasn't been saved/run yet).

**Examples:**

```python theme={"system"}
evaluation = Evaluation(dataset=examples, scorers=[scorer])
await evaluation.evaluate(model)  # Run evaluation first
calls = evaluation.get_evaluate_calls()
for call in calls:
     print(f"Evaluation run: {call.id} at {call.started_at}")
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/evaluation/eval.py#L433)

### <kbd>method</kbd> `get_score_calls`

```python theme={"system"}
get_score_calls() → dict[str, list[Call]]
```

Retrieve scorer calls for each evaluation run, grouped by trace ID.

**Returns:**

* **`dict[str, list[Call]]`**:  A dictionary mapping trace IDs to lists of scorer Call objects.  Each trace ID represents one evaluation run, and the list contains all scorer  calls executed during that run.

**Examples:**

```python theme={"system"}
evaluation = Evaluation(dataset=examples, scorers=[accuracy_scorer, f1_scorer])
await evaluation.evaluate(model)
score_calls = evaluation.get_score_calls()
for trace_id, calls in score_calls.items():
     print(f"Trace {trace_id}: {len(calls)} scorer calls")
     for call in calls:
         scorer_name = call.summary.get("weave", {}).get("trace_name")
         print(f"  Scorer: {scorer_name}, Output: {call.output}")
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/evaluation/eval.py#L472)

### <kbd>method</kbd> `get_scores`

```python theme={"system"}
get_scores() → dict[str, dict[str, list[Any]]]
```

Extract and organize scorer outputs from evaluation runs.

**Returns:**

* **`dict[str, dict[str, list[Any]]]`**:  A nested dictionary structure where:
  * First level keys are trace IDs (evaluation runs)
  * Second level keys are scorer names
  * Values are lists of scorer outputs for that run and scorer

**Examples:**

```python theme={"system"}
evaluation = Evaluation(dataset=examples, scorers=[accuracy_scorer, f1_scorer])
await evaluation.evaluate(model)
scores = evaluation.get_scores()
# Access scores by trace and scorer
for trace_id, trace_scores in scores.items():
         print(f"Evaluation run {trace_id}:")
         for scorer_name, outputs in trace_scores.items():
             print(f"  {scorer_name}: {outputs}")
```

Expected output:

```
{
     "trace_123": {
     "accuracy_scorer": [{"accuracy": 0.85}],
     "f1_scorer": [{"f1": 0.78}]
     }
}
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/pydantic/_internal/_model_construction.py#L249)

### <kbd>method</kbd> `model_post_init`

```python theme={"system"}
model_post_init(context: Any) → None
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace/op.py#L266)

### <kbd>method</kbd> `predict_and_score`

```python theme={"system"}
predict_and_score(model: Op | Model, example: dict) → dict
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace/op.py#L306)

### <kbd>method</kbd> `summarize`

```python theme={"system"}
summarize(eval_table: EvaluationResults) → dict
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/evaluation/eval_imperative.py#L642)

## <kbd>class</kbd> `EvaluationLogger`

This class provides an imperative interface for logging evaluations.

An evaluation is started automatically when the first prediction is logged using the `log_prediction` method, and finished when the `log_summary` method is called.

Each time you log a prediction, you will get back a `ScoreLogger` object. You can use this object to log scores and metadata for that specific prediction. For more information, see the `ScoreLogger` class.

Basic usage - log predictions with inputs and outputs directly:

```python theme={"system"}
ev = EvaluationLogger()

# Log predictions with known inputs/outputs
pred = ev.log_prediction(inputs={'q': 'Hello'}, outputs={'a': 'Hi there!'})
pred.log_score("correctness", 0.9)

# Finish the evaluation
ev.log_summary({"avg_score": 0.9})
```

Advanced usage - use context manager for dynamic outputs and nested operations:

```python theme={"system"}
ev = EvaluationLogger()

# Use context manager when you need to capture nested operations
with ev.log_prediction(inputs={'q': 'Hello'}) as pred:
     # Any operations here (like LLM calls) automatically become
     # children of the predict call
     response = your_llm_call(...)
     pred.output = response.content
     pred.log_score("correctness", 0.9)

# Finish the evaluation
ev.log_summary({"avg_score": 0.9})
```

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/evaluation/eval_imperative.py#L684)

### <kbd>method</kbd> `__init__`

```python theme={"system"}
__init__(
    name: 'str | None' = None,
    model: 'Model | dict | str | None' = None,
    dataset: 'Dataset | list[dict] | str | None' = None,
    eval_attributes: 'dict[str, Any] | None' = None,
    scorers: 'list[str] | None' = None
) → None
```

***

#### <kbd>property</kbd> attributes

***

#### <kbd>property</kbd> ui\_url

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/evaluation/eval_imperative.py#L1106)

### <kbd>method</kbd> `fail`

```python theme={"system"}
fail(exception: 'BaseException') → None
```

Convenience method to fail the evaluation with an exception.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/evaluation/eval_imperative.py#L1090)

### <kbd>method</kbd> `finish`

```python theme={"system"}
finish(exception: 'BaseException | None' = None) → None
```

Clean up the evaluation resources explicitly without logging a summary.

Ensures all prediction calls and the main evaluation call are finalized. This is automatically called if the logger is used as a context manager.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/evaluation/eval_imperative.py#L950)

### <kbd>method</kbd> `log_example`

```python theme={"system"}
log_example(
    inputs: 'dict[str, Any]',
    output: 'Any',
    scores: 'dict[str, ScoreType]'
) → None
```

Log a complete example with inputs, output, and scores.

This is a convenience method that combines log\_prediction and log\_score for when you have all the data upfront.

**Args:**

* **`inputs`**: The input data for the prediction
* **`output`**: The output value
* **`scores`**: Dictionary mapping scorer names to score values

**Example:**

```python theme={"system"}
ev = EvaluationLogger()
ev.log_example(
    inputs={'q': 'What is 2+2?'},
    output='4',
    scores={'correctness': 1.0, 'fluency': 0.9}
)
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/evaluation/eval_imperative.py#L877)

### <kbd>method</kbd> `log_prediction`

```python theme={"system"}
log_prediction(inputs: 'dict[str, Any]', output: 'Any' = None) → ScoreLogger
```

Log a prediction to the Evaluation.

Returns a ScoreLogger that can be used directly or as a context manager.

**Args:**

* **`inputs`**: The input data for the prediction
* **`output`**: The output value. Defaults to None. Can be set later using pred.output.

**Returns:**
ScoreLogger for logging scores and optionally finishing the prediction.

Example (direct):

* **`pred = ev.log_prediction({'q'`**:  '...'}, output="answer") pred.log\_score("correctness", 0.9) pred.finish()

Example (context manager):

* **`with ev.log_prediction({'q'`**:  '...'}) as pred:  response = model(...)  pred.output = response  pred.log\_score("correctness", 0.9) # Automatically calls finish() on exit

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/evaluation/eval_imperative.py#L989)

### <kbd>method</kbd> `log_summary`

```python theme={"system"}
log_summary(summary: 'dict | None' = None, auto_summarize: 'bool' = True) → None
```

Log a summary dict to the Evaluation.

This will calculate the summary, call the summarize op, and then finalize the evaluation, meaning no more predictions or scores can be logged.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/evaluation/eval_imperative.py#L1038)

### <kbd>method</kbd> `set_view`

```python theme={"system"}
set_view(
    name: 'str',
    content: 'Content | str',
    extension: 'str | None' = None,
    mimetype: 'str | None' = None,
    metadata: 'dict[str, Any] | None' = None,
    encoding: 'str' = 'utf-8'
) → None
```

Attach a view to the evaluation's main call summary under `weave.views`.

Saves the provided content as an object in the project and writes its reference URI under `summary.weave.views.<name>` for the evaluation's `evaluate` call. String inputs are wrapped as text content using `Content.from_text` with the provided extension or mimetype.

**Args:**

* **`name`**: The view name to display, used as the key under `summary.weave.views`.
* **`content`**: A `weave.Content` instance or string to serialize.
* **`extension`**: Optional file extension for string content inputs.
* **`mimetype`**: Optional MIME type for string content inputs.
* **`metadata`**: Optional metadata attached to newly created `Content`.
* **`encoding`**: Text encoding for string content inputs.

**Returns:**
None

**Examples:**

```python theme={"system"}
import weave
ev = weave.EvaluationLogger()
ev.set_view("report", "# Report", extension="md")
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/type_handlers/File/file.py#L30)

## <kbd>class</kbd> `File`

A class representing a file with path, mimetype, and size information.

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/type_handlers/File/file.py#L34)

### <kbd>method</kbd> `__init__`

```python theme={"system"}
__init__(path: 'str | Path', mimetype: 'str | None' = None)
```

Initialize a File object.

**Args:**

***

#### <kbd>property</kbd> filename

Get the filename of the file.

* **`path`**: Path to the file (string or pathlib.Path)
* **`mimetype`**: Optional MIME type of the file - will be inferred from extension if not provided

**Returns:**

* **`str`**:  The name of the file without the directory path.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/type_handlers/File/file.py#L60)

### <kbd>method</kbd> `open`

```python theme={"system"}
open() → bool
```

Open the file using the operating system's default application.

This method uses the platform-specific mechanism to open the file with the default application associated with the file's type.

**Returns:**

* **`bool`**:  True if the file was successfully opened, False otherwise.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/type_handlers/File/file.py#L81)

### <kbd>method</kbd> `save`

```python theme={"system"}
save(dest: 'str | Path') → None
```

Copy the file to the specified destination path.

**Args:**

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/conversation/conversation.py#L418)

## <kbd>class</kbd> `LLM`

One LLM API call. Maps to a chat OTel span.

* **`dest`**: Destination path where the file will be copied to (string or pathlib.Path)  The destination path can be a file or a directory.

**Pydantic Fields:**

* `model`: `<class 'str'>`
* `provider_name`: `<class 'str'>`
* `response_id`: `<class 'str'>`
* `response_model`: `<class 'str'>`
* `output_type`: `<class 'str'>`
* `system_instructions`: `list[str]`
* `usage`: `<class 'conversation.types.Usage'>`
* `reasoning`: `<class 'conversation.types.Reasoning'>`
* `finish_reasons`: `list[str]`
* `input_messages`: `list[conversation.types.Message]`
* `output_messages`: `list[conversation.types.Message]`
* `media_attachments`: `list[conversation.types.MediaAttachment]`
* `request_temperature`: `float | None`
* `request_max_tokens`: `int | None`
* `request_top_p`: `float | None`
* `request_frequency_penalty`: `float | None`
* `request_presence_penalty`: `float | None`
* `request_seed`: `int | None`
* `request_stop_sequences`: `list[str]`
* `request_choice_count`: `int | None`
* `started_at`: `datetime.datetime | None`
* `ended_at`: `datetime.datetime | None`

[Source](https://github.com/wandb/weave/blob/v0.53.1/typing_extensions.py#L257)

### <kbd>method</kbd> `add_event`

```python theme={"system"}
add_event(
    name: 'str',
    attributes: 'dict[str, Any] | None' = None,
    timestamp: 'datetime | None' = None
) → Self
```

Record an OTel span event at a point in time within this span.

> [!WARNING]
>
> **Deprecated:** Record this data with `set_attributes` instead. OpenTelemetry is phasing out the Span Event API (`Span.add_event`). `add_event` still works and existing span-event data stays valid. See [https://opentelemetry.io/blog/2026/deprecating-span-events/](https://opentelemetry.io/blog/2026/deprecating-span-events/).

Use for marker / lifecycle data — permission prompts (e.g. `weave.permission_request`), lifecycle transitions (e.g. `spawned` / `streaming` / `finished`), or any custom milestone that happens at a point in time within the span's lifetime (vs an attribute, which is a property of the span as a whole).

Must be called between span start and span end (inside `with`). Outside that window the call is a no-op and logs a warning.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/conversation/conversation.py#L462)

### <kbd>method</kbd> `attach_media`

```python theme={"system"}
attach_media(
    content: 'bytes | str' = '',
    uri: 'str' = '',
    file_id: 'str' = '',
    mime_type: 'str' = '',
    modality: 'str' = ''
) → LLM
```

Attach media to this LLM call.

Creates a `Content` object from the provided data, publishes it to get a `weave://` ref, and stores only that ref.  Exactly one of `content`, `uri`, or `file_id` must be provided.

The publish (which uploads the media) runs on a dedicated background thread so the call returns immediately without blocking the caller; one thread is dispatched per attachment so multiple uploads proceed in parallel. The placeholder `MediaAttachment` is appended synchronously and its `ref` is filled in once the upload completes. Refs are guaranteed populated before the span is emitted (the build path waits on the in-flight uploads via `_await_uploads`).

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/conversation/conversation.py#L555)

### <kbd>method</kbd> `attach_media_url`

```python theme={"system"}
attach_media_url(url: 'str', modality: 'str' = '') → LLM
```

Attach a media URL to this LLM call.

Convenience over `attach_media` for the common case where the caller has a URL string from an upstream message. `data:` URLs are parsed into bytes and published; plain URIs are fetched and published. Empty URLs are ignored. Returns `self` for chaining.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/conversation/conversation.py#L690)

### <kbd>method</kbd> `end`

```python theme={"system"}
end() → None
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/pydantic/_internal/_model_construction.py#L448)

### <kbd>method</kbd> `model_post_init`

```python theme={"system"}
model_post_init(context: 'Any') → None
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/conversation/conversation.py#L452)

### <kbd>method</kbd> `output`

```python theme={"system"}
output(content: 'str') → LLM
```

Append an assistant message to output\_messages.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/conversation/conversation.py#L572)

### <kbd>method</kbd> `record`

```python theme={"system"}
record(
    input_messages: 'list[Message] | None' = None,
    output_messages: 'list[Message] | None' = None,
    media_attachments: 'list[MediaAttachment] | None' = None,
    usage: 'Usage | None' = None,
    reasoning: 'Reasoning | str | None' = None,
    response_id: 'str | None' = None,
    response_model: 'str | None' = None,
    finish_reasons: 'list[str] | None' = None,
    output_type: 'str | None' = None
) → LLM
```

Set multiple LLM-call fields in one call.

Manually-instrumented agents typically build up a chat span by assigning eight or more individual fields at the end of an LLM call (`input_messages`, `output_messages`, `usage`, `response_id`, etc.). `record(...)` collapses those into a single keyword call so the recording site stays compact.

Only fields explicitly passed (non-`None`) are applied — existing values are preserved. `reasoning` accepts either a `Reasoning` instance or a plain string (wrapped automatically). Returns `self` for chaining.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/conversation/conversation.py#L241)

### <kbd>method</kbd> `set_attributes`

```python theme={"system"}
set_attributes(attributes: 'dict[str, Any]') → Self
```

Stamp arbitrary OTel attributes on this span.

Pass a dict whether you have one key or many — single-key callers use `span.set_attributes({"weave.tag": "value"})`. Mirrors OTel's `Span.set_attributes`.

Must be called between span start and span end — i.e. inside a `with` block. Outside that window the call is a no-op and logs a warning. For batch ingest, populate the object's declared fields directly and pass it to `log_turn` / `log_conversation`.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/conversation/conversation.py#L457)

### <kbd>method</kbd> `think`

```python theme={"system"}
think(content: 'str') → LLM
```

Set reasoning/chain-of-thought content.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/conversation/types.py#L256)

## <kbd>class</kbd> `LogResult`

Result of a batch log\_\* call.

**Pydantic Fields:**

* `conversation_id`: `<class 'str'>`
* `trace_ids`: `list[str]`
* `root_span_ids`: `list[str]`
* `span_count`: `<class 'int'>`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/rich/markdown.py#L513)

## <kbd>class</kbd> `Markdown`

A Markdown renderable.

**Args:**

* **`markup`** (str):  A string containing markdown.
* **`code_theme`** (str, optional):  Pygments theme for code blocks. Defaults to "monokai". See [https://pygments.org/styles/](https://pygments.org/styles/) for code themes.
* **`justify`** (JustifyMethod, optional):  Justify value for paragraphs. Defaults to None.
* **`style`** (Union\[str, Style], optional):  Optional style to apply to markdown.
* **`hyperlinks`** (bool, optional):  Enable hyperlinks. Defaults to `True`.

[Source](https://github.com/wandb/weave/blob/v0.53.1/rich/markdown.py#L549)

### <kbd>method</kbd> `__init__`

```python theme={"system"}
__init__(
    markup: 'str',
    code_theme: 'str' = 'monokai',
    justify: 'JustifyMethod | None' = None,
    style: 'str | Style' = 'none',
    hyperlinks: 'bool' = True,
    inline_code_lexer: 'str | None' = None,
    inline_code_theme: 'str | None' = None
) → None
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/conversation/types.py#L243)

## <kbd>class</kbd> `MediaAttachment`

A media attachment on an LLM call.

Always holds a `weave://` content ref URI.  Raw bytes, data-URLs, and plain HTTP URIs are converted to a published `Content` object by `LLM.attach_media` before being stored here.

* **`inline_code_lexer`**: (str, optional): Lexer to use if inline code highlighting is  enabled. Defaults to None.
* **`inline_code_theme`**: (Optional\[str], optional): Pygments theme for inline code  highlighting, or None for no highlighting. Defaults to None.

**Pydantic Fields:**

* `ref`: `<class 'str'>`
* `modality`: `<class 'str'>`
* `mime_type`: `<class 'str'>`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/conversation/types.py#L158)

## <kbd>class</kbd> `Message`

A single message in a conversation.

Two construction styles are supported:

1. Flat (back-compat, ergonomic for plain text):  `Message(role="assistant", content="Hi there")`

2. Explicit parts (richer — supports tool calls, mixed reasoning+text,  inline media):  `Message(role="assistant", parts=[TextPart(content="Let me check"),  ToolCallPart(id="c1", name="get_weather", arguments='{...}')])`

When `parts` is non-empty it is the canonical representation. When empty, the serializer synthesizes a single TextPart (or ToolCallResponsePart for `role="tool"`) from the flat fields.

**Pydantic Fields:**

* `role`: `typing.Literal['user', 'assistant', 'system', 'tool']`
* `content`: `<class 'str'>`
* `tool_call_id`: `<class 'str'>`
* `tool_name`: `<class 'str'>`
* `parts`: `list[typing.Annotated[conversation.types.TextPart | conversation.types.ReasoningPart | conversation.types.ToolCallPart | conversation.types.ToolCallResponsePart | conversation.types.BlobPart | conversation.types.UriPart | conversation.types.FilePart, FieldInfo(annotation=NoneType, required=True, discriminator='type')]]`

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/conversation/types.py#L192)

### <kbd>classmethod</kbd> `assistant`

```python theme={"system"}
assistant(
    text: 'str' = '',
    tool_calls: 'list[ToolCallPart] | None' = None
) → Message
```

Build an assistant message with optional text and tool calls.

Use plain text for simple replies; pass `tool_calls` when the assistant requests one or more tools. When both are present the text is emitted as a leading `TextPart` followed by each `ToolCallPart` so the chat view renders them inline.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/conversation/types.py#L187)

### <kbd>classmethod</kbd> `system`

```python theme={"system"}
system(text: 'str') → Message
```

Build a system message from plain text.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/conversation/types.py#L214)

### <kbd>classmethod</kbd> `tool_result`

```python theme={"system"}
tool_result(call_id: 'str', output: 'Any') → Message
```

Build a tool-result message for a previously-requested tool call.

`output` may be a string, dict, list, scalar, or `None` — the underlying `ToolCallResponsePart` JSON-encodes non-strings.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/conversation/types.py#L182)

### <kbd>classmethod</kbd> `user`

```python theme={"system"}
user(text: 'str') → Message
```

Build a user message from plain text.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/prompt/prompt.py#L164)

## <kbd>class</kbd> `MessagesPrompt`

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/prompt/prompt.py#L168)

### <kbd>method</kbd> `__init__`

```python theme={"system"}
__init__(messages: list[dict])
```

**Pydantic Fields:**

* `name`: `str | None`
* `description`: `str | None`
* `ref`: `trace.refs.ObjectRef | None`
* `messages`: `list[dict]`

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/prompt/prompt.py#L180)

### <kbd>method</kbd> `format`

```python theme={"system"}
format(**kwargs: Any) → list
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/prompt/prompt.py#L172)

### <kbd>method</kbd> `format_message`

```python theme={"system"}
format_message(message: dict, **kwargs: Any) → dict
```

Format a single message by replacing template variables.

This method delegates to the standalone format\_message\_with\_template\_vars function for the actual formatting logic.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/prompt/prompt.py#L183)

### <kbd>classmethod</kbd> `from_obj`

```python theme={"system"}
from_obj(obj: WeaveObject) → Self
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/flow/model.py#L25)

## <kbd>class</kbd> `Model`

Intended to capture a combination of code and data the operates on an input. For example it might call an LLM with a prompt to make a prediction or generate text.

When you change the attributes or the code that defines your model, these changes will be logged and the version will be updated. This ensures that you can compare the predictions across different versions of your model. Use this to iterate on prompts or to try the latest LLM and compare predictions across different settings

**Examples:**

```python theme={"system"}
class YourModel(Model):
     attribute1: str
     attribute2: int

     @weave.op
     def predict(self, input_data: str) -> dict:
         # Model logic goes here
         prediction = self.attribute1 + ' ' + input_data
         return {'pred': prediction}
```

**Pydantic Fields:**

* `name`: `str | None`
* `description`: `str | None`
* `ref`: `trace.refs.ObjectRef | None`

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/flow/model.py#L51)

### <kbd>method</kbd> `get_infer_method`

```python theme={"system"}
get_infer_method() → Callable
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/flow/monitor.py#L48)

## <kbd>class</kbd> `Monitor`

Sets up a monitor to score incoming calls automatically.

Note that the op name will be converted to a weave ref using the entity and project from the Weave client. If you're operating on multiple entities and projects with the same client, you'll need to specify a fully-qualified weave ref. See \_normalized\_op\_names for more details.

**Examples:**

```python theme={"system"}
import weave
from weave.scorers import ValidJSONScorer

json_scorer = ValidJSONScorer()

my_monitor = weave.Monitor(
     name="my-monitor",
     description="This is a test monitor",
     sampling_rate=0.5,
     op_names=["my_op"],
     query={
         "$expr": {
             "$gt": [
                 {
                         "$getField": "started_at"
                     },
                     {
                         "$literal": 1742540400
                     }
                 ]
             }
         }
     },
     scorers=[json_scorer],
)

my_monitor.activate()
```

**Pydantic Fields:**

* `name`: `str | None`
* `description`: `str | None`
* `ref`: `trace.refs.ObjectRef | None`
* `sampling_rate`: `<class 'float'>`
* `scorers`: `list[flow.scorer.Scorer]`
* `op_names`: `list[typing.Union[typing.Literal['genai.turn_ended'], str]]`
* `query`: `trace_server.interface.query.Query | None`
* `is_traced`: `<class 'bool'>`
* `active`: `<class 'bool'>`
* `scorer_debounce_config`: `flow.monitor.ScorerDebounceConfig | None`

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/flow/monitor.py#L141)

### <kbd>method</kbd> `activate`

```python theme={"system"}
activate() → ObjectRef
```

Activates the monitor.

**Returns:**
The ref to the monitor.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/flow/monitor.py#L152)

### <kbd>method</kbd> `deactivate`

```python theme={"system"}
deactivate() → ObjectRef
```

Deactivates the monitor.

**Returns:**
The ref to the monitor.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/flow/monitor.py#L203)

### <kbd>classmethod</kbd> `from_obj`

```python theme={"system"}
from_obj(obj: WeaveObject) → Self
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/flow/monitor.py#L118)

### <kbd>method</kbd> `model_post_init`

```python theme={"system"}
model_post_init(context: Any) → None
```

Normalize `op_names` at construction when a client is available.

Publishing has no per-object hook, so to also cover a bare `weave.publish(monitor)` (no `activate()`), expand short names here: anyone who will publish has typically called `weave.init`, so the client is set when the monitor is constructed.

Several use cases perform construction without a client, such as unit tests, inspection, deserializing a stored monitor in a worker. The guard on `get_weave_client()` allows construction without a client. Normalization won't occur in this case, but that should be ok because stored monitors already hold full refs.

There is an edge case where a monitor can be created using the SDK without normalizing: if the user constructs the monitor, then calls weave.init, and then publishes it. Calling `activate()` or `deactivate()` could be a workaround for this use-case.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/object/obj.py#L26)

## <kbd>class</kbd> `Object`

Base class for Weave objects that can be tracked and versioned.

This class extends Pydantic's BaseModel to provide Weave-specific functionality for object tracking, referencing, and serialization. Objects can have names, descriptions, and references that allow them to be stored and retrieved from the Weave system.

**Attributes:**

* **`name`** (str | None):  A human-readable name for the object.
* **`description`** (str | None):  A description of what the object represents.
* **`ref`** (ObjectRef | None):  A reference to the object in the Weave system.

**Examples:**

```python theme={"system"}
# Create a simple object
obj = Object(name="my_object", description="A test object")

# Create an object from a URI
obj = Object.from_uri("weave:///entity/project/object:digest")
```

**Pydantic Fields:**

* `name`: `str | None`
* `description`: `str | None`
* `ref`: `trace.refs.ObjectRef | None`

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/object/obj.py#L65)

### <kbd>classmethod</kbd> `from_uri`

```python theme={"system"}
from_uri(uri: str, objectify: bool = True) → Self
```

Create an object instance from a Weave URI.

**Args:**

* **`uri`** (str):  The Weave URI pointing to the object.
* **`objectify`** (bool):  Whether to objectify the result. Defaults to True.

**Returns:**

* **`Self`**:  An instance of the class created from the URI.

**Raises:**

* **`NotImplementedError`**:  If the class doesn't implement the required  methods for deserialization.

**Examples:**

```python theme={"system"}
obj = MyObject.from_uri("weave:///entity/project/object:digest")
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/object/obj.py#L108)

### <kbd>classmethod</kbd> `handle_relocatable_object`

```python theme={"system"}
handle_relocatable_object(
    v: Any,
    handler: ValidatorFunctionWrapHandler,
    info: ValidationInfo
) → Any
```

Handle validation of relocatable objects including ObjectRef and WeaveObject.

This validator handles special cases where the input is an ObjectRef or WeaveObject that needs to be properly converted to a standard Object instance. It ensures that references are preserved and that ignored types are handled correctly during the validation process.

**Args:**

* **`v`** (Any):  The value to validate.
* **`handler`** (ValidatorFunctionWrapHandler):  The standard pydantic validation handler.
* **`info`** (ValidationInfo):  Validation context information.

**Returns:**

* **`Any`**:  The validated object instance.

**Examples:**
This method is called automatically during object creation and validation. It handles cases like:

```python theme={"system"}
# When an ObjectRef is passed
obj = MyObject(some_object_ref)

# When a WeaveObject is passed
obj = MyObject(some_weave_object)
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/object/obj.py#L91)

### <kbd>classmethod</kbd> `strip_weave_serialization_metadata`

```python theme={"system"}
strip_weave_serialization_metadata(data: Any) → Any
```

Strip weave serialization metadata from dict inputs.

Weave's serialization adds \_type, \_class\_name, and \_bases to dicts for type reconstruction.  These are not real model fields and must be removed before Pydantic validation, which uses extra="forbid".

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace/refs.py#L183)

## <kbd>class</kbd> `ObjectRef`

ObjectRef(entity: 'str', project: 'str', name: 'str', \_digest: 'str | Future\[str]', \_extra: 'tuple\[str | Future\[str], ...]' = ())

[Source](https://github.com/wandb/weave/blob/v0.53.1/../../../../weave/trace/refs/__init__)

### <kbd>method</kbd> `__init__`

```python theme={"system"}
__init__(
    entity: 'str',
    project: 'str',
    name: 'str',
    _digest: 'str | Future[str]',
    _extra: 'tuple[str | Future[str], ]' = ()
) → None
```

***

#### <kbd>property</kbd> digest

***

#### <kbd>property</kbd> extra

***

#### <kbd>property</kbd> is\_digest\_resolved

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace/refs.py#L191)

### <kbd>method</kbd> `as_param_dict`

```python theme={"system"}
as_param_dict() → dict
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace/refs.py#L287)

### <kbd>method</kbd> `delete`

```python theme={"system"}
delete() → None
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace/refs.py#L243)

### <kbd>method</kbd> `get`

```python theme={"system"}
get(objectify: 'bool' = True) → Any
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace/refs.py#L271)

### <kbd>method</kbd> `is_descended_from`

```python theme={"system"}
is_descended_from(potential_ancestor: 'ObjectRef') → bool
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace/refs.py#L93)

### <kbd>method</kbd> `maybe_parse_uri`

```python theme={"system"}
maybe_parse_uri(s: 'str') → AnyRef | None
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace/refs.py#L294)

### <kbd>method</kbd> `parse_uri`

```python theme={"system"}
parse_uri(uri: 'str') → ObjectRef
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace/refs.py#L173)

### <kbd>method</kbd> `with_attr`

```python theme={"system"}
with_attr(attr: 'str') → Self
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace/refs.py#L165)

### <kbd>method</kbd> `with_extra`

```python theme={"system"}
with_extra(extra: 'tuple[str | Future[str], ]') → Self
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace/refs.py#L176)

### <kbd>method</kbd> `with_index`

```python theme={"system"}
with_index(index: 'int') → Self
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace/refs.py#L179)

### <kbd>method</kbd> `with_item`

```python theme={"system"}
with_item(item_digest: 'str | Future[str]') → Self
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace/refs.py#L170)

### <kbd>method</kbd> `with_key`

```python theme={"system"}
with_key(key: 'str') → Self
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/prompt/prompt.py#L83)

## <kbd>class</kbd> `Prompt`

**Pydantic Fields:**

* `name`: `str | None`
* `description`: `str | None`
* `ref`: `trace.refs.ObjectRef | None`

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/prompt/prompt.py#L84)

### <kbd>method</kbd> `format`

```python theme={"system"}
format(**kwargs: Any) → Any
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/flow/saved_view.py#L494)

## <kbd>class</kbd> `SavedView`

A fluent-style class for working with SavedView objects.

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/flow/saved_view.py#L500)

### <kbd>method</kbd> `__init__`

```python theme={"system"}
__init__(view_type: 'str' = 'traces', label: 'str' = 'SavedView') → None
```

***

#### <kbd>property</kbd> entity

***

#### <kbd>property</kbd> label

***

#### <kbd>property</kbd> project

***

#### <kbd>property</kbd> view\_type

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/flow/saved_view.py#L624)

### <kbd>method</kbd> `add_column`

```python theme={"system"}
add_column(path: 'str | ObjectPath', label: 'str | None' = None) → SavedView
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/flow/saved_view.py#L633)

### <kbd>method</kbd> `add_columns`

```python theme={"system"}
add_columns(*columns: 'str') → SavedView
```

Convenience method for adding multiple columns to the grid.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/flow/saved_view.py#L525)

### <kbd>method</kbd> `add_filter`

```python theme={"system"}
add_filter(
    field: 'str',
    operator: 'str',
    value: 'Any | None' = None
) → SavedView
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/flow/saved_view.py#L599)

### <kbd>method</kbd> `add_sort`

```python theme={"system"}
add_sort(field: 'str', direction: 'SortDirection') → SavedView
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/flow/saved_view.py#L664)

### <kbd>method</kbd> `column_index`

```python theme={"system"}
column_index(path: 'int | str | ObjectPath') → int
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/flow/saved_view.py#L579)

### <kbd>method</kbd> `filter_op`

```python theme={"system"}
filter_op(op_name: 'str | None') → SavedView
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/flow/saved_view.py#L849)

### <kbd>method</kbd> `get_calls`

```python theme={"system"}
get_calls(
    limit: 'int | None' = None,
    offset: 'int | None' = None,
    include_costs: 'bool' = False,
    include_feedback: 'bool' = False,
    all_columns: 'bool' = False
) → CallsIter
```

Get calls matching this saved view's filters and settings.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/flow/saved_view.py#L907)

### <kbd>method</kbd> `get_known_columns`

```python theme={"system"}
get_known_columns(num_calls_to_query: 'int | None' = None) → list[str]
```

Get the set of columns that are known to exist.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/flow/saved_view.py#L917)

### <kbd>method</kbd> `get_table_columns`

```python theme={"system"}
get_table_columns() → list[TableColumn]
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/flow/saved_view.py#L618)

### <kbd>method</kbd> `hide_column`

```python theme={"system"}
hide_column(col_name: 'str') → SavedView
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/flow/saved_view.py#L639)

### <kbd>method</kbd> `insert_column`

```python theme={"system"}
insert_column(
    idx: 'int',
    path: 'str | ObjectPath',
    label: 'str | None' = None
) → SavedView
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/flow/saved_view.py#L977)

### <kbd>classmethod</kbd> `load`

```python theme={"system"}
load(ref: 'str') → Self
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/flow/saved_view.py#L742)

### <kbd>method</kbd> `page_size`

```python theme={"system"}
page_size(page_size: 'int') → SavedView
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/flow/saved_view.py#L712)

### <kbd>method</kbd> `pin_column_left`

```python theme={"system"}
pin_column_left(col_name: 'str') → SavedView
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/flow/saved_view.py#L722)

### <kbd>method</kbd> `pin_column_right`

```python theme={"system"}
pin_column_right(col_name: 'str') → SavedView
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/flow/saved_view.py#L684)

### <kbd>method</kbd> `remove_column`

```python theme={"system"}
remove_column(path: 'int | str | ObjectPath') → SavedView
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/flow/saved_view.py#L703)

### <kbd>method</kbd> `remove_columns`

```python theme={"system"}
remove_columns(*columns: 'str') → SavedView
```

Remove columns from the saved view.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/flow/saved_view.py#L548)

### <kbd>method</kbd> `remove_filter`

```python theme={"system"}
remove_filter(index_or_field: 'int | str') → SavedView
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/flow/saved_view.py#L563)

### <kbd>method</kbd> `remove_filters`

```python theme={"system"}
remove_filters() → SavedView
```

Remove all filters from the saved view.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/flow/saved_view.py#L521)

### <kbd>method</kbd> `rename`

```python theme={"system"}
rename(label: 'str') → SavedView
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/flow/saved_view.py#L678)

### <kbd>method</kbd> `rename_column`

```python theme={"system"}
rename_column(path: 'int | str | ObjectPath', label: 'str') → SavedView
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/flow/saved_view.py#L834)

### <kbd>method</kbd> `save`

```python theme={"system"}
save() → SavedView
```

Publish the saved view to the server.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/flow/saved_view.py#L658)

### <kbd>method</kbd> `set_columns`

```python theme={"system"}
set_columns(*columns: 'str') → SavedView
```

Set the columns to be displayed in the grid.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/flow/saved_view.py#L612)

### <kbd>method</kbd> `show_column`

```python theme={"system"}
show_column(col_name: 'str') → SavedView
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/flow/saved_view.py#L606)

### <kbd>method</kbd> `sort_by`

```python theme={"system"}
sort_by(field: 'str', direction: 'SortDirection') → SavedView
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/flow/saved_view.py#L890)

### <kbd>method</kbd> `to_grid`

```python theme={"system"}
to_grid(limit: 'int | None' = None) → Grid
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/flow/saved_view.py#L771)

### <kbd>method</kbd> `to_rich_table_str`

```python theme={"system"}
to_rich_table_str() → str
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/flow/saved_view.py#L754)

### <kbd>method</kbd> `ui_url`

```python theme={"system"}
ui_url() → str | None
```

URL to show this saved view in the UI.

Note this is the "result" page with traces etc, not the URL for the view object.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/flow/saved_view.py#L732)

### <kbd>method</kbd> `unpin_column`

```python theme={"system"}
unpin_column(col_name: 'str') → SavedView
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/flow/scorer.py#L30)

## <kbd>class</kbd> `Scorer`

**Pydantic Fields:**

* `name`: `str | None`
* `description`: `str | None`
* `ref`: `trace.refs.ObjectRef | None`
* `column_map`: `dict[str, str] | None`

***

#### <kbd>property</kbd> display\_name

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/flow/scorer.py#L57)

### <kbd>classmethod</kbd> `from_obj`

```python theme={"system"}
from_obj(obj: WeaveObject) → Self
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/flow/scorer.py#L36)

### <kbd>method</kbd> `model_post_init`

```python theme={"system"}
model_post_init(context: Any) → None
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace/op.py#L49)

### <kbd>method</kbd> `score`

```python theme={"system"}
score(output: Any, **kwargs: Any) → Any
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace/op.py#L53)

### <kbd>method</kbd> `summarize`

```python theme={"system"}
summarize(score_rows: list) → dict | None
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/conversation/_deprecated.py#L119)

## <kbd>class</kbd> `Session`

Deprecated alias of :class:`weave.Conversation`.

Accepts the old `session_id` / `session_name` constructor fields and also exposes them as read/write properties that proxy to `conversation_id` / `conversation_name`. The original `Session` had these as model fields, so old code that reads or assigns `s.session_id` keeps working.

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/conversation/_deprecated.py#L129)

### <kbd>method</kbd> `__init__`

```python theme={"system"}
__init__(**data: 'Any') → None
```

**Pydantic Fields:**

* `conversation_id`: `<class 'str'>`
* `conversation_name`: `<class 'str'>`
* `agent_name`: `<class 'str'>`
* `model`: `<class 'str'>`
* `agent_id`: `<class 'str'>`
* `agent_description`: `<class 'str'>`
* `agent_version`: `<class 'str'>`
* `include_content`: `<class 'bool'>`
* `continue_parent_trace`: `<class 'bool'>`
* `attributes`: `dict[str, typing.Any]`

#### <kbd>property</kbd> session\_id

Deprecated alias of :attr:`conversation_id`.

***

#### <kbd>property</kbd> session\_name

Deprecated alias of :attr:`conversation_name`.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/prompt/prompt.py#L88)

## <kbd>class</kbd> `StringPrompt`

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/prompt/prompt.py#L92)

### <kbd>method</kbd> `__init__`

```python theme={"system"}
__init__(content: str)
```

**Pydantic Fields:**

* `name`: `str | None`
* `description`: `str | None`
* `ref`: `trace.refs.ObjectRef | None`
* `content`: `<class 'str'>`

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/prompt/prompt.py#L96)

### <kbd>method</kbd> `format`

```python theme={"system"}
format(**kwargs: Any) → str
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/prompt/prompt.py#L99)

### <kbd>classmethod</kbd> `from_obj`

```python theme={"system"}
from_obj(obj: WeaveObject) → Self
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/conversation/conversation.py#L732)

## <kbd>class</kbd> `SubAgent`

A delegated agent invocation within a turn.

Maps to a nested invoke\_agent OTel span in the same trace.

**Pydantic Fields:**

* `name`: `<class 'str'>`
* `model`: `<class 'str'>`
* `agent_id`: `<class 'str'>`
* `agent_description`: `<class 'str'>`
* `agent_version`: `<class 'str'>`
* `system_instructions`: `list[str]`
* `started_at`: `datetime.datetime | None`
* `ended_at`: `datetime.datetime | None`

[Source](https://github.com/wandb/weave/blob/v0.53.1/typing_extensions.py#L257)

### <kbd>method</kbd> `add_event`

```python theme={"system"}
add_event(
    name: 'str',
    attributes: 'dict[str, Any] | None' = None,
    timestamp: 'datetime | None' = None
) → Self
```

Record an OTel span event at a point in time within this span.

> [!WARNING]
>
> **Deprecated:** Record this data with `set_attributes` instead. OpenTelemetry is phasing out the Span Event API (`Span.add_event`). `add_event` still works and existing span-event data stays valid. See [https://opentelemetry.io/blog/2026/deprecating-span-events/](https://opentelemetry.io/blog/2026/deprecating-span-events/).

Use for marker / lifecycle data — permission prompts (e.g. `weave.permission_request`), lifecycle transitions (e.g. `spawned` / `streaming` / `finished`), or any custom milestone that happens at a point in time within the span's lifetime (vs an attribute, which is a property of the span as a whole).

Must be called between span start and span end (inside `with`). Outside that window the call is a no-op and logs a warning.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/conversation/conversation.py#L843)

### <kbd>method</kbd> `end`

```python theme={"system"}
end() → None
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/conversation/conversation.py#L749)

### <kbd>method</kbd> `llm`

```python theme={"system"}
llm(
    model: 'str' = '',
    provider_name: 'str' = '',
    system_instructions: 'list[str] | None' = None
) → LLM
```

Start an LLM call within this sub-agent.

Sets the `_current_llm` contextvar so the LLM is visible via `get_current_llm()` regardless of whether a context manager is used.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/conversation/conversation.py#L773)

### <kbd>method</kbd> `record`

```python theme={"system"}
record(
    name: 'str | None' = None,
    model: 'str | None' = None,
    system_instructions: 'list[str] | None' = None,
    agent_id: 'str | None' = None,
    agent_description: 'str | None' = None,
    agent_version: 'str | None' = None
) → SubAgent
```

Set multiple sub-agent fields in one call.

Collapses the per-field assignments a manually-instrumented agent otherwise makes on a sub-agent (`system_instructions`, `agent_id`, ...) into a single keyword call. Only fields explicitly passed (non-`None`) are applied — existing values are preserved. Returns `self` for chaining. Mirrors `Turn.record` / `LLM.record`.

Note: on the streaming (`with`) path the sub-agent span is named from `name` at `__enter__`, so set `name` via `start_subagent` / `turn.subagent` rather than `record` if you need the span name to reflect it; `record` still updates the `gen_ai.agent.name` attribute.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/conversation/conversation.py#L241)

### <kbd>method</kbd> `set_attributes`

```python theme={"system"}
set_attributes(attributes: 'dict[str, Any]') → Self
```

Stamp arbitrary OTel attributes on this span.

Pass a dict whether you have one key or many — single-key callers use `span.set_attributes({"weave.tag": "value"})`. Mirrors OTel's `Span.set_attributes`.

Must be called between span start and span end — i.e. inside a `with` block. Outside that window the call is a no-op and logs a warning. For batch ingest, populate the object's declared fields directly and pass it to `log_turn` / `log_conversation`.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/conversation/conversation.py#L769)

### <kbd>method</kbd> `tool`

```python theme={"system"}
tool(name: 'str', arguments: 'str' = '', tool_call_id: 'str' = '') → Tool
```

Start a tool execution within this sub-agent.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace/table.py#L9)

## <kbd>class</kbd> `Table`

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace/table.py#L12)

### <kbd>method</kbd> `__init__`

```python theme={"system"}
__init__(rows: 'list[dict]') → None
```

***

#### <kbd>property</kbd> rows

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace/table.py#L50)

### <kbd>method</kbd> `append`

```python theme={"system"}
append(row: 'dict') → None
```

Add a row to the table.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace/table.py#L56)

### <kbd>method</kbd> `pop`

```python theme={"system"}
pop(index: 'int') → None
```

Remove a row at the given index from the table.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace/util.py#L105)

## <kbd>class</kbd> `ContextAwareThread`

A Thread that runs functions with the context of the caller.

This is a drop-in replacement for threading.Thread that ensures calls behave as expected inside the thread.  Weave requires certain contextvars to be set (see call\_context.py), but new threads do not automatically copy context from the parent, which can cause the call context to be lost -- not good!  This class automates contextvar copying so using this thread "just works" as the user probably expects.

You can achieve the same effect without this class by instead writing:

```python theme={"system"}
def run_with_context(func, *args, **kwargs):
     context = copy_context()
     def wrapper():
         context.run(func, *args, **kwargs)
     return wrapper

thread = threading.Thread(target=run_with_context(your_func, *args, **kwargs))
thread.start()
```

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace/util.py#L129)

### <kbd>method</kbd> `__init__`

```python theme={"system"}
__init__(*args: 'Any', **kwargs: 'Any') → None
```

***

#### <kbd>property</kbd> daemon

A boolean value indicating whether this thread is a daemon thread.

This must be set before start() is called, otherwise RuntimeError is raised. Its initial value is inherited from the creating thread; the main thread is not a daemon thread and therefore all threads created in the main thread default to daemon = False.

The entire Python program exits when only daemon threads are left.

***

#### <kbd>property</kbd> ident

Thread identifier of this thread or None if it has not been started.

This is a nonzero integer. See the get\_ident() function. Thread identifiers may be recycled when a thread exits and another thread is created. The identifier is available even after the thread has exited.

***

#### <kbd>property</kbd> name

A string used for identification purposes only.

It has no semantics. Multiple threads may be given the same name. The initial name is set by the constructor.

***

#### <kbd>property</kbd> native\_id

Native integral thread ID of this thread, or None if it has not been started.

This is a non-negative integer. See the get\_native\_id() function. This represents the Thread ID as reported by the kernel.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace/util.py#L133)

### <kbd>method</kbd> `run`

```python theme={"system"}
run() → None
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace/api.py#L535)

## <kbd>class</kbd> `ThreadContext`

Context object providing access to current thread and turn information.

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace/api.py#L538)

### <kbd>method</kbd> `__init__`

```python theme={"system"}
__init__(thread_id: 'str | None')
```

Initialize ThreadContext with the specified thread\_id.

**Args:**

***

#### <kbd>property</kbd> thread\_id

Get the thread\_id for this context.

* **`thread_id`**: The thread identifier for this context, or None if disabled.

**Returns:**
The thread identifier, or None if thread tracking is disabled.

***

#### <kbd>property</kbd> turn\_id

Get the current turn\_id from the active context.

**Returns:**
The current turn\_id if set, None otherwise.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace/util.py#L45)

## <kbd>class</kbd> `ContextAwareThreadPoolExecutor`

A ThreadPoolExecutor that runs functions with the context of the caller.

This is a drop-in replacement for concurrent.futures.ThreadPoolExecutor that ensures weave calls behave as expected inside the executor.  Weave requires certain contextvars to be set (see call\_context.py), but new threads do not automatically copy context from the parent, which can cause the call context to be lost -- not good!  This class automates contextvar copying so using this executor "just works" as the user probably expects.

You can achieve the same effect without this class by instead writing:

```python theme={"system"}
with concurrent.futures.ThreadPoolExecutor() as executor:
     contexts = [copy_context() for _ in range(len(vals))]

     def _wrapped_fn(*args):
         return contexts.pop().run(fn, *args)

     executor.map(_wrapped_fn, vals)
```

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace/util.py#L68)

### <kbd>method</kbd> `__init__`

```python theme={"system"}
__init__(*args: 'Any', **kwargs: 'Any') → None
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace/util.py#L77)

### <kbd>method</kbd> `map`

```python theme={"system"}
map(
    fn: 'Callable',
    *iterables: 'Iterable[Any]',
    timeout: 'float | None' = None,
    chunksize: 'int' = 1
) → Iterator
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace/util.py#L73)

### <kbd>method</kbd> `submit`

```python theme={"system"}
submit(fn: 'Callable', *args: 'Any', **kwargs: 'Any') → Any
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/conversation/conversation.py#L326)

## <kbd>class</kbd> `Tool`

One tool execution. Maps to an execute\_tool OTel span.

`arguments` and `result` use the `JSONString` annotation: callers can assign a dict / list / scalar and the SDK JSON-encodes it at construction or assignment. The stored value is always a string, matching the wire format per GenAI semconv.

**Pydantic Fields:**

* `name`: `<class 'str'>`
* `arguments`: `<class 'str'>`
* `result`: `<class 'str'>`
* `tool_call_id`: `<class 'str'>`
* `tool_type`: `<class 'str'>`
* `tool_description`: `<class 'str'>`
* `tool_definitions`: `<class 'str'>`
* `duration_ms`: `<class 'int'>`
* `started_at`: `datetime.datetime | None`
* `ended_at`: `datetime.datetime | None`

[Source](https://github.com/wandb/weave/blob/v0.53.1/typing_extensions.py#L257)

### <kbd>method</kbd> `add_event`

```python theme={"system"}
add_event(
    name: 'str',
    attributes: 'dict[str, Any] | None' = None,
    timestamp: 'datetime | None' = None
) → Self
```

Record an OTel span event at a point in time within this span.

> [!WARNING]
>
> **Deprecated:** Record this data with `set_attributes` instead. OpenTelemetry is phasing out the Span Event API (`Span.add_event`). `add_event` still works and existing span-event data stays valid. See [https://opentelemetry.io/blog/2026/deprecating-span-events/](https://opentelemetry.io/blog/2026/deprecating-span-events/).

Use for marker / lifecycle data — permission prompts (e.g. `weave.permission_request`), lifecycle transitions (e.g. `spawned` / `streaming` / `finished`), or any custom milestone that happens at a point in time within the span's lifetime (vs an attribute, which is a property of the span as a whole).

Must be called between span start and span end (inside `with`). Outside that window the call is a no-op and logs a warning.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/conversation/conversation.py#L382)

### <kbd>method</kbd> `end`

```python theme={"system"}
end() → None
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/conversation/conversation.py#L241)

### <kbd>method</kbd> `set_attributes`

```python theme={"system"}
set_attributes(attributes: 'dict[str, Any]') → Self
```

Stamp arbitrary OTel attributes on this span.

Pass a dict whether you have one key or many — single-key callers use `span.set_attributes({"weave.tag": "value"})`. Mirrors OTel's `Span.set_attributes`.

Must be called between span start and span end — i.e. inside a `with` block. Outside that window the call is a no-op and logs a warning. For batch ingest, populate the object's declared fields directly and pass it to `log_turn` / `log_conversation`.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/conversation/conversation.py#L882)

## <kbd>class</kbd> `Turn`

One user-agent exchange. Maps to an invoke\_agent OTel span.

By default each turn starts its own OTel trace (`continue_parent_trace=False`) so the Agents tab shows one trace per turn. Set `continue_parent_trace=True` on the Conversation (or directly on the Turn) when an outer trace is already active and you want the agent invocation to nest inside it — e.g. inside a fastapi-instrumented request.

**Pydantic Fields:**

* `agent_name`: `<class 'str'>`
* `model`: `<class 'str'>`
* `agent_id`: `<class 'str'>`
* `agent_description`: `<class 'str'>`
* `agent_version`: `<class 'str'>`
* `system_instructions`: `list[str]`
* `messages`: `list[conversation.types.Message]`
* `spans`: `list[conversation.conversation.LLM | conversation.conversation.Tool | conversation.conversation.SubAgent]`
* `continue_parent_trace`: `<class 'bool'>`
* `started_at`: `datetime.datetime | None`
* `ended_at`: `datetime.datetime | None`

[Source](https://github.com/wandb/weave/blob/v0.53.1/typing_extensions.py#L257)

### <kbd>method</kbd> `add_event`

```python theme={"system"}
add_event(
    name: 'str',
    attributes: 'dict[str, Any] | None' = None,
    timestamp: 'datetime | None' = None
) → Self
```

Record an OTel span event at a point in time within this span.

> [!WARNING]
>
> **Deprecated:** Record this data with `set_attributes` instead. OpenTelemetry is phasing out the Span Event API (`Span.add_event`). `add_event` still works and existing span-event data stays valid. See [https://opentelemetry.io/blog/2026/deprecating-span-events/](https://opentelemetry.io/blog/2026/deprecating-span-events/).

Use for marker / lifecycle data — permission prompts (e.g. `weave.permission_request`), lifecycle transitions (e.g. `spawned` / `streaming` / `finished`), or any custom milestone that happens at a point in time within the span's lifetime (vs an attribute, which is a property of the span as a whole).

Must be called between span start and span end (inside `with`). Outside that window the call is a no-op and logs a warning.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/conversation/conversation.py#L1033)

### <kbd>method</kbd> `end`

```python theme={"system"}
end() → None
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/conversation/conversation.py#L916)

### <kbd>method</kbd> `llm`

```python theme={"system"}
llm(
    model: 'str' = '',
    provider_name: 'str' = '',
    system_instructions: 'list[str] | None' = None
) → LLM
```

Start an LLM call (chat span, child of this turn).

Sets the `_current_llm` contextvar so the LLM is visible via `get_current_llm()` regardless of whether a context manager is used.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/pydantic/_internal/_model_construction.py#L907)

### <kbd>method</kbd> `model_post_init`

```python theme={"system"}
model_post_init(context: 'Any') → None
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/conversation/conversation.py#L954)

### <kbd>method</kbd> `record`

```python theme={"system"}
record(
    messages: 'list[Message] | None' = None,
    system_instructions: 'list[str] | None' = None,
    agent_name: 'str | None' = None,
    model: 'str | None' = None,
    agent_id: 'str | None' = None,
    agent_description: 'str | None' = None,
    agent_version: 'str | None' = None
) → Turn
```

Set multiple turn fields in one call.

Collapses the per-field assignments a manually-instrumented agent otherwise makes on a turn (`system_instructions`, `agent_id`, ...) into a single keyword call. Only fields explicitly passed (non-`None`) are applied — existing values are preserved. `messages` **replaces** the turn's existing messages (unlike `Turn.user(...)`, which appends a single message). Returns `self` for chaining. Mirrors `LLM.record`.

Note: on the streaming (`with`) path the turn span is named from `agent_name` at `__enter__`, so set `agent_name` via `start_turn` rather than `record` if you need the span name to reflect it; `record` still updates the `gen_ai.agent.name` attribute.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/conversation/conversation.py#L241)

### <kbd>method</kbd> `set_attributes`

```python theme={"system"}
set_attributes(attributes: 'dict[str, Any]') → Self
```

Stamp arbitrary OTel attributes on this span.

Pass a dict whether you have one key or many — single-key callers use `span.set_attributes({"weave.tag": "value"})`. Mirrors OTel's `Span.set_attributes`.

Must be called between span start and span end — i.e. inside a `with` block. Outside that window the call is a no-op and logs a warning. For batch ingest, populate the object's declared fields directly and pass it to `log_turn` / `log_conversation`.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/conversation/conversation.py#L940)

### <kbd>method</kbd> `subagent`

```python theme={"system"}
subagent(
    name: 'str',
    model: 'str' = '',
    system_instructions: 'list[str] | None' = None
) → SubAgent
```

Start a sub-agent invocation (nested invoke\_agent span, same trace).

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/conversation/conversation.py#L936)

### <kbd>method</kbd> `tool`

```python theme={"system"}
tool(name: 'str', arguments: 'str' = '', tool_call_id: 'str' = '') → Tool
```

Start a tool execution (execute\_tool span, child of this turn).

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/conversation/conversation.py#L911)

### <kbd>method</kbd> `user`

```python theme={"system"}
user(content: 'str') → Turn
```

Append a user message mid-turn.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/conversation/types.py#L227)

## <kbd>class</kbd> `Usage`

Token usage for an LLM call.

**Pydantic Fields:**

* `input_tokens`: `<class 'int'>`
* `output_tokens`: `<class 'int'>`
* `reasoning_tokens`: `<class 'int'>`
* `cache_creation_input_tokens`: `<class 'int'>`
* `cache_read_input_tokens`: `<class 'int'>`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace/api.py#L270)

### <kbd>function</kbd> `add_tags`

```python theme={"system"}
add_tags(obj_ref: 'ObjectRef | str', tags: 'list[str]') → None
```

Add tags to an object version.

**Args:**

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace/op.py#L1477)

### <kbd>function</kbd> `as_op`

```python theme={"system"}
as_op(fn: 'Callable[P, R]') → Op[P, R]
```

Given a @weave.op decorated function, return its Op.

@weave.op decorated functions are instances of Op already, so this function should be a no-op at runtime. But you can use it to satisfy type checkers if you need to access OpDef attributes in a typesafe way.

* **`obj_ref`**: Reference to the object version, either an ObjectRef (returned by weave.publish()) or a weave /// URI string.
* **`tags`**: List of tag strings to add.

**Args:**

* **`fn`**: A weave.op decorated function.

**Returns:**
The Op of the function.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/../../../../weave/trace/api/attributes#L462)

### <kbd>function</kbd> `attributes`

```python theme={"system"}
attributes(attributes: 'dict[str, Any]') → Iterator
```

Context manager for setting attributes on a call.

**Example:**

```python theme={"system"}
with weave.attributes({'env': 'production'}):
     print(my_function.call("World"))
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/conversation/conversation.py#L1317)

### <kbd>function</kbd> `end_conversation`

```python theme={"system"}
end_conversation() → None
```

End the current conversation (from contextvar).

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/conversation/conversation.py#L1331)

### <kbd>function</kbd> `end_llm`

```python theme={"system"}
end_llm() → None
```

End the current LLM call (from contextvar).

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/conversation/_deprecated.py#L107)

### <kbd>function</kbd> `end_session`

```python theme={"system"}
end_session() → None
```

Deprecated alias of :func:`weave.end_conversation`.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/conversation/conversation.py#L1324)

### <kbd>function</kbd> `end_turn`

```python theme={"system"}
end_turn() → None
```

End the current turn (from contextvar).

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace/api.py#L612)

### <kbd>function</kbd> `finish`

```python theme={"system"}
finish() → None
```

Stops logging to weave.

Following finish, calls of weave.op decorated functions will no longer be logged. You will need to run weave.init() again to resume logging.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace/api.py#L436)

### <kbd>function</kbd> `get`

```python theme={"system"}
get(uri: 'str | ObjectRef') → Any
```

A convenience function for getting an object from a URI.

Many objects logged by Weave are automatically registered with the Weave server. This function allows you to retrieve those objects by their URI.

**Args:**

* **`uri`**: A fully-qualified weave ref URI.

**Returns:**
The object.

**Example:**

```python theme={"system"}
weave.init("weave_get_example")
dataset = weave.Dataset(rows=[{"a": 1, "b": 2}])
ref = weave.publish(dataset)

dataset2 = weave.get(ref)  # same as dataset!
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace/api.py#L332)

### <kbd>function</kbd> `get_aliases`

```python theme={"system"}
get_aliases(obj_ref: 'ObjectRef | str') → list[str]
```

Get aliases for an object version.

**Args:**

* **`obj_ref`**: Reference to the object version, either an ObjectRef or a weave /// URI string.

**Returns:**
List of alias strings.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace/api.py#L184)

### <kbd>function</kbd> `get_client`

```python theme={"system"}
get_client() → WeaveClient | None
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace/context/call_context.py#L119)

### <kbd>function</kbd> `get_current_call`

```python theme={"system"}
get_current_call() → Call | None
```

Get the Call object for the currently executing Op, within that Op.

**Returns:**
The Call object for the currently executing Op, or  None if tracking has not been initialized or this method is  invoked outside an Op.

**Note:**

> The returned Call's `attributes` dictionary becomes immutable once the call starts. Use :func:`weave.attributes` to set call metadata before invoking an Op. The `summary` field may be updated while the Op executes and will be merged with computed summary information when the call finishes.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/conversation/conversation.py#L1338)

### <kbd>function</kbd> `get_current_conversation`

```python theme={"system"}
get_current_conversation() → Conversation | None
```

Return the active conversation from contextvar, or None.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/conversation/conversation.py#L1348)

### <kbd>function</kbd> `get_current_llm`

```python theme={"system"}
get_current_llm() → LLM | None
```

Return the active LLM call from contextvar, or None.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/conversation/_deprecated.py#L113)

### <kbd>function</kbd> `get_current_session`

```python theme={"system"}
get_current_session() → Conversation | None
```

Deprecated alias of :func:`weave.get_current_conversation`.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/conversation/conversation.py#L1343)

### <kbd>function</kbd> `get_current_turn`

```python theme={"system"}
get_current_turn() → Turn | None
```

Return the active turn from contextvar, or None.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace/api.py#L294)

### <kbd>function</kbd> `get_tags`

```python theme={"system"}
get_tags(obj_ref: 'ObjectRef | str') → list[str]
```

Get tags for an object version.

**Args:**

* **`obj_ref`**: Reference to the object version, either an ObjectRef or a weave /// URI string.

**Returns:**
List of tag strings.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace/api.py#L346)

### <kbd>function</kbd> `get_tags_and_aliases`

```python theme={"system"}
get_tags_and_aliases(obj_ref: 'ObjectRef | str') → tuple[list[str], list[str]]
```

Get both tags and aliases for an object version in a single call.

**Args:**

* **`obj_ref`**: Reference to the object version, either an ObjectRef or a weave /// URI string.

**Returns:**
A tuple of (tags, aliases). Each is a list of strings.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace/api.py#L41)

### <kbd>function</kbd> `init`

```python theme={"system"}
init(
    project_name: 'str',
    settings: 'UserSettings | dict[str, Any] | None' = None,
    autopatch_settings: 'AutopatchSettings | None' = None,
    postprocess_inputs: 'PostprocessInputsFunc | None' = None,
    postprocess_output: 'PostprocessOutputFunc | None' = None,
    attributes: 'dict[str, Any] | None' = None,
    global_postprocess_inputs: 'PostprocessInputsFunc | None' = None,
    global_postprocess_output: 'PostprocessOutputFunc | None' = None,
    global_attributes: 'dict[str, Any] | None' = None
) → WeaveClient
```

Initialize weave tracking, logging to a wandb project.

Logging is initialized globally, so you do not need to keep a reference to the return value of init.

Following init, calls of weave.op decorated functions will be logged to the specified project.

**Args:**

NOTE: Client-level postprocessing runs after each op's own postprocessing. The order is always: 1. Op-specific postprocessing 2. Client-level postprocessing

* **`project_name`**: The name of the Weights & Biases team and project to log to. If you don't  specify a team, your default entity is used. To find or update your default entity, refer to [User settings](https://docs.coreweave.com/products/wandb/platform/app/settings-page/user-settings.md#default-team) in the W\&B documentation.
* **`settings`**: Configuration for the Weave client generally. Can be a UserSettings instance or a dict  with any of the following keys (all optional). All settings can also be configured  via environment variables using the prefix WEAVE\_ (e.g., WEAVE\_DISABLED=true).  Available settings: - `disabled` (bool): Disables traces on all functions. Default: `False` - `print_call_link` (bool): Prints links in terminal to Weave UI for ops. Default: `True` - `log_level` (str): Sets what type of information to log (`DEBUG`, `INFO`, `WARNING`, `ERROR`, `CRITICAL`). Default: `INFO` - `display_viewer` (str): Controls how Weave displays objects in the console (`auto`, `rich`, `print`). Default: `auto` - `capture_code` (bool): Captures code of traced ops to your Weave project. Default: `True` - `implicitly_patch_integrations` (bool): Auto-patches supported libraries. Default: `True` - `redact_pii` (bool): Scans all trace data for sensitive information,  like emails, phone numbers, and credit cards, and replaces them with placeholder values  before sending to the server. Requires presidio-analyzer and presidio-anonymizer packages.
* **`Default`**: `False` - `redact_pii_fields` (list\[str]): Specifies which PII entity types to redact when `redact_pii` is True. If empty, uses Presidio's default set. Examples  \['EMAIL','PHONE\_NUMBER','CREDIT\_CARD','US\_SSN']. See full list at  [https://microsoft.github.io/presidio/supported\_entities/](https://microsoft.github.io/presidio/supported_entities/)
* **`Default`**: `[]` - `redact_pii_exclude_fields` (list\[str]): PII entity types to exclude. Default: `[]` - `capture_client_info` (bool): Captures Python/SDK version info. Default: `True` - `capture_system_info` (bool): Captures OS information. Default: `True` - `client_parallelism` (int): Number of workers for background ops. Default: `auto` - `use_server_cache` (bool): Enables local disk caching of server responses. - `server_cache_size_limit` (int): Cache size limit in bytes. Default: `1_000_000_000` - `server_cache_dir` (str): Directory for server cache. Default: `temporary` - `scorers_dir` (str): Directory for scorer model checkpoints. Default: `~/.cache/wandb/weave-scorers` - `max_calls_queue_size` (int): Maximum queue size (0 = unbounded). Default: `100_000` - `retry_max_interval` (float): Maximum retry interval in seconds. Default: `300` - `retry_max_attempts` (int): Maximum number of retries. Default: `3` - `enable_disk_fallback` (bool): Writes dropped items to disk. Default: `True` - `use_parallel_table_upload` (bool): Enables parallel chunked upload for large tables. If False, tables are uploaded sequentially in smaller chunks.
* **`Default`**: `True` - `http_timeout` (float): Maximum time in seconds to wait for HTTP requests to complete. This includes connection time, data transfer, and server processing. Increase for slow networks or when working with large payloads.
* **`Default`**: `30.0` - `use_stainless_server` (bool): Uses the Stainless-generated HTTP client which provides better type safety, automatic retries, and improved error handling. This is experimental and may become the default in future versions.
* **`Default`**: `False` - `use_calls_complete` (bool): Uses an optimized write path that batches complete call data (start and end) into a single request instead of separate start/end requests. This reduces server load and improves performance, especially for short-lived ops.
* **`Default`**: `True` - `use_otel_v2`: (bool): Routes OTel-capable integrations through their OTel variant.
* **`Default`**: `True`
* **`autopatch_settings`**: (Deprecated) Configuration for autopatch integrations. Use explicit patching instead.
* **`postprocess_inputs`**: A function applied to the inputs of every op traced by this client.
* **`postprocess_output`**: A function applied to the output of every op traced by this client.
* **`attributes`**: A dictionary of attributes applied to every trace produced by this client.

**Returns:**
A Weave client.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace/api.py#L409)

### <kbd>function</kbd> `link_prompt_to_registry`

```python theme={"system"}
link_prompt_to_registry(
    prompt: 'LinkablePrompt',
    target_path: 'str',
    aliases: 'Sequence[str] | None' = None
) → LinkAssetToRegistryRes
```

Link a published prompt version into the registry.

**Args:**

* **`prompt`**: A published prompt, an `ObjectRef`, or a fully qualified weave ///... URI string.
* **`target_path`**: Registry destination path in the format  `<registry_project>/<portfolio_name>`, for example  `wandb-registry-prompts/my-prompt-collection`.
* **`aliases`**: Optional aliases to attach to the created registry version.

**Returns:**

* **`LinkAssetToRegistryRes`**:  Parsed response from the registry-link endpoint.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace/api.py#L370)

### <kbd>function</kbd> `list_aliases`

```python theme={"system"}
list_aliases() → list[str]
```

List all distinct aliases in the project.

**Returns:**
Sorted list of all alias strings in the project.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace/api.py#L360)

### <kbd>function</kbd> `list_tags`

```python theme={"system"}
list_tags() → list[str]
```

List all distinct tags in the project.

**Returns:**
Sorted list of all tag strings in the project.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace/log_call.py#L18)

### <kbd>function</kbd> `log_call`

```python theme={"system"}
log_call(
    op: 'str',
    inputs: 'dict[str, Any]',
    output: 'Any',
    parent: 'Call | None' = None,
    attributes: 'dict[str, Any] | None' = None,
    display_name: 'str | Callable[[Call], str] | None' = None,
    use_stack: 'bool' = True,
    exception: 'BaseException | None' = None
) → Call
```

Log a call directly to Weave without using the decorator pattern.

This function provides an imperative API for logging operations to Weave, useful when you want to log calls after they've already been executed or when the decorator pattern isn't suitable for your use case.

**Args:**

* **`op`** (str):  The operation name to log. This will be used as the op\_name  for the call. Anonymous operations (strings not referring to published  ops) are supported.
* **`inputs`** (dict\[str, Any]):  A dictionary of input parameters for the operation.
* **`output`** (Any):  The output/result of the operation.
* **`parent`** (Call | None):  Optional parent call to nest this call under.  If not provided, the call will be a root-level call (or nested under  the current call context if one exists). Defaults to None.
* **`attributes`** (dict\[str, Any] | None):  Optional metadata to attach to the call.  These are frozen once the call is created. Defaults to None.
* **`display_name`** (str | Callable\[\[Call], str] | None):  Optional display name  for the call in the UI. Can be a string or a callable that takes the  call and returns a string. Defaults to None.
* **`use_stack`** (bool):  Whether to push the call onto the runtime stack. When True,  the call will be available in the call context and can be accessed via  weave.require\_current\_call(). When False, the call is logged but not  added to the call stack. Defaults to True.
* **`exception`** (BaseException | None):  Optional exception to log if the operation  failed. Defaults to None.

**Returns:**

* **`Call`**:  The created and finished Call object with full trace information.

**Examples:**
Basic usage:

```python theme={"system"}
import weave
weave.init('my-project')
call = weave.log_call(
    op="my_function",
    inputs={"x": 5, "y": 10},
    output=15
)

# Logging with attributes and display name:
call = weave.log_call(
    op="process_data",
    inputs={"data": [1, 2, 3]},
    output={"mean": 2.0},
    attributes={"version": "1.0", "env": "prod"},
    display_name="Data Processing"
)

# Logging a failed operation:
try:
    result = risky_operation()
except Exception as e:
    call = weave.log_call(
        op="risky_operation",
        inputs={},
        output=None,
        exception=e
    )

# Nesting calls:
parent_call = weave.log_call("parent", {"input": 1}, 2)
child_call = weave.log_call(
    "child",
    {"input": 2},
    4,
    parent=parent_call
)

# Logging without adding to call stack:
call = weave.log_call(
    op="background_task",
    inputs={"task_id": 123},
    output="completed",
    use_stack=False  # Don't push to call stack
)
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/conversation/conversation.py#L1584)

### <kbd>function</kbd> `log_conversation`

```python theme={"system"}
log_conversation(
    turns: 'list[Turn]',
    conversation_id: 'str' = '',
    conversation_name: 'str' = '',
    agent_name: 'str' = '',
    model: 'str' = '',
    agent_id: 'str' = '',
    agent_description: 'str' = '',
    agent_version: 'str' = '',
    include_content: 'bool' = True,
    continue_parent_trace: 'bool' = False,
    attributes: 'Attributes' = None
) → LogResult
```

Imperatively emit a complete conversation.

Each Turn's `.spans` attribute provides its children. Auto-generates `conversation_id` if empty. By default each turn gets its own OTel trace. `agent_name` / `model` / `agent_id` / `agent_description` / `agent_version` are conversation-level defaults — a Turn's own value wins; the conversation value only fills in when the Turn leaves it empty. The conversation's `continue_parent_trace` applies to every turn (a per-Turn `continue_parent_trace` is intentionally superseded here).

`attributes` are stamped on every emitted span. Use custom, non-semconv keys: a key that collides with a span's own `gen_ai.*` / `weave.*` attribute is unsupported (which value wins is path-dependent).

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/conversation/_deprecated.py#L78)

### <kbd>function</kbd> `log_session`

```python theme={"system"}
log_session(
    turns: 'list[Turn]',
    session_id: 'str' = '',
    session_name: 'str' = '',
    agent_name: 'str' = '',
    model: 'str' = '',
    include_content: 'bool' = True,
    continue_parent_trace: 'bool' = False,
    attributes: 'Attributes' = None
) → LogResult
```

Deprecated alias of :func:`weave.log_conversation`.

`session_id` / `session_name` map to `conversation_id` / `conversation_name`.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/conversation/conversation.py#L1518)

### <kbd>function</kbd> `log_turn`

```python theme={"system"}
log_turn(
    conversation_id: 'str',
    agent_name: 'str' = '',
    conversation_name: 'str' = '',
    model: 'str' = '',
    agent_id: 'str' = '',
    agent_description: 'str' = '',
    agent_version: 'str' = '',
    messages: 'list[Message] | None' = None,
    system_instructions: 'list[str] | None' = None,
    spans: 'list[LLM | Tool | SubAgent] | None' = None,
    started_at: 'datetime | None' = None,
    ended_at: 'datetime | None' = None,
    include_content: 'bool' = True,
    continue_parent_trace: 'bool' = False,
    attributes: 'Attributes' = None
) → LogResult
```

Imperatively emit one turn and its child spans to OTel.

Use when context managers aren't viable (stateless containers, callbacks, queue workers). Each child span passed in should have `started_at` / `ended_at` set; the emitted OTel span timestamps come from those fields. Falls back to the earliest/latest child timestamp, then `now()`, when the turn doesn't supply its own. `agent_id` / `agent_description` / `agent_version` mirror the streaming path.

`attributes` are stamped on every emitted span; the streaming path reads these from the active conversation instead. Use custom, non-semconv keys: a key that collides with a span's own `gen_ai.*` / `weave.*` attribute is unsupported (which value wins is path-dependent).

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace/op.py#L1240)

### <kbd>function</kbd> `op`

```python theme={"system"}
op(
    func: 'Callable[P, R] | None' = None,
    name: 'str | None' = None,
    call_display_name: 'str | CallDisplayNameFunc | None' = None,
    postprocess_inputs: 'PostprocessInputsFunc | None' = None,
    postprocess_output: 'PostprocessOutputFunc | None' = None,
    tracing_sample_rate: 'float' = 1.0,
    enable_code_capture: 'bool' = True,
    accumulator: 'Callable[[Any | None, Any], Any] | None' = None,
    kind: 'OpKind | None' = None,
    color: 'OpColor | None' = None,
    attributes: 'dict[str, Any] | None' = None,
    eager_call_start: 'bool' = False
) → Callable[[Callable[P, R]], Op[P, R]] | Op[P, R]
```

A decorator to weave op-ify a function or method. Works for both sync and async. Automatically detects iterator functions and applies appropriate behavior.

**Args:**

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace/urls.py#L14)

### <kbd>function</kbd> `otel_traces_endpoint`

```python theme={"system"}
otel_traces_endpoint(base_url: str | None = None) → str
```

Return the full OTLP HTTP endpoint URL for Weave GenAI trace ingestion.

External callers (e.g. boot-time probes that want to verify the ingest endpoint is reachable before relying on the BatchSpanProcessor to silently drop exports) should call this rather than constructing the URL by hand. The path is owned by the SDK and may move.

* **`func`**: The function to decorate.
* **`name`**: Custom name for the op. Defaults to the function name.
* **`call_display_name`**: Display name for calls, can be a string or callable.
* **`postprocess_inputs`**: Function to transform inputs before logging.
* **`postprocess_output`**: Function to transform output before logging.
* **`tracing_sample_rate`**: Fraction of calls to trace (0.0 to 1.0).
* **`enable_code_capture`**: Whether to capture source code for this op.
* **`accumulator`**: Function to accumulate results for streaming ops.
* **`attributes`**: Default attributes merged into every call this op creates,  at the lowest precedence. A `weave.attributes()` context and explicit  per-call attributes override them on key collision. The reserved  "weave" key may not be set here.
* **`eager_call_start`**: If True, call starts are sent immediately rather than batched.  Useful for long-running operations like evaluations that should  be visible in the UI immediately.

**Args:**

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace/api.py#L188)

### <kbd>function</kbd> `publish`

```python theme={"system"}
publish(
    obj: 'Any',
    name: 'str | None' = None,
    tags: 'list[str] | None' = None,
    aliases: 'list[str] | None' = None
) → ObjectRef
```

Save and version a Python object.

Weave creates a new version of the object if the object's name already exists and its content hash does not match the latest version of that object.

* **`base_url`**: Trace server base URL. Defaults to  `weave_trace_server_url()`.

**Args:**

* **`obj`**: The object to save and version.
* **`name`**: The name to save the object under.
* **`tags`**: Optional list of tags to add to the published object version.
* **`aliases`**: Optional list of aliases to set on the published object version.

**Returns:**
A Weave Ref to the saved object.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace/api.py#L380)

### <kbd>function</kbd> `ref`

```python theme={"system"}
ref(location: 'str') → ObjectRef
```

Creates a Ref to an existing Weave object. This does not directly retrieve the object but allows you to pass it to other Weave API functions.

**Args:**

* **`location`**: A Weave Ref URI, or if `weave.init()` has been called, `name:version` or `name`. If no version is provided, `latest` is used.

**Returns:**
A Weave Ref to the object.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace/api.py#L320)

### <kbd>function</kbd> `remove_aliases`

```python theme={"system"}
remove_aliases(obj_ref: 'ObjectRef | str', alias: 'str | list[str]') → None
```

Remove one or more aliases from an object.

**Args:**

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace/api.py#L282)

### <kbd>function</kbd> `remove_tags`

```python theme={"system"}
remove_tags(obj_ref: 'ObjectRef | str', tags: 'list[str]') → None
```

Remove tags from an object version.

* **`obj_ref`**: Reference to the object, either an ObjectRef or a weave /// URI string.
* **`alias`**: An alias name or list of alias names to remove.

**Args:**

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace/context/call_context.py#L70)

### <kbd>function</kbd> `require_current_call`

```python theme={"system"}
require_current_call() → Call
```

Get the Call object for the currently executing Op, within that Op.

This allows you to access attributes of the Call such as its id or feedback while it is running.

```python theme={"system"}
@weave.op
def hello(name: str) -> None:
     print(f"Hello {name}!")
     current_call = weave.require_current_call()
     print(current_call.id)
```

It is also possible to access a Call after the Op has returned.

If you have the Call's id, perhaps from the UI, you can use the `get_call` method on the `WeaveClient` returned from `weave.init` to retrieve the Call object.

```python theme={"system"}
client = weave.init("<project>")
mycall = client.get_call("<call_id>")
```

Alternately, after defining your Op you can use its `call` method. For example:

```python theme={"system"}
@weave.op
def add(a: int, b: int) -> int:
     return a + b

result, call = add.call(1, 2)
print(call.id)
```

* **`obj_ref`**: Reference to the object version, either an ObjectRef or a weave /// URI string.
* **`tags`**: List of tag strings to remove.

**Returns:**
The Call object for the currently executing Op

**Raises:**

* **`NoCurrentCallError`**:  If tracking has not been initialized or this method is  invoked outside an Op.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace/api.py#L308)

### <kbd>function</kbd> `set_aliases`

```python theme={"system"}
set_aliases(obj_ref: 'ObjectRef | str', alias: 'str | list[str]') → None
```

Set one or more aliases for an object version.

**Args:**

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace/api.py#L482)

### <kbd>function</kbd> `set_view`

```python theme={"system"}
set_view(
    name: 'str',
    content: 'Content | str',
    extension: 'str | None' = None,
    mimetype: 'str | None' = None,
    metadata: 'dict[str, Any] | None' = None,
    encoding: 'str' = 'utf-8'
) → None
```

Attach a custom view to the current call summary at `_weave.views.<name>`.

* **`obj_ref`**: Reference to the object version, either an ObjectRef or a weave /// URI string.
* **`alias`**: An alias name or list of alias names to set (e.g., "production").

**Args:**

* **`name`**: The view name (key under `summary._weave.views`).
* **`content`**: A `weave.Content` instance or raw string. Strings are wrapped via  `Content.from_text` using the supplied extension or mimetype.
* **`extension`**: Optional file extension to use when `content` is a string.
* **`mimetype`**: Optional MIME type to use when `content` is a string.
* **`metadata`**: Optional metadata to attach when creating `Content` from text.
* **`encoding`**: Text encoding to apply when creating `Content` from text.

**Returns:**
None

**Examples:**

```python theme={"system"}
import weave
weave.init("proj")
@weave.op
def foo():
    weave.set_view("readme", "# Hello", extension="md")
    return 1
foo()
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/conversation/conversation.py#L1198)

### <kbd>function</kbd> `start_conversation`

```python theme={"system"}
start_conversation(
    agent_name: 'str' = '',
    model: 'str' = '',
    conversation_id: 'str' = '',
    conversation_name: 'str' = '',
    include_content: 'bool' = True,
    continue_parent_trace: 'bool' = False,
    attributes: 'Attributes' = None
) → Conversation
```

Create and activate a conversation. Sets the contextvar for cross-module access.

`attributes` are stamped on every span this conversation emits (e.g. an integration identity like `weave.integration.*`). Use custom, non-semconv keys: set semantic-convention fields via the typed params (`conversation_name`, `model`, ...). A key that collides with a span's own `gen_ai.*` / `weave.*` attribute is unsupported; which value wins is path-dependent (streaming vs `log_turn`).

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/conversation/conversation.py#L1262)

### <kbd>function</kbd> `start_llm`

```python theme={"system"}
start_llm(
    model: 'str' = '',
    provider_name: 'str' = '',
    system_instructions: 'list[str] | None' = None
) → LLM
```

Create and activate an LLM call. Uses the current turn if available.

If no turn is active, returns a disconnected LLM (no contextvar set).

Pass `provider_name` explicitly. The SDK does not infer it from the model identifier: prefix-based guessing misattributes user fine-tunes (e.g. a model named `text-...`) and bakes assumptions about future model names into telemetry that's expensive to correct after the fact.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/conversation/_deprecated.py#L51)

### <kbd>function</kbd> `start_session`

```python theme={"system"}
start_session(
    agent_name: 'str' = '',
    model: 'str' = '',
    session_id: 'str' = '',
    session_name: 'str' = '',
    include_content: 'bool' = True,
    continue_parent_trace: 'bool' = False,
    attributes: 'Attributes' = None
) → Conversation
```

Deprecated alias of :func:`weave.start_conversation`.

`session_id` / `session_name` map to `conversation_id` / `conversation_name`.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/conversation/conversation.py#L1302)

### <kbd>function</kbd> `start_subagent`

```python theme={"system"}
start_subagent(
    name: 'str',
    model: 'str' = '',
    system_instructions: 'list[str] | None' = None
) → SubAgent
```

Create a sub-agent invocation span.

The SubAgent's OTel span automatically becomes a child of whatever span is current in OTel context — typically a Turn span if one is active. Mirrors `start_tool` in shape; OTel context handles parent-child propagation, no explicit delegation is needed.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/conversation/conversation.py#L1291)

### <kbd>function</kbd> `start_tool`

```python theme={"system"}
start_tool(name: 'str', arguments: 'str' = '', tool_call_id: 'str' = '') → Tool
```

Create a tool execution span.

The Tool's OTel span automatically becomes a child of whatever span is current in OTel context — typically a Turn span if one is active. No explicit turn delegation is needed: parent-child propagation happens via OTel context, not via the Conversation SDK contextvars.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/conversation/conversation.py#L1230)

### <kbd>function</kbd> `start_turn`

```python theme={"system"}
start_turn(
    user_message: 'str' = '',
    model: 'str' = '',
    agent_name: 'str' = '',
    system_instructions: 'list[str] | None' = None
) → Turn
```

Create and activate a turn. Uses the current conversation if available.

If no conversation is active, returns a disconnected Turn that is NOT set in the contextvar. This means `get_current_turn()` will return None. Use `conversation.start_turn()` instead if you need contextvar-based cross-module access.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/../../../../weave/trace/api/thread#L565)

### <kbd>function</kbd> `thread`

```python theme={"system"}
thread(
    thread_id: 'str | object | None' = <object object at 0x7f136d9f4bd0>
) → Iterator[ThreadContext]
```

Context manager for setting thread\_id on calls within the context.

**Examples:**

```python theme={"system"}
# Auto-generate thread_id
with weave.thread() as t:
     print(f"Thread ID: {t.thread_id}")
     result = my_function("input")  # This call will have the auto-generated thread_id
     print(f"Current turn: {t.turn_id}")

# Explicit thread_id
with weave.thread("custom_thread") as t:
     result = my_function("input")  # This call will have thread_id="custom_thread"

# Disable threading
with weave.thread(None) as t:
     result = my_function("input")  # This call will have thread_id=None
```

**Args:**

* **`thread_id`**: The thread identifier to associate with calls in this context.  If not provided, a UUID v7 will be auto-generated.  If None, thread tracking will be disabled.

**Yields:**

* **`ThreadContext`**:  An object providing access to thread\_id and current turn\_id.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/integrations/wandb/wandb.py#L9)

### <kbd>function</kbd> `wandb_init_hook`

```python theme={"system"}
wandb_init_hook() → None
```
