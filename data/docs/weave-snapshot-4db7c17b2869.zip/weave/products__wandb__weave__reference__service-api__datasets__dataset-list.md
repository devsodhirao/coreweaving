> ## Documentation Index
> Fetch the complete documentation index at: https://docs.coreweave.com/llms.txt
> Use this file to discover all available pages before exploring further.

# Dataset List

> List dataset objects.



## OpenAPI

````yaml products/wandb/weave/reference/service-api/openapi.json GET /v2/{entity}/{project}/datasets
openapi: 3.1.0
info:
  title: FastAPI
  version: 0.1.0
servers: []
security: []
paths:
  /v2/{entity}/{project}/datasets:
    get:
      tags:
        - Datasets
      summary: Dataset List
      description: List dataset objects.
      operationId: dataset_list_v2__entity___project__datasets_get
      parameters:
        - name: entity
          in: path
          required: true
          schema:
            type: string
            title: Entity
        - name: project
          in: path
          required: true
          schema:
            type: string
            title: Project
        - name: limit
          in: query
          required: false
          schema:
            anyOf:
              - type: integer
              - type: 'null'
            description: Maximum number of datasets to return
            title: Limit
          description: Maximum number of datasets to return
        - name: offset
          in: query
          required: false
          schema:
            anyOf:
              - type: integer
              - type: 'null'
            description: Number of datasets to skip
            title: Offset
          description: Number of datasets to skip
      responses:
        '200':
          description: Stream of data in JSONL format
          content:
            application/x-ndjson:
              schema:
                $ref: '#/components/schemas/DatasetReadRes'
        '422':
          description: Validation Error
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/HTTPValidationError'
components:
  schemas:
    DatasetReadRes:
      properties:
        object_id:
          type: string
          title: Object Id
          description: The dataset ID
        digest:
          type: string
          title: Digest
          description: The digest of the dataset object
        version_index:
          type: integer
          title: Version Index
          description: The version index of the object
        created_at:
          type: string
          format: date-time
          title: Created At
          description: When the object was created
        name:
          type: string
          title: Name
          description: The name of the dataset
        description:
          anyOf:
            - type: string
            - type: 'null'
          title: Description
          description: Description of the dataset
        rows:
          type: string
          title: Rows
          description: Reference to the dataset rows data
      type: object
      required:
        - object_id
        - digest
        - version_index
        - created_at
        - name
        - rows
      title: DatasetReadRes
    HTTPValidationError:
      properties:
        detail:
          items:
            $ref: '#/components/schemas/ValidationError'
          type: array
          title: Detail
      type: object
      title: HTTPValidationError
    ValidationError:
      properties:
        loc:
          items:
            anyOf:
              - type: string
              - type: integer
          type: array
          title: Location
        msg:
          type: string
          title: Message
        type:
          type: string
          title: Error Type
        input:
          title: Input
        ctx:
          type: object
          title: Context
      type: object
      required:
        - loc
        - msg
        - type
      title: ValidationError

````