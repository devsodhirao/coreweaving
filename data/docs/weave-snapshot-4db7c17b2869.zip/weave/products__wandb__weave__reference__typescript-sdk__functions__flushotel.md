> ## Documentation Index
> Fetch the complete documentation index at: https://docs.coreweave.com/llms.txt
> Use this file to discover all available pages before exploring further.

# flushOTel

> TypeScript SDK reference

```ts theme={"system"}
flushOTel(): Promise<void>
```

[GitHub source](https://github.com/wandb/weave/blob/7c9efdc9fe05ffcaf2430dd652ef9bc5b3ffdfaa/sdks/node/src/genai/flush.ts#L15)

Force-flush any GenAI spans buffered by the active span processor.

Resolves immediately if `weave.init()` has not been called. Otherwise
delegates to `BasicTracerProvider.forceFlush()`, which waits for the
underlying span processor to drain its queue and complete its OTLP export
round-trip.

Call before process exit when using `'simple'` or any other processor that
may have in-flight work, or in tests that need to observe exported spans
synchronously.

## Returns

`Promise`\<`void`>
