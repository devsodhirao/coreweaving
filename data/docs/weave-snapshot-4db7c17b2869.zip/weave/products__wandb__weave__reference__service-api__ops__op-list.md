> ## Documentation Index
> Fetch the complete documentation index at: https://docs.coreweave.com/llms.txt
> Use this file to discover all available pages before exploring further.

# Op List

> List op objects.



## OpenAPI

````yaml products/wandb/weave/reference/service-api/openapi.json GET /v2/{entity}/{project}/ops
openapi: 3.1.0
info:
  title: FastAPI
  version: 0.1.0
servers: []
security: []
paths:
  /v2/{entity}/{project}/ops:
    get:
      tags:
        - Ops
      summary: Op List
      description: List op objects.
      operationId: op_list_v2__entity___project__ops_get
      parameters:
        - name: entity
          in: path
          required: true
          schema:
            type: string
            title: Entity
        - name: project
          in: path
          required: true
          schema:
            type: string
            title: Project
        - name: limit
          in: query
          required: false
          schema:
            anyOf:
              - type: integer
              - type: 'null'
            description: Maximum number of ops to return
            title: Limit
          description: Maximum number of ops to return
        - name: offset
          in: query
          required: false
          schema:
            anyOf:
              - type: integer
              - type: 'null'
            description: Number of ops to skip
            title: Offset
          description: Number of ops to skip
      responses:
        '200':
          description: Stream of data in JSONL format
          content:
            application/x-ndjson:
              schema:
                $ref: '#/components/schemas/OpReadRes'
        '422':
          description: Validation Error
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/HTTPValidationError'
components:
  schemas:
    OpReadRes:
      properties:
        object_id:
          type: string
          title: Object Id
          description: The op ID
        digest:
          type: string
          title: Digest
          description: The digest of the op
        version_index:
          type: integer
          title: Version Index
          description: The version index of this op
        created_at:
          type: string
          format: date-time
          title: Created At
          description: When this op was created
        code:
          type: string
          title: Code
          description: The actual op source code
      type: object
      required:
        - object_id
        - digest
        - version_index
        - created_at
        - code
      title: OpReadRes
      description: |-
        Response model for reading an Op object.

        The code field contains the actual source code of the op.
    HTTPValidationError:
      properties:
        detail:
          items:
            $ref: '#/components/schemas/ValidationError'
          type: array
          title: Detail
      type: object
      title: HTTPValidationError
    ValidationError:
      properties:
        loc:
          items:
            anyOf:
              - type: string
              - type: integer
          type: array
          title: Location
        msg:
          type: string
          title: Message
        type:
          type: string
          title: Error Type
        input:
          title: Input
        ctx:
          type: object
          title: Context
      type: object
      required:
        - loc
        - msg
        - type
      title: ValidationError

````