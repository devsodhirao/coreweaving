> ## Documentation Index
> Fetch the complete documentation index at: https://docs.coreweave.com/llms.txt
> Use this file to discover all available pages before exploring further.

# Obj Remove Aliases

> Remove aliases from an object.



## OpenAPI

````yaml products/wandb/weave/reference/service-api/openapi.json POST /objs/{object_id}/aliases/remove
openapi: 3.1.0
info:
  title: FastAPI
  version: 0.1.0
servers: []
security: []
paths:
  /objs/{object_id}/aliases/remove:
    post:
      tags:
        - Objects
      summary: Obj Remove Aliases
      description: Remove aliases from an object.
      operationId: obj_remove_aliases_objs__object_id__aliases_remove_post
      parameters:
        - name: object_id
          in: path
          required: true
          schema:
            type: string
            title: Object Id
      requestBody:
        required: true
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/ObjRemoveAliasesBody'
      responses:
        '200':
          description: Successful Response
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/ObjRemoveAliasesRes'
        '422':
          description: Validation Error
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/HTTPValidationError'
components:
  schemas:
    ObjRemoveAliasesBody:
      properties:
        project_id:
          type: string
          title: Project Id
          examples:
            - entity/project
        aliases:
          items:
            type: string
          type: array
          title: Aliases
          examples:
            - - staging
      type: object
      required:
        - project_id
        - aliases
      title: ObjRemoveAliasesBody
      description: Request body for removing aliases (object_id comes from path).
    ObjRemoveAliasesRes:
      properties: {}
      type: object
      title: ObjRemoveAliasesRes
    HTTPValidationError:
      properties:
        detail:
          items:
            $ref: '#/components/schemas/ValidationError'
          type: array
          title: Detail
      type: object
      title: HTTPValidationError
    ValidationError:
      properties:
        loc:
          items:
            anyOf:
              - type: string
              - type: integer
          type: array
          title: Location
        msg:
          type: string
          title: Message
        type:
          type: string
          title: Error Type
        input:
          title: Input
        ctx:
          type: object
          title: Context
      type: object
      required:
        - loc
        - msg
        - type
      title: ValidationError

````