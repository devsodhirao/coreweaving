> ## Documentation Index
> Fetch the complete documentation index at: https://docs.coreweave.com/llms.txt
> Use this file to discover all available pages before exploring further.

# StringPrompt

> TypeScript SDK reference

[GitHub source](https://github.com/wandb/weave/blob/7c9efdc9fe05ffcaf2430dd652ef9bc5b3ffdfaa/sdks/node/src/prompt.ts#L19)

## Extends

* `Prompt`

## Constructor

> **new StringPrompt**(`parameters`): `StringPrompt`

### Parameters

**parameters** `object` *required*

**properties**

**content** `string` *required*

**description** `string`

**name** `string`

### Returns

`StringPrompt`

### Overrides

`Prompt.constructor`

## Properties

### \_\_savedRef

> `optional` **\_\_savedRef**: [`ObjectRef`](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/classes/objectref) | `Promise`\<[`ObjectRef`](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/classes/objectref)>

#### Inherited from

`Prompt.__savedRef`

***

### content

> **content**: `string`

## Accessors

### description

#### Get Signature

> **get** **description**(): `string` | `undefined`

##### Returns

`string` | `undefined`

#### Inherited from

`Prompt.description`

***

### name

#### Get Signature

> **get** **name**(): `string`

##### Returns

`string`

#### Inherited from

`Prompt.name`

## Methods

### format()

> **format**(`values?`): `string`

#### Parameters

**values** `Record\<string, any\> = \{\}`

#### Returns

`string`

***

### saveAttrs()

> **saveAttrs**(): `object`

#### Returns

`object`

#### Inherited from

`Prompt.saveAttrs`

***

### get()

> `static` **get**(`client`, `uri`): `Promise`\<`StringPrompt`>

#### Parameters

**client** `WeaveClient` *required*

See [`WeaveClient`](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/interfaces/weaveclient).

**uri** `string` *required*

#### Returns

`Promise`\<`StringPrompt`>
