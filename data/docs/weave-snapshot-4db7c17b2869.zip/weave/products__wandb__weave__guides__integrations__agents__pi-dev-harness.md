> ## Documentation Index
> Fetch the complete documentation index at: https://docs.coreweave.com/llms.txt
> Use this file to discover all available pages before exploring further.

# Pi extension

> Trace Pi agentic sessions, LLM calls, and tool executions in Weave.

> [!TIP]
>
> **This workflow is also available in CoreWeave Agent Lens.** Agent Lens is the Forge experience built for tracing, monitoring, and analyzing AI agents, with automated insights into agent failures and user intents. It uses the same trace data as Weights & Biases Weave, so the traces you already send appear there with nothing to migrate.
> [See how to do this in Agent Lens](https://docs.coreweave.com/products/agent-lens/integrations/pi.md).

[Pi](https://pi.dev/) is a terminal-based coding agent. Weave traces Pi sessions, LLM calls, and tool executions automatically using the `createOtelExtension` integration, which conforms to the [GenAI semantic conventions](https://opentelemetry.io/docs/specs/semconv/gen-ai/). This page shows you how to enable Weave tracing in a Pi application so you can observe agent behavior, debug runs, and analyze token usage and cost.

> [!WARNING]
>
> This integration sends Pi session data to Weave. That data can include user prompts, model responses, tool inputs and outputs, file contents read by Pi tools, shell commands and output, and fetched URLs and page content.
>
> The integration doesn't implement PII scrubbing or sensitive-data redaction. If you can't send this data to Weave under your security or compliance requirements, don't enable Weave tracing in your Pi application.

## Prerequisites

* [Node.js](https://nodejs.org/) (v18 or later).
* A CoreWeave Forge account and [API key](https://forge.coreweave.com/settings#apikeys) set as a `WANDB_API_KEY` environment variable.

> [!NOTE]
>
> Pi is a TypeScript and Node.js framework with no Python equivalent. Pi requires the ESM module system. Your project must use `"type": "module"` in `package.json`, or compile TypeScript to ESM output. CommonJS projects error. For more information about setting up an ESM project, see [TypeScript SDK integration](https://docs.coreweave.com/products/wandb/weave/guides/integrations/js.md#set-up-an-esm-project).

## Install packages

Install Weave, Pi, and Node type definitions as local project dependencies:

```bash lines theme={"system"}
npm install weave @earendil-works/pi-coding-agent
npm install --save-dev @types/node tsx typescript
```

## Trace a Pi prompt and response

The following example shows the minimum setup needed to trace a single Pi prompt and response. Call `weave.init()` before you create your agent session, then pass `createOtelExtension()` as an extension factory. Weave traces the full agent lifecycle: the conversation, each prompt-and-response cycle (`invoke_agent`), individual LLM calls (`chat`), and tool executions (`execute_tool`). `SessionManager.inMemory()` generates the session ID automatically.

```typescript lines twoslash theme={"system"}
// @noErrors
import {init, createOtelExtension} from 'weave';

import {
  createAgentSession,
  DefaultResourceLoader,
  SessionManager,
  getAgentDir,
} from '@earendil-works/pi-coding-agent';

async function main() {
  // 1. Initialize Weave. Sets up the OTEL TracerProvider that points at your
  //    Weave project. All spans created by createOtelExtension() are
  //    automatically exported here.
  await init('[YOUR-TEAM]/[YOUR-PROJECT]');

  // 2. Create a resource loader and inject the Weave OTEL extension.
  //    The resource loader provides the Pi runtime environment and
  //    extension lifecycle used for tracing agent activity.
  const resourceLoader = new DefaultResourceLoader({
    cwd: process.cwd(),
    agentDir: getAgentDir(),
    extensionFactories: [createOtelExtension({})],
  });

  await resourceLoader.reload();

  // 3. Start the agent session
  const {session} = await createAgentSession({
    resourceLoader,
    sessionManager: SessionManager.inMemory(),
  });

  // 4. Bind extensions. Triggers session_start event so the OTEL adapter
  //    creates the root conversation span and captures the conversation ID.
  await session.bindExtensions({});

  // 5. Stream assistant output to stdout
  session.subscribe(event => {
    if (
      event.type === 'message_update' &&
      event.assistantMessageEvent.type === 'text_delta'
    ) {
      process.stdout.write(event.assistantMessageEvent.delta);
    }
  });

  // 6. Send a prompt and wait for the full response
  await session.prompt('What files are in the current directory?');
  console.log();
}

main();
```

Compile and execute the script with `tsx`, replacing `[FILENAME]` with the name of your TypeScript file:

```bash theme={"system"}
npx tsx [FILENAME].ts
```

When you run your code, your traces appear in the **Agents** tab of your Weave project at `https://forge.coreweave.com/wandb/[YOUR-TEAM]/[YOUR-PROJECT]/weave/agents`. Weave captures Pi sessions, LLM calls, and tool executions for every run of your application.

### Next steps

To turn this example into a multi-turn conversation, add more prompts. Weave traces each call to `session.prompt()` as a separate `invoke_agent` span, all nested under a single root span. The agent retains context across prompts automatically.

After running the code, the **Agents** tab shows the full multi-turn timeline with nested LLM calls, tool executions, token usage, and cost.
