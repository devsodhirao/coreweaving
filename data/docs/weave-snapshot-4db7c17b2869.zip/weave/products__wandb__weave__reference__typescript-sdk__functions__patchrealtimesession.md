> ## Documentation Index
> Fetch the complete documentation index at: https://docs.coreweave.com/llms.txt
> Use this file to discover all available pages before exploring further.

# patchRealtimeSession

> TypeScript SDK reference

```ts theme={"system"}
patchRealtimeSession(): Promise<boolean>
```

[GitHub source](https://github.com/wandb/weave/blob/7c9efdc9fe05ffcaf2430dd652ef9bc5b3ffdfaa/sdks/node/src/integrations/openai.realtime.agent.ts#L861)

Manually patch the `RealtimeSession` class from `@openai/agents-realtime` so that
every new instance is automatically traced by Weave.

**Note: You typically don't need to call this function!** `@openai/agents-realtime` is
automatically instrumented via module loader hooks when you import Weave. This function
is provided for edge cases where automatic instrumentation doesn't work (e.g. dynamic
imports, bundlers that bypass hooks).

Call this **once** at app startup, before any `RealtimeSession` is constructed.
The function is idempotent — safe to call multiple times.

## Returns

`Promise`\<`boolean`>

`true` if the patch was applied (or was already in place), `false` if
`@openai/agents-realtime` could not be loaded.

## Example

```typescript twoslash theme={"system"}
// @noErrors
import { patchRealtimeSession } from 'weave';
await patchRealtimeSession();
// Every new RealtimeSession(...) is now auto-instrumented
```
