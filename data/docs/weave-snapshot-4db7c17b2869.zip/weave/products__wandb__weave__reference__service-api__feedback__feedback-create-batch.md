> ## Documentation Index
> Fetch the complete documentation index at: https://docs.coreweave.com/llms.txt
> Use this file to discover all available pages before exploring further.

# Feedback Create Batch

> Add multiple feedback items to calls or objects.



## OpenAPI

````yaml products/wandb/weave/reference/service-api/openapi.json POST /feedback/batch/create
openapi: 3.1.0
info:
  title: FastAPI
  version: 0.1.0
servers: []
security: []
paths:
  /feedback/batch/create:
    post:
      tags:
        - Feedback
      summary: Feedback Create Batch
      description: Add multiple feedback items to calls or objects.
      operationId: feedback_create_batch_feedback_batch_create_post
      requestBody:
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/FeedbackCreateBatchReq'
        required: true
      responses:
        '200':
          description: Successful Response
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/FeedbackCreateBatchRes'
        '422':
          description: Validation Error
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/HTTPValidationError'
components:
  schemas:
    FeedbackCreateBatchReq:
      properties:
        batch:
          items:
            $ref: '#/components/schemas/FeedbackCreateReq'
          type: array
          title: Batch
      type: object
      required:
        - batch
      title: FeedbackCreateBatchReq
    FeedbackCreateBatchRes:
      properties:
        res:
          items:
            $ref: '#/components/schemas/FeedbackCreateRes'
          type: array
          title: Res
      type: object
      required:
        - res
      title: FeedbackCreateBatchRes
    HTTPValidationError:
      properties:
        detail:
          items:
            $ref: '#/components/schemas/ValidationError'
          type: array
          title: Detail
      type: object
      title: HTTPValidationError
    FeedbackCreateReq:
      properties:
        id:
          anyOf:
            - type: string
            - type: 'null'
          title: Id
          description: >-
            If provided by the client, this ID will be used for the feedback row
            instead of a server-generated one.
          examples:
            - 018f1f2a-9c2b-7d3e-b5a1-8c9d2e4f6a7b
        project_id:
          type: string
          title: Project Id
          examples:
            - entity/project
        weave_ref:
          type: string
          title: Weave Ref
          examples:
            - weave:///entity/project/object/name:digest
        creator:
          anyOf:
            - type: string
            - type: 'null'
          title: Creator
          examples:
            - Jane Smith
        feedback_type:
          type: string
          title: Feedback Type
          examples:
            - custom
        payload:
          additionalProperties: true
          type: object
          title: Payload
          examples:
            - key: value
        annotation_ref:
          anyOf:
            - type: string
            - type: 'null'
          title: Annotation Ref
          examples:
            - weave:///entity/project/object/name:digest
        runnable_ref:
          anyOf:
            - type: string
            - type: 'null'
          title: Runnable Ref
          examples:
            - weave:///entity/project/op/name:digest
        call_ref:
          anyOf:
            - type: string
            - type: 'null'
          title: Call Ref
          examples:
            - weave:///entity/project/call/call_id
        trigger_ref:
          anyOf:
            - type: string
            - type: 'null'
          title: Trigger Ref
          examples:
            - weave:///entity/project/object/name:digest
        queue_id:
          anyOf:
            - type: string
            - type: 'null'
          title: Queue Id
          description: >-
            The annotation queue ID this feedback was created from. References
            annotation_queues.id. NULL when feedback is created outside of
            queues.
          examples:
            - 018f1f2a-9c2b-7d3e-b5a1-8c9d2e4f6a7b
        scorer_tags:
          items:
            type: string
          type: array
          title: Scorer Tags
          description: Tags applied to the ref by a scorer
          examples:
            - - nsfw
              - high-quality
        scorer_tag_reasons:
          additionalProperties:
            type: string
          type: object
          title: Scorer Tag Reasons
          description: reason text per tag, keyed by tag name
          examples:
            - nsfw: Contains explicit language
        scorer_tag_confidences:
          additionalProperties:
            type: number
          type: object
          title: Scorer Tag Confidences
          description: confidence (0-1) per tag, keyed by tag name
          examples:
            - nsfw: 0.92
        scorer_ratings:
          additionalProperties:
            type: number
          type: object
          title: Scorer Ratings
          description: numeric ratings (0-1) keyed by rating name
          examples:
            - _rating_: 0.87
        scorer_rating_reasons:
          additionalProperties:
            type: string
          type: object
          title: Scorer Rating Reasons
          description: reason text per rating, keyed by rating name
          examples:
            - _rating_: very confident response
        scorer_rating_confidences:
          additionalProperties:
            type: number
          type: object
          title: Scorer Rating Confidences
          description: confidence (0-1) per rating, keyed by rating name
          examples:
            - _rating_: 0.92
        span_agent_name:
          type: string
          title: Span Agent Name
          description: Display name of the scored agent (from spans.agent_name)
          default: ''
          examples:
            - midi-generator
        span_agent_version:
          type: string
          title: Span Agent Version
          description: Version of the scored agent (from spans.agent_version)
          default: ''
          examples:
            - 1.2.0
        span_status_code:
          type: string
          title: Span Status Code
          description: Status of the scored turn (from spans.status_code)
          default: UNSET
          examples:
            - OK
        span_conversation_id:
          type: string
          title: Span Conversation Id
          description: Conversation the feedback belongs to (from spans.conversation_id)
          default: ''
        span_trace_id:
          type: string
          title: Span Trace Id
          description: Turn the feedback belongs to (from spans.trace_id)
          default: ''
        scorer_trace_id:
          type: string
          title: Scorer Trace Id
          description: >-
            Trace of the scorer (judge) invocation that produced this feedback
            (spans.trace_id of the judge call). Distinct from span_trace_id,
            which is the scored turn. Lets signals price the invocation off the
            judge span without joining the calls model.
          default: ''
        wb_user_id:
          anyOf:
            - type: string
            - type: 'null'
          title: Wb User Id
          description: Do not set directly. Server will automatically populate this field.
      type: object
      required:
        - project_id
        - weave_ref
        - feedback_type
        - payload
      title: FeedbackCreateReq
    FeedbackCreateRes:
      properties:
        id:
          type: string
          title: Id
        created_at:
          type: string
          format: date-time
          title: Created At
        wb_user_id:
          type: string
          title: Wb User Id
        payload:
          additionalProperties: true
          type: object
          title: Payload
      type: object
      required:
        - id
        - created_at
        - wb_user_id
        - payload
      title: FeedbackCreateRes
    ValidationError:
      properties:
        loc:
          items:
            anyOf:
              - type: string
              - type: integer
          type: array
          title: Location
        msg:
          type: string
          title: Message
        type:
          type: string
          title: Error Type
        input:
          title: Input
        ctx:
          type: object
          title: Context
      type: object
      required:
        - loc
        - msg
        - type
      title: ValidationError

````