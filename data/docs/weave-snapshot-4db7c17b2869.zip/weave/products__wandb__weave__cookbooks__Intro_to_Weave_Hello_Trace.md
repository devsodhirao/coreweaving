> ## Documentation Index
> Fetch the complete documentation index at: https://docs.coreweave.com/llms.txt
> Use this file to discover all available pages before exploring further.

# Introduction to Traces

> Learn how to use introduction to traces with W&B Weave

> [!NOTE]
>
> This is an interactive notebook. You can run it locally or use the following links:
>
> * [Open in Google Colab](https://colab.research.google.com/github/wandb/examples/blob/main/colabs/weave/Intro_to_Weave_Hello_Trace.ipynb)
> * [View source on GitHub](https://github.com/wandb/examples/blob/main/colabs/weave/Intro_to_Weave_Hello_Trace.ipynb)

This notebook shows you how to capture your first trace in W\&B Weave by decorating an OpenAI-powered function with `@weave.op`. Tracing helps you inspect the inputs, outputs, and intermediate steps of LLM calls so you can debug and improve your applications. This tutorial targets developers who are new to Weave and want a minimal end-to-end example.

## 🔑 Prerequisites

Before you can begin tracing in Weave, complete the following prerequisites. These steps install the required SDKs, authenticate you with Weights & Biases and OpenAI, and initialize a project to send traces to.

1. Install the Weave SDK and log in with your [API key](https://forge.coreweave.com/settings#apikeys).
2. Install the OpenAI SDK and log in with your [API key](https://platform.openai.com/api-keys).
3. Initialize your Weights & Biases project.

```python lines theme={"system"}
# Install dependencies and imports
!pip install wandb weave openai -q

import json
import os
from getpass import getpass

from openai import OpenAI

import weave

# 🔑 Setup your API keys
# Running this cell will prompt you for your API key with `getpass` and will not echo to the terminal.
#####
print("---")
print(
    "Create an API key at: https://forge.coreweave.com/settings#apikeys"
)
os.environ["WANDB_API_KEY"] = getpass("Enter your CoreWeave Forge API key: ")
print("---")
print("You can generate your OpenAI API key here: https://platform.openai.com/api-keys")
os.environ["OPENAI_API_KEY"] = getpass("Enter your OpenAI API key: ")
print("---")
#####

# 🏠 Enter your W&B project name
weave_client = weave.init("MY_PROJECT_NAME")  # 🐝 Your W&B project name
```

## 🐝 Run your first trace

The following code sample shows how to capture and visualize a trace in Weave using the `@weave.op` decorator. It defines a function called `extract_fruit` that sends a prompt to OpenAI's GPT-4o to extract structured data (fruit, color, and flavor) from a sentence. By decorating the function with `@weave.op`, Weave automatically tracks the function execution, including inputs, outputs, and intermediate steps. When you call the function with a sample sentence, Weave saves the full trace and makes it viewable in the Weights & Biases UI.

```python lines theme={"system"}
@weave.op()  # 🐝 Decorator to track requests
def extract_fruit(sentence: str) -> dict:
    client = OpenAI()
    system_prompt = (
        "Parse sentences into a JSON dict with keys: fruit, color and flavor."
    )
    response = client.chat.completions.create(
        model="gpt-4o",
        messages=[
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": sentence},
        ],
        temperature=0.7,
        response_format={"type": "json_object"},
    )
    extracted = response.choices[0].message.content
    return json.loads(extracted)

sentence = "There are many fruits that were found on the recently discovered planet Goocrux. There are neoskizzles that grow there, which are purple and taste like candy."
extract_fruit(sentence)
```

You now have a working Weave project that captures traces from a decorated function, and you can view the trace in the Weights & Biases UI.

## 🚀 More examples

Use the following resources to go deeper with Weave tracing:

* [Quickstart guide](https://docs.coreweave.com/products/wandb/weave/quickstart.md)
* [Advanced tracing topics](https://docs.coreweave.com/products/wandb/weave/tutorial-tracing_2.md)
* [Tracing in Weave](https://docs.coreweave.com/products/wandb/weave/guides/tracking/tracing.md)
