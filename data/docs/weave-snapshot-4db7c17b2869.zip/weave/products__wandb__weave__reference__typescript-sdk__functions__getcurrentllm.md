> ## Documentation Index
> Fetch the complete documentation index at: https://docs.coreweave.com/llms.txt
> Use this file to discover all available pages before exploring further.

# getCurrentLLM

> TypeScript SDK reference

```ts theme={"system"}
getCurrentLLM(): LLM | undefined
```

[GitHub source](https://github.com/wandb/weave/blob/7c9efdc9fe05ffcaf2430dd652ef9bc5b3ffdfaa/sdks/node/src/genai/context.ts#L72)

Returns the current LLM, or undefined.

## Returns

[`LLM`](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/interfaces/llm) | `undefined`
