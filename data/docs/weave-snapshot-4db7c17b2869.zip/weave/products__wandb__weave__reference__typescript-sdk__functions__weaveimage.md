> ## Documentation Index
> Fetch the complete documentation index at: https://docs.coreweave.com/llms.txt
> Use this file to discover all available pages before exploring further.

# weaveImage

> TypeScript SDK reference

```ts theme={"system"}
weaveImage(options: object): WeaveImage
```

[GitHub source](https://github.com/wandb/weave/blob/7c9efdc9fe05ffcaf2430dd652ef9bc5b3ffdfaa/sdks/node/src/media.ts#L31)

Create a new WeaveImage object

## Parameters

**options** `object` *required*

The options for this media type

* data: The raw image data as a Buffer
* imageType: (Optional) The image format: 'png' (default), 'jpeg' or 'webp'.
  Publishing always names the stored file image.png

**properties**

**data** `Buffer` *required*

**imageType** `"png" | "jpeg" | "webp"`

## Returns

[`WeaveImage`](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/interfaces/weaveimage)

## Example

```ts twoslash theme={"system"}
// @noErrors
const imageBuffer = fs.readFileSync('path/to/image.png');
const weaveImage = weaveImage({ data: imageBuffer });
```
