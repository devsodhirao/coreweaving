> ## Documentation Index
> Fetch the complete documentation index at: https://docs.coreweave.com/llms.txt
> Use this file to discover all available pages before exploring further.

# Turn

> TypeScript SDK reference

[GitHub source](https://github.com/wandb/weave/blob/7c9efdc9fe05ffcaf2430dd652ef9bc5b3ffdfaa/sdks/node/src/genai/turn.ts#L98)

An agent invocation. Typically wraps the work to respond to a single
user message. Emits an `invoke_agent` span and acts as the root of the
trace for that turn: it is always started under `ROOT_CONTEXT` so it
never accidentally inherits a parent from another OTel-instrumented
library.

Created by `weave.startTurn()` (or `conversation.startTurn()`) and
terminated with `end()`. Only one Turn may be active in an async chain.
Children (LLM, Tool, SubAgent) attach via the `startLLM`, `startTool`,
`startSubagent` methods.

## Examples

```ts twoslash theme={"system"}
// @noErrors
const turn = weave.startTurn();

try {
  const llm = turn.startLLM({model: 'gpt-4o', providerName: 'openai'});
  // ...
  llm.end();
} finally {
  turn.end();
}
```

```ts twoslash theme={"system"}
// @noErrors
const turn = weave.startTurn({
  model: 'gpt-4o',
  agentName: 'research-bot',
  agentId: 'research-bot-prod',
  agentDescription: 'Looks up facts on Wikipedia.',
  agentVersion: '1.4.2',
  userMessage: 'What is the weather in Tokyo?',
  systemInstructions: ['You are a helpful weather bot.'],
  startTime: new Date('2026-05-29T10:00:00.000Z'),
});

try {
  const llm = turn.startLLM({model: 'gpt-4o', providerName: 'openai'});
  // ...
  llm.end();
} finally {
  turn.end();
}
```

## Extends

* `SpanBase`

## Accessors

### agentName

#### Get Signature

> **get** **agentName**(): `string`

##### Returns

`string`

***

### model

#### Get Signature

> **get** **model**(): `string`

##### Returns

`string`

## Methods

### ~~addEvent()~~

> [!WARNING]
>
> **Deprecated.** Record this data via [setAttributes](#setattributes) instead.
> OpenTelemetry is phasing out the Span Event API (`Span.addEvent`). This
> method still works and existing span-event data stays valid.
> See [https://opentelemetry.io/blog/2026/deprecating-span-events/](https://opentelemetry.io/blog/2026/deprecating-span-events/)

> **addEvent**(`name`, `attributes?`, `startTime?`): `this`

Add a named event to the span. Useful for marking non-span moments such as
context compaction, tool-loop detection, or guardrail trips. Warns and
no-ops after `end()`. Mirrors OTel `Span.addEvent`.

#### Parameters

**name** `string` *required*

**attributes** `Attributes`

**startTime** `TimeInput`

#### Returns

`this`

#### Example

```ts twoslash theme={"system"}
// @noErrors
span.addEvent('context_compacted', {removedMessages: 12});
```

#### Inherited from

`SpanBase.addEvent`

***

### end()

> **end**(`opts?`): `void`

Read current field values (to reflect mutations made via `record()`
since `start`) and close the span. Idempotent. Pass `error` to mark
it as failed; pass `endTime` to backdate the close.

#### Parameters

**opts** `object`

**properties**

**endTime** `TimeInput`

**error** `Error`

#### Returns

`void`

***

### record()

> **record**(`opts`): `this`

Bulk-set any subset of the mutable fields. Replaces (does not merge).
Useful for assigning everything at once after a provider call returns.

#### Parameters

**opts** `object` *required*

**properties**

**agentDescription** `string`

**agentId** `string`

**agentName** `string`

**agentVersion** `string`

**messages** `Message[]`

See [`Message`](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/interfaces/message).

**model** `string`

**outputMessages** `Message[]`

See [`Message`](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/interfaces/message).

**systemInstructions** `string[]`

#### Returns

`this`

***

### ~~setAttribute()~~

> [!WARNING]
>
> **Deprecated.** Use [setAttributes](#setattributes) instead, which mirrors the Python
> SDK's `set_attributes` and OTel's `Span.setAttributes`. Retained as a thin
> alias so existing single-attribute callers keep working. Only `Turn`
> carries this — the other emitters never shipped a singular form.

> **setAttribute**(`key`, `value`): `this`

#### Parameters

**key** `string` *required*

**value** `AttributeValue` *required*

#### Returns

`this`

***

### setAttributes()

> **setAttributes**(`attributes`): `this`

Set multiple attributes on the span at once. Warns and no-ops after
`end()`. Mirrors OTel `Span.setAttributes` (and the Python SDK's
`set_attributes`).

#### Parameters

**attributes** `Attributes` *required*

#### Returns

`this`

#### Example

```ts twoslash theme={"system"}
// @noErrors
span.setAttributes({'weave.tag': 'prod', 'gen_ai.response.id': id});
```

#### Inherited from

`SpanBase.setAttributes`

***

### startLLM()

> **startLLM**(`opts`): [`LLM`](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/interfaces/llm)

Start a child LLM span under this Turn.

#### Parameters

**opts** `LLMInit` *required*

See [`LLMInit`](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/interfaces/llminit).

#### Returns

[`LLM`](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/interfaces/llm)

***

### startSubagent()

> **startSubagent**(`opts`): [`SubAgent`](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/interfaces/subagent)

Start a child SubAgent span under this Turn.

#### Parameters

**opts** `SubAgentInit` *required*

See [`SubAgentInit`](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/interfaces/subagentinit).

#### Returns

[`SubAgent`](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/interfaces/subagent)

***

### startTool()

> **startTool**(`opts`): [`Tool`](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/interfaces/tool)

Start a child Tool span under this Turn.

#### Parameters

**opts** `ToolInit` *required*

See [`ToolInit`](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/interfaces/toolinit).

#### Returns

[`Tool`](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/interfaces/tool)
