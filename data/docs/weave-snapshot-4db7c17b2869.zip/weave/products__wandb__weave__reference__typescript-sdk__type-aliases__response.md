> ## Documentation Index
> Fetch the complete documentation index at: https://docs.coreweave.com/llms.txt
> Use this file to discover all available pages before exploring further.

# Response<T>

> TypeScript SDK reference

> **Response**\<`T`> = [`HttpResponse`](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/interfaces/httpresponse)\<`T`, [`HTTPValidationError`](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/interfaces/httpvalidationerror)>

[GitHub source](https://github.com/wandb/weave/blob/7c9efdc9fe05ffcaf2430dd652ef9bc5b3ffdfaa/sdks/node/src/weaveClient.ts#L72)

## Type Parameters

**T**
