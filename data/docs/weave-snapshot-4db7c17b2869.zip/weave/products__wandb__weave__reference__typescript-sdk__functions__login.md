> ## Documentation Index
> Fetch the complete documentation index at: https://docs.coreweave.com/llms.txt
> Use this file to discover all available pages before exploring further.

# login

> TypeScript SDK reference

```ts theme={"system"}
login(apiKey: string, host?: string): Promise<void>
```

[GitHub source](https://github.com/wandb/weave/blob/7c9efdc9fe05ffcaf2430dd652ef9bc5b3ffdfaa/sdks/node/src/clientApi.ts#L26)

Log in to Weights & Biases (W\&B) using the provided API key.
This function attempts to save the credentials to your netrc file for future use,
but will continue even if it cannot write to the file system.

## Parameters

**apiKey** `string` *required*

Your W\&B API key.

**host** `string`

(Optional) The host name (usually only needed if you're using a custom W\&B server).

## Returns

`Promise`\<`void`>

## Throws

If the API key is not specified or if the connection to the weave trace server cannot be verified.
