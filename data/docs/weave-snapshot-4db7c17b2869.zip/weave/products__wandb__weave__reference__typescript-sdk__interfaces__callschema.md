> ## Documentation Index
> Fetch the complete documentation index at: https://docs.coreweave.com/llms.txt
> Use this file to discover all available pages before exploring further.

# CallSchema

> TypeScript SDK reference

[GitHub source](https://github.com/wandb/weave/blob/7c9efdc9fe05ffcaf2430dd652ef9bc5b3ffdfaa/sdks/node/src/generated/traceServerApi.ts#L2012)

CallSchema

## Properties

### attributes

> **attributes**: `Record`\<`string`, `any`>

Attributes

***

### deleted\_at

> `optional` **deleted\_at**: `string` | `null`

Deleted At

***

### display\_name

> `optional` **display\_name**: `string` | `null`

Display Name

***

### ended\_at

> `optional` **ended\_at**: `string` | `null`

Ended At

***

### exception

> `optional` **exception**: `string` | `null`

Exception

***

### expire\_at

> `optional` **expire\_at**: `string` | `null`

Expire At
Expiration timestamp for this call. None = no TTL configured for the project (the row will not be expired).

***

### id

> **id**: `string`

Id

***

### inputs

> **inputs**: `Record`\<`string`, `any`>

Inputs

***

### op\_name

> **op\_name**: `string`

Op Name

***

### output

> `optional` **output**: `null`

Output

***

### parent\_id

> `optional` **parent\_id**: `string` | `null`

Parent Id

***

### project\_id

> **project\_id**: `string`

Project Id

***

### started\_at

> **started\_at**: `string`

Started At

#### Format

date-time

***

### storage\_size\_bytes

> `optional` **storage\_size\_bytes**: `number` | `null`

Storage Size Bytes

***

### summary

> `optional` **summary**: `Record`\<`string`, `any`>

***

### thread\_id

> `optional` **thread\_id**: `string` | `null`

Thread Id

***

### total\_storage\_size\_bytes

> `optional` **total\_storage\_size\_bytes**: `number` | `null`

Total Storage Size Bytes

***

### trace\_id

> **trace\_id**: `string`

Trace Id

***

### turn\_id

> `optional` **turn\_id**: `string` | `null`

Turn Id

***

### wb\_run\_id

> `optional` **wb\_run\_id**: `string` | `null`

Wb Run Id

***

### wb\_run\_step

> `optional` **wb\_run\_step**: `number` | `null`

Wb Run Step

***

### wb\_run\_step\_end

> `optional` **wb\_run\_step\_end**: `number` | `null`

Wb Run Step End

***

### wb\_user\_id

> `optional` **wb\_user\_id**: `string` | `null`

Wb User Id

***

### wb\_username

> `optional` **wb\_username**: `string` | `null`

Wb Username
