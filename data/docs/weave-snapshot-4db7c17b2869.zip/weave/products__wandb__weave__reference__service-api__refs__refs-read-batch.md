> ## Documentation Index
> Fetch the complete documentation index at: https://docs.coreweave.com/llms.txt
> Use this file to discover all available pages before exploring further.

# Refs Read Batch



## OpenAPI

````yaml products/wandb/weave/reference/service-api/openapi.json POST /refs/read_batch
openapi: 3.1.0
info:
  title: FastAPI
  version: 0.1.0
servers: []
security: []
paths:
  /refs/read_batch:
    post:
      tags:
        - Refs
      summary: Refs Read Batch
      operationId: refs_read_batch_refs_read_batch_post
      requestBody:
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/RefsReadBatchReq'
        required: true
      responses:
        '200':
          description: Successful Response
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/RefsReadBatchRes'
        '422':
          description: Validation Error
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/HTTPValidationError'
components:
  schemas:
    RefsReadBatchReq:
      properties:
        refs:
          items:
            type: string
          type: array
          title: Refs
      type: object
      required:
        - refs
      title: RefsReadBatchReq
    RefsReadBatchRes:
      properties:
        vals:
          items: {}
          type: array
          title: Vals
      type: object
      required:
        - vals
      title: RefsReadBatchRes
    HTTPValidationError:
      properties:
        detail:
          items:
            $ref: '#/components/schemas/ValidationError'
          type: array
          title: Detail
      type: object
      title: HTTPValidationError
    ValidationError:
      properties:
        loc:
          items:
            anyOf:
              - type: string
              - type: integer
          type: array
          title: Location
        msg:
          type: string
          title: Message
        type:
          type: string
          title: Error Type
        input:
          title: Input
        ctx:
          type: object
          title: Context
      type: object
      required:
        - loc
        - msg
        - type
      title: ValidationError

````