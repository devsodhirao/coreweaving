> ## Documentation Index
> Fetch the complete documentation index at: https://docs.coreweave.com/llms.txt
> Use this file to discover all available pages before exploring further.

# SubAgentInit

> TypeScript SDK reference

[GitHub source](https://github.com/wandb/weave/blob/7c9efdc9fe05ffcaf2430dd652ef9bc5b3ffdfaa/sdks/node/src/genai/subagent.ts#L29)

## Extends

* `SpanInitBase`

## Properties

### agentDescription

> `optional` **agentDescription**: `string`

***

### agentId

> `optional` **agentId**: `string`

***

### agentVersion

> `optional` **agentVersion**: `string`

***

### model

> `optional` **model**: `string`

***

### name

> **name**: `string`

***

### startTime

> `optional` **startTime**: `TimeInput`

#### Inherited from

`SpanInitBase.startTime`

***

### systemInstructions

> `optional` **systemInstructions**: `string`\[]
