> ## Documentation Index
> Fetch the complete documentation index at: https://docs.coreweave.com/llms.txt
> Use this file to discover all available pages before exploring further.

# LLM

> TypeScript SDK reference

[GitHub source](https://github.com/wandb/weave/blob/7c9efdc9fe05ffcaf2430dd652ef9bc5b3ffdfaa/sdks/node/src/genai/llm.ts#L90)

An LLM call. Emits a `chat` span with `gen_ai.*` attributes.

Created by `weave.startLLM()` (or `turn.startLLM()`) and terminated with
`end()`. Only one LLM may be active in an async context at a time; nest
tool/subagent calls under it via `startTool` / `startSubagent`.

Populate `inputMessages` / `outputMessages` / `usage` / `reasoning` directly,
or via the helper functions (`output`, `think`, `attachMedia`, `record`).

All recorded data is flushed to the span at `end()`.

## Examples

```ts twoslash theme={"system"}
// @noErrors
const llm = weave.startLLM({model: 'gpt-4o-mini', providerName: 'openai'});

try {
  llm.inputMessages = [{role: 'user', content: prompt}];
  const resp = await openai.chat.completions.create({...});
  llm.output(resp.choices[0].message.content ?? '');
  llm.record({usage: {inputTokens: resp.usage?.prompt_tokens}});
} finally {
  llm.end();
}
```

```ts twoslash theme={"system"}
// @noErrors
const llm = weave.startLLM({
  model: 'gpt-4o-mini',
  providerName: 'openai',
  systemInstructions: ['You are a helpful weather bot.'],
  startTime: new Date('2026-05-29T10:00:00.000Z'),
});

try {
  // ... call the LLM, populate llm.outputMessages / usage ...
} finally {
  llm.end();
}
```

## Extends

* `SpanBase`

## Properties

### inputMessages

> **inputMessages**: [`Message`](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/interfaces/message)\[] = `[]`

Input messages sent to the model. Flushed to `gen_ai.input.messages` on
`end()`.

***

### model

> `readonly` **model**: `string`

***

### outputMessages

> **outputMessages**: [`Message`](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/interfaces/message)\[] = `[]`

Assistant messages returned by the model. Flushed to
`gen_ai.output.messages` on `end()`.

***

### providerName

> `readonly` **providerName**: `string`

***

### reasoning

> `optional` **reasoning**: [`Reasoning`](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/interfaces/reasoning)

Chain-of-thought content. Folded into the last assistant message as a
ReasoningPart at serialization time.

***

### usage

> **usage**: [`Usage`](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/interfaces/usage) = `{}`

Token counts and cache stats. Flushed to `gen_ai.usage.*` on `end()`.

## Methods

### ~~addEvent()~~

> [!WARNING]
>
> **Deprecated.** Record this data via [setAttributes](#setattributes) instead.
> OpenTelemetry is phasing out the Span Event API (`Span.addEvent`). This
> method still works and existing span-event data stays valid.
> See [https://opentelemetry.io/blog/2026/deprecating-span-events/](https://opentelemetry.io/blog/2026/deprecating-span-events/)

> **addEvent**(`name`, `attributes?`, `startTime?`): `this`

Add a named event to the span. Useful for marking non-span moments such as
context compaction, tool-loop detection, or guardrail trips. Warns and
no-ops after `end()`. Mirrors OTel `Span.addEvent`.

#### Parameters

**name** `string` *required*

**attributes** `Attributes`

**startTime** `TimeInput`

#### Returns

`this`

#### Example

```ts twoslash theme={"system"}
// @noErrors
span.addEvent('context_compacted', {removedMessages: 12});
```

#### Inherited from

`SpanBase.addEvent`

***

### attachMedia()

> **attachMedia**(`opts`): `this`

Stage a media attachment for the LLM call. Pick exactly one of
`content` (inline base64 bytes), `uri` (URI reference), or `fileId`
(pre-uploaded file id). The attachment is glued onto the last user
message in `inputMessages` on `end()`.

#### Parameters

**opts** `\{…\} | \{…\} | \{…\}` *required*

See [`Modality`](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/type-aliases/modality), [`Modality`](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/type-aliases/modality), [`Modality`](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/type-aliases/modality).

Full type: `{ content: string; mimeType: string; modality: Modality; } | { modality: Modality; uri: string; } | { fileId: string; mimeType?: string; modality: Modality; }`

#### Returns

`this`

***

### attachMediaUrl()

> **attachMediaUrl**(`url`, `opts`): `this`

Convenience for `attachMedia({uri, modality})`.

#### Parameters

**url** `string` *required*

**opts** `object` *required*

**properties**

**modality** `Modality` *required*

See [`Modality`](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/type-aliases/modality).

#### Returns

`this`

***

### end()

> **end**(`opts?`): `void`

Flush accumulated state and close the span. Idempotent. Pass `error` to mark failed; pass `endTime` to backdate the close.

#### Parameters

**opts** `object`

**properties**

**endTime** `TimeInput`

**error** `Error`

#### Returns

`void`

***

### output()

> **output**(`content`): `this`

Append an assistant message to the response.

#### Parameters

**content** `string` *required*

#### Returns

`this`

***

### record()

> **record**(`opts`): `this`

Bulk-set any subset of the mutable fields. Replaces (does not merge).
Useful for assigning everything at once after a provider call returns.

#### Parameters

**opts** `object` *required*

**properties**

**finishReasons** `string[]`

**inputMessages** `Message[]`

See [`Message`](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/interfaces/message).

**mediaAttachments** `(\{…\} | \{…\} | \{…\})[]`

See [`Modality`](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/type-aliases/modality), [`Modality`](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/type-aliases/modality), [`Modality`](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/type-aliases/modality).

Full type: `({ content: string; mimeType: string; modality: Modality; } | { modality: Modality; uri: string; } | { fileId: string; mimeType?: string; modality: Modality; })[]`

**outputMessages** `Message[]`

See [`Message`](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/interfaces/message).

**outputType** `string`

**reasoning** `Reasoning`

See [`Reasoning`](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/interfaces/reasoning).

**responseId** `string`

**responseModel** `string`

**usage** `Usage`

See [`Usage`](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/interfaces/usage).

#### Returns

`this`

***

### setAttributes()

> **setAttributes**(`attributes`): `this`

Set multiple attributes on the span at once. Warns and no-ops after
`end()`. Mirrors OTel `Span.setAttributes` (and the Python SDK's
`set_attributes`).

#### Parameters

**attributes** `Attributes` *required*

#### Returns

`this`

#### Example

```ts twoslash theme={"system"}
// @noErrors
span.setAttributes({'weave.tag': 'prod', 'gen_ai.response.id': id});
```

#### Inherited from

`SpanBase.setAttributes`

***

### startSubagent()

> **startSubagent**(`opts`): [`SubAgent`](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/interfaces/subagent)

Start a child SubAgent span nested under this LLM.

#### Parameters

**opts** `SubAgentInit` *required*

See [`SubAgentInit`](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/interfaces/subagentinit).

#### Returns

[`SubAgent`](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/interfaces/subagent)

***

### startTool()

> **startTool**(`opts`): [`Tool`](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/interfaces/tool)

Start a child Tool span nested under this LLM.

#### Parameters

**opts** `ToolInit` *required*

See [`ToolInit`](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/interfaces/toolinit).

#### Returns

[`Tool`](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/interfaces/tool)

***

### think()

> **think**(`content`): `this`

Set or extend the model's reasoning/chain-of-thought content. Accumulates
into `this.reasoning.content`. Folded into the last assistant message as
a `ReasoningPart` at serialization time, matching the Python SDK's
on-the-wire shape.

#### Parameters

**content** `string` *required*

#### Returns

`this`
