> ## Documentation Index
> Fetch the complete documentation index at: https://docs.coreweave.com/llms.txt
> Use this file to discover all available pages before exploring further.

# Calls Complete

> Upsert a batch of completed calls directly to the calls_complete table.

Each call in the batch contains both start and end information.
This endpoint is used when calls are buffered client-side and sent as complete records.



## OpenAPI

````yaml products/wandb/weave/reference/service-api/openapi.json POST /v2/{entity}/{project}/calls/complete
openapi: 3.1.0
info:
  title: FastAPI
  version: 0.1.0
servers: []
security: []
paths:
  /v2/{entity}/{project}/calls/complete:
    post:
      tags:
        - Calls
      summary: Calls Complete
      description: >-
        Upsert a batch of completed calls directly to the calls_complete table.


        Each call in the batch contains both start and end information.

        This endpoint is used when calls are buffered client-side and sent as
        complete records.
      operationId: calls_complete_v2__entity___project__calls_complete_post
      parameters:
        - name: entity
          in: path
          required: true
          schema:
            type: string
            title: Entity
        - name: project
          in: path
          required: true
          schema:
            type: string
            title: Project
      requestBody:
        required: true
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/CallsUpsertCompleteReq'
      responses:
        '200':
          description: Successful Response
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/CallsUpsertCompleteRes'
        '422':
          description: Validation Error
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/HTTPValidationError'
components:
  schemas:
    CallsUpsertCompleteReq:
      properties:
        batch:
          items:
            $ref: '#/components/schemas/CompletedCallSchemaForInsert'
          type: array
          title: Batch
      type: object
      required:
        - batch
      title: CallsUpsertCompleteReq
      description: Request for upserting a batch of completed calls.
    CallsUpsertCompleteRes:
      properties: {}
      type: object
      title: CallsUpsertCompleteRes
      description: Response for upserting a batch of completed calls.
    HTTPValidationError:
      properties:
        detail:
          items:
            $ref: '#/components/schemas/ValidationError'
          type: array
          title: Detail
      type: object
      title: HTTPValidationError
    CompletedCallSchemaForInsert:
      properties:
        project_id:
          type: string
          title: Project Id
        id:
          type: string
          title: Id
        trace_id:
          type: string
          title: Trace Id
        op_name:
          type: string
          title: Op Name
        started_at:
          type: string
          format: date-time
          title: Started At
        ended_at:
          type: string
          format: date-time
          title: Ended At
        display_name:
          anyOf:
            - type: string
            - type: 'null'
          title: Display Name
        parent_id:
          anyOf:
            - type: string
            - type: 'null'
          title: Parent Id
        thread_id:
          anyOf:
            - type: string
            - type: 'null'
          title: Thread Id
        turn_id:
          anyOf:
            - type: string
            - type: 'null'
          title: Turn Id
        attributes:
          additionalProperties: true
          type: object
          title: Attributes
        inputs:
          additionalProperties: true
          type: object
          title: Inputs
        output:
          anyOf:
            - {}
            - type: 'null'
          title: Output
        summary:
          $ref: '#/components/schemas/SummaryInsertMap'
        otel_dump:
          anyOf:
            - additionalProperties: true
              type: object
            - type: 'null'
          title: Otel Dump
        exception:
          anyOf:
            - type: string
            - type: 'null'
          title: Exception
        wb_user_id:
          anyOf:
            - type: string
            - type: 'null'
          title: Wb User Id
          description: Do not set directly. Server will automatically populate this field.
        wb_run_id:
          anyOf:
            - type: string
            - type: 'null'
          title: Wb Run Id
        wb_run_step:
          anyOf:
            - type: integer
            - type: 'null'
          title: Wb Run Step
        wb_run_step_end:
          anyOf:
            - type: integer
            - type: 'null'
          title: Wb Run Step End
      type: object
      required:
        - project_id
        - id
        - trace_id
        - op_name
        - started_at
        - ended_at
        - attributes
        - inputs
        - summary
      title: CompletedCallSchemaForInsert
      description: >-
        Schema for inserting a completed call directly.


        This represents a call that is already finished at insertion time, with
        both

        start and end information provided together. Used by the calls_complete
        endpoint.
    ValidationError:
      properties:
        loc:
          items:
            anyOf:
              - type: string
              - type: integer
          type: array
          title: Location
        msg:
          type: string
          title: Message
        type:
          type: string
          title: Error Type
        input:
          title: Input
        ctx:
          type: object
          title: Context
      type: object
      required:
        - loc
        - msg
        - type
      title: ValidationError
    SummaryInsertMap:
      properties:
        usage:
          additionalProperties:
            $ref: '#/components/schemas/LLMUsageSchema'
          type: object
          title: Usage
        status_counts:
          additionalProperties:
            type: integer
          propertyNames:
            $ref: '#/components/schemas/TraceStatus'
          type: object
          title: Status Counts
      additionalProperties: true
      type: object
      title: SummaryInsertMap
    LLMUsageSchema:
      properties:
        prompt_tokens:
          anyOf:
            - type: integer
            - type: 'null'
          title: Prompt Tokens
        input_tokens:
          anyOf:
            - type: integer
            - type: 'null'
          title: Input Tokens
        completion_tokens:
          anyOf:
            - type: integer
            - type: 'null'
          title: Completion Tokens
        output_tokens:
          anyOf:
            - type: integer
            - type: 'null'
          title: Output Tokens
        requests:
          anyOf:
            - type: integer
            - type: 'null'
          title: Requests
        total_tokens:
          anyOf:
            - type: integer
            - type: 'null'
          title: Total Tokens
        cache_creation_input_tokens:
          anyOf:
            - type: integer
            - type: 'null'
          title: Cache Creation Input Tokens
        cache_read_input_tokens:
          anyOf:
            - type: integer
            - type: 'null'
          title: Cache Read Input Tokens
      additionalProperties: true
      type: object
      title: LLMUsageSchema

````