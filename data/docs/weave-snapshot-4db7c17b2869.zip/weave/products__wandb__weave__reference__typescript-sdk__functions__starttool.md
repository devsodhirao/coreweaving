> ## Documentation Index
> Fetch the complete documentation index at: https://docs.coreweave.com/llms.txt
> Use this file to discover all available pages before exploring further.

# startTool

> TypeScript SDK reference

```ts theme={"system"}
startTool(opts: ToolInit): Tool
```

[GitHub source](https://github.com/wandb/weave/blob/7c9efdc9fe05ffcaf2430dd652ef9bc5b3ffdfaa/sdks/node/src/genai/api.ts#L110)

Start a Tool span. Parent resolution (matches the design's "flat by
default, hierarchical if you nest"):

* If an LLM is active, the Tool nests under it.
* Otherwise, the Tool is a sibling under the current Turn.

Throws if neither a Turn nor an LLM is active.

## Parameters

**opts** `ToolInit` *required*

See [`ToolInit`](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/interfaces/toolinit).

## Returns

[`Tool`](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/interfaces/tool)

## Examples

```ts twoslash theme={"system"}
// @noErrors
weave.startTool({
  name: 'get_weather',
  args: {city: 'Tokyo'},
  toolCallId: 'call_t1',
});
```

```ts twoslash theme={"system"}
// @noErrors
weave.startTool({
  name: 'get_weather',
  args: {city: 'Tokyo'},
  toolCallId: 'call_t1',
  startTime: new Date('2026-05-29T10:00:00.800Z'),
});
```
