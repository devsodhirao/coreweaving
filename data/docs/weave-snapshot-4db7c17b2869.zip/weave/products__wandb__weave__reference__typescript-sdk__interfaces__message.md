> ## Documentation Index
> Fetch the complete documentation index at: https://docs.coreweave.com/llms.txt
> Use this file to discover all available pages before exploring further.

# Message

> TypeScript SDK reference

[GitHub source](https://github.com/wandb/weave/blob/7c9efdc9fe05ffcaf2430dd652ef9bc5b3ffdfaa/sdks/node/src/genai/types.ts#L27)

## Properties

### content

> `optional` **content**: `string`

***

### parts

> `optional` **parts**: [`MessagePart`](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/type-aliases/messagepart)\[]

***

### role

> **role**: [`Role`](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/type-aliases/role)

***

### toolCallId

> `optional` **toolCallId**: `string`

***

### toolName

> `optional` **toolName**: `string`
