> ## Documentation Index
> Fetch the complete documentation index at: https://docs.coreweave.com/llms.txt
> Use this file to discover all available pages before exploring further.

# op

> TypeScript SDK reference

## Call Signature

```ts theme={"system"}
op<T>(fn: T, options?: object): Op<T>
```

[GitHub source](https://github.com/wandb/weave/blob/7c9efdc9fe05ffcaf2430dd652ef9bc5b3ffdfaa/sdks/node/src/op.ts#L392)

### Type Parameters

**T** `extends (...args) =\> any`

### Parameters

**fn** `T` *required*

**options** `object`

**properties**

**attributes** `Record\<string, any\>`

Default attributes applied to every call this op creates. Integrations set
this to stamp `attributes.integration` provenance. Merged beneath `kind`/
`color`, which take precedence on key collision.

**bindThis** `WeaveObject`

See [`WeaveObject`](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/classes/weaveobject).

**callDisplayName** `(...args) =\> string`

**isDecorator** `boolean`

**name** `string`

**opColor** `string`

Custom color for the operation in the UI

**opKind** `string`

The kind of operation (e.g., 'llm', 'agent', 'tool', 'search') for UI categorization

**originalFunction** `T`

**parameterNames** `"useParam0Object" | string[]`

**shouldAdoptThis** `boolean`

**streamReducer** `object`

Full type: `{ finalizeFn: (state) => void; initialStateFn: () => any; reduceFn: (state, chunk) => any; }`

**properties**

**finalizeFn** `(state) =\> void` *required*

**initialStateFn** `() =\> any` *required*

**reduceFn** `(state, chunk) =\> any` *required*

**summarize** `(result) =\> Record\<string, any\>`

### Returns

[`Op`](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/type-aliases/op)\<`T`>

## Call Signature

```ts theme={"system"}
op<T>(thisArg: any, fn: T, options?: object): Op<T>
```

### Type Parameters

**T** `extends (...args) =\> any`

### Parameters

**thisArg** `any` *required*

**fn** `T` *required*

**options** `object`

**properties**

**attributes** `Record\<string, any\>`

Default attributes applied to every call this op creates. Integrations set
this to stamp `attributes.integration` provenance. Merged beneath `kind`/
`color`, which take precedence on key collision.

**bindThis** `WeaveObject`

See [`WeaveObject`](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/classes/weaveobject).

**callDisplayName** `(...args) =\> string`

**isDecorator** `boolean`

**name** `string`

**opColor** `string`

Custom color for the operation in the UI

**opKind** `string`

The kind of operation (e.g., 'llm', 'agent', 'tool', 'search') for UI categorization

**originalFunction** `T`

**parameterNames** `"useParam0Object" | string[]`

**shouldAdoptThis** `boolean`

**streamReducer** `object`

Full type: `{ finalizeFn: (state) => void; initialStateFn: () => any; reduceFn: (state, chunk) => any; }`

**properties**

**finalizeFn** `(state) =\> void` *required*

**initialStateFn** `() =\> any` *required*

**reduceFn** `(state, chunk) =\> any` *required*

**summarize** `(result) =\> Record\<string, any\>`

### Returns

[`Op`](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/type-aliases/op)\<`T`>

## Call Signature

```ts theme={"system"}
op(target: object, propertyKey: string | symbol, descriptor: TypedPropertyDescriptor<any>): TypedPropertyDescriptor<any>
```

### Parameters

**target** `object` *required*

**propertyKey** `string | symbol` *required*

**descriptor** `TypedPropertyDescriptor\<any\>` *required*

### Returns

`TypedPropertyDescriptor`\<`any`>

## Call Signature

```ts theme={"system"}
op<T>(value: T, context: object): Op<T>
```

### Type Parameters

**T** `extends (...args) =\> any`

### Parameters

**value** `T` *required*

**context** `object` *required*

**properties**

**access** `\{ get: Function; has: boolean; \}`

**properties**

**get** *required*

**has** *required*

**class** `Function`

**kind** `"method"` *required*

**metadata** `any`

**name** `string | symbol` *required*

**private** `boolean`

**static** `boolean`

**addInitializer**

### Returns

[`Op`](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/type-aliases/op)\<`T`>

## Call Signature

```ts theme={"system"}
op(options: Partial<OpOptions<any>>): MethodDecorator
```

### Parameters

**options** `Partial\<OpOptions\<any\>\>` *required*

### Returns

`MethodDecorator`
