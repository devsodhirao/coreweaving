> ## Documentation Index
> Fetch the complete documentation index at: https://docs.coreweave.com/llms.txt
> Use this file to discover all available pages before exploring further.

# Create and manage saved views

> Customize how you interact with traced function calls and evaluations

In Weave, *saved views* let you customize how you interact with traced function calls and evaluations. By defining a saved view, you can configure filters, sorting, and column visibility to quickly access relevant data. Saved views help you and your team return to the same curated slice of your traces or evaluations without reapplying configuration each time.

You can create, modify, and save views through the UI or directly in the Weave Python SDK. The UI lets you explore and save different table configurations in the **Traces** and **Evals** tabs, while the Python SDK provides fine-grained control for programmatic filtering and querying. Select the tab that matches your workflow.

**UI**

You can create, load, rename, and edit saved views in the Weights & Biases UI. The UI is the quickest way to capture an ad hoc table configuration as a reusable view. For programmatic control, select the **Python** tab.

### Create a saved view

1. Navigate to your **Traces** or **Evals** tab.
2. Adjust any of the following variables in your table configuration:
   * Filters
   * Sort order
   * Page size
   * Column visibility
   * Column pinning
3. Save the view using one of two options:
   * In the upper-right corner, click **Save view**.
   * Click the **menu** () button to the left of **Save view**. In the dropdown menu, click **+ Save as new view**.

### Load a saved view

1. Navigate to your **Traces** or **Evals** tab.
2. Click the **menu** () button to the left of the tab title. A dropdown menu showing all saved views displays.
3. Click the view that you want to access. The saved view displays in the **Traces** or **Evals** tab.

### Rename a saved view

1. Follow the steps described in [Load a saved view](#load-a-saved-view).
2. In the upper-left corner of the **Traces** or **Evals** tab, click the view name.
3. Enter a new name for the view.
4. To save the new view name, press **Enter**.

### Edit a saved view

1. Follow the steps described in [Load a saved view](#load-a-saved-view).
2. Adjust your table configuration.
3. In the upper-right corner, click **Save view**.

### Delete a saved view

> [!WARNING]
>
> You can delete a view if you believe it's no longer useful to you and your team. You can't undo this action.

1. Navigate to your **Traces** or **Evals** tab.
2. [Load the view](#load-a-saved-view) that you want to delete.
3. Click the **menu** () button to the left of **Save view**.
4. In the dropdown menu, click **Delete view**.
5. In the pop-up modal, confirm by clicking **Delete view**. Alternatively, click **Cancel** to stop deletion.

### Return to the default view

1. Navigate to your **Traces** or **Evals** tab.
2. Click the **menu** () button to the right of the **Traces** or **Evals** tab. A dropdown menu showing all saved views displays.
3. At the bottom of the menu, click **Traces** or **Evals**. The default view displays.

**Python**

The `SavedView` class in Weave lets you save, filter, sort, and customize views of trace and evals data. The following sections walk through how to initialize a view, configure its columns and filters, and persist it so you can retrieve matching Calls later.

### Initialize a `SavedView`

Initialize a `SavedView` instance in your Weave project:

```python lines theme={"system"}
import weave
client = weave.init("[MY_PROJECT]")

view = weave.SavedView()
```

### Visualize the `SavedView` as a grid

Use `.to_grid()` to display the saved view as a grid. Specify the maximum number of rows to display with `limit`.

```python lines theme={"system"}
view.to_grid(limit=5)
```

Display the grid representation using `.show()`:

```python lines theme={"system"}
view.to_grid().show()
```

### Set displayed columns

Use `.set_columns()` to set the columns that display in the view. Specify one or more columns to display.

```python lines theme={"system"}
view.set_columns("id", "op_name")
```

### Add columns

Use `.add_column()` to add one or more new columns to the view. Specify one or more columns to add.

```python lines theme={"system"}
# Add a column with the field specifier and label "Created"
view.add_column("Created")
# Optionally, you can add a second argument to specify a different label name for the new column. By default, the field specifier is used for the label.
```

### Sort columns

Use `.sort_by()` to sort results based on a specific column. Specify the column name to sort and the sort order (`asc` or `desc`).

```python lines theme={"system"}
view.sort_by("started_at", "desc")
```

### Filter by operation name

In Weave, every trace or eval is associated with an operation name.
Use `.filter_op()` to filter the `SavedView` to only include Calls where that specific operation ran.

```python lines theme={"system"}
view.filter_op("Evaluation.predict_and_score")
```

### Filter by operator and condition

Use `.add_filter()` to apply a custom filter to the view. Define the filter using one of the [supported filter operators](#filter-operators) and a condition.

```python lines theme={"system"}
view.add_filter("output.model_latency", ">=", 5)
```

#### Filter operators

| Operator | Description | Example |
| - | - | - |
| `"contains"` | Checks whether a string contains a substring. | `view.add_filter("output.status", "contains", "error")` |
| `"equals"` | Checks whether a string is exactly equal to a given value. | `view.add_filter("input.category", "equals", "Alice")` |
| `"in"` | Checks whether a string is in a list of values. | `view.add_filter("category", "in", ["A", "B", "C"])` |
| `"="` | Checks whether a number is equal to a value. | `view.add_filter("output.score", "=", 80)` |
| `"≠", "!="` | Checks whether a number isn't equal to a value. | `view.add_filter("metrics.loss", "!=", 0.5)` |
| `"<"` | Checks whether a number is less than a value. | `view.add_filter("age", "<", 30)` |
| `"≤", "<="` | Checks whether a number is less than or equal to a value. | `view.add_filter("metric.value", "<=", 100)` |
| `">"` | Checks whether a number is greater than a value. | `view.add_filter("output.score", ">", 90)` |
| `"≥", ">="` | Checks whether a number is greater than or equal to a value. | `view.add_filter("output.model_latency", ">=", 5)` |
| `"is"` | Checks whether a boolean field is `True` or `False`. | `view.add_filter("is_active", "is", True)` |
| `"after"` | Checks whether a date is after a given timestamp. | `view.add_filter("started_at", "after", "2024-01-01")` |
| `"before"` | Checks whether a date is before a given timestamp. | `view.add_filter("ended_at", "before", "2024-12-31")` |
| `"is empty"` | Checks whether a field is empty (`None` or `""`). | `view.add_filter("comments", "is empty", None)` |
| `"is not empty"` | Checks whether a field isn't empty. | `view.add_filter("attachments", "is not empty", None)` |

### Remove filters

Use `.remove_filter()` to remove a specific filter from the view by index or field name.

```python lines theme={"system"}
view.remove_filter("output.model_latency")
```

Use `.remove_filters()` to remove all filters.

```python lines theme={"system"}
view.remove_filters()
```

### Save the `SavedView`

Use `.save()` to publish the saved view to Weave.

```python lines theme={"system"}
view.save()
```

### Retrieve function calls

Use `.get_calls()` to retrieve function calls that match the filters in the saved view. You can specify optional parameters such as `limit` and `offset`.

```python lines theme={"system"}
calls = view.get_calls(limit=10)
```
