> ## Documentation Index
> Fetch the complete documentation index at: https://docs.coreweave.com/llms.txt
> Use this file to discover all available pages before exploring further.

# WeaveImage

> TypeScript SDK reference

[GitHub source](https://github.com/wandb/weave/blob/7c9efdc9fe05ffcaf2430dd652ef9bc5b3ffdfaa/sdks/node/src/media.ts#L15)

## Extends

* `WeaveImageInput`

## Properties

### \_weaveType

> **\_weaveType**: `"Image"`

***

### data

> **data**: `Buffer`

#### Inherited from

`WeaveImageInput.data`

***

### imageType

> `optional` **imageType**: `"png"` | `"jpeg"` | `"webp"`

#### Inherited from

`WeaveImageInput.imageType`
