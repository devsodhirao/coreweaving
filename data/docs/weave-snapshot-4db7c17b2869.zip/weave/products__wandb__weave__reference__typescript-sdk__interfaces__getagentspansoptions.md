> ## Documentation Index
> Fetch the complete documentation index at: https://docs.coreweave.com/llms.txt
> Use this file to discover all available pages before exploring further.

# GetAgentSpansOptions

> TypeScript SDK reference

[GitHub source](https://github.com/wandb/weave/blob/7c9efdc9fe05ffcaf2430dd652ef9bc5b3ffdfaa/sdks/node/src/weaveClient.ts#L187)

Options for [WeaveClient.getAgentSpans](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/interfaces/weaveclient.md#getagentspans).

## Properties

### agentName

> `optional` **agentName**: `string`

***

### limit

> `optional` **limit**: `number`

#### Min

0

#### Max

10000

#### Default

```ts twoslash theme={"system"}
// @noErrors
100
```

***

### offset

> `optional` **offset**: `number`

#### Min

0

#### Default

```ts twoslash theme={"system"}
// @noErrors
0
```

***

### query

> `optional` **query**: [`Query`](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/interfaces/query) | `null`

Mongo-style filter on the spans.

***

### sortBy

> `optional` **sortBy**: [`SortBy`](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/interfaces/sortby)\[]
