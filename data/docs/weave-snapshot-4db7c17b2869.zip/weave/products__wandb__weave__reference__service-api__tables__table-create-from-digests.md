> ## Documentation Index
> Fetch the complete documentation index at: https://docs.coreweave.com/llms.txt
> Use this file to discover all available pages before exploring further.

# Table Create From Digests



## OpenAPI

````yaml products/wandb/weave/reference/service-api/openapi.json POST /table/create_from_digests
openapi: 3.1.0
info:
  title: FastAPI
  version: 0.1.0
servers: []
security: []
paths:
  /table/create_from_digests:
    post:
      tags:
        - Tables
      summary: Table Create From Digests
      operationId: table_create_from_digests_table_create_from_digests_post
      requestBody:
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/TableCreateFromDigestsReq'
        required: true
      responses:
        '200':
          description: Successful Response
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/TableCreateFromDigestsRes'
        '422':
          description: Validation Error
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/HTTPValidationError'
components:
  schemas:
    TableCreateFromDigestsReq:
      properties:
        project_id:
          type: string
          title: Project Id
        row_digests:
          items:
            type: string
          type: array
          title: Row Digests
        expected_digest:
          anyOf:
            - type: string
            - type: 'null'
          title: Expected Digest
          description: Client-computed table digest for server-side validation.
      type: object
      required:
        - project_id
        - row_digests
      title: TableCreateFromDigestsReq
    TableCreateFromDigestsRes:
      properties:
        digest:
          type: string
          title: Digest
      type: object
      required:
        - digest
      title: TableCreateFromDigestsRes
    HTTPValidationError:
      properties:
        detail:
          items:
            $ref: '#/components/schemas/ValidationError'
          type: array
          title: Detail
      type: object
      title: HTTPValidationError
    ValidationError:
      properties:
        loc:
          items:
            anyOf:
              - type: string
              - type: integer
          type: array
          title: Location
        msg:
          type: string
          title: Message
        type:
          type: string
          title: Error Type
        input:
          title: Input
        ctx:
          type: object
          title: Context
      type: object
      required:
        - loc
        - msg
        - type
      title: ValidationError

````