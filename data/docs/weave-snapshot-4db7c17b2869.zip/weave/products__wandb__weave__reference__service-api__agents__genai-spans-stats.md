> ## Documentation Index
> Fetch the complete documentation index at: https://docs.coreweave.com/llms.txt
> Use this file to discover all available pages before exploring further.

# GenAI Spans Stats

> Query chart-ready aggregations over agent spans.



## OpenAPI

````yaml products/wandb/weave/reference/service-api/openapi.json POST /agents/spans/stats
openapi: 3.1.0
info:
  title: FastAPI
  version: 0.1.0
servers: []
security: []
paths:
  /agents/spans/stats:
    post:
      tags:
        - Agents
      summary: Genai Spans Stats
      description: Query chart-ready aggregations over agent spans.
      operationId: genai_spans_stats_agents_spans_stats_post
      requestBody:
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/AgentSpanStatsReq'
        required: true
      responses:
        '200':
          description: Successful Response
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/AgentSpanStatsRes'
        '422':
          description: Validation Error
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/HTTPValidationError'
components:
  schemas:
    AgentSpanStatsReq:
      properties:
        project_id:
          type: string
          title: Project Id
        query:
          anyOf:
            - $ref: '#/components/schemas/Query'
            - type: 'null'
        start:
          type: string
          format: date-time
          title: Start
        end:
          anyOf:
            - type: string
              format: date-time
            - type: 'null'
          title: End
        granularity:
          anyOf:
            - type: integer
              exclusiveMinimum: 0
            - type: 'null'
          title: Granularity
        timezone:
          type: string
          title: Timezone
          default: UTC
        group_by:
          items:
            $ref: '#/components/schemas/AgentGroupByRef'
          type: array
          title: Group By
        metrics:
          items:
            $ref: '#/components/schemas/AgentSpanStatsMetricSpec'
          type: array
          title: Metrics
        group_limit:
          type: integer
          maximum: 1000
          minimum: 1
          title: Group Limit
          default: 50
        bucket_by:
          anyOf:
            - oneOf:
                - $ref: '#/components/schemas/AgentSpanStatsTimeBucketSpec'
                - $ref: '#/components/schemas/AgentSpanStatsNumericBucketSpec'
              discriminator:
                propertyName: type
                mapping:
                  number: '#/components/schemas/AgentSpanStatsNumericBucketSpec'
                  time: '#/components/schemas/AgentSpanStatsTimeBucketSpec'
            - type: 'null'
          title: Bucket By
        group_filters:
          items:
            $ref: '#/components/schemas/AgentSpanGroupFilter'
          type: array
          title: Group Filters
        signal_filters:
          anyOf:
            - $ref: '#/components/schemas/AgentSignalFilter'
            - type: 'null'
      type: object
      required:
        - project_id
        - start
      title: AgentSpanStatsReq
      description: Request chart-ready aggregations over GenAI agent spans.
    AgentSpanStatsRes:
      properties:
        start:
          type: string
          format: date-time
          title: Start
        end:
          type: string
          format: date-time
          title: End
        granularity:
          anyOf:
            - type: integer
            - type: 'null'
          title: Granularity
        timezone:
          type: string
          title: Timezone
        bucket_type:
          type: string
          enum:
            - time
            - number
          title: Bucket Type
          default: time
        columns:
          items:
            $ref: '#/components/schemas/AgentSpanStatsColumn'
          type: array
          title: Columns
        rows:
          items:
            additionalProperties:
              anyOf:
                - type: string
                  format: date-time
                - type: string
                - type: integer
                - type: number
                - type: boolean
                - type: 'null'
            type: object
          type: array
          title: Rows
      type: object
      required:
        - start
        - end
        - granularity
        - timezone
        - bucket_type
        - columns
        - rows
      title: AgentSpanStatsRes
      description: Response containing chart-ready agent span stats rows.
    HTTPValidationError:
      properties:
        detail:
          items:
            $ref: '#/components/schemas/ValidationError'
          type: array
          title: Detail
      type: object
      title: HTTPValidationError
    Query:
      properties:
        $expr:
          anyOf:
            - $ref: '#/components/schemas/AndOperation'
            - $ref: '#/components/schemas/OrOperation'
            - $ref: '#/components/schemas/NotOperation'
            - $ref: '#/components/schemas/EqOperation'
            - $ref: '#/components/schemas/GtOperation'
            - $ref: '#/components/schemas/LtOperation'
            - $ref: '#/components/schemas/GteOperation'
            - $ref: '#/components/schemas/LteOperation'
            - $ref: '#/components/schemas/InOperation'
            - $ref: '#/components/schemas/ContainsOperation'
          title: $Expr
      additionalProperties: false
      type: object
      required:
        - $expr
      title: Query
    AgentGroupByRef:
      properties:
        source:
          type: string
          enum:
            - field
            - column
            - custom_attrs_string
            - custom_attrs_int
            - custom_attrs_float
            - custom_attrs_bool
          title: Source
          default: field
        key:
          type: string
          title: Key
        alias:
          anyOf:
            - type: string
            - type: 'null'
          title: Alias
      type: object
      required:
        - key
      title: AgentGroupByRef
      description: >-
        Reference to a field or map-key that spans should be grouped by.


        `source="field"` targets a semantic span field (`agent.name`) or direct

        span column (`agent_name`), allowlisted server-side. `source="column"`
        is

        accepted for existing callers.

        The other sources target keys inside the typed custom attribute Map
        columns,

        which accept arbitrary user-defined keys.
    AgentSpanStatsMetricSpec:
      properties:
        alias:
          type: string
          pattern: ^[a-zA-Z_][a-zA-Z0-9_]*$
          title: Alias
        value_type:
          type: string
          enum:
            - datetime
            - number
            - boolean
            - string
          title: Value Type
        aggregations:
          items:
            type: string
            enum:
              - sum
              - avg
              - min
              - max
              - count
              - count_distinct
              - count_true
              - count_false
          type: array
          title: Aggregations
        percentiles:
          items:
            type: number
          type: array
          title: Percentiles
        value:
          $ref: '#/components/schemas/AgentSpanValueRef'
      type: object
      required:
        - alias
        - value_type
        - value
      title: AgentSpanStatsMetricSpec
      description: Metric to extract from each matching span and aggregate into chart rows.
    AgentSpanStatsTimeBucketSpec:
      properties:
        type:
          type: string
          const: time
          title: Type
          default: time
      type: object
      title: AgentSpanStatsTimeBucketSpec
      description: Bucket stats rows by started_at time intervals.
    AgentSpanStatsNumericBucketSpec:
      properties:
        type:
          type: string
          const: number
          title: Type
          default: number
        alias:
          type: string
          pattern: ^[a-zA-Z_][a-zA-Z0-9_]*$
          title: Alias
          default: value
        bins:
          type: integer
          maximum: 200
          minimum: 1
          title: Bins
          default: 24
        min:
          anyOf:
            - type: number
            - type: 'null'
          title: Min
        max:
          anyOf:
            - type: number
            - type: 'null'
          title: Max
        value:
          anyOf:
            - $ref: '#/components/schemas/AgentSpanValueRef'
            - type: 'null'
        group_by:
          items:
            $ref: '#/components/schemas/AgentGroupByRef'
          type: array
          title: Group By
        measure:
          anyOf:
            - $ref: '#/components/schemas/AgentSpanMeasureSpec'
            - type: 'null'
      type: object
      title: AgentSpanStatsNumericBucketSpec
      description: Bucket stats rows by ranges of one numeric span or grouped value.
    AgentSpanGroupFilter:
      properties:
        group_by:
          items:
            $ref: '#/components/schemas/AgentGroupByRef'
          type: array
          title: Group By
        measure:
          $ref: '#/components/schemas/AgentSpanMeasureSpec'
        min:
          anyOf:
            - type: number
            - type: string
              format: date-time
            - type: 'null'
          title: Min
        max:
          anyOf:
            - type: number
            - type: string
              format: date-time
            - type: 'null'
          title: Max
      type: object
      required:
        - measure
      title: AgentSpanGroupFilter
      description: Range filter over one grouped span measure.
    AgentSignalFilter:
      properties:
        tags:
          items:
            type: string
          type: array
          title: Tags
        ratings:
          items:
            $ref: '#/components/schemas/RatingCondition'
          type: array
          title: Ratings
      type: object
      title: AgentSignalFilter
    AgentSpanStatsColumn:
      properties:
        name:
          type: string
          title: Name
        role:
          type: string
          enum:
            - time
            - bucket
            - group
            - metric
          title: Role
        value_type:
          type: string
          enum:
            - datetime
            - number
            - boolean
            - string
          title: Value Type
        metric:
          anyOf:
            - type: string
            - type: 'null'
          title: Metric
        aggregation:
          anyOf:
            - type: string
            - type: 'null'
          title: Aggregation
      type: object
      required:
        - name
        - role
        - value_type
        - metric
        - aggregation
      title: AgentSpanStatsColumn
      description: Metadata describing one column in an agent span stats result row.
    ValidationError:
      properties:
        loc:
          items:
            anyOf:
              - type: string
              - type: integer
          type: array
          title: Location
        msg:
          type: string
          title: Message
        type:
          type: string
          title: Error Type
        input:
          title: Input
        ctx:
          type: object
          title: Context
      type: object
      required:
        - loc
        - msg
        - type
      title: ValidationError
    AndOperation:
      properties:
        $and:
          items:
            anyOf:
              - $ref: '#/components/schemas/LiteralOperation'
              - $ref: '#/components/schemas/GetFieldOperator'
              - $ref: '#/components/schemas/ConvertOperation'
              - $ref: '#/components/schemas/SizeOperation'
              - $ref: '#/components/schemas/AndOperation'
              - $ref: '#/components/schemas/OrOperation'
              - $ref: '#/components/schemas/NotOperation'
              - $ref: '#/components/schemas/EqOperation'
              - $ref: '#/components/schemas/GtOperation'
              - $ref: '#/components/schemas/LtOperation'
              - $ref: '#/components/schemas/GteOperation'
              - $ref: '#/components/schemas/LteOperation'
              - $ref: '#/components/schemas/InOperation'
              - $ref: '#/components/schemas/ContainsOperation'
          type: array
          title: $And
      type: object
      required:
        - $and
      title: AndOperation
      description: |-
        Logical AND. All conditions must evaluate to true.

        Example:
            ```
            {
                "$and": [
                    {"$eq": [{"$getField": "op_name"}, {"$literal": "predict"}]},
                    {"$gt": [{"$getField": "summary.usage.tokens"}, {"$literal": 1000}]}
                ]
            }
            ```
    OrOperation:
      properties:
        $or:
          items:
            anyOf:
              - $ref: '#/components/schemas/LiteralOperation'
              - $ref: '#/components/schemas/GetFieldOperator'
              - $ref: '#/components/schemas/ConvertOperation'
              - $ref: '#/components/schemas/SizeOperation'
              - $ref: '#/components/schemas/AndOperation'
              - $ref: '#/components/schemas/OrOperation'
              - $ref: '#/components/schemas/NotOperation'
              - $ref: '#/components/schemas/EqOperation'
              - $ref: '#/components/schemas/GtOperation'
              - $ref: '#/components/schemas/LtOperation'
              - $ref: '#/components/schemas/GteOperation'
              - $ref: '#/components/schemas/LteOperation'
              - $ref: '#/components/schemas/InOperation'
              - $ref: '#/components/schemas/ContainsOperation'
          type: array
          title: $Or
      type: object
      required:
        - $or
      title: OrOperation
      description: |-
        Logical OR. At least one condition must be true.

        Example:
            ```
            {
                "$or": [
                    {"$eq": [{"$getField": "op_name"}, {"$literal": "a"}]},
                    {"$eq": [{"$getField": "op_name"}, {"$literal": "b"}]}
                ]
            }
            ```
    NotOperation:
      properties:
        $not:
          prefixItems:
            - anyOf:
                - $ref: '#/components/schemas/LiteralOperation'
                - $ref: '#/components/schemas/GetFieldOperator'
                - $ref: '#/components/schemas/ConvertOperation'
                - $ref: '#/components/schemas/SizeOperation'
                - $ref: '#/components/schemas/AndOperation'
                - $ref: '#/components/schemas/OrOperation'
                - $ref: '#/components/schemas/NotOperation'
                - $ref: '#/components/schemas/EqOperation'
                - $ref: '#/components/schemas/GtOperation'
                - $ref: '#/components/schemas/LtOperation'
                - $ref: '#/components/schemas/GteOperation'
                - $ref: '#/components/schemas/LteOperation'
                - $ref: '#/components/schemas/InOperation'
                - $ref: '#/components/schemas/ContainsOperation'
          type: array
          maxItems: 1
          minItems: 1
          title: $Not
      type: object
      required:
        - $not
      title: NotOperation
      description: |-
        Logical NOT. Inverts the condition.

        Example:
            ```
            {
                "$not": [
                    {"$eq": [{"$getField": "op_name"}, {"$literal": "debug"}]}
                ]
            }
            ```
    EqOperation:
      properties:
        $eq:
          prefixItems:
            - anyOf:
                - $ref: '#/components/schemas/LiteralOperation'
                - $ref: '#/components/schemas/GetFieldOperator'
                - $ref: '#/components/schemas/ConvertOperation'
                - $ref: '#/components/schemas/SizeOperation'
                - $ref: '#/components/schemas/AndOperation'
                - $ref: '#/components/schemas/OrOperation'
                - $ref: '#/components/schemas/NotOperation'
                - $ref: '#/components/schemas/EqOperation'
                - $ref: '#/components/schemas/GtOperation'
                - $ref: '#/components/schemas/LtOperation'
                - $ref: '#/components/schemas/GteOperation'
                - $ref: '#/components/schemas/LteOperation'
                - $ref: '#/components/schemas/InOperation'
                - $ref: '#/components/schemas/ContainsOperation'
            - anyOf:
                - $ref: '#/components/schemas/LiteralOperation'
                - $ref: '#/components/schemas/GetFieldOperator'
                - $ref: '#/components/schemas/ConvertOperation'
                - $ref: '#/components/schemas/SizeOperation'
                - $ref: '#/components/schemas/AndOperation'
                - $ref: '#/components/schemas/OrOperation'
                - $ref: '#/components/schemas/NotOperation'
                - $ref: '#/components/schemas/EqOperation'
                - $ref: '#/components/schemas/GtOperation'
                - $ref: '#/components/schemas/LtOperation'
                - $ref: '#/components/schemas/GteOperation'
                - $ref: '#/components/schemas/LteOperation'
                - $ref: '#/components/schemas/InOperation'
                - $ref: '#/components/schemas/ContainsOperation'
          type: array
          maxItems: 2
          minItems: 2
          title: $Eq
      type: object
      required:
        - $eq
      title: EqOperation
      description: |-
        Equality check between two operands.

        Example:
            ```
            {
                "$eq": [{"$getField": "op_name"}, {"$literal": "predict"}]
            }
            ```
    GtOperation:
      properties:
        $gt:
          prefixItems:
            - anyOf:
                - $ref: '#/components/schemas/LiteralOperation'
                - $ref: '#/components/schemas/GetFieldOperator'
                - $ref: '#/components/schemas/ConvertOperation'
                - $ref: '#/components/schemas/SizeOperation'
                - $ref: '#/components/schemas/AndOperation'
                - $ref: '#/components/schemas/OrOperation'
                - $ref: '#/components/schemas/NotOperation'
                - $ref: '#/components/schemas/EqOperation'
                - $ref: '#/components/schemas/GtOperation'
                - $ref: '#/components/schemas/LtOperation'
                - $ref: '#/components/schemas/GteOperation'
                - $ref: '#/components/schemas/LteOperation'
                - $ref: '#/components/schemas/InOperation'
                - $ref: '#/components/schemas/ContainsOperation'
            - anyOf:
                - $ref: '#/components/schemas/LiteralOperation'
                - $ref: '#/components/schemas/GetFieldOperator'
                - $ref: '#/components/schemas/ConvertOperation'
                - $ref: '#/components/schemas/SizeOperation'
                - $ref: '#/components/schemas/AndOperation'
                - $ref: '#/components/schemas/OrOperation'
                - $ref: '#/components/schemas/NotOperation'
                - $ref: '#/components/schemas/EqOperation'
                - $ref: '#/components/schemas/GtOperation'
                - $ref: '#/components/schemas/LtOperation'
                - $ref: '#/components/schemas/GteOperation'
                - $ref: '#/components/schemas/LteOperation'
                - $ref: '#/components/schemas/InOperation'
                - $ref: '#/components/schemas/ContainsOperation'
          type: array
          maxItems: 2
          minItems: 2
          title: $Gt
      type: object
      required:
        - $gt
      title: GtOperation
      description: |-
        Greater than comparison.

        Example:
            ```
            {
                "$gt": [{"$getField": "summary.usage.tokens"}, {"$literal": 100}]
            }
            ```
    LtOperation:
      properties:
        $lt:
          prefixItems:
            - anyOf:
                - $ref: '#/components/schemas/LiteralOperation'
                - $ref: '#/components/schemas/GetFieldOperator'
                - $ref: '#/components/schemas/ConvertOperation'
                - $ref: '#/components/schemas/SizeOperation'
                - $ref: '#/components/schemas/AndOperation'
                - $ref: '#/components/schemas/OrOperation'
                - $ref: '#/components/schemas/NotOperation'
                - $ref: '#/components/schemas/EqOperation'
                - $ref: '#/components/schemas/GtOperation'
                - $ref: '#/components/schemas/LtOperation'
                - $ref: '#/components/schemas/GteOperation'
                - $ref: '#/components/schemas/LteOperation'
                - $ref: '#/components/schemas/InOperation'
                - $ref: '#/components/schemas/ContainsOperation'
            - anyOf:
                - $ref: '#/components/schemas/LiteralOperation'
                - $ref: '#/components/schemas/GetFieldOperator'
                - $ref: '#/components/schemas/ConvertOperation'
                - $ref: '#/components/schemas/SizeOperation'
                - $ref: '#/components/schemas/AndOperation'
                - $ref: '#/components/schemas/OrOperation'
                - $ref: '#/components/schemas/NotOperation'
                - $ref: '#/components/schemas/EqOperation'
                - $ref: '#/components/schemas/GtOperation'
                - $ref: '#/components/schemas/LtOperation'
                - $ref: '#/components/schemas/GteOperation'
                - $ref: '#/components/schemas/LteOperation'
                - $ref: '#/components/schemas/InOperation'
                - $ref: '#/components/schemas/ContainsOperation'
          type: array
          maxItems: 2
          minItems: 2
          title: $Lt
      type: object
      required:
        - $lt
      title: LtOperation
      description: |-
        Less than comparison.

        Example:
            ```
            {
                "$lt": [{"$getField": "summary.usage.tokens"}, {"$literal": 100}]
            }
            ```
    GteOperation:
      properties:
        $gte:
          prefixItems:
            - anyOf:
                - $ref: '#/components/schemas/LiteralOperation'
                - $ref: '#/components/schemas/GetFieldOperator'
                - $ref: '#/components/schemas/ConvertOperation'
                - $ref: '#/components/schemas/SizeOperation'
                - $ref: '#/components/schemas/AndOperation'
                - $ref: '#/components/schemas/OrOperation'
                - $ref: '#/components/schemas/NotOperation'
                - $ref: '#/components/schemas/EqOperation'
                - $ref: '#/components/schemas/GtOperation'
                - $ref: '#/components/schemas/LtOperation'
                - $ref: '#/components/schemas/GteOperation'
                - $ref: '#/components/schemas/LteOperation'
                - $ref: '#/components/schemas/InOperation'
                - $ref: '#/components/schemas/ContainsOperation'
            - anyOf:
                - $ref: '#/components/schemas/LiteralOperation'
                - $ref: '#/components/schemas/GetFieldOperator'
                - $ref: '#/components/schemas/ConvertOperation'
                - $ref: '#/components/schemas/SizeOperation'
                - $ref: '#/components/schemas/AndOperation'
                - $ref: '#/components/schemas/OrOperation'
                - $ref: '#/components/schemas/NotOperation'
                - $ref: '#/components/schemas/EqOperation'
                - $ref: '#/components/schemas/GtOperation'
                - $ref: '#/components/schemas/LtOperation'
                - $ref: '#/components/schemas/GteOperation'
                - $ref: '#/components/schemas/LteOperation'
                - $ref: '#/components/schemas/InOperation'
                - $ref: '#/components/schemas/ContainsOperation'
          type: array
          maxItems: 2
          minItems: 2
          title: $Gte
      type: object
      required:
        - $gte
      title: GteOperation
      description: |-
        Greater than or equal comparison.

        Example:
            ```
            {
                "$gte": [{"$getField": "summary.usage.tokens"}, {"$literal": 100}]
            }
            ```
    LteOperation:
      properties:
        $lte:
          prefixItems:
            - anyOf:
                - $ref: '#/components/schemas/LiteralOperation'
                - $ref: '#/components/schemas/GetFieldOperator'
                - $ref: '#/components/schemas/ConvertOperation'
                - $ref: '#/components/schemas/SizeOperation'
                - $ref: '#/components/schemas/AndOperation'
                - $ref: '#/components/schemas/OrOperation'
                - $ref: '#/components/schemas/NotOperation'
                - $ref: '#/components/schemas/EqOperation'
                - $ref: '#/components/schemas/GtOperation'
                - $ref: '#/components/schemas/LtOperation'
                - $ref: '#/components/schemas/GteOperation'
                - $ref: '#/components/schemas/LteOperation'
                - $ref: '#/components/schemas/InOperation'
                - $ref: '#/components/schemas/ContainsOperation'
            - anyOf:
                - $ref: '#/components/schemas/LiteralOperation'
                - $ref: '#/components/schemas/GetFieldOperator'
                - $ref: '#/components/schemas/ConvertOperation'
                - $ref: '#/components/schemas/SizeOperation'
                - $ref: '#/components/schemas/AndOperation'
                - $ref: '#/components/schemas/OrOperation'
                - $ref: '#/components/schemas/NotOperation'
                - $ref: '#/components/schemas/EqOperation'
                - $ref: '#/components/schemas/GtOperation'
                - $ref: '#/components/schemas/LtOperation'
                - $ref: '#/components/schemas/GteOperation'
                - $ref: '#/components/schemas/LteOperation'
                - $ref: '#/components/schemas/InOperation'
                - $ref: '#/components/schemas/ContainsOperation'
          type: array
          maxItems: 2
          minItems: 2
          title: $Lte
      type: object
      required:
        - $lte
      title: LteOperation
      description: |-
        Less than or equal comparison.

        Example:
            ```
            {
                "$lte": [{"$getField": "summary.usage.tokens"}, {"$literal": 100}]
            }
            ```
    InOperation:
      properties:
        $in:
          prefixItems:
            - anyOf:
                - $ref: '#/components/schemas/LiteralOperation'
                - $ref: '#/components/schemas/GetFieldOperator'
                - $ref: '#/components/schemas/ConvertOperation'
                - $ref: '#/components/schemas/SizeOperation'
                - $ref: '#/components/schemas/AndOperation'
                - $ref: '#/components/schemas/OrOperation'
                - $ref: '#/components/schemas/NotOperation'
                - $ref: '#/components/schemas/EqOperation'
                - $ref: '#/components/schemas/GtOperation'
                - $ref: '#/components/schemas/LtOperation'
                - $ref: '#/components/schemas/GteOperation'
                - $ref: '#/components/schemas/LteOperation'
                - $ref: '#/components/schemas/InOperation'
                - $ref: '#/components/schemas/ContainsOperation'
            - items:
                anyOf:
                  - $ref: '#/components/schemas/LiteralOperation'
                  - $ref: '#/components/schemas/GetFieldOperator'
                  - $ref: '#/components/schemas/ConvertOperation'
                  - $ref: '#/components/schemas/SizeOperation'
                  - $ref: '#/components/schemas/AndOperation'
                  - $ref: '#/components/schemas/OrOperation'
                  - $ref: '#/components/schemas/NotOperation'
                  - $ref: '#/components/schemas/EqOperation'
                  - $ref: '#/components/schemas/GtOperation'
                  - $ref: '#/components/schemas/LtOperation'
                  - $ref: '#/components/schemas/GteOperation'
                  - $ref: '#/components/schemas/LteOperation'
                  - $ref: '#/components/schemas/InOperation'
                  - $ref: '#/components/schemas/ContainsOperation'
              type: array
          type: array
          maxItems: 2
          minItems: 2
          title: $In
      type: object
      required:
        - $in
      title: InOperation
      description: >-
        Membership check.


        Returns true if the left operand is in the list provided as the second
        operand.


        Example:
            ```
            {
                "$in": [
                    {"$getField": "op_name"},
                    [{"$literal": "predict"}, {"$literal": "generate"}]
                ]
            }
            ```
    ContainsOperation:
      properties:
        $contains:
          $ref: '#/components/schemas/ContainsSpec'
      type: object
      required:
        - $contains
      title: ContainsOperation
      description: |-
        Case-insensitive substring match.

        Not part of MongoDB. Weave-specific addition.

        Example:
            ```
            {
                "$contains": {
                    "input": {"$getField": "display_name"},
                    "substr": {"$literal": "llm"},
                    "case_insensitive": true
                }
            }
            ```
    AgentSpanValueRef:
      properties:
        source:
          type: string
          enum:
            - field
            - derived
            - custom_attrs_string
            - custom_attrs_int
            - custom_attrs_float
            - custom_attrs_bool
          title: Source
          default: field
        key:
          type: string
          title: Key
      type: object
      required:
        - key
      title: AgentSpanValueRef
      description: Reference to a span field or typed custom attribute map value.
    AgentSpanMeasureSpec:
      properties:
        alias:
          type: string
          pattern: ^[a-zA-Z_][a-zA-Z0-9_]*$
          title: Alias
        aggregation:
          type: string
          enum:
            - sum
            - avg
            - min
            - max
            - count
            - count_distinct
            - count_true
            - count_false
          title: Aggregation
        value:
          anyOf:
            - $ref: '#/components/schemas/AgentSpanValueRef'
            - type: 'null'
        value_type:
          anyOf:
            - type: string
              enum:
                - datetime
                - number
                - boolean
                - string
            - type: 'null'
          title: Value Type
        filter:
          anyOf:
            - $ref: '#/components/schemas/Query'
            - type: 'null'
      type: object
      required:
        - alias
        - aggregation
      title: AgentSpanMeasureSpec
      description: One aggregate measure computed over spans in a group or bucket.
    RatingCondition:
      properties:
        scorer_key:
          type: string
          title: Scorer Key
        op:
          type: string
          enum:
            - gte
            - gt
            - lte
            - lt
            - eq
          title: Op
        value:
          type: number
          title: Value
      type: object
      required:
        - scorer_key
        - op
        - value
      title: RatingCondition
    LiteralOperation:
      properties:
        $literal:
          anyOf:
            - type: string
            - type: integer
            - type: number
            - type: boolean
            - additionalProperties:
                $ref: '#/components/schemas/LiteralOperation'
              type: object
            - items:
                $ref: '#/components/schemas/LiteralOperation'
              type: array
            - type: 'null'
          title: $Literal
      type: object
      required:
        - $literal
      title: LiteralOperation
      description: |-
        Represents a constant value in the query language.

        This can be any standard JSON-serializable value.

        Example:
            ```
            {"$literal": "predict"}
            ```
    GetFieldOperator:
      properties:
        $getField:
          type: string
          title: $Getfield
      type: object
      required:
        - $getField
      title: GetFieldOperator
      description: |-
        Access a field on the traced call.

        Supports dot notation for nested access, e.g. `summary.usage.tokens`.

        Only works on fields present in the `CallSchema`, including:
        - Top-level fields like `op_name`, `trace_id`, `started_at`
        - Nested fields like `inputs.input_name`, `summary.usage.tokens`, etc.

        Example:
            ```
            {"$getField": "op_name"}
            ```
    ConvertOperation:
      properties:
        $convert:
          $ref: '#/components/schemas/ConvertSpec'
      type: object
      required:
        - $convert
      title: ConvertOperation
      description: >-
        Convert the input value to a specific type (e.g., `int`, `bool`,
        `string`).


        Example:
            ```
            {
                "$convert": {
                    "input": {"$getField": "inputs.value"},
                    "to": "int"
                }
            }
            ```
    SizeOperation:
      properties:
        $size:
          anyOf:
            - $ref: '#/components/schemas/LiteralOperation'
            - $ref: '#/components/schemas/GetFieldOperator'
            - $ref: '#/components/schemas/ConvertOperation'
            - $ref: '#/components/schemas/SizeOperation'
            - $ref: '#/components/schemas/AndOperation'
            - $ref: '#/components/schemas/OrOperation'
            - $ref: '#/components/schemas/NotOperation'
            - $ref: '#/components/schemas/EqOperation'
            - $ref: '#/components/schemas/GtOperation'
            - $ref: '#/components/schemas/LtOperation'
            - $ref: '#/components/schemas/GteOperation'
            - $ref: '#/components/schemas/LteOperation'
            - $ref: '#/components/schemas/InOperation'
            - $ref: '#/components/schemas/ContainsOperation'
          title: $Size
      type: object
      required:
        - $size
      title: SizeOperation
      description: |-
        Return the number of elements in a collection or characters in a string.

        Example:
            ```
            {"$size": {"$getField": "scorer_tags"}}
            ```
    ContainsSpec:
      properties:
        input:
          anyOf:
            - $ref: '#/components/schemas/LiteralOperation'
            - $ref: '#/components/schemas/GetFieldOperator'
            - $ref: '#/components/schemas/ConvertOperation'
            - $ref: '#/components/schemas/SizeOperation'
            - $ref: '#/components/schemas/AndOperation'
            - $ref: '#/components/schemas/OrOperation'
            - $ref: '#/components/schemas/NotOperation'
            - $ref: '#/components/schemas/EqOperation'
            - $ref: '#/components/schemas/GtOperation'
            - $ref: '#/components/schemas/LtOperation'
            - $ref: '#/components/schemas/GteOperation'
            - $ref: '#/components/schemas/LteOperation'
            - $ref: '#/components/schemas/InOperation'
            - $ref: '#/components/schemas/ContainsOperation'
          title: Input
        substr:
          anyOf:
            - $ref: '#/components/schemas/LiteralOperation'
            - $ref: '#/components/schemas/GetFieldOperator'
            - $ref: '#/components/schemas/ConvertOperation'
            - $ref: '#/components/schemas/SizeOperation'
            - $ref: '#/components/schemas/AndOperation'
            - $ref: '#/components/schemas/OrOperation'
            - $ref: '#/components/schemas/NotOperation'
            - $ref: '#/components/schemas/EqOperation'
            - $ref: '#/components/schemas/GtOperation'
            - $ref: '#/components/schemas/LtOperation'
            - $ref: '#/components/schemas/GteOperation'
            - $ref: '#/components/schemas/LteOperation'
            - $ref: '#/components/schemas/InOperation'
            - $ref: '#/components/schemas/ContainsOperation'
          title: Substr
        case_insensitive:
          anyOf:
            - type: boolean
            - type: 'null'
          title: Case Insensitive
          default: false
      type: object
      required:
        - input
        - substr
      title: ContainsSpec
      description: |-
        Specification for the `$contains` operation.

        - `input`: The string to search.
        - `substr`: The substring to search for.
        - `case_insensitive`: If true, match is case-insensitive.
    ConvertSpec:
      properties:
        input:
          anyOf:
            - $ref: '#/components/schemas/LiteralOperation'
            - $ref: '#/components/schemas/GetFieldOperator'
            - $ref: '#/components/schemas/ConvertOperation'
            - $ref: '#/components/schemas/SizeOperation'
            - $ref: '#/components/schemas/AndOperation'
            - $ref: '#/components/schemas/OrOperation'
            - $ref: '#/components/schemas/NotOperation'
            - $ref: '#/components/schemas/EqOperation'
            - $ref: '#/components/schemas/GtOperation'
            - $ref: '#/components/schemas/LtOperation'
            - $ref: '#/components/schemas/GteOperation'
            - $ref: '#/components/schemas/LteOperation'
            - $ref: '#/components/schemas/InOperation'
            - $ref: '#/components/schemas/ContainsOperation'
          title: Input
        to:
          type: string
          enum:
            - double
            - string
            - int
            - bool
            - exists
          title: To
      type: object
      required:
        - input
        - to
      title: ConvertSpec
      description: |-
        Specifies conversion details for `$convert`.

        - `input`: The operand to convert.
        - `to`: The type to convert to.

````