> ## Documentation Index
> Fetch the complete documentation index at: https://docs.coreweave.com/llms.txt
> Use this file to discover all available pages before exploring further.

# MistralAI

> Track and monitor MistralAI model calls with Weave's automatic tracing for chat completions, function calling, and model interactions.

[Try in Colab](https://colab.research.google.com/github/wandb/examples/blob/master/weave/docs/quickstart_mistral.ipynb)

Weave automatically tracks and logs LLM calls made through the [MistralAI Python library](https://github.com/mistralai/client-python). This guide shows you how to capture traces for MistralAI calls, wrap calls in your own ops for reproducibility, and organize experiments using the `Model` class.

> Weave supports the Mistral v1.0 SDK. For details on upgrading, see the [migration guide](https://github.com/mistralai/client-python/blob/main/MIGRATION.md).

## Traces

It's important to store traces of LLM applications in a central database, both during development and in production. You use these traces for debugging, and as a dataset that helps you improve your application.

Weave automatically captures traces for [mistralai](https://github.com/mistralai/client-python). To use the library as usual, start by calling `weave.init()`:

```python lines theme={"system"}
import weave
weave.init("cheese_recommender")

# then use mistralai library as usual
import os
from mistralai import Mistral

api_key = os.environ["MISTRAL_API_KEY"]
model = "mistral-large-latest"

client = Mistral(api_key=api_key)

messages = [
    {
        "role": "user",
        "content": "What is the best French cheese?",
    },
]

chat_response = client.chat.complete(
    model=model,
    messages=messages,
)
```

Weave now tracks and logs all LLM calls made through the MistralAI library. You can view the traces in the Weave web interface.

[![mistral\_trace.png](https://mintcdn.com/coreweave-dbfa0e8d/3Dv_sw2eg8feUJlx/products/wandb/weave/_media/mistral_trace.png?fit=max\&auto=format\&n=3Dv_sw2eg8feUJlx\&q=85\&s=6f496fd1aba7c2d4a7d4b61d62eadd88)](https://forge.coreweave.com/wandb/capecape/mistralai_project/weave/calls)

## Wrap calls with your own ops

Once basic tracing works, you can wrap your MistralAI calls in Weave Ops to make them reproducible across experiments. Weave ops make results *reproducible* by automatically versioning code as you experiment, and they capture their inputs and outputs. Create a function decorated with [`@weave.op()`](https://docs.coreweave.com/products/wandb/weave/guides/tracking/ops) that calls into [`mistralai.client.MistralClient.chat()`](https://docs.mistral.ai/capabilities/completion), and Weave tracks the inputs and outputs for you. The following example shows how to do this for a cheese recommender:

```python lines {1} theme={"system"}
@weave.op()
def cheese_recommender(region:str, model:str) -> str:
    "Recommend the best cheese in a given region"
    
    messages = [
        {
            "role": "user",
            "content": f"What is the best cheese in {region}?",
        },
    ]

    chat_response = client.chat.complete(
        model=model,
        messages=messages,
    )
    return chat_response.choices[0].message.content

cheese_recommender(region="France", model="mistral-large-latest")
cheese_recommender(region="Spain", model="mistral-large-latest")
cheese_recommender(region="Netherlands", model="mistral-large-latest")
```

[![mistral\_ops.png](https://mintcdn.com/coreweave-dbfa0e8d/3Dv_sw2eg8feUJlx/products/wandb/weave/_media/mistral_ops.png?fit=max\&auto=format\&n=3Dv_sw2eg8feUJlx\&q=85\&s=8718757963f0f23ce7955c043a19d30f)](https://forge.coreweave.com/wandb/capecape/mistralai_project/weave/calls)

## Create a `Model` for easier experimentation

Organizing experimentation is difficult with many moving pieces. By using the [`Model`](https://docs.coreweave.com/products/wandb/weave/guides/core-types/models) class, you can capture and organize the experimental details of your app like your system prompt or the model you're using. This helps organize and compare different iterations of your app.

Besides versioning code and capturing inputs and outputs, [`Model`](https://docs.coreweave.com/products/wandb/weave/guides/core-types/models)s capture structured parameters that control your application's behavior, making it easy to find what parameters worked best. You can also use Weave Models with `serve`, and [`Evaluation`](https://docs.coreweave.com/products/wandb/weave/guides/core-types/evaluations)s.

In the following example, you can experiment with `model` and `country`. Every time you change one of these, you get a new *version* of `CheeseRecommender`.

```python lines theme={"system"}
import weave
from mistralai import Mistral

weave.init("mistralai_project")

class CheeseRecommender(weave.Model): # Change to `weave.Model`
    model: str
    temperature: float

    @weave.op()
    def predict(self, region:str) -> str: # Change to `predict`
        "Recommend the best cheese in a given region"
        
        client = Mistral(api_key=api_key)

        messages = [
            {
                "role": "user",
                "content": f"What is the best cheese in {region}?",
            },
        ]

        chat_response = client.chat.complete(
            model=model,
            messages=messages,
            temperature=self.temperature
        )
        return chat_response.choices[0].message.content

cheese_model = CheeseRecommender(
    model="mistral-medium-latest",
    temperature=0.0
    )
result = cheese_model.predict(region="France")
print(result)
```

[![mistral\_model.png](https://mintcdn.com/coreweave-dbfa0e8d/3Dv_sw2eg8feUJlx/products/wandb/weave/_media/mistral_model.png?fit=max\&auto=format\&n=3Dv_sw2eg8feUJlx\&q=85\&s=576975bf65feac4cb2dd1da1b68244cd)](https://forge.coreweave.com/wandb/capecape/mistralai_project/weave/models)
