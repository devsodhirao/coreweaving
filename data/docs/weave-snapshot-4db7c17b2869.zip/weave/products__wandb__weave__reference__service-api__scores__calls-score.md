> ## Documentation Index
> Fetch the complete documentation index at: https://docs.coreweave.com/llms.txt
> Use this file to discover all available pages before exploring further.

# Calls Score



## OpenAPI

````yaml products/wandb/weave/reference/service-api/openapi.json POST /calls/score
openapi: 3.1.0
info:
  title: FastAPI
  version: 0.1.0
servers: []
security: []
paths:
  /calls/score:
    post:
      tags:
        - Scores
      summary: Calls Score
      operationId: calls_score_calls_score_post
      requestBody:
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/CallsScoreReq'
        required: true
      responses:
        '200':
          description: Successful Response
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/CallsScoreRes'
        '422':
          description: Validation Error
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/HTTPValidationError'
components:
  schemas:
    CallsScoreReq:
      properties:
        project_id:
          type: string
          title: Project Id
        call_ids:
          items:
            type: string
          type: array
          title: Call Ids
          description: List of call IDs to score
        scorer_refs:
          items:
            type: string
          type: array
          title: Scorer Refs
          description: List of scorer refs to apply
        wb_user_id:
          anyOf:
            - type: string
            - type: 'null'
          title: Wb User Id
          description: Do not set directly. Server will automatically populate this field.
      type: object
      required:
        - project_id
        - call_ids
        - scorer_refs
      title: CallsScoreReq
      description: >-
        Request to enqueue scoring jobs for a list of calls.


        Scoring is performed asynchronously by the call_scoring_worker, which

        consumes messages from Kafka and applies each scorer_ref to each
        call_id.
    CallsScoreRes:
      properties: {}
      type: object
      title: CallsScoreRes
      description: |-
        Empty response for calls_score.

        Defined as a model (rather than returning None) to follow the convention
        used throughout this interface and to allow fields to be added later
        without a breaking change.
    HTTPValidationError:
      properties:
        detail:
          items:
            $ref: '#/components/schemas/ValidationError'
          type: array
          title: Detail
      type: object
      title: HTTPValidationError
    ValidationError:
      properties:
        loc:
          items:
            anyOf:
              - type: string
              - type: integer
          type: array
          title: Location
        msg:
          type: string
          title: Message
        type:
          type: string
          title: Error Type
        input:
          title: Input
        ctx:
          type: object
          title: Context
      type: object
      required:
        - loc
        - msg
        - type
      title: ValidationError

````