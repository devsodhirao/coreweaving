> ## Documentation Index
> Fetch the complete documentation index at: https://docs.coreweave.com/llms.txt
> Use this file to discover all available pages before exploring further.

# init

> TypeScript SDK reference

```ts theme={"system"}
init(project: string, settings?: Partial<{…}>): Promise<WeaveClient>
```

[GitHub source](https://github.com/wandb/weave/blob/7c9efdc9fe05ffcaf2430dd652ef9bc5b3ffdfaa/sdks/node/src/clientApi.ts#L86)

Initialize the Weave client, which is required for weave tracing to work.

## Parameters

**project** `string` *required*

The W\&B project name (can be project or entity/project). If you don't
specify a CoreWeave Forge team (e.g., 'team/project'), your default entity is used.
To find or update your default entity, refer to User settings at
[https://docs.wandb.ai/platform/app/settings-page/user-settings#default-team](https://docs.wandb.ai/platform/app/settings-page/user-settings#default-team)

**settings** `Partial\<\{…\}\>`

(Optional) Weave tracing settings

Full type: `Partial<{ attributes: Record<string, any>; genai: { batchOptions?: BufferConfig; spanProcessor?: "batch" | "simple" | SpanProcessor; }; printCallLink: boolean; useCallsComplete: boolean; useOTelV2: boolean; }>`

## Returns

`Promise`\<[`WeaveClient`](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/interfaces/weaveclient)>

A promise that resolves to the initialized Weave client.

## Throws

If the initialization fails
