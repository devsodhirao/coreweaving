> ## Documentation Index
> Fetch the complete documentation index at: https://docs.coreweave.com/llms.txt
> Use this file to discover all available pages before exploring further.

# Disable tracing

> Learn options to disable or conditionally turn off Weave tracing

This page describes how to disable Weave tracing in your application. Use these options when you want to prevent traces from being logged, for example, during local development, in test environments, or for specific code paths where tracing isn't needed. Choose the approach that best matches the scope of control you need: program-wide, per-client, or per-code-block.

## Environment variable

Use an environment variable when you want to disable tracing for the entire program without modifying application code.

To unconditionally disable tracing for the entire program, set the environment variable `WEAVE_DISABLED=true`.

`WEAVE_DISABLED` is read only once, at function-definition time. You can't use this variable to toggle tracing at runtime.

## Client initialization

To conditionally disable tracing for a specific Weave client, initialize the client with the `disabled` flag in init settings.

**Python**

```python lines theme={"system"}
import weave

# Initialize the client
client = weave.init(..., settings={"disabled": True})
```

**TypeScript**

```plaintext theme={"system"}
This feature is not available for the TypeScript SDK yet.
```

## Context manager

To conditionally disable tracing only within a specific block of code, use a tracing context manager. Use `with tracing_disabled()` to suppress tracing **only for the function calls executed inside the `with` block**. Use it in application code to scope which calls shouldn't be logged.

**Python**

```python lines theme={"system"}
import weave
from weave.trace.context.call_context import tracing_disabled

client = weave.init('your-team/your-project-name')

@weave.op
def my_op():
    ...

with tracing_disabled():
    my_op()
```

**TypeScript**

```plaintext theme={"system"}
This feature is not available for the TypeScript SDK yet.
```

Although tracing behavior is fixed when functions are defined, you can use this for runtime control when you combine it with application logic. For example, wrap the context manager in a conditional to dynamically enable or disable tracing based on a runtime value:

**Python**

```python lines theme={"system"}
if should_trace:
    my_op()
else:
    with tracing_disabled():
        my_op()
```

**TypeScript**

```plaintext theme={"system"}
This feature is not available for the TypeScript SDK yet.
```
