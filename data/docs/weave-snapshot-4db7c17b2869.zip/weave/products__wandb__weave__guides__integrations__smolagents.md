> ## Documentation Index
> Fetch the complete documentation index at: https://docs.coreweave.com/llms.txt
> Use this file to discover all available pages before exploring further.

# Smolagents

> Track Smolagents applications with Weave's automatic tracing, capturing tool calls, model inferences, and multi-step agent workflows.

> [!WARNING]
>
> All code samples shown on this page are in Python.

This page explains how to integrate [Smolagents](https://huggingface.co/docs/smolagents/en/index) with Weave to track and analyze your agentic applications. It's intended for developers building agentic workflows who want visibility into their model and tool calls. You'll learn how to log model inferences, monitor function calls, and organize experiments using Weave's tracing and versioning capabilities. By following the examples provided, you can capture valuable insights, debug your applications efficiently, and compare different model configurations (all within the Weave web interface).

## Overview

Smolagents is a framework that offers minimal abstractions for building agentic applications. It supports multiple LLM providers, such as OpenAI, Hugging Face Transformers, and Anthropic.

Weave automatically captures traces for [Smolagents](https://huggingface.co/docs/smolagents/en/index). To start tracking, call `weave.init()` and use the library as usual.

## Prerequisites

Before you start, you must install the required libraries and configure access to your chosen LLM provider.

1. Before you can use Smolagents with Weave, you must install the required libraries or upgrade to the latest versions. The following command installs or upgrades `smolagents`, `openai`, and `weave`, and suppresses output:

   ```bash theme={"system"}
   pip install -U smolagents openai weave -qqq
   ```

2. Smolagents supports multiple LLM providers, such as OpenAI, Hugging Face Transformers, and Anthropic. Set the API key for your chosen provider so that Smolagents can authenticate when invoking the model. Set the corresponding environment variable:

   ```python lines theme={"system"}
   import os
   import getpass

   os.environ["OPENAI_API_KEY"] = getpass.getpass("Enter your OpenAI API key: ")
   ```

## Basic tracing

This section shows how Weave automatically captures traces for a basic Smolagents workflow.

Storing traces of language model applications in a central location is essential during development and production. These traces help with debugging and serve as datasets for improving your application.

Weave automatically captures traces for [Smolagents](https://huggingface.co/docs/smolagents/en/index). To start tracking, initialize Weave by calling `weave.init()`, then use the library as usual.

The following example demonstrates how to log inference calls to a tool-using LLM agent with Weave. In this scenario:

* You define a language model (OpenAI's `gpt-4o`) using Smolagents' `OpenAIServerModel`.
* You configure a search tool (`DuckDuckGoSearchTool`) that the agent can invoke when needed.
* You construct a `ToolCallingAgent`, passing in the tool and model.
* You run a query through the agent that triggers the search tool.
* Weave logs each function and model invocation, making them available for inspection in its web interface.

```python lines theme={"system"}
import weave
from smolagents import DuckDuckGoSearchTool, OpenAIServerModel, ToolCallingAgent

# Initialize Weave
weave.init(project_name="smolagents")

# Define your LLM provider supported by Smolagents
model = OpenAIServerModel(model_id="gpt-4o")

# Define a DuckDuckGo web search tool based on your query
search_tool = DuckDuckGoSearchTool()

# Define a tool-calling agent
agent = ToolCallingAgent(tools=[search_tool], model=model)
answer = agent.run(
    "Get me just the title of the page at url 'https://forge.coreweave.com/wandb/geekyrakshit/story-illustration/reports/Building-a-GenAI-assisted-automatic-story-illustrator--Vmlldzo5MTYxNTkw'?"
)
```

Once you run the code sample, navigate to your Weave project dashboard to view the traces.

![Weave logs each inference call, providing details about inputs, outputs, and metadata.](https://mintcdn.com/coreweave-dbfa0e8d/3Dv_sw2eg8feUJlx/products/wandb/weave/_media/smolagents-trace.png?fit=max\&auto=format\&n=3Dv_sw2eg8feUJlx\&q=85\&s=1c3d1f1d2c7f65e64ab91816093f555f)

## Tracing custom tools

In addition to built-in tools, you can extend your agents with custom tools and have Weave trace those calls as well.

You can declare custom tools for your agentic workflows by decorating a function with `@tool` from `smolagents` or by inheriting from the `smolagents.Tool` class.

Weave automatically tracks custom tool calls for your Smolagents workflows. The following example shows how to log a custom Smolagents tool call with Weave:

* You define a custom `get_weather` function and decorate it with `@tool` from Smolagents, enabling the agent to invoke it as part of its reasoning process.
* The function accepts a location and an optional flag for Celsius output.
* You instantiate a language model using `OpenAIServerModel`.
* You create a `ToolCallingAgent` with the custom tool and model.
* When the agent runs the query, it selects and invokes the `get_weather` tool.
* Weave logs both the model inference and the custom tool invocation, including arguments and return values.

```python lines theme={"system"}
from typing import Optional

import weave
from smolagents import OpenAIServerModel, ToolCallingAgent, tool

weave.init(project_name="smolagents")

@tool
def get_weather(location: str, celsius: Optional[bool] = False) -> str:
    """
    Get the weather in the next few days for a given location.
    Args:
        location: The location.
        celsius: Whether to use Celsius for temperature.
    """
    return f"The weather in {location} is sunny with temperatures around 7°C."

model = OpenAIServerModel(model_id="gpt-4o")
agent = ToolCallingAgent(tools=[get_weather], model=model)
answer = agent.run("What is the weather in Tokyo?")
```

Once you run the code sample, navigate to your Weave project dashboard to view the traces.

![Weave logs each custom tool call.](https://mintcdn.com/coreweave-dbfa0e8d/3Dv_sw2eg8feUJlx/products/wandb/weave/_media/smolagents-custom-tool.png?fit=max\&auto=format\&n=3Dv_sw2eg8feUJlx\&q=85\&s=8db13e892f9c1ee196a872e56f5c8354)
