> ## Documentation Index
> Fetch the complete documentation index at: https://docs.coreweave.com/llms.txt
> Use this file to discover all available pages before exploring further.

# Map columns in datasets

> Map columns in datasets to different names. This helps you align the column names in your dataset with the column names expected by the scorer.

**Python**

In the Weave Python SDK, use the `column_map` attribute on a scorer to map its expected parameter names to your dataset's column names. The mapping format is `{scorer_parameter: dataset_column}`.

The following example maps the `output` and `target` parameters to a dataset's `model_output` and `answer` columns:

```python theme={"system"}
from weave.scorers import EmbeddingSimilarityScorer

similarity_scorer = EmbeddingSimilarityScorer()

similarity_scorer.column_map = {
    "output": "model_output",  # The model's generated text
    "target": "answer"         # The expected or reference response
}
```

For more information about scorer column mapping, see [Mapping Column Names with `column_map`](https://docs.coreweave.com/products/wandb/weave/guides/evaluation/scorers#mapping-column-names-with-column_map).

**TypeScript**

In the Weave TypeScript SDK, you configure column mapping on the `Evaluation` object using the `columnMapping` option, not on individual scorers. The mapping format is `{scorer_key: dataset_column}`.

The following example maps `expectedOutputTimesTwo` (used by the scorer) to the `expected` column in the dataset:

```typescript twoslash theme={"system"}
// @noErrors
import * as weave from 'weave';

const myScorer = weave.op(
  ({modelOutput, datasetRow}) => {
    return modelOutput * 2 === datasetRow.expectedOutputTimesTwo;
  },
  {name: 'myScorer'}
);

const myEval = new weave.Evaluation({
  id: 'my-evaluation',
  dataset: [{expected: 2}],
  scorers: [myScorer],
  columnMapping: {expectedOutputTimesTwo: 'expected'},
});
```

For more information about TypeScript scorer arguments, see [Scorer Keyword Arguments](https://docs.coreweave.com/products/wandb/weave/guides/evaluation/scorers.md#scorer-keyword-arguments).
