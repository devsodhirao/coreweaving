> ## Documentation Index
> Fetch the complete documentation index at: https://docs.coreweave.com/llms.txt
> Use this file to discover all available pages before exploring further.

# Role

> TypeScript SDK reference

> **Role** = `"user"` | `"assistant"` | `"system"` | `"tool"` | `"developer"` | `"function"`

[GitHub source](https://github.com/wandb/weave/blob/7c9efdc9fe05ffcaf2430dd652ef9bc5b3ffdfaa/sdks/node/src/genai/types.ts#L17)
