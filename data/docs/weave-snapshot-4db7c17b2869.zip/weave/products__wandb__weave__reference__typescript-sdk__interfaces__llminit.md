> ## Documentation Index
> Fetch the complete documentation index at: https://docs.coreweave.com/llms.txt
> Use this file to discover all available pages before exploring further.

# LLMInit

> TypeScript SDK reference

[GitHub source](https://github.com/wandb/weave/blob/7c9efdc9fe05ffcaf2430dd652ef9bc5b3ffdfaa/sdks/node/src/genai/llm.ts#L36)

## Extends

* `SpanInitBase`

## Properties

### model

> **model**: `string`

***

### providerName

> `optional` **providerName**: `string`

***

### startTime

> `optional` **startTime**: `TimeInput`

#### Inherited from

`SpanInitBase.startTime`

***

### systemInstructions

> `optional` **systemInstructions**: `string`\[]
