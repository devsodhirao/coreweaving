> ## Documentation Index
> Fetch the complete documentation index at: https://docs.coreweave.com/llms.txt
> Use this file to discover all available pages before exploring further.

# Use the Playground to experiment with prompts

> Simplify the process of iterating on LLM prompts and responses

> [!TIP]
>
> For a limited time, Serverless Inference is included in your free tier. Serverless Inference provides access to leading open source foundation models through API and the Weave Playground.
>
> * [Developer documentation](https://docs.coreweave.com/products/wandb/weave/guides/integrations/inference.md)
> * [Product page](https://wandb.ai/site/inference)

Evaluating LLM prompts and responses is challenging. The Weave Playground simplifies the process of iterating on LLM prompts and responses, helping you experiment with different models and prompts. With features like prompt editing, message retrying, and model comparison, Playground helps you test and improve your LLM applications. Playground is intended for developers and prompt engineers who want to test, compare, and refine LLM prompts before integrating them into applications. Playground supports models from providers such as OpenAI, Anthropic, and Google, as well as [custom runtimes](#custom-runtimes).

* **Quick access:** Open the **Playground** from the Weave sidebar menu for a fresh session or from the Call page to test an existing project.
* **Message controls:** Edit, retry, or delete messages directly within the chat.
* **Flexible messaging:** Add new messages as either user or system inputs, and send them to the LLM.
* **Customizable settings:** Configure your preferred LLM provider and adjust model settings.
* **Multi-LLM support:** Switch between models, with team-level API key management.
* **Compare models:** Compare how different models respond to prompts.
* **Custom runtimes:** Test OpenAI-compatible API endpoints for custom models.
* **Saved models:** Create and configure a reusable model preset for your workflow.

Get started with the Playground to optimize your LLM interactions and streamline your prompt engineering process and LLM application development. The following sections describe how to configure and use the Playground:

* [Add provider credentials and information](#add-provider-credentials-and-information)
* [Access the Playground](#access-the-playground)
* [Select an LLM](#select-an-llm)
* [Customize Playground settings](#customize-playground-settings)
* [Message controls](#message-controls)
* [Compare LLMs](#compare-llms)
* [Custom runtimes](#custom-runtimes)
* [Saved models](#saved-models)

## Add provider credentials and information

Before you can use Playground, you must add provider credentials so that Playground can authenticate requests to each model provider on your behalf. Playground supports models from many providers. To use one of the available models, you must add the appropriate information to your team secrets in Weights & Biases settings.

* Amazon Bedrock:
  * `AWS_ACCESS_KEY_ID`
  * `AWS_SECRET_ACCESS_KEY`
  * `AWS_REGION_NAME`
* Anthropic: `ANTHROPIC_API_KEY`
* Azure:
  * `AZURE_API_KEY`
  * `AZURE_API_BASE`
  * `AZURE_API_VERSION`
* Deepseek: `DEEPSEEK_API_KEY`
* Google: `GEMINI_API_KEY`
* Groq: `GROQ_API_KEY`
* Mistral: `MISTRAL_API_KEY`
* OpenAI: `OPENAI_API_KEY`
* X.AI: `XAI_API_KEY`

## Access the Playground

You can access the Playground in two ways:

1. *Open a fresh Playground page with a default system prompt*: In the sidebar of a Weave project, select **Playground**. Playground opens in the same tab.
2. *Open Playground for a specific call*:
   1. In the sidebar, select the **Traces** tab. A list of traces displays.
   2. In the list of traces, click the name of the call that you want to view. The call's details page opens.
   3. Click **Open chat in Playground**. Playground opens in a new tab.

![Screenshot of Open in Playground button](https://mintcdn.com/coreweave-dbfa0e8d/3Dv_sw2eg8feUJlx/products/wandb/weave/_media/open_chat_in_playground.png?fit=max\&auto=format\&n=3Dv_sw2eg8feUJlx\&q=85\&s=d2cf25b85a250baa787e341c5360dcdb)

## Select an LLM

You can switch the LLM using the **Select a model** dropdown in the prompt header (top of the main Playground panel). The following providers are available:

* Amazon Bedrock
* Anthropic
* Azure
* Deepseek
* Google
* Groq
* Mistral
* OpenAI
* X.AI

The available models depend on the providers configured for your team.

## Customize Playground settings

You can adjust the parameters of your selected model and add functions for the model to call. The following sections describe how to customize Playground settings.

### Adjust LLM parameters

You can experiment with different parameter values for your selected model. To adjust parameters in the Playground, do the following:

1. In the prompt header (top of main panel), click the **Chat settings ()** button to open the **Chat settings** panel.
2. In the **Chat settings** panel, adjust parameters as desired. You can also toggle Weave call tracking on or off, and [add a function](#add-a-function).
3. Changes apply automatically. Click **Chat settings** again, or the **x** in the upper-right corner, to close the panel. The hover text for the **Chat settings** button shows the settings you've changed.

> [!NOTE]
>
> If you leave the page, your settings are lost. To save your settings, [save your model](#save-a-model). If you want to discard your changed settings and start over, refresh the page.

![The Weave Playground showing the Select a model dropdown open and the Chat settings panel open on the right.](https://mintcdn.com/coreweave-dbfa0e8d/3Dv_sw2eg8feUJlx/products/wandb/weave/_media/playground_settings.png?fit=max\&auto=format\&n=3Dv_sw2eg8feUJlx\&q=85\&s=43416618be53a6a994d2a28088231269)

Playground lets you generate multiple outputs for the same input by setting the number of trials. The default setting is `1`. To adjust the number of trials, open the **Chat settings** panel and adjust the **Number of trials** setting.

### Add a function

You can test how different models use functions based on input they receive from the user. To add a function for testing in Playground, in the **Chat settings** panel, click **+ Add function**. Follow the on-screen guidance to define the function and save your changes.

## Message controls

The Playground chat interface is organized into three areas: the prompt definition area, the messages panel, and the message composer. The following sections describe each area.

### Prompt definition area

The **Prompt definition area** lets you define the instructions that shape the model's behavior throughout an interaction.

Use this area to provide context that applies consistently before any messages are exchanged. This includes role definition, tone and style guidance, behavioral constraints, and output requirements. Changes made here affect all subsequent interactions unless modified.

It includes:

* **Prompt selector**: Select an existing saved prompt or create a new one.
* **Message role selector**: Specify the role of the message being defined (**System**, **Assistant**, or **User** role).
* **Prompt text**: Enter the instruction text that establishes how the model responds.
* **Add message** button: Lets you include additional messages in the prompt context before execution.

These messages are sent to the model together, and you can use them to:

* Add supplemental system-level instructions.
* Provide example assistant messages to guide responses (such as few-shot prompting).
* Predefine user messages for testing specific scenarios.

### Messages panel

The **Messages panel** displays the conversation generated during execution.

It includes:

* Any predefined messages included in the prompt setup.
* Messages sent from the message composer.
* Responses returned by the model.

You can also **Copy**, **Delete**, **Edit**, and **Retry** messages inside the panel.

### Message composer (input field)

Use the **Message composer** to send new messages to the model.

It supports selecting the message role and submitting messages for execution. Most interactions are authored as **User** messages. You can add **System** or **Assistant** messages when testing instruction changes.

![Weave Playground showing the prompt definition area at the top, message history in the middle, and a message composer for sending new messages at the bottom.](https://mintcdn.com/coreweave-dbfa0e8d/3Dv_sw2eg8feUJlx/products/wandb/weave/_media/playground_chat_input.png?fit=max\&auto=format\&n=3Dv_sw2eg8feUJlx\&q=85\&s=4883e49f5049eb91b8b2058169861eec)

## View message history

To view message history, click the **History ()** button in the right-side Playground toolbar. This opens a History panel showing all messages sent for the current project.

Selecting an item from the history loads it into an additional chat panel for comparison.

## Compare LLMs

Playground lets you compare LLMs side by side so you can evaluate how different models respond to the same prompts. To perform a comparison, click the **Add Chat ()** button in the right-side Playground toolbar. A second chat opens next to the original chat. The second chat has the same functionality as the original chat, such as choosing the model, adjusting the settings, and adding functions.

## Custom runtimes

In addition to the built-in providers, the Playground supports custom runtimes: OpenAI-compatible API endpoints that you register to your project. Custom runtimes were previously called *custom providers*. Use a custom runtime to test models such as an agent prototype your team serves, a local model, or an older version of a supported provider's model.

To register a custom runtime in the UI or with the Python SDK, see [Custom runtimes](https://docs.coreweave.com/products/wandb/weave/guides/tools/custom-runtimes.md). After you register a custom runtime, select its models from the **Select a model** dropdown and test them using standard Playground features.

### Use a local model as a custom runtime

To test a locally running model in the Playground, use ngrok and Ollama to create a temporary public URL that avoids CORS restrictions. This lets the Playground reach a model that is running on your own machine without violating browser security policies.

To set it up, do the following:

1. [Install ngrok](https://ngrok.com/docs/getting-started/#step-1-install) for your operating system.

2. Start your Ollama model. Replace `[MODEL]` with the name of the Ollama model you want to run.

   ```bash theme={"system"}
   ollama run [MODEL]
   ```

3. In a separate terminal, create an ngrok tunnel with the required CORS headers:

   ```bash theme={"system"}
   ngrok http 11434 --response-header-add "Access-Control-Allow-Origin: *" --host-header rewrite
   ```

4. After ngrok starts, it displays a public URL, such as `https://xxxx-xxxx.ngrok-free.app`. Use this URL as the **Base URL** when you [register a custom runtime](https://docs.coreweave.com/products/wandb/weave/guides/tools/custom-runtimes.md#register-a-custom-runtime-in-the-ui).

The following diagram illustrates the data flow between your local environment, the ngrok proxy, and the Weights & Biases cloud services:

```mermaid theme={"system"}
flowchart LR
    %% Style definitions
    classDef clientMachine fill:#FFD95CCC,stroke:#454B52,stroke-width:2px
    classDef proxy fill:#00CDDBCC,stroke:#454B52,stroke-width:2px
    classDef wandbCloud fill:#DE72FFCC,stroke:#454B52,stroke-width:2px
    classDef publicCloud fill:#FFCBADCC,stroke:#454B52,stroke-width:2px

    %% Subgraphs
    subgraph Client_Machine
        browser[Browser]
        llm_local[Local LLM Provider]
    end

    subgraph Proxy
        ngrok[Ngrok Proxy]
    end

    subgraph WandB_Cloud
        trace_server[Trace Server]
    end

    subgraph Public_Cloud
        llm_cloud[Public LLM Provider]
    end

    %% Apply styles to subgraphs
    class Client_Machine clientMachine
    class Proxy proxy
    class WandB_Cloud wandbCloud
    class Public_Cloud publicCloud

    %% Current Data Flow
    browser -->|Sends chat request| trace_server
    trace_server -->|Uses Public LLM| llm_cloud
    trace_server -->|Uses Local LLM| ngrok
    ngrok -->|Forwards to| llm_local
    llm_cloud -->|Returns response| trace_server
    llm_local -->|Returns response| ngrok
    ngrok -->|Forwards to| trace_server
    trace_server -->|Returns response| browser

    %% Future Possible Connection
    browser -.->|Future: Call local LLM directly| llm_local

    %% Link styles
    linkStyle default stroke:#454B52,stroke-width:2px
    linkStyle 8 stroke:#454B52,stroke-width:2px,stroke-dasharray:5
```

## Saved models

Saved models let you preserve a provider, model, parameters, and function hooks as a reusable preset. The following sections describe how to save, use, and update a model.

### Save a model

You can create and configure a reusable model preset for your workflow. Saving a model lets you quickly load it with your preferred settings, parameters, and function hooks.

1. In the prompt header (top of main panel), in the **Select a model** dropdown, select a provider and model.
2. In the prompt header, click the **Chat settings ()** button to open the **Chat settings** panel.
3. In the **Chat settings** panel:
   * **Model Name** (required): Enter a name for your saved model.
   * Adjust parameters as desired. You can also toggle Weave call tracking on or off, and [add a function](#add-a-function).
4. Click **Publish model**. The model is saved and accessible from **Saved Models** in the **Select a model** dropdown. You can then [use](#use-a-saved-model) and [update](#update-a-saved-model) the saved model.

### Use a saved model

Switch to a previously [saved model](#save-a-model) to maintain consistency across experiments or sessions. This way you can pick up where you left off.

1. In the prompt header, in the **Select a model** dropdown, select **Saved Models**.
2. From the list of saved models, select the saved model you want to load. The model loads and is ready to use in the Playground.

### Update a saved model

Edit an existing [saved model](#save-a-model) to fine-tune parameters or refresh its configuration. This way, your saved models evolve alongside your use cases.

1. In the prompt header, in the **Select a model** dropdown, select **Saved Models**.
2. From the list of saved models, select the saved model you want to update.
3. In the prompt header, click the **Chat settings ()** button to open the **Chat settings** panel.
4. In the **Chat settings** panel, adjust parameters as desired. You can also toggle Weave call tracking on or off, and [add a function](#add-a-function).
5. Click **Update model**. This updates the model and makes it accessible from **Saved Models** in the **Select a model** dropdown. The version of your saved model increments automatically.
