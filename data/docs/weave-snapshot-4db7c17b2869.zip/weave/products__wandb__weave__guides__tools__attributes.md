> ## Documentation Index
> Fetch the complete documentation index at: https://docs.coreweave.com/llms.txt
> Use this file to discover all available pages before exploring further.

# Define and log attributes

> Use attributes to add metadata to your traces and evaluations.

> [!NOTE]
>
> This page describes attributes for functions traced with the `@weave.op` decorator. If you instrument an agent with the Weave agent SDK, set attributes and events on agent spans (`Turn`, `LLM`, `Tool`, and `SubAgent`) instead. See [Set attributes and events on agent spans](https://docs.coreweave.com/products/wandb/weave/guides/tracking/trace-agents-attributes.md).

Attributes in Weave let you attach custom metadata to your traces and evaluations. This metadata can include information like environment names, model versions, experiment IDs, user IDs, or other contextual information to help you organize, filter, and analyze your Weave data.

Attributes are especially helpful for grouping or filtering traces by:

* Deployments
* Tenants
* Experiments

Weave provides two ways to add attributes:

* **Per-call attributes**: Use the `weave.attributes()` context manager to add metadata to specific operations or code blocks.
* **Global attributes**: Use the `global_attributes` field to set attributes at initialization that apply to all traces and evaluations in your project.

You can view all attributes logged during traces and evaluations in the UI. You can then use them to filter and group data.

This guide is for Weave users who want to enrich their traces and evaluations with custom metadata. It covers how to attach attributes to individual calls, set project-wide defaults at initialization, combine the two approaches, and read the current attribute set during execution.

## Per-call attributes

The `weave.attributes()` context manager lets you add metadata to specific traced operations. Use it to tag particular function calls or evaluation runs with contextual information.

> [!TIP]
>
> You can't modify `call.attributes` once the call starts. Use this
> context manager to set any metadata before invoking the op.

**Python**

```python lines theme={"system"}
import weave

weave.init("[TEAM-NAME]/[PROJECT-NAME]")

@weave.op
def my_function(name: str):
    return f"Hello, {name}!"

# Add attributes to a specific call
with weave.attributes({'env': 'production', 'user_id': '12345'}):
    result = my_function("World")
```

**TypeScript**

```typescript twoslash lines theme={"system"}
// @noErrors
import {init, op, withAttributes} from 'weave';

async function main() {
  await init('your-team/attribute-example');

  const myFunction = op(async function myFunction(name: string) {
    return `Hello, ${name}!`;
  });

  // Add attributes to a specific call
  const result = await withAttributes(
    {env: 'production', user_id: '12345'},
    async () => myFunction('World')
  );

  console.log('Result:', result);
}

main().catch(console.error);
```

The function attaches the attributes to all traced operations within the context manager block (Python) or callback function (TypeScript).

You can also nest `weave.attributes()` contexts. Inner contexts override outer contexts for the same keys:

**Python**

```python lines theme={"system"}
@weave.op
def process_data(data: str):
    return data.upper()

# Outer context
with weave.attributes({
    "env": "production",
    "version": "1.0.0",
    "region": "us-west-2"
}):
    process_data("hello")  # Has all three attributes
    
    # Inner context overrides 'version'
    with weave.attributes({
        "version": "1.1.0",
        "experiment": "exp-456"
    }):
        process_data("world")  # Has env='production', version='1.1.0', region='us-west-2', experiment='exp-456'
```

**TypeScript**

```typescript twoslash lines theme={"system"}
// @noErrors
import {init, op, withAttributes} from 'weave';

async function main() {
  await init('your-team/attribute-example');

  const processData = op(async function processData(data: string) {
    return data.toUpperCase();
  });
  
  // Outer context
  await withAttributes(
    {
      env: 'production',
      version: '1.0.0',
      region: 'us-west-2'
    },
    async () => {
      await processData('hello');  // Has all three attributes
      
      // Inner context overrides 'version'
      await withAttributes(
        {
          version: '1.1.0',
          experiment: 'exp-456'
        },
        async () => {
          await processData('world');  // Has env='production', version='1.1.0', region='us-west-2', experiment='exp-456'
        }
      );
    }
  );
}

main().catch(console.error);
```

## Global attributes

When you set global attributes during Weave initialization, they automatically apply to all traces and evaluations in your project. This is useful for propagating project-wide metadata like environment, deployment version, or team information.

**Python**

```python lines theme={"system"}
import weave

weave.init(
    "my-project",
    global_attributes={
        "env": "production",
        "app_version": "2.1.0",
        "region": "us-west-2",
        "team": "ml-platform"
    }
)

# The global_attributes dictionary now applies these attributes to all subsequent operations
@weave.op
def my_function():
    return "Hello"

my_function()  # Automatically has all global attributes

# Evaluations also get global attributes
evaluation = weave.Evaluation(dataset=examples, scorers=[scorer])
asyncio.run(evaluation.evaluate(model))  # Has all global attributes
```

**TypeScript**

```typescript twoslash lines theme={"system"}
// @noErrors
import {init, op, withAttributes} from 'weave';

async function main() {
    await init('your-team/attribute-example', {
        globalAttributes: {
            env: 'production',
            app_version: '2.1.0',
            region: 'us-west-2',
            team: 'ml-platform'
        }
    });
    
    // The globalAttributes object now applies these attributes to all subsequent operations
    const myFunction = op(async function myFunction() {
        return 'Hello';
    });
    
    const result = await myFunction();  // Automatically has all global attributes
    console.log('Result:', result);
}
main().catch(console.error);
```

### Combine global and per-call attributes

You can use global attributes and per-call attributes together. Per-call attributes with the same key override global attributes:

**Python**

```python lines theme={"system"}
import weave

# Set global attributes
weave.init(
    "my-project",
    global_attributes={
        "env": "production",
        "app_version": "2.1.0"
    }
)

@weave.op
def process(data: str):
    return data

# This call has: env='production', app_version='2.1.0'
process("test1")

# This call has: env='staging', app_version='2.1.0', experiment='A'
with weave.attributes({'env': 'staging', 'experiment': 'A'}):
    process("test2")
```

**TypeScript**

```typescript twoslash lines theme={"system"}
// @noErrors
import {init, op, withAttributes} from 'weave';

async function main() {
    // Set global attributes
    await init('your-team/attribute-example', {
    globalAttributes: {
        env: 'production',
        app_version: '2.1.0'
    }
    });

    const process = op(async function process(data: string) {
    return data;
    });

    // This call has: env='production', app_version='2.1.0'
    await process('test1');

    // This call has: env='staging', app_version='2.1.0', experiment='A'
    await withAttributes(
    {env: 'staging', experiment: 'A'},
    async () => process('test2')
    );
}
main().catch(console.error);
```

## Get attributes during execution

At runtime, you can inspect the attributes in effect for a Call. This is useful when you want to debug which metadata Weave attaches, or when your code needs to branch on contextual information set by an outer caller.

**Python**

The following example sets the Weave decorator to log the `process_data` function, configures attributes to log, and then returns them on execution.

```python lines  theme={"system"}
import weave

weave.init("your-team/your-project")

@weave.op
def process_data(data: str):
    # Get the current call inside the op
    call = weave.get_current_call()
    if call:
        print(f"Attributes: {call.attributes}")
    return data.upper()

# Set attributes and execute the function
with weave.attributes({
    "env": "production",
    "version": "1.0.0",
    "region": "us-west-2"
}):
    process_data("hello")
    
    with weave.attributes({
        "version": "1.1.0",
        "experiment": "exp-456"
    }):
        process_data("world")
```

This outputs:

```text theme={"system"}
Attributes: {'env': 'production', 'version': '1.0.0', 'region': 'us-west-2'}
Attributes: {'env': 'production', 'version': '1.1.0', 'region': 'us-west-2', 'experiment': 'exp-456'}
```

> [!NOTE]
>
> `weave.get_current_call()` only works inside a `@weave.op` decorated function. Outside of an op, it returns `None`.

**TypeScript**

With the Weave TypeScript SDK, you can get the current attributes with `client.getCurrentAttributes()`. Unlike the Weave Python SDK, you can access TypeScript attributes within a `withAttributes()` context, not just inside an op.

```typescript twoslash lines theme={"system"}
// @noErrors
import * as weave from 'weave';
import { withAttributes } from 'weave';

async function main() {
  const client = await weave.init('your-team/your-project');

  const processData = weave.op(async function processData(data: string) {
    // You can also access attributes inside an op
    const attrs = client.getCurrentAttributes();
    console.log('Attributes inside op:', attrs);
    return data.toUpperCase();
  });

  // Set attributes and execute the function
  await withAttributes(
    {
      env: 'production',
      version: '1.0.0',
      region: 'us-west-2'
    },
    async () => {
      // Get attributes from anywhere in the context
      console.log('Current attributes:', client.getCurrentAttributes());
      await processData('hello');

      await withAttributes(
        {
          version: '1.1.0',
          experiment: 'exp-456'
        },
        async () => {
          console.log('Nested attributes:', client.getCurrentAttributes());
          await processData('world');
        }
      );
    }
  );
}

main().catch(console.error);
```

This outputs:

```text theme={"system"}
Current attributes: { env: 'production', version: '1.0.0', region: 'us-west-2' }
Attributes inside op: { env: 'production', version: '1.0.0', region: 'us-west-2' }
Nested attributes: { env: 'production', version: '1.1.0', region: 'us-west-2', experiment: 'exp-456' }
Attributes inside op: { env: 'production', version: '1.1.0', region: 'us-west-2', experiment: 'exp-456' }
```
