> ## Documentation Index
> Fetch the complete documentation index at: https://docs.coreweave.com/llms.txt
> Use this file to discover all available pages before exploring further.

# feedback

> Python SDK reference for weave.trace.feedback

# API Overview

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace/feedback.py#L84)

## <kbd>class</kbd> `FeedbackQuery`

Lazy-loading object for fetching feedback from the server.

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace/feedback.py#L97)

### <kbd>method</kbd> `__init__`

```python theme={"system"}
__init__(
    entity: 'str',
    project: 'str',
    query: 'Query',
    offset: 'int | None' = None,
    limit: 'int | None' = None,
    show_refs: 'bool' = False
)
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace/feedback.py#L145)

### <kbd>method</kbd> `execute`

```python theme={"system"}
execute() → Feedbacks
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace/feedback.py#L126)

### <kbd>method</kbd> `refresh`

```python theme={"system"}
refresh() → Feedbacks
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace/feedback.py#L151)

### <kbd>method</kbd> `refs`

```python theme={"system"}
refs() → Refs
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace/feedback.py#L21)

## <kbd>class</kbd> `Feedbacks`

A collection of Feedback objects with utilities.

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace/feedback.py#L26)

### <kbd>method</kbd> `__init__`

```python theme={"system"}
__init__(
    show_refs: 'bool',
    feedbacks: 'Iterable[Feedback] | None' = None
) → None
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace/feedback.py#L32)

### <kbd>method</kbd> `refs`

```python theme={"system"}
refs() → Refs
```

Return the unique refs associated with these feedbacks.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace/feedback.py#L168)

## <kbd>class</kbd> `RefFeedbackQuery`

Object for interacting with feedback associated with a particular ref.

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace/feedback.py#L173)

### <kbd>method</kbd> `__init__`

```python theme={"system"}
__init__(ref: 'str') → None
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace/feedback.py#L219)

### <kbd>method</kbd> `add`

```python theme={"system"}
add(
    feedback_type: 'str',
    payload: 'dict[str, Any] | None' = None,
    creator: 'str | None' = None,
    annotation_ref: 'str | None' = None,
    **kwargs: 'dict[str, Any]'
) → str
```

Add feedback to the ref.

feedback\_type: A string identifying the type of feedback. The "wandb." prefix is reserved. creator: The name to display for the originator of the feedback.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace/feedback.py#L247)

### <kbd>method</kbd> `add_note`

```python theme={"system"}
add_note(note: 'str', creator: 'str | None' = None) → str
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace/feedback.py#L238)

### <kbd>method</kbd> `add_reaction`

```python theme={"system"}
add_reaction(emoji: 'str', creator: 'str | None' = None) → str
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace/feedback.py#L145)

### <kbd>method</kbd> `execute`

```python theme={"system"}
execute() → Feedbacks
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace/feedback.py#L256)

### <kbd>method</kbd> `purge`

```python theme={"system"}
purge(feedback_id: 'str') → None
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace/feedback.py#L126)

### <kbd>method</kbd> `refresh`

```python theme={"system"}
refresh() → Feedbacks
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace/feedback.py#L151)

### <kbd>method</kbd> `refs`

```python theme={"system"}
refs() → Refs
```
