> ## Documentation Index
> Fetch the complete documentation index at: https://docs.coreweave.com/llms.txt
> Use this file to discover all available pages before exploring further.

# Op Delete

> Delete an op object. If digests are provided, only those versions are deleted. Otherwise, all versions are deleted.



## OpenAPI

````yaml products/wandb/weave/reference/service-api/openapi.json DELETE /v2/{entity}/{project}/ops/{object_id}
openapi: 3.1.0
info:
  title: FastAPI
  version: 0.1.0
servers: []
security: []
paths:
  /v2/{entity}/{project}/ops/{object_id}:
    delete:
      tags:
        - Ops
      summary: Op Delete
      description: >-
        Delete an op object. If digests are provided, only those versions are
        deleted. Otherwise, all versions are deleted.
      operationId: op_delete_v2__entity___project__ops__object_id__delete
      parameters:
        - name: entity
          in: path
          required: true
          schema:
            type: string
            title: Entity
        - name: project
          in: path
          required: true
          schema:
            type: string
            title: Project
        - name: object_id
          in: path
          required: true
          schema:
            type: string
            title: Object Id
        - name: digests
          in: query
          required: false
          schema:
            anyOf:
              - items:
                  type: string
                type: array
              - type: 'null'
            description: >-
              List of digests to delete. If not provided, all digests for the op
              will be deleted.
            title: Digests
          description: >-
            List of digests to delete. If not provided, all digests for the op
            will be deleted.
      responses:
        '200':
          description: Successful Response
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/OpDeleteRes'
        '422':
          description: Validation Error
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/HTTPValidationError'
components:
  schemas:
    OpDeleteRes:
      properties:
        num_deleted:
          type: integer
          title: Num Deleted
          description: Number of op versions deleted from this op
      type: object
      required:
        - num_deleted
      title: OpDeleteRes
    HTTPValidationError:
      properties:
        detail:
          items:
            $ref: '#/components/schemas/ValidationError'
          type: array
          title: Detail
      type: object
      title: HTTPValidationError
    ValidationError:
      properties:
        loc:
          items:
            anyOf:
              - type: string
              - type: integer
          type: array
          title: Location
        msg:
          type: string
          title: Message
        type:
          type: string
          title: Error Type
        input:
          title: Input
        ctx:
          type: object
          title: Context
      type: object
      required:
        - loc
        - msg
        - type
      title: ValidationError

````