> ## Documentation Index
> Fetch the complete documentation index at: https://docs.coreweave.com/llms.txt
> Use this file to discover all available pages before exploring further.

# util

> Python SDK reference for weave.trace.util

# API Overview

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace/util.py#L105)

## <kbd>class</kbd> `ContextAwareThread`

A Thread that runs functions with the context of the caller.

This is a drop-in replacement for threading.Thread that ensures calls behave as expected inside the thread.  Weave requires certain contextvars to be set (see call\_context.py), but new threads do not automatically copy context from the parent, which can cause the call context to be lost -- not good!  This class automates contextvar copying so using this thread "just works" as the user probably expects.

You can achieve the same effect without this class by instead writing:

```python theme={"system"}
def run_with_context(func, *args, **kwargs):
     context = copy_context()
     def wrapper():
         context.run(func, *args, **kwargs)
     return wrapper

thread = threading.Thread(target=run_with_context(your_func, *args, **kwargs))
thread.start()
```

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace/util.py#L129)

### <kbd>method</kbd> `__init__`

```python theme={"system"}
__init__(*args: 'Any', **kwargs: 'Any') → None
```

***

#### <kbd>property</kbd> daemon

A boolean value indicating whether this thread is a daemon thread.

This must be set before start() is called, otherwise RuntimeError is raised. Its initial value is inherited from the creating thread; the main thread is not a daemon thread and therefore all threads created in the main thread default to daemon = False.

The entire Python program exits when only daemon threads are left.

***

#### <kbd>property</kbd> ident

Thread identifier of this thread or None if it has not been started.

This is a nonzero integer. See the get\_ident() function. Thread identifiers may be recycled when a thread exits and another thread is created. The identifier is available even after the thread has exited.

***

#### <kbd>property</kbd> name

A string used for identification purposes only.

It has no semantics. Multiple threads may be given the same name. The initial name is set by the constructor.

***

#### <kbd>property</kbd> native\_id

Native integral thread ID of this thread, or None if it has not been started.

This is a non-negative integer. See the get\_native\_id() function. This represents the Thread ID as reported by the kernel.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace/util.py#L133)

### <kbd>method</kbd> `run`

```python theme={"system"}
run() → None
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace/util.py#L45)

## <kbd>class</kbd> `ContextAwareThreadPoolExecutor`

A ThreadPoolExecutor that runs functions with the context of the caller.

This is a drop-in replacement for concurrent.futures.ThreadPoolExecutor that ensures weave calls behave as expected inside the executor.  Weave requires certain contextvars to be set (see call\_context.py), but new threads do not automatically copy context from the parent, which can cause the call context to be lost -- not good!  This class automates contextvar copying so using this executor "just works" as the user probably expects.

You can achieve the same effect without this class by instead writing:

```python theme={"system"}
with concurrent.futures.ThreadPoolExecutor() as executor:
     contexts = [copy_context() for _ in range(len(vals))]

     def _wrapped_fn(*args):
         return contexts.pop().run(fn, *args)

     executor.map(_wrapped_fn, vals)
```

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace/util.py#L68)

### <kbd>method</kbd> `__init__`

```python theme={"system"}
__init__(*args: 'Any', **kwargs: 'Any') → None
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace/util.py#L77)

### <kbd>method</kbd> `map`

```python theme={"system"}
map(
    fn: 'Callable',
    *iterables: 'Iterable[Any]',
    timeout: 'float | None' = None,
    chunksize: 'int' = 1
) → Iterator
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace/util.py#L73)

### <kbd>method</kbd> `submit`

```python theme={"system"}
submit(fn: 'Callable', *args: 'Any', **kwargs: 'Any') → Any
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace/util.py#L164)

### <kbd>function</kbd> `deprecated`

```python theme={"system"}
deprecated(new_name: 'str') → Callable[[Callable[P, R]], Callable[P, R]]
```

Decorator to mark a function as deprecated and redirect users to `new_name`.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace/util.py#L137)

### <kbd>function</kbd> `is_colab`

```python theme={"system"}
is_colab()
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace/util.py#L146)

### <kbd>function</kbd> `is_notebook`

```python theme={"system"}
is_notebook() → bool
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace/util.py#L21)

### <kbd>function</kbd> `log_once`

```python theme={"system"}
log_once(log_method: 'Callable[[str], None]', message: 'str') → None
```

Logs a message once, suppressing subsequent messages of the same type. This is useful for notifying the user about errors without spamming the logs.

This is mostly useful for cases where the same error message might occur many times. For example, if an op fails to save, it is likely going to happen every time that op is called. Or, if we have an error in our patched iterator, then it likely happens every time we iterate over the result. This allows use to inform the user about the error without clogging up their logs.

**Args:**

* **`log_method`**: The method to use to log the message. This should accept a string argument.
* **`message`**: The message to log.

**Example:**

```python theme={"system"}
log_once(logger.error, "Failed to save op")
```
