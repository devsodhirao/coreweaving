> ## Documentation Index
> Fetch the complete documentation index at: https://docs.coreweave.com/llms.txt
> Use this file to discover all available pages before exploring further.

# Link To Registry



## OpenAPI

````yaml products/wandb/weave/reference/service-api/openapi.json POST /link_to_registry
openapi: 3.1.0
info:
  title: FastAPI
  version: 0.1.0
servers: []
security: []
paths:
  /link_to_registry:
    post:
      tags:
        - Registry
      summary: Link To Registry
      operationId: link_to_registry_link_to_registry_post
      requestBody:
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/CreateAndLinkPayload'
        required: true
      responses:
        '200':
          description: Successful Response
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/CreateAndLinkWeaveAssetRes'
        '422':
          description: Validation Error
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/HTTPValidationError'
components:
  schemas:
    CreateAndLinkPayload:
      properties:
        ref:
          type: string
          minLength: 1
          title: Ref
        target:
          $ref: '#/components/schemas/CreateAndLinkTarget'
        aliases:
          items:
            type: string
          type: array
          title: Aliases
          default: []
      type: object
      required:
        - ref
        - target
      title: CreateAndLinkPayload
    CreateAndLinkWeaveAssetRes:
      properties:
        version_index:
          anyOf:
            - type: integer
            - type: 'null'
          title: Version Index
      type: object
      title: CreateAndLinkWeaveAssetRes
    HTTPValidationError:
      properties:
        detail:
          items:
            $ref: '#/components/schemas/ValidationError'
          type: array
          title: Detail
      type: object
      title: HTTPValidationError
    CreateAndLinkTarget:
      properties:
        portfolio_name:
          type: string
          minLength: 1
          title: Portfolio Name
        entity_name:
          type: string
          minLength: 1
          title: Entity Name
        project_name:
          type: string
          minLength: 1
          title: Project Name
      type: object
      required:
        - portfolio_name
        - entity_name
        - project_name
      title: CreateAndLinkTarget
    ValidationError:
      properties:
        loc:
          items:
            anyOf:
              - type: string
              - type: integer
          type: array
          title: Location
        msg:
          type: string
          title: Message
        type:
          type: string
          title: Error Type
        input:
          title: Input
        ctx:
          type: object
          title: Context
      type: object
      required:
        - loc
        - msg
        - type
      title: ValidationError

````