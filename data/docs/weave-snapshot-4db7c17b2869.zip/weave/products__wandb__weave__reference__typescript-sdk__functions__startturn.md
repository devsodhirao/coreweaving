> ## Documentation Index
> Fetch the complete documentation index at: https://docs.coreweave.com/llms.txt
> Use this file to discover all available pages before exploring further.

# startTurn

> TypeScript SDK reference

```ts theme={"system"}
startTurn(opts?: TurnInit = {}): Turn
```

[GitHub source](https://github.com/wandb/weave/blob/7c9efdc9fe05ffcaf2430dd652ef9bc5b3ffdfaa/sdks/node/src/genai/api.ts#L54)

Start a new Turn. If a Conversation is active, the turn inherits its
`conversationId`; otherwise the turn has no conversation id.

## Parameters

**opts** `TurnInit = \{\}`

See [`TurnInit`](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/interfaces/turninit).

## Returns

[`Turn`](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/interfaces/turn)

## Examples

```ts twoslash theme={"system"}
// @noErrors
weave.startTurn();
```

```ts twoslash theme={"system"}
// @noErrors
weave.startTurn({
  agentId: 'research-bot-prod',
  agentName: 'research-bot',
  agentDescription: 'Looks up facts on Wikipedia.',
  agentVersion: '1.4.2',
  model: 'gpt-4o',
  userMessage: 'What is the weather in Tokyo?',
  systemInstructions: ['You are a helpful weather bot.'],
  startTime: new Date('2026-05-29T10:00:00.000Z'),
});
```
