> ## Documentation Index
> Fetch the complete documentation index at: https://docs.coreweave.com/llms.txt
> Use this file to discover all available pages before exploring further.

# File Content



## OpenAPI

````yaml products/wandb/weave/reference/service-api/openapi.json POST /file/content
openapi: 3.1.0
info:
  title: FastAPI
  version: 0.1.0
servers: []
security: []
paths:
  /file/content:
    post:
      tags:
        - Files
      summary: File Content
      operationId: file_content_file_content_post
      requestBody:
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/FileContentReadReq'
        required: true
      responses:
        '200':
          description: Successful Response
          content:
            application/json:
              schema: {}
        '422':
          description: Validation Error
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/HTTPValidationError'
components:
  schemas:
    FileContentReadReq:
      properties:
        project_id:
          type: string
          title: Project Id
        digest:
          type: string
          title: Digest
      type: object
      required:
        - project_id
        - digest
      title: FileContentReadReq
    HTTPValidationError:
      properties:
        detail:
          items:
            $ref: '#/components/schemas/ValidationError'
          type: array
          title: Detail
      type: object
      title: HTTPValidationError
    ValidationError:
      properties:
        loc:
          items:
            anyOf:
              - type: string
              - type: integer
          type: array
          title: Location
        msg:
          type: string
          title: Message
        type:
          type: string
          title: Error Type
        input:
          title: Input
        ctx:
          type: object
          title: Context
      type: object
      required:
        - loc
        - msg
        - type
      title: ValidationError

````