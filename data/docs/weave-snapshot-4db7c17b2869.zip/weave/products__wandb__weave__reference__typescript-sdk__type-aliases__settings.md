> ## Documentation Index
> Fetch the complete documentation index at: https://docs.coreweave.com/llms.txt
> Use this file to discover all available pages before exploring further.

# Settings

> TypeScript SDK reference

> **Settings** = `object`

[GitHub source](https://github.com/wandb/weave/blob/7c9efdc9fe05ffcaf2430dd652ef9bc5b3ffdfaa/sdks/node/src/settings.ts#L6)

## Properties

### attributes

> `readonly` **attributes**: `Record`\<`string`, `any`>

A map of attributes applied to every trace produced by this client.

***

### genai

> `readonly` **genai**: `object`

#### batchOptions

> `optional` **batchOptions**: `BufferConfig`

`BatchSpanProcessor` configuration. Ignored unless `spanProcessor === 'batch'`.

#### spanProcessor

> `optional` **spanProcessor**: `"batch"` | `"simple"` | `SpanProcessor`

How GenAI spans are exported.

* `'batch'` (default): `BatchSpanProcessor`, suitable for production
  agents and long-lived processes.
* `'simple'`: `SimpleSpanProcessor`, one HTTP POST per span. Useful for
  tests and short-lived CLIs where deterministic flush matters more than
  throughput.
* `SpanProcessor` instance: a user-supplied processor. The caller owns
  its lifecycle; the Weave OTLP exporter targeting `/agents/otel/v1/traces`
  is not used.

***

### printCallLink

> `readonly` **printCallLink**: `boolean`

Prints links in terminal to Weave UI for ops.

#### Default

`true`

***

### useCallsComplete

> **useCallsComplete**: `boolean`

Sends finished calls to the `calls/complete` endpoint (start+end paired
client-side) instead of the legacy `call/upsert_batch` path.

#### Default

`true`

***

### useOTelV2

> **useOTelV2**: `boolean`

Routes OTel-capable integrations through their OTel variant.

#### Default

`true`
