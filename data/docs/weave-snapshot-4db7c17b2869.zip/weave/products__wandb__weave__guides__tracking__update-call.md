> ## Documentation Index
> Fetch the complete documentation index at: https://docs.coreweave.com/llms.txt
> Use this file to discover all available pages before exploring further.

# Update and delete Calls

> Modify display names, add feedback, and delete Calls in Weave

This page describes how to modify Calls in Weave after they've been created. Most Call properties are immutable after creation, but Weave supports the following mutations:

* [Set display name](#set-display-name)
* [Add feedback](#add-feedback)
* [Delete a Call](#delete-a-call)

You can perform all of these mutations from the UI by navigating to the Call detail page. To update a Call in the web app:

1. Navigate to [Forge](https://forge.coreweave.com/wandb) and select your project.
2. In the Weave project sidebar, click **Traces**.
3. Find the Call you want to view in the table.
4. Click the Call to open its details page.
5. Click the **Feedback** tab in the Call detail's tab bar.

From the Call detail page, you can edit the display name of the Call, add feedback, or delete the Call.

![Weave Traces page excerpt of a selected Call details panel showing how you can rename or delete a Call](https://mintcdn.com/coreweave-dbfa0e8d/3Dv_sw2eg8feUJlx/products/wandb/weave/_media/call_edit_screenshot.png?fit=max\&auto=format\&n=3Dv_sw2eg8feUJlx\&q=85\&s=2962874faea65df3511e1c968e08c5e4)

## Set display name

**Python**

To set the display name of a Call, use the [`Call.set_display_name()`](https://docs.coreweave.com/products/wandb/weave/reference/python-sdk/trace/weave_client#method-set-display-name) method.

```python lines theme={"system"}
import weave

# Initialize the client
client = weave.init("your-project-name")

# Get a specific Call by its ID
call = client.get_call("call-uuid-here")

# Set the display name of the Call
call.set_display_name("My Custom Display Name")
```

**TypeScript**

To set the display name of a Call, use [`client.updateCall`](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/interfaces/weaveclient#updatecall) to update by call ID directly:

```typescript twoslash lines theme={"system"}
// @noErrors
import * as weave from 'weave'

// Initialize the client
const client = await weave.init('your-project-name')

// Update the display name of a Call by its ID
await client.updateCall('call-uuid-here', 'My Custom Display Name')
```

**HTTP API**

To set the display name of a Call using the Service API, make a request to the [`/call/update`](https://docs.coreweave.com/products/wandb/weave/reference/service-api/calls/call-update) endpoint.

```bash lines theme={"system"}
curl -L 'https://trace.wandb.ai/call/update' \
-H 'Content-Type: application/json' \
-H 'Accept: application/json' \
-d '{
    "project_id": "string",
    "call_id": "string",
    "display_name": "string",
}'
```

You can also [set a Call's display name at execution](https://docs.coreweave.com/products/wandb/weave/guides/tracking/get-call-object.md).

## Add feedback

For more information, see [Collect feedback and use annotations](https://docs.coreweave.com/products/wandb/weave/guides/tracking/feedback.md).

## Delete a Call

**Python**

To delete a Call using the Python API, use the [`Call.delete`](https://docs.coreweave.com/products/wandb/weave/reference/python-sdk/trace/weave_client#method-delete) method.

```python lines theme={"system"}
import weave

# Initialize the client
client = weave.init("your-project-name")

# Get a specific Call by its ID
call = client.get_call("call-uuid-here")

# Delete the Call
call.delete()
```

**TypeScript**

```plaintext lines theme={"system"}
This feature is not available in the TypeScript SDK yet.
```

**HTTP API**

To delete a Call using the Service API, make a request to the [`/calls/delete`](https://docs.coreweave.com/products/wandb/weave/reference/service-api/calls/calls-delete) endpoint.

```bash lines theme={"system"}
curl -L 'https://trace.wandb.ai/calls/delete' \
-H 'Content-Type: application/json' \
-H 'Accept: application/json' \
-d '{
    "project_id": "string",
    "call_ids": [
        "string"
    ],
}'
```

## Delete multiple Calls

**Python**

To delete batches of Calls using the Python API, pass a list of Call IDs to `delete_calls()`.

* You can delete a maximum of `1000` Calls at a time.
* Deleting a Call also deletes all of its children.

```python lines theme={"system"}
import weave

# Initialize the client
client = weave.init("my-project")

# Get all Calls from client
all_calls = client.get_calls()

# Get list of first 1000 Call objects
first_1000_calls = all_calls[:1000]

# Get list of first 1000 Call IDs
first_1000_calls_ids = [c.id for c in first_1000_calls]

# Delete first 1000 Calls by ID
client.delete_calls(call_ids=first_1000_calls_ids)
```

**TypeScript**

```plaintext lines theme={"system"}
This feature is not available in the TypeScript SDK yet.
```
