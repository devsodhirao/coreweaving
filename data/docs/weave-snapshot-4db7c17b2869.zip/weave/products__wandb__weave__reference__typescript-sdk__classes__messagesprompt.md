> ## Documentation Index
> Fetch the complete documentation index at: https://docs.coreweave.com/llms.txt
> Use this file to discover all available pages before exploring further.

# MessagesPrompt

> TypeScript SDK reference

[GitHub source](https://github.com/wandb/weave/blob/7c9efdc9fe05ffcaf2430dd652ef9bc5b3ffdfaa/sdks/node/src/prompt.ts#L43)

## Extends

* `Prompt`

## Constructor

> **new MessagesPrompt**(`parameters`): `MessagesPrompt`

### Parameters

**parameters** `object` *required*

**properties**

**description** `string`

**messages** `Record\<string, any\>[]` *required*

**name** `string`

### Returns

`MessagesPrompt`

### Overrides

`Prompt.constructor`

## Properties

### \_\_savedRef

> `optional` **\_\_savedRef**: [`ObjectRef`](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/classes/objectref) | `Promise`\<[`ObjectRef`](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/classes/objectref)>

#### Inherited from

`Prompt.__savedRef`

***

### messages

> **messages**: `Record`\<`string`, `any`>\[]

## Accessors

### description

#### Get Signature

> **get** **description**(): `string` | `undefined`

##### Returns

`string` | `undefined`

#### Inherited from

`Prompt.description`

***

### name

#### Get Signature

> **get** **name**(): `string`

##### Returns

`string`

#### Inherited from

`Prompt.name`

## Methods

### format()

> **format**(`values?`): `Record`\<`string`, `any`>\[]

#### Parameters

**values** `Record\<string, any\> = \{\}`

#### Returns

`Record`\<`string`, `any`>\[]

***

### saveAttrs()

> **saveAttrs**(): `object`

#### Returns

`object`

#### Inherited from

`Prompt.saveAttrs`

***

### get()

> `static` **get**(`client`, `uri`): `Promise`\<`MessagesPrompt`>

#### Parameters

**client** `WeaveClient` *required*

See [`WeaveClient`](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/interfaces/weaveclient).

**uri** `string` *required*

#### Returns

`Promise`\<`MessagesPrompt`>
