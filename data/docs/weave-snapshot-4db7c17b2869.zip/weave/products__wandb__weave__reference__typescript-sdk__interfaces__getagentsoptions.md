> ## Documentation Index
> Fetch the complete documentation index at: https://docs.coreweave.com/llms.txt
> Use this file to discover all available pages before exploring further.

# GetAgentsOptions

> TypeScript SDK reference

[GitHub source](https://github.com/wandb/weave/blob/7c9efdc9fe05ffcaf2430dd652ef9bc5b3ffdfaa/sdks/node/src/weaveClient.ts#L142)

Options for [WeaveClient.getAgents](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/interfaces/weaveclient.md#getagents).

## Properties

### agentName

> `optional` **agentName**: `string`

***

### limit

> `optional` **limit**: `number`

***

### offset

> `optional` **offset**: `number`

***

### sortBy

> `optional` **sortBy**: [`SortBy`](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/interfaces/sortby)\[]
