> ## Documentation Index
> Fetch the complete documentation index at: https://docs.coreweave.com/llms.txt
> Use this file to discover all available pages before exploring further.

# endLLM

> TypeScript SDK reference

```ts theme={"system"}
endLLM(opts?: object): void
```

[GitHub source](https://github.com/wandb/weave/blob/7c9efdc9fe05ffcaf2430dd652ef9bc5b3ffdfaa/sdks/node/src/genai/api.ts#L202)

End the current LLM. No-op if no LLM is active.

## Parameters

**opts** `object`

**properties**

**endTime** `TimeInput`

**error** `Error`

## Returns

`void`

## Examples

```ts twoslash theme={"system"}
// @noErrors
weave.endLLM();
```

```ts twoslash theme={"system"}
// @noErrors
weave.endLLM({endTime: new Date('2026-05-29T10:00:00.800Z')});
```

```ts twoslash theme={"system"}
// @noErrors
weave.endLLM({error: new Error('llm call failed')});
```
