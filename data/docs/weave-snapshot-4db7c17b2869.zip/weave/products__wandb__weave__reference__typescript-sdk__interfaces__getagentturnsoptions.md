> ## Documentation Index
> Fetch the complete documentation index at: https://docs.coreweave.com/llms.txt
> Use this file to discover all available pages before exploring further.

# GetAgentTurnsOptions

> TypeScript SDK reference

[GitHub source](https://github.com/wandb/weave/blob/7c9efdc9fe05ffcaf2430dd652ef9bc5b3ffdfaa/sdks/node/src/weaveClient.ts#L264)

Options for [WeaveClient.getAgentTurns](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/interfaces/weaveclient.md#getagentturns).

## Properties

### conversationId

> **conversationId**: `string`

***

### includeFeedback

> `optional` **includeFeedback**: `boolean`

***

### limit

> `optional` **limit**: `number`

#### Min

0

#### Max

50

#### Default

```ts twoslash theme={"system"}
// @noErrors
50
```

***

### offset

> `optional` **offset**: `number`

#### Min

0

#### Default

```ts twoslash theme={"system"}
// @noErrors
0
```
