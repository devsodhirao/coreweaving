> ## Documentation Index
> Fetch the complete documentation index at: https://docs.coreweave.com/llms.txt
> Use this file to discover all available pages before exploring further.

# Rescore Evaluation

> Rescore an existing evaluation run with different scorer(s).

Applies the provided scorer(s) to the predictions from source_evaluation_run_id
and returns a new evaluation_run_id. Original prediction call IDs are preserved.



## OpenAPI

````yaml products/wandb/weave/reference/service-api/openapi.json POST /evaluations/rescore
openapi: 3.1.0
info:
  title: FastAPI
  version: 0.1.0
servers: []
security: []
paths:
  /evaluations/rescore:
    post:
      tags:
        - Evaluations
      summary: Rescore Evaluation
      description: >-
        Rescore an existing evaluation run with different scorer(s).


        Applies the provided scorer(s) to the predictions from
        source_evaluation_run_id

        and returns a new evaluation_run_id. Original prediction call IDs are
        preserved.
      operationId: rescore_evaluation_evaluations_rescore_post
      requestBody:
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/RescoreReq'
        required: true
      responses:
        '200':
          description: Successful Response
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/RescoreRes'
        '422':
          description: Validation Error
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/HTTPValidationError'
components:
  schemas:
    RescoreReq:
      properties:
        source_evaluation_run_id:
          type: string
          title: Source Evaluation Run Id
          description: The evaluation run whose predictions will be rescored
        scorer_refs:
          items:
            type: string
          type: array
          minItems: 1
          title: Scorer Refs
          description: Scorer references (weave:// URIs) to apply; must be non-empty
        project_id:
          type: string
          title: Project Id
        wb_user_id:
          anyOf:
            - type: string
            - type: 'null'
          title: Wb User Id
          description: Do not set directly. Server will automatically populate this field.
      type: object
      required:
        - source_evaluation_run_id
        - scorer_refs
        - project_id
      title: RescoreReq
      description: Full rescore request including server-set fields.
    RescoreRes:
      properties:
        call_id:
          type: string
          title: Call Id
          description: Call ID for /evaluations/status polling
        evaluation_run_id:
          type: string
          title: Evaluation Run Id
          description: The newly created EvaluationRun ID
      type: object
      required:
        - call_id
        - evaluation_run_id
      title: RescoreRes
      description: Response for a rescore request.
    HTTPValidationError:
      properties:
        detail:
          items:
            $ref: '#/components/schemas/ValidationError'
          type: array
          title: Detail
      type: object
      title: HTTPValidationError
    ValidationError:
      properties:
        loc:
          items:
            anyOf:
              - type: string
              - type: integer
          type: array
          title: Location
        msg:
          type: string
          title: Message
        type:
          type: string
          title: Error Type
        input:
          title: Input
        ctx:
          type: object
          title: Context
      type: object
      required:
        - loc
        - msg
        - type
      title: ValidationError

````