> ## Documentation Index
> Fetch the complete documentation index at: https://docs.coreweave.com/llms.txt
> Use this file to discover all available pages before exploring further.

# Understand Ops, Calls, and Traces

> Learn how Ops, Calls, and Traces create the foundation of Weave's tracing system.

Weave's tracing system is built on four related concepts: Ops, Calls, Traces, and Threads. This page defines each concept and explains how they relate to one another, so you can interpret what Weave captures when you instrument and run your application.

## Ops

An **Op** is a versioned, tracked function. When you decorate a function with `@weave.op()` (Python) or wrap it with `weave.op()` (TypeScript), Weave automatically captures its code, inputs, outputs, and execution metadata. Ops are the building blocks of tracing, evaluation scorers, and any tracked computation.

```python Python theme={"system"}
    @weave.op
    async def my_function(){
      ...  }
```

```typescript twoslash TypeScript theme={"system"}
// @noErrors
function myFunction() {
    ...
}

const myFunctionOp = weave.op(myFunction)
```

## Calls

A **Call** is a logged execution of an Op. Every time an Op runs, Weave creates a Call that captures:

* Input arguments
* Output value
* Timing and latency
* Parent-child relationships (for nested calls)
* Any errors that occur

Calls show up as **Traces** in the Weights & Biases UI and provide the data for debugging, analysis, and evaluation. For the full Call object structure and properties, see the [Call schema reference](https://docs.coreweave.com/products/wandb/weave/guides/tracking/call-schema-reference.md).

Calls are similar to spans in the [OpenTelemetry](https://opentelemetry.io) data model. A Call can:

* Belong to a Trace, a collection of Calls in the same execution context.
* Have parent and child Calls, forming a tree structure.

## Traces

Traces are full trees of Calls that share the same execution context. Each Trace contains an ID (`trace_id`) you can use to retrieve the entire tree of Calls. If you retrieve Call information using the Call's ID, Weave returns data about the specified Call only, and none of its child Calls.

## Threads

Threads are collections of Traces related to a single session or conversation. You can use Threads to analyze or score the entire conversation instead of individual Calls.

The following diagram illustrates the relationships between Threads, Traces, and Calls:

```text theme={"system"}
Thread: "session-abc"
  ├── Turn 1 (trace_id: aaa) -> user says "Hi"
  │     ├── LLM call
  │     └── format response
  ├── Turn 2 (trace_id: bbb) -> user says "What is the capital of France?"
  │     ├── RAG retrieval
  │     ├── LLM call
  │     └── format response
  └── Turn 3 (trace_id: ccc) -> user says "Thanks"
        └── LLM call
```
