> ## Documentation Index
> Fetch the complete documentation index at: https://docs.coreweave.com/llms.txt
> Use this file to discover all available pages before exploring further.

# File Create



## OpenAPI

````yaml products/wandb/weave/reference/service-api/openapi.json POST /file/create
openapi: 3.1.0
info:
  title: FastAPI
  version: 0.1.0
servers: []
security: []
paths:
  /file/create:
    post:
      tags:
        - Files
      summary: File Create
      operationId: file_create_file_create_post
      requestBody:
        content:
          multipart/form-data:
            schema:
              $ref: '#/components/schemas/Body_file_create_file_create_post'
        required: true
      responses:
        '200':
          description: Successful Response
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/FileCreateRes'
        '422':
          description: Validation Error
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/HTTPValidationError'
components:
  schemas:
    Body_file_create_file_create_post:
      properties:
        project_id:
          type: string
          title: Project Id
        file:
          type: string
          contentMediaType: application/octet-stream
          title: File
        expected_digest:
          anyOf:
            - type: string
            - type: 'null'
          title: Expected Digest
      type: object
      required:
        - project_id
        - file
      title: Body_file_create_file_create_post
    FileCreateRes:
      properties:
        digest:
          type: string
          title: Digest
      type: object
      required:
        - digest
      title: FileCreateRes
    HTTPValidationError:
      properties:
        detail:
          items:
            $ref: '#/components/schemas/ValidationError'
          type: array
          title: Detail
      type: object
      title: HTTPValidationError
    ValidationError:
      properties:
        loc:
          items:
            anyOf:
              - type: string
              - type: integer
          type: array
          title: Location
        msg:
          type: string
          title: Message
        type:
          type: string
          title: Error Type
        input:
          title: Input
        ctx:
          type: object
          title: Context
      type: object
      required:
        - loc
        - msg
        - type
      title: ValidationError

````