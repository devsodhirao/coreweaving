> ## Documentation Index
> Fetch the complete documentation index at: https://docs.coreweave.com/llms.txt
> Use this file to discover all available pages before exploring further.

# ScoreLogger

> TypeScript SDK reference

[GitHub source](https://github.com/wandb/weave/blob/7c9efdc9fe05ffcaf2430dd652ef9bc5b3ffdfaa/sdks/node/src/evaluationLogger.ts#L330)

ScoreLogger manages scoring for a single prediction.
Returned from EvaluationLogger.logPrediction().

## Example

```ts twoslash theme={"system"}
// @noErrors
const pred = await ev.logPrediction(example, output);
await pred.logScore("accuracy", 0.95);
await pred.logScore("relevance", 0.8);
await pred.finish(); // Finalizes the prediction
```

## Constructor

> **new ScoreLogger**(`evalLogger`): `ScoreLogger`

### Parameters

**evalLogger** `EvaluationLogger` *required*

See [`EvaluationLogger`](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/classes/evaluationlogger).

### Returns

`ScoreLogger`

## Accessors

### isFinishCalled

#### Get Signature

> **get** **isFinishCalled**(): `boolean`

Check if finish() has been called.
Used by EvaluationLogger to detect unfinished predictions.

##### Returns

`boolean`

## Methods

### finish()

> **finish**(): `Promise`\<`void`>

Finish the scoring process for the prediction.
Finalizes the predict\_and\_score call with accumulated scores.
Updates incremental aggregates and frees memory.

#### Returns

`Promise`\<`void`>

***

### logScore()

> **logScore**(`scorerName`, `score`): `Promise`\<`void`>

Log a score for this prediction.
Creates a scorer call as a child of predict\_and\_score.

#### Parameters

**scorerName** `string` *required*

Name of the scorer (e.g., "accuracy", "f1\_score")

**score** `any` *required*

The score value

#### Returns

`Promise`\<`void`>
