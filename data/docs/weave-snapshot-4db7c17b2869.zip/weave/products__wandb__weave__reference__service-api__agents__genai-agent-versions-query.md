> ## Documentation Index
> Fetch the complete documentation index at: https://docs.coreweave.com/llms.txt
> Use this file to discover all available pages before exploring further.

# GenAI Agent Versions Query



## OpenAPI

````yaml products/wandb/weave/reference/service-api/openapi.json POST /agents/agent-versions/query
openapi: 3.1.0
info:
  title: FastAPI
  version: 0.1.0
servers: []
security: []
paths:
  /agents/agent-versions/query:
    post:
      tags:
        - Agents
      summary: Genai Agent Versions Query
      operationId: genai_agent_versions_query_agents_agent_versions_query_post
      requestBody:
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/AgentVersionsQueryReq'
        required: true
      responses:
        '200':
          description: Successful Response
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/AgentVersionsQueryRes'
        '422':
          description: Validation Error
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/HTTPValidationError'
components:
  schemas:
    AgentVersionsQueryReq:
      properties:
        project_id:
          type: string
          title: Project Id
        agent_name:
          type: string
          title: Agent Name
        sort_by:
          anyOf:
            - items:
                $ref: '#/components/schemas/AgentSortBy'
              type: array
            - type: 'null'
          title: Sort By
        limit:
          type: integer
          maximum: 10000
          minimum: 0
          title: Limit
          default: 100
        offset:
          type: integer
          minimum: 0
          title: Offset
          default: 0
        include_costs:
          type: boolean
          title: Include Costs
          default: false
      type: object
      required:
        - project_id
        - agent_name
      title: AgentVersionsQueryReq
      description: Request to list versions for an agent.
    AgentVersionsQueryRes:
      properties:
        versions:
          items:
            $ref: '#/components/schemas/AgentVersionSchema'
          type: array
          title: Versions
        total_count:
          type: integer
          title: Total Count
          default: 0
      type: object
      required:
        - versions
        - total_count
      title: AgentVersionsQueryRes
      description: Response containing agent version stats.
    HTTPValidationError:
      properties:
        detail:
          items:
            $ref: '#/components/schemas/ValidationError'
          type: array
          title: Detail
      type: object
      title: HTTPValidationError
    AgentSortBy:
      properties:
        field:
          type: string
          title: Field
        direction:
          type: string
          enum:
            - asc
            - desc
          title: Direction
          default: desc
      type: object
      required:
        - field
      title: AgentSortBy
      description: Sort specification for agent query endpoints.
    AgentVersionSchema:
      properties:
        project_id:
          type: string
          title: Project Id
        agent_name:
          type: string
          title: Agent Name
        invocation_count:
          type: integer
          title: Invocation Count
        span_count:
          type: integer
          title: Span Count
        total_input_tokens:
          type: integer
          title: Total Input Tokens
        total_output_tokens:
          type: integer
          title: Total Output Tokens
        total_duration_ms:
          type: integer
          title: Total Duration Ms
        error_count:
          type: integer
          title: Error Count
        first_seen:
          anyOf:
            - type: string
              format: date-time
            - type: 'null'
          title: First Seen
        last_seen:
          anyOf:
            - type: string
              format: date-time
            - type: 'null'
          title: Last Seen
        total_cost_usd:
          anyOf:
            - type: number
            - type: 'null'
          title: Total Cost Usd
        agent_version:
          type: string
          title: Agent Version
      type: object
      required:
        - project_id
        - agent_name
        - invocation_count
        - span_count
        - total_input_tokens
        - total_output_tokens
        - total_duration_ms
        - error_count
        - first_seen
        - last_seen
        - total_cost_usd
        - agent_version
      title: AgentVersionSchema
      description: Aggregated per-version stats from the agent_versions AMT.
    ValidationError:
      properties:
        loc:
          items:
            anyOf:
              - type: string
              - type: integer
          type: array
          title: Location
        msg:
          type: string
          title: Message
        type:
          type: string
          title: Error Type
        input:
          title: Input
        ctx:
          type: object
          title: Context
      type: object
      required:
        - loc
        - msg
        - type
      title: ValidationError

````