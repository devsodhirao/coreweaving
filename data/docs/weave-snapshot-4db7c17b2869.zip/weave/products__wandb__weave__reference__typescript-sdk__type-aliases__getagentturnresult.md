> ## Documentation Index
> Fetch the complete documentation index at: https://docs.coreweave.com/llms.txt
> Use this file to discover all available pages before exploring further.

# GetAgentTurnResult

> TypeScript SDK reference

> **GetAgentTurnResult** = [`AgentTurn`](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/type-aliases/agentturn)

[GitHub source](https://github.com/wandb/weave/blob/7c9efdc9fe05ffcaf2430dd652ef9bc5b3ffdfaa/sdks/node/src/weaveClient.ts#L259)

Result shape returned by [WeaveClient.getAgentTurn](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/interfaces/weaveclient.md#getagentturn).
