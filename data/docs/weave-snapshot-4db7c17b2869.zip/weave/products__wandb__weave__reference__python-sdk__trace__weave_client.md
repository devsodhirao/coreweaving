> ## Documentation Index
> Fetch the complete documentation index at: https://docs.coreweave.com/llms.txt
> Use this file to discover all available pages before exploring further.

# weave_client

> Python SDK reference for weave.trace.weave_client

# API Overview

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace/weave_client.py#L217)

## <kbd>class</kbd> `CrossProjectRefError`

Raised when client-side digest computation encounters a ref to a different project that cannot be resolved to an internal ID.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace/weave_client.py#L3433)

## <kbd>class</kbd> `FlushStatus`

Status information about the current flush operation.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace/weave_client.py#L211)

## <kbd>class</kbd> `NoInternalProjectIDError`

Raised when client-side digest computation cannot proceed because no internal project ID has been resolved yet.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace/weave_client.py#L3423)

## <kbd>class</kbd> `PendingJobCounts`

Counts of pending jobs for each type.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace/weave_client.py#L420)

## <kbd>class</kbd> `WeaveClient`

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace/weave_client.py#L445)

### <kbd>method</kbd> `__init__`

```python theme={"system"}
__init__(
    entity: 'str',
    project: 'str',
    server: 'TraceServerClientInterface',
    ensure_project_exists: 'bool' = True,
    postprocess_inputs: 'PostprocessInputsFunc | None' = None,
    postprocess_output: 'PostprocessOutputFunc | None' = None,
    attributes: 'dict[str, Any] | None' = None,
    api_key: 'str | None' = None
)
```

***

#### <kbd>property</kbd> num\_outstanding\_jobs

Returns the total number of pending jobs across all executors and the server.

This property can be used to check the progress of background tasks without blocking the main thread.

**Returns:**

* **`int`**:  The total number of pending jobs

***

#### <kbd>property</kbd> project\_id

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/telemetry/trace_sentry.py#L1312)

### <kbd>method</kbd> `add_calls_to_annotation_queue`

```python theme={"system"}
add_calls_to_annotation_queue(
    queue_id: 'str',
    call_ids: 'list[str]',
    display_fields: 'list[str]'
) → AnnotationQueueAddCallsRes
```

Add calls to an annotation queue.

**Args:**

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace/weave_client.py#L2253)

### <kbd>method</kbd> `add_cost`

```python theme={"system"}
add_cost(
    llm_id: 'str',
    prompt_token_cost: 'float',
    completion_token_cost: 'float',
    effective_date: 'datetime | None' = None,
    prompt_token_cost_unit: 'str | None' = 'USD',
    completion_token_cost_unit: 'str | None' = 'USD',
    provider_id: 'str | None' = 'default'
) → CostCreateRes
```

Add a cost to the current project.

* **`queue_id`**: Annotation queue ID.
* **`call_ids`**: Call IDs to add to the queue.
* **`display_fields`**: JSON paths to show reviewers, such as  `inputs.prompt` or `output.text`.

**Examples:**

```python theme={"system"}
client.add_cost(llm_id="my_expensive_custom_model", prompt_token_cost=1, completion_token_cost=2)
client.add_cost(llm_id="my_expensive_custom_model", prompt_token_cost=500, completion_token_cost=1000, effective_date=datetime(1998, 10, 3))
```

**Args:**

* **`llm_id`**: The ID of the LLM. eg "gpt-4o-mini-2024-07-18"
* **`prompt_token_cost`**: The cost per prompt token. eg .0005
* **`completion_token_cost`**: The cost per completion token. eg .0015
* **`effective_date`**: Defaults to the current date. A datetime.datetime object.
* **`provider_id`**: The provider of the LLM. Defaults to "default". eg "openai"
* **`prompt_token_cost_unit`**: The unit of the cost for the prompt tokens. Defaults to "USD". (Currently unused, will be used in the future to specify the currency type for the cost eg "tokens" or "time")
* **`completion_token_cost_unit`**: The unit of the cost for the completion tokens. Defaults to "USD". (Currently unused, will be used in the future to specify the currency type for the cost eg "tokens" or "time")

**Returns:**
A CostCreateRes object. Which has one field called a list of tuples called ids. Each tuple contains the llm\_id and the id of the created cost object.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/telemetry/trace_sentry.py#L1961)

### <kbd>method</kbd> `add_tags`

```python theme={"system"}
add_tags(obj_ref: 'ObjectRef | str', tags: 'list[str]') → None
```

Add tags to an object version.

**Args:**

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace/weave_client.py#L1803)

### <kbd>method</kbd> `clear_wandb_run_context`

```python theme={"system"}
clear_wandb_run_context() → None
```

Clear wandb run context override.

After calling this, calls will fall back to using the global wandb.run (if available) for run\_id and step information.

* **`obj_ref`**: Reference to the object version, either an ObjectRef or a weave /// URI string.
* **`tags`**: List of tag strings to add.

**Examples:**

```python theme={"system"}
client = weave.init("my-project")
client.set_wandb_run_context(run_id="my-run-id", step=5)
# ... make some calls ...
client.clear_wandb_run_context()
# Now calls will use global wandb.run again
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/telemetry/trace_sentry.py#L1225)

### <kbd>method</kbd> `create_annotation_queue`

```python theme={"system"}
create_annotation_queue(
    name: 'str',
    scorer_refs: 'list[str]',
    description: 'str' = ''
) → str
```

Create an annotation queue for this project.

**Args:**

* **`name`**: Display name for the queue.
* **`scorer_refs`**: Weave refs for the scorers/annotation fields reviewers complete.
* **`description`**: Optional reviewer guidelines or queue description.

**Returns:**
The ID of the created annotation queue.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/telemetry/trace_sentry.py#L1374)

### <kbd>method</kbd> `create_call`

```python theme={"system"}
create_call(
    op: 'str | Op',
    inputs: 'dict[str, Any]',
    parent: 'Call | None' = None,
    attributes: 'dict[str, Any] | None' = None,
    display_name: 'str | Callable[[Call], str] | None' = None,
    use_stack: 'bool' = True,
    _call_id_override: 'str | None' = None,
    started_at: 'datetime | None' = None
) → Call
```

Create, log, and push a call onto the runtime stack.

**Args:**

* **`op`**: The operation producing the call, or the name of an anonymous operation.
* **`inputs`**: The inputs to the operation.
* **`parent`**: The parent call. If parent is not provided, the current run is used as the parent.
* **`display_name`**: The display name for the call. Defaults to None.
* **`attributes`**: The attributes for the call. Defaults to None.
* **`use_stack`**: Whether to push the call onto the runtime stack. Defaults to True.
* **`started_at`**: Override the call start time. If None, uses current time.

**Returns:**
The created Call object.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/telemetry/trace_sentry.py#L1879)

### <kbd>method</kbd> `delete_all_object_versions`

```python theme={"system"}
delete_all_object_versions(object_name: 'str') → int
```

Delete all versions of an object.

**Args:**

* **`object_name`**: The name of the object whose versions should be deleted.

**Returns:**
The number of versions deleted.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/telemetry/trace_sentry.py#L2143)

### <kbd>method</kbd> `delete_all_op_versions`

```python theme={"system"}
delete_all_op_versions(op_name: 'str') → int
```

Delete all versions of an op.

**Args:**

* **`op_name`**: The name of the op whose versions should be deleted.

**Returns:**
The number of versions deleted.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/telemetry/trace_sentry.py#L1304)

### <kbd>method</kbd> `delete_annotation_queue`

```python theme={"system"}
delete_annotation_queue(queue_id: 'str') → AnnotationQueueSchema
```

Soft-delete an annotation queue.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/telemetry/trace_sentry.py#L1844)

### <kbd>method</kbd> `delete_call`

```python theme={"system"}
delete_call(call: 'Call') → None
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/telemetry/trace_sentry.py#L1853)

### <kbd>method</kbd> `delete_calls`

```python theme={"system"}
delete_calls(call_ids: 'list[str]') → None
```

Delete calls by their IDs.

Deleting a call will also delete all of its children.

**Args:**

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/telemetry/trace_sentry.py#L1869)

### <kbd>method</kbd> `delete_object_version`

```python theme={"system"}
delete_object_version(object: 'ObjectRef') → None
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/telemetry/trace_sentry.py#L1898)

### <kbd>method</kbd> `delete_object_versions`

```python theme={"system"}
delete_object_versions(object_name: 'str', digests: 'list[str]') → int
```

Delete specific versions of an object.

* **`call_ids`**: A list of call IDs to delete. Ex: \["2F0193e107-8fcf-7630-b576-977cc3062e2e"]

**Args:**

* **`object_name`**: The name of the object whose versions should be deleted.
* **`digests`**: List of digests to delete. Can include aliases like "latest" or "v0".

**Returns:**
The number of versions deleted.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/telemetry/trace_sentry.py#L2133)

### <kbd>method</kbd> `delete_op_version`

```python theme={"system"}
delete_op_version(op: 'OpRef') → None
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/telemetry/trace_sentry.py#L1774)

### <kbd>method</kbd> `fail_call`

```python theme={"system"}
fail_call(call: 'Call', exception: 'BaseException') → None
```

Fail a call with an exception. This is a convenience method for finish\_call.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace/weave_client.py#L3229)

### <kbd>method</kbd> `finish`

```python theme={"system"}
finish(
    use_progress_bar: 'bool' = True,
    callback: 'Callable[[FlushStatus], None] | None' = None
) → None
```

Flushes all background tasks to ensure they are processed.

This method blocks until all currently enqueued jobs are processed, displaying a progress bar to show the status of the pending tasks. It ensures parallel processing during main thread execution and can improve performance when user code completes before data has been uploaded to the server.

**Args:**

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/telemetry/trace_sentry.py#L1600)

### <kbd>method</kbd> `finish_call`

```python theme={"system"}
finish_call(
    call: 'Call',
    output: 'Any' = None,
    exception: 'BaseException | None' = None,
    op: 'Op | None' = None,
    ended_at: 'datetime | None' = None
) → None
```

Finalize a call and persist its results.

Any values present in `call.summary` are deep-merged with computed summary statistics (e.g. usage and status counts) before being written to the database.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace/weave_client.py#L3267)

### <kbd>method</kbd> `flush`

```python theme={"system"}
flush() → None
```

Flushes background asynchronous tasks, safe to call multiple times.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/telemetry/trace_sentry.py#L568)

### <kbd>method</kbd> `get`

```python theme={"system"}
get(ref: 'ObjectRef', objectify: 'bool' = True) → Any
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/telemetry/trace_sentry.py#L1131)

### <kbd>method</kbd> `get_agent_custom_attributes`

```python theme={"system"}
get_agent_custom_attributes(
    query: 'Query | None' = None,
    started_after: 'datetime | None' = None,
    started_before: 'datetime | None' = None,
    limit: 'int' = 200,
    offset: 'int' = 0
) → AgentCustomAttrsSchemaRes
```

Discover typed custom-attribute keys on matching agent spans.

Useful for populating filter/column pickers: returns the custom attribute keys (and their value types) seen on the selected spans.

* **`use_progress_bar`**: Whether to display a progress bar during flush.  Set to False for environments where a progress bar  would not render well (e.g., CI environments).
* **`callback`**: Optional callback function that receives status updates.  Overrides use\_progress\_bar.

**Args:**

* **`query`**: A mongo-style filter expression to restrict the spans.
* **`started_after`**: Only consider spans started at/after this time.
* **`started_before`**: Only consider spans started before this time.
* **`limit`**: Maximum number of attribute keys to return.
* **`offset`**: Number of keys to skip (for pagination).

**Returns:**
An `AgentCustomAttrsSchemaRes` with `attributes` and `has_more`.

**Example:**

```python theme={"system"}
client = weave.init("entity/project")
resp = client.get_agent_custom_attributes()
for attr in resp.attributes:
     print(attr.key, attr.value_type, attr.span_count)
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/telemetry/trace_sentry.py#L1079)

### <kbd>method</kbd> `get_agent_span_stats`

```python theme={"system"}
get_agent_span_stats(
    start: 'datetime',
    metrics: 'list[AgentSpanStatsMetricSpec]',
    end: 'datetime | None' = None,
    query: 'Query | None' = None,
    group_by: 'list[AgentGroupByRef] | None' = None,
    granularity: 'int | None' = None,
    timezone: 'str' = 'UTC'
) → AgentSpanStatsRes
```

Compute chart-ready aggregations over agent spans.

Covers the common time-series / grouped-metric case. For numeric-bucket stats or other advanced options, call `server.agent_spans_stats` directly.

**Args:**

* **`start`**: Start of the time range (inclusive).
* **`metrics`**: One or more metrics to aggregate (e.g. token sums).
* **`end`**: End of the time range. Defaults to now when omitted.
* **`query`**: A mongo-style filter expression to restrict the spans.
* **`group_by`**: Span fields to group the aggregations by.
* **`granularity`**: Time-bucket width in seconds for time-series stats.
* **`timezone`**: IANA timezone used to align time buckets.

**Returns:**
An `AgentSpanStatsRes` with `columns` and `rows`.

**Example:**

```python theme={"system"}
client = weave.init("entity/project")
resp = client.get_agent_span_stats(start=start, metrics=metrics)
for row in resp.rows:
     print(row)
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/telemetry/trace_sentry.py#L943)

### <kbd>method</kbd> `get_agent_spans`

```python theme={"system"}
get_agent_spans(
    agent_name: 'str | None' = None,
    query: 'Query | None' = None,
    sort_by: 'list[AgentSortBy] | None' = None,
    limit: 'int | None' = None,
    offset: 'int | None' = None,
    page_size: 'int' = 100
) → AgentSpansIter
```

Query agent spans for this project, optionally filtered.

Returns a `PaginatedIterator` (like `get_calls`) that fetches pages as you consume it; `len(...)` reports the total span count.

**Args:**

* **`agent_name`**: If set, restrict results to this agent (a convenience  shortcut for a `query` on the `agent_name` field).
* **`query`**: A mongo-style filter expression. Combined with `agent_name`  via `$and` when both are provided.
* **`sort_by`**: Fields to sort the results by.
* **`limit`**: Maximum number of spans to yield. `None` yields all.
* **`offset`**: Number of spans to skip before yielding (for pagination).
* **`page_size`**: Number of spans fetched per request.

**Returns:**
A `PaginatedIterator` over `AgentSpanSchema`.

**Example:**

```python theme={"system"}
client = weave.init("entity/project")
for span in client.get_agent_spans(agent_name="my-agent"):
     print(span.span_id, span.span_name, span.input_tokens)
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/telemetry/trace_sentry.py#L1002)

### <kbd>method</kbd> `get_agent_turn`

```python theme={"system"}
get_agent_turn(
    trace_id: 'str',
    include_feedback: 'bool' = False
) → AgentTraceChatRes
```

Get the structured chat view (messages) for a single turn.

A turn corresponds to one trace.

**Args:**

* **`trace_id`**: The trace whose chat view to fetch.
* **`include_feedback`**: If true, include feedback on the messages.

**Returns:**
An `AgentTraceChatRes` with the ordered `messages` for the turn.

**Example:**

```python theme={"system"}
client = weave.init("entity/project")
resp = client.get_agent_turn(trace_id="...", include_feedback=True)
for message in resp.messages:
     print(message.type)
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/telemetry/trace_sentry.py#L1037)

### <kbd>method</kbd> `get_agent_turns`

```python theme={"system"}
get_agent_turns(
    conversation_id: 'str',
    limit: 'int' = 50,
    offset: 'int' = 0,
    include_feedback: 'bool' = False
) → AgentConversationChatRes
```

Get the multi-turn chat view for a conversation.

Each turn corresponds to one trace.

**Args:**

* **`conversation_id`**: The conversation whose turns to fetch.
* **`limit`**: Maximum number of turns to return.
* **`offset`**: Number of most-recent turns to skip (for pagination).
* **`include_feedback`**: If true, include feedback on the messages.

**Returns:**
An `AgentConversationChatRes` with the ordered `turns`.

**Example:**

```python theme={"system"}
client = weave.init("entity/project")
resp = client.get_agent_turns(conversation_id="...", limit=20)
for turn in resp.turns:
     for message in turn.messages:
         print(message.type)
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/telemetry/trace_sentry.py#L888)

### <kbd>method</kbd> `get_agent_versions`

```python theme={"system"}
get_agent_versions(
    agent_name: 'str',
    sort_by: 'list[AgentSortBy] | None' = None,
    limit: 'int | None' = None,
    offset: 'int | None' = None,
    page_size: 'int' = 100
) → AgentVersionsIter
```

List versions for a single agent, with aggregated stats.

Returns a `PaginatedIterator` (like `get_calls`) that fetches pages as you consume it; `len(...)` reports the total version count.

**Args:**

* **`agent_name`**: The agent whose versions to list.
* **`sort_by`**: Fields to sort the results by.
* **`limit`**: Maximum number of versions to yield. `None` yields all.
* **`offset`**: Number of versions to skip before yielding (for pagination).
* **`page_size`**: Number of versions fetched per request.

**Returns:**
A `PaginatedIterator` over `AgentVersionSchema`.

**Example:**

```python theme={"system"}
client = weave.init("entity/project")
for version in client.get_agent_versions(agent_name="my-agent"):
     print(version.agent_version, version.total_input_tokens)
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/telemetry/trace_sentry.py#L827)

### <kbd>method</kbd> `get_agents`

```python theme={"system"}
get_agents(
    agent_name: 'str | None' = None,
    sort_by: 'list[AgentSortBy] | None' = None,
    limit: 'int | None' = None,
    offset: 'int | None' = None,
    page_size: 'int' = 100
) → AgentsIter
```

List agents in this project with aggregated stats.

Returns a `PaginatedIterator` (like `get_calls`) that transparently fetches pages as you consume it; `len(...)` reports the total agent count, and indexing/slicing are supported.

**Args:**

* **`agent_name`**: If set, restrict results to this agent.
* **`sort_by`**: Fields to sort the results by.
* **`limit`**: Maximum number of agents to yield. `None` yields all.
* **`offset`**: Number of agents to skip before yielding (for pagination).
* **`page_size`**: Number of agents fetched per request.

**Returns:**
A `PaginatedIterator` over `AgentSchema`.

**Example:**

```python theme={"system"}
client = weave.init("entity/project")
for agent in client.get_agents(limit=20):
     print(agent.agent_name, agent.total_input_tokens)
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/telemetry/trace_sentry.py#L2090)

### <kbd>method</kbd> `get_aliases`

```python theme={"system"}
get_aliases(obj_ref: 'ObjectRef | str') → list[str]
```

Get aliases for an object version.

**Args:**

* **`obj_ref`**: Reference to the object version, either an ObjectRef or a weave /// URI string.

**Returns:**
List of alias strings. Includes the virtual "latest" alias if the object version is the latest.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/telemetry/trace_sentry.py#L1253)

### <kbd>method</kbd> `get_annotation_queue`

```python theme={"system"}
get_annotation_queue(queue_id: 'str') → AnnotationQueueSchema
```

Read a single annotation queue by ID.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/telemetry/trace_sentry.py#L1364)

### <kbd>method</kbd> `get_annotation_queue_stats`

```python theme={"system"}
get_annotation_queue_stats(
    queue_ids: 'list[str]'
) → list[AnnotationQueueStatsSchema]
```

Get item completion stats for annotation queues.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/telemetry/trace_sentry.py#L790)

### <kbd>method</kbd> `get_call`

```python theme={"system"}
get_call(
    call_id: 'str',
    include_costs: 'bool' = False,
    include_feedback: 'bool' = False,
    columns: 'list[str] | None' = None
) → WeaveObject
```

Get a single call by its ID.

**Args:**

* **`call_id`**: The ID of the call to get.
* **`include_costs`**: If true, cost info is included at summary.weave
* **`include_feedback`**: If true, feedback info is included at summary.weave.feedback
* **`columns`**: A list of columns to include in the response. If None,  all columns are included. Specifying fewer columns may be more performant. Some columns are always included  id, project\_id, trace\_id, op\_name, started\_at

**Returns:**
A call object.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/telemetry/trace_sentry.py#L707)

### <kbd>method</kbd> `get_calls`

```python theme={"system"}
get_calls(
    filter: 'CallsFilterLike | None' = None,
    limit: 'int | None' = None,
    offset: 'int | None' = None,
    sort_by: 'list[SortByLike] | None' = None,
    query: 'QueryLike | None' = None,
    include_costs: 'bool' = False,
    include_feedback: 'bool' = False,
    include_storage_size: 'bool' = False,
    include_total_storage_size: 'bool' = False,
    include_usernames: 'bool' = False,
    columns: 'list[str] | None' = None,
    expand_columns: 'list[str] | None' = None,
    return_expanded_column_values: 'bool' = True,
    scored_by: 'str | list[str] | None' = None,
    page_size: 'int' = 1000
) → CallsIter
```

Retrieve a list of traced calls (operations) for this project.

This method provides a powerful and flexible interface for querying trace data. It supports pagination, filtering, sorting, field projection, and scoring metadata, and can be used to power custom trace UIs or analysis tools.

Performance Tip: Specify `columns` and use `filter` or `query` to reduce result size.

**Args:**

* **`filter`**:  High-level filter for narrowing results by fields like `op_name`, `parent_ids`, etc.
* **`limit`**:  Maximum number of calls to return.
* **`offset`**:  Number of calls to skip before returning results (used for pagination).
* **`sort_by`**:  List of fields to sort the results by (e.g., `started_at desc`).
* **`query`**:  A mongo-like expression for advanced filtering. Not all Mongo operators are supported.
* **`include_costs`**:  If True, includes token/cost info in `summary.weave`.
* **`include_feedback`**:  If True, includes feedback in `summary.weave.feedback`.
* **`include_storage_size`**:  If True, includes the storage size for a call.
* **`include_total_storage_size`**:  If True, includes the total storage size for a trace.
* **`include_usernames`**:  If True, attempts to resolve each call's `wb_user_id` to a `wb_username`.
* **`columns`**:  List of fields to return per call. Reducing this can significantly improve performance.  (Some fields like `id`, `trace_id`, `op_name`, and `started_at` are always included.)
* **`scored_by`**:  Filter by one or more scorers (name or ref URI). Multiple scorers are AND-ed.
* **`page_size`**:  Number of calls fetched per page. Tune this for performance in large queries.

**Returns:**

* **`CallsIter`**:  An iterator over `Call` objects. Supports slicing, iteration, and `.to_pandas()`.

**Example:**

```python theme={"system"}
calls = client.get_calls(
     filter=CallsFilter(op_names=["my_op"]),
     columns=["inputs", "output", "summary"],
     limit=100,
)
for call in calls:
     print(call.inputs, call.output)
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace/weave_client.py#L633)

### <kbd>method</kbd> `get_evaluation`

```python theme={"system"}
get_evaluation(uri: 'str') → Evaluation
```

Retrieve a specific Evaluation object by its URI.

Evaluation URIs typically follow the format: `weave:///entity/project/object/Evaluation:version`

You can also get the evaluation by its "friendly" name: get\_evaluation("Evaluation:v1")

**Args:**

* **`uri`** (str):  The unique resource identifier of the evaluation to retrieve.

**Returns:**

* **`Evaluation`**:  The Evaluation object corresponding to the provided URI.

**Raises:**

* **`TypeError`**:  If the object at the URI is not an Evaluation instance.
* **`ValueError`**:  If the URI is invalid or the object cannot be found.

**Examples:**

```python theme={"system"}
client = weave.init("my-project")
evaluation = client.get_evaluation("weave:///entity/project/object/my-eval:v1")
print(evaluation.name)
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace/weave_client.py#L668)

### <kbd>method</kbd> `get_evaluations`

```python theme={"system"}
get_evaluations() → list[Evaluation]
```

Retrieve all Evaluation objects from the current project.

**Returns:**

* **`list[Evaluation]`**:  A list of all Evaluation objects in the current project.  Empty list if no evaluations are found or if all conversions fail.

**Examples:**

```python theme={"system"}
client = weave.init("my-project")
evaluations = client.get_evaluations()
print(f"Found {len(evaluations)} evaluations")
for eval in evaluations:
     print(f"Evaluation: {eval.name}")
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace/weave_client.py#L2162)

### <kbd>method</kbd> `get_feedback`

```python theme={"system"}
get_feedback(
    query: 'Query | str | None' = None,
    reaction: 'str | None' = None,
    offset: 'int' = 0,
    limit: 'int' = 100
) → FeedbackQuery
```

Query project for feedback.

**Examples:**

```python theme={"system"}
# Fetch a specific feedback object.
# Note that this still returns a collection, which is expected
# to contain zero or one item(s).
client.get_feedback("1B4082A3-4EDA-4BEB-BFEB-2D16ED59AA07")

# Find all feedback objects with a specific reaction.
client.get_feedback(reaction="👍", limit=10)

# Find all feedback objects with a specific feedback type with
# mongo-style query.
from weave.trace_server.interface.query import Query

query = Query(
    **{
        "$expr": {
            "$eq": [
                {"$getField": "feedback_type"},
                {"$literal": "wandb.reaction.1"},
            ],
        }
    }
)
client.get_feedback(query=query)
```

**Args:**

* **`query`**: A mongo-style query expression. For convenience, also accepts a feedback UUID string.
* **`reaction`**: For convenience, filter by a particular reaction emoji.
* **`offset`**: The offset to start fetching feedback objects from.
* **`limit`**: The maximum number of feedback objects to fetch.

**Returns:**
A FeedbackQuery object.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/telemetry/trace_sentry.py#L1999)

### <kbd>method</kbd> `get_tags`

```python theme={"system"}
get_tags(obj_ref: 'ObjectRef | str') → list[str]
```

Get tags for an object version.

**Args:**

* **`obj_ref`**: Reference to the object version, either an ObjectRef or a weave /// URI string.

**Returns:**
List of tag strings. Returns empty list if the object version has no tags.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/telemetry/trace_sentry.py#L2022)

### <kbd>method</kbd> `get_tags_and_aliases`

```python theme={"system"}
get_tags_and_aliases(obj_ref: 'ObjectRef | str') → tuple[list[str], list[str]]
```

Get both tags and aliases for an object version in a single call.

**Args:**

* **`obj_ref`**: Reference to the object version, either an ObjectRef or a weave /// URI string.

**Returns:**
A tuple of (tags, aliases). Each is a list of strings. Returns empty lists if the object version has no tags or aliases.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/telemetry/trace_sentry.py#L1925)

### <kbd>method</kbd> `link_prompt_to_registry`

```python theme={"system"}
link_prompt_to_registry(
    prompt: 'LinkablePrompt',
    target_path: 'str',
    aliases: 'Sequence[str] | None' = None
) → LinkAssetToRegistryRes
```

Link a published prompt version into the registry.

**Args:**

* **`prompt`**: A published prompt, an `ObjectRef`, or a fully qualified weave ///... URI string.
* **`target_path`**: Registry destination path in the format  `<registry_project>/<portfolio_name>`, for example  `wandb-registry-prompts/my-prompt-collection`.
* **`aliases`**: Optional aliases to attach to the created registry version.

**Returns:**

* **`LinkAssetToRegistryRes`**:  Parsed response from the registry-link endpoint.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/telemetry/trace_sentry.py#L2123)

### <kbd>method</kbd> `list_aliases`

```python theme={"system"}
list_aliases() → list[str]
```

List all distinct aliases in the project.

**Returns:**
List of all alias strings in the project.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/telemetry/trace_sentry.py#L1339)

### <kbd>method</kbd> `list_annotation_queue_items`

```python theme={"system"}
list_annotation_queue_items(
    queue_id: 'str',
    filter: 'AnnotationQueueItemsFilter | None' = None,
    sort_by: 'list[SortBy] | None' = None,
    limit: 'int | None' = None,
    offset: 'int | None' = None,
    include_position: 'bool' = False
) → list[AnnotationQueueItemSchema]
```

List calls assigned to an annotation queue.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/telemetry/trace_sentry.py#L1261)

### <kbd>method</kbd> `list_annotation_queues`

```python theme={"system"}
list_annotation_queues(
    name: 'str | None' = None,
    sort_by: 'list[SortBy] | None' = None,
    limit: 'int | None' = None,
    offset: 'int | None' = None
) → list[AnnotationQueueSchema]
```

List annotation queues for this project.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/telemetry/trace_sentry.py#L2113)

### <kbd>method</kbd> `list_tags`

```python theme={"system"}
list_tags() → list[str]
```

List all distinct tags in the project.

**Returns:**
List of all tag strings in the project.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace/weave_client.py#L2299)

### <kbd>method</kbd> `purge_costs`

```python theme={"system"}
purge_costs(ids: 'list[str] | str') → None
```

Purge costs from the current project.

**Examples:**

```python theme={"system"}
client.purge_costs([ids])
client.purge_costs(ids)
```

**Args:**

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace/weave_client.py#L2323)

### <kbd>method</kbd> `query_costs`

```python theme={"system"}
query_costs(
    query: 'Query | str | None' = None,
    llm_ids: 'list[str] | None' = None,
    offset: 'int' = 0,
    limit: 'int' = 100
) → list[CostQueryOutput]
```

Query project for costs.

* **`ids`**: The cost IDs to purge. Can be a single ID or a list of IDs.

**Examples:**

```python theme={"system"}
# Fetch a specific cost object.
# Note that this still returns a collection, which is expected
# to contain zero or one item(s).
client.query_costs("1B4082A3-4EDA-4BEB-BFEB-2D16ED59AA07")

# Find all cost objects with a specific reaction.
client.query_costs(llm_ids=["gpt-4o-mini-2024-07-18"], limit=10)
```

**Args:**

* **`query`**: A mongo-style query expression. For convenience, also accepts a cost UUID string.
* **`llm_ids`**: For convenience, filter for a set of llm\_ids.
* **`offset`**: The offset to start fetching cost objects from.
* **`limit`**: The maximum number of cost objects to fetch.

**Returns:**
A CostQuery object.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/telemetry/trace_sentry.py#L2069)

### <kbd>method</kbd> `remove_aliases`

```python theme={"system"}
remove_aliases(obj_ref: 'ObjectRef | str', alias: 'str | list[str]') → None
```

Remove one or more aliases from an object.

**Args:**

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/telemetry/trace_sentry.py#L1980)

### <kbd>method</kbd> `remove_tags`

```python theme={"system"}
remove_tags(obj_ref: 'ObjectRef | str', tags: 'list[str]') → None
```

Remove tags from an object version.

* **`obj_ref`**: Reference to the object, either an ObjectRef or a weave /// URI string (digest is not used since aliases are object-scoped).
* **`alias`**: An alias name or list of alias names to remove.

**Args:**

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/telemetry/trace_sentry.py#L539)

### <kbd>method</kbd> `save`

```python theme={"system"}
save(val: 'Any', name: 'str', branch: 'str' = 'latest') → Any
```

Do not call directly, use weave.publish() instead.

* **`obj_ref`**: Reference to the object version, either an ObjectRef or a weave /// URI string.
* **`tags`**: List of tag strings to remove.

**Args:**

* **`val`**: The object to save.
* **`name`**: The name to save the object under.
* **`branch`**: The branch to save the object under. Defaults to "latest".

**Returns:**
A deserialized version of the saved object.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/telemetry/trace_sentry.py#L1176)

### <kbd>method</kbd> `search_agents`

```python theme={"system"}
search_agents(
    query: 'str' = '',
    agent_name: 'str | None' = None,
    conversation_id: 'str | None' = None,
    trace_id: 'str | None' = None,
    limit: 'int' = 20,
    offset: 'int' = 0
) → AgentSearchRes
```

Search agent messages by content, grouped by conversation.

Searches message content (and/or the structured filters below) and returns matching conversations with their matched messages. An empty `query` turns this into structured retrieval over the filters.

**Args:**

* **`query`**: Substring to match in message content. Empty matches all.
* **`agent_name`**: Restrict to messages from this agent.
* **`conversation_id`**: Restrict to a single conversation.
* **`trace_id`**: Restrict to a single trace.
* **`limit`**: Maximum number of matching messages to consider.
* **`offset`**: Number of matches to skip (for pagination).

**Returns:**
An `AgentSearchRes` with `results` (matched conversations).

**Example:**

```python theme={"system"}
client = weave.init("entity/project")
resp = client.search_agents(query="timeout", agent_name="my-agent")
for conversation in resp.results:
     print(conversation.conversation_id, conversation.matched_messages)
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/telemetry/trace_sentry.py#L2047)

### <kbd>method</kbd> `set_aliases`

```python theme={"system"}
set_aliases(obj_ref: 'ObjectRef | str', alias: 'str | list[str]') → None
```

Set one or more aliases for an object version.

**Args:**

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace/weave_client.py#L1779)

### <kbd>method</kbd> `set_wandb_run_context`

```python theme={"system"}
set_wandb_run_context(run_id: 'str', step: 'int | None' = None) → None
```

Override wandb run\_id and step for calls created by this client.

This allows you to associate Weave calls with a specific WandB run that is not bound to the global wandb.run symbol.

* **`obj_ref`**: Reference to the object version, either an ObjectRef or a weave /// URI string.
* **`alias`**: An alias name or list of alias names to set (e.g., "production").

**Args:**

* **`run_id`**: The run ID (not including entity/project prefix).  The client will automatically add the entity/project prefix.
* **`step`**: The step number to use for calls. If None, step will not be set.

**Examples:**

```python theme={"system"}
client = weave.init("my-project")
client.set_wandb_run_context(run_id="my-run-id", step=5)
# Now all calls will be associated with entity/project/my-run-id at step 5

# Or without a step
client.set_wandb_run_context(run_id="my-run-id")
# Calls will be associated with entity/project/my-run-id with no step
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/telemetry/trace_sentry.py#L1283)

### <kbd>method</kbd> `update_annotation_queue`

```python theme={"system"}
update_annotation_queue(
    queue_id: 'str',
    name: 'str | None' = None,
    description: 'str | None' = None,
    scorer_refs: 'list[str] | None' = None
) → AnnotationQueueSchema
```

Update annotation queue metadata.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace/weave_client.py#L332)

### <kbd>function</kbd> `get_obj_name`

```python theme={"system"}
get_obj_name(val: 'Any') → str
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace/weave_client.py#L3450)

### <kbd>function</kbd> `get_parallelism_settings`

```python theme={"system"}
get_parallelism_settings() → tuple[int | None, int | None]
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace/weave_client.py#L363)

### <kbd>function</kbd> `map_to_refs`

```python theme={"system"}
map_to_refs(obj: 'Any') → Any
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace/weave_client.py#L226)

### <kbd>function</kbd> `print_call_link`

```python theme={"system"}
print_call_link(call: 'Call') → None
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace/weave_client.py#L3491)

### <kbd>function</kbd> `redact_sensitive_keys`

```python theme={"system"}
redact_sensitive_keys(obj: 'Any') → Any
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace/weave_client.py#L3527)

### <kbd>function</kbd> `sanitize_object_name`

```python theme={"system"}
sanitize_object_name(name: 'str') → str
```
