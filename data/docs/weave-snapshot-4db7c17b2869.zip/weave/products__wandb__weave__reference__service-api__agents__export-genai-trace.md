> ## Documentation Index
> Fetch the complete documentation index at: https://docs.coreweave.com/llms.txt
> Use this file to discover all available pages before exploring further.

# Export GenAI Trace

> Ingest OTel spans into the GenAI observability system.



## OpenAPI

````yaml products/wandb/weave/reference/service-api/openapi.json POST /agents/otel/v1/traces
openapi: 3.1.0
info:
  title: FastAPI
  version: 0.1.0
servers: []
security: []
paths:
  /agents/otel/v1/traces:
    post:
      tags:
        - Agents
      summary: Export Genai Trace
      description: Ingest OTel spans into the GenAI observability system.
      operationId: export_genai_trace_agents_otel_v1_traces_post
      responses:
        '200':
          description: Successful Response
          content:
            application/json:
              schema: {}

````