> ## Documentation Index
> Fetch the complete documentation index at: https://docs.coreweave.com/llms.txt
> Use this file to discover all available pages before exploring further.

# weaveAudio

> TypeScript SDK reference

```ts theme={"system"}
weaveAudio(options: object): WeaveAudio
```

[GitHub source](https://github.com/wandb/weave/blob/7c9efdc9fe05ffcaf2430dd652ef9bc5b3ffdfaa/sdks/node/src/media.ts#L85)

Create a new WeaveAudio object

## Parameters

**options** `object` *required*

The options for this media type

* data: The raw audio data as a Buffer
* audioType: (Optional) The type of audio file, currently only 'wav' is supported

**properties**

**audioType** `"wav"`

**data** `Buffer` *required*

## Returns

[`WeaveAudio`](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/interfaces/weaveaudio)

## Example

```ts twoslash theme={"system"}
// @noErrors
const audioBuffer = fs.readFileSync('path/to/audio.wav');
const weaveAudio = weaveAudio({ data: audioBuffer });
```
