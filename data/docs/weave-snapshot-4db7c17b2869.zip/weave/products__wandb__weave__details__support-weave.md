> ## Documentation Index
> Fetch the complete documentation index at: https://docs.coreweave.com/llms.txt
> Use this file to discover all available pages before exploring further.

# W&B Weave support

Select a category to view its related support articles.

## Browse by category

> **[Agents](https://docs.coreweave.com/support/weave/tags/agents)**
>
> 2 articles

> **[Client Info](https://docs.coreweave.com/support/weave/tags/client-info.md)**
>
> 2 articles

> **[Code Capture](https://docs.coreweave.com/support/weave/tags/code-capture.md)**
>
> 2 articles

> **[Data Capture](https://docs.coreweave.com/support/weave/tags/data-capture.md)**
>
> 3 articles

> **[Evaluation](https://docs.coreweave.com/support/weave/tags/evaluation.md)**
>
> 2 articles

> **[Performance](https://docs.coreweave.com/support/weave/tags/performance.md)**
>
> 4 articles

> **[System Info](https://docs.coreweave.com/support/weave/tags/system-info.md)**
>
> 2 articles

> **[Trace Data](https://docs.coreweave.com/support/weave/tags/trace-data.md)**
>
> 5 articles

> **[Tracing](https://docs.coreweave.com/support/weave/tags/tracing)**
>
> 2 articles

> **[TypeScript](https://docs.coreweave.com/support/weave/tags/typescript)**
>
> 1 article

> **[UI Rendering](https://docs.coreweave.com/support/weave/tags/ui-rendering.md)**
>
> 2 articles

> **[weave.op](https://docs.coreweave.com/support/weave/tags/weave-op)**
>
> 2 articles
