> ## Documentation Index
> Fetch the complete documentation index at: https://docs.coreweave.com/llms.txt
> Use this file to discover all available pages before exploring further.

# Op<T>

> TypeScript SDK reference

> **Op**\<`T`> = `object` & `T` & (...`args`) => `ReturnType`\<`T`> *extends* `AsyncIterable`\<infer U> ? `AsyncIterable`\<`Awaited`\<`U`>> : `Promise`\<`Awaited`\<`ReturnType`\<`T`>>>

[GitHub source](https://github.com/wandb/weave/blob/7c9efdc9fe05ffcaf2430dd652ef9bc5b3ffdfaa/sdks/node/src/opType.ts#L8)

## Type Declaration

### \_\_boundThis

> `optional` **\_\_boundThis**: [`WeaveObject`](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/classes/weaveobject)

### \_\_isOp

> **\_\_isOp**: `true`

### \_\_name

> **\_\_name**: `string`

### \_\_parameterNames

> `optional` **\_\_parameterNames**: `"useParam0Object"` | `string`\[]

### \_\_savedRef

> `optional` **\_\_savedRef**: `OpRef` | `Promise`\<`OpRef`>

### \_\_wrappedFunction

> **\_\_wrappedFunction**: `T`

### invoke

> **invoke**: `CallMethod`\<`T`>

## Type Parameters

**T** `extends (...args) =\> any`
