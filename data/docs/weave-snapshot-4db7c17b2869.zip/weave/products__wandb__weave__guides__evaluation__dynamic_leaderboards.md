> ## Documentation Index
> Fetch the complete documentation index at: https://docs.coreweave.com/llms.txt
> Use this file to discover all available pages before exploring further.

# Create dynamic Leaderboards in Evaluations

> Dynamic Leaderboards let you configure, customize, save, and update Leaderboard views directly from an evaluation.

This guide shows you how to use dynamic Leaderboards to visualize, customize, save, and update Leaderboard views directly from your Weave Evaluations. Dynamic Leaderboards help you track and compare model performance over time as new experiments accumulate, so you can maintain persistent, up-to-date views without re-creating them each time. This page is for users who are already running Weave Evaluations and want to organize results into shareable, reusable views.

When working with Weave Evaluations, you can visualize and customize your experiment results as Leaderboards.

Saved Leaderboard views are dynamic. As you add new evaluation runs and as results match the saved filters, the Leaderboard automatically updates to include them, without requiring manual reconfiguration.

This lets you use views as persistent Leaderboards that evolve alongside your experiments.

## Visualize evaluation results in a Leaderboard

When your project contains Weave Evaluation data, you can use the evaluation table to quickly create a Weave Leaderboard view based on a filtered subset of results.

To create a Weave Leaderboard:

1. Navigate to [Forge](https://forge.coreweave.com/wandb).
2. In the Weave sidebar menu, click **Evaluations**.
3. Apply filters to the evaluation table to narrow the data to the models, datasets, or runs you want to compare.
4. In the **evaluation table toolbar**, click **Visualize**.
   Weave automatically creates a Leaderboard panel using only the data currently filtered in the table.
5. In the Leaderboard panel header, click **Configure** to open the **Edit Leaderboard** panel.
   The **Edit Leaderboard** panel gives you fine-grained control over how models, datasets, scorers, and metrics appear.

The following shows how a filtered evaluation table is visualized as a Leaderboard and where to configure the resulting Leaderboard.

![Evaluations page showing the evaluation table with filters applied, the Visualize button in the table toolbar, and the resulting Leaderboard panel on the right with the Configure button in the panel header.](https://mintcdn.com/coreweave-dbfa0e8d/3Dv_sw2eg8feUJlx/products/wandb/weave/_media/configure-leaderboard.png?fit=max\&auto=format\&n=3Dv_sw2eg8feUJlx\&q=85\&s=ed59bd34a715457150cc6898e71f5b0c)

### Configure Leaderboard elements with visibility and custom names

The **Edit Leaderboard** panel lets you control which elements appear in the Leaderboard and how they're labeled. The following shows the **Edit Leaderboard** panel with four configuration tabs: Models, Datasets, Scorers, and Metrics.

![Evaluations page showing the Edit Leaderboard panel open on the right, with tabs for Models, Datasets, Scorers, and Metrics used to configure the leaderboard.](https://mintcdn.com/coreweave-dbfa0e8d/3Dv_sw2eg8feUJlx/products/wandb/weave/_media/edit-leaderboard.png?fit=max\&auto=format\&n=3Dv_sw2eg8feUJlx\&q=85\&s=adf79b66b0d3a9e2feb285a3bb1b3f4e)

In the **Edit Leaderboard** panel, you can:

* **Activate or deactivate display**\
  Select which models, datasets, scorers, and metrics appear in the Leaderboard by checking or unchecking them.

* **Rename models, datasets, and scorers**\
  Assign display-friendly names (for example, renaming a model run to `GPT-4` or a dataset to `JokesV1`).

  Renamed items:

  * Update immediately in the Leaderboard.
  * Remain clickable so you can still open the underlying reference in the side panel.
  * Automatically propagate anywhere the Leaderboard view is used.

This makes it easier to compare experiments using meaningful, human-readable names without changing the underlying objects.

### Configure Leaderboard metric behavior and coloring

Different metrics require different interpretations of "good" performance. The **Edit Leaderboard** panel lets you set the direction for each metric so that visual highlighting matches your intent.

In the **Edit Leaderboard** panel, for each metric, you can specify one of the following directions:

* **Higher values are better**
* **Lower values are better**

This setting directly affects Leaderboard coloring:

* Green highlights the *better* value.
* Red highlights the *worse* value.
* Colors automatically invert when you switch between "higher is better" and "lower is better".

This ensures that visual cues remain accurate across different types of metrics (for example, accuracy compared to latency or error rate).

## Save and reuse Leaderboard views

After you customize a Leaderboard, you can save it as a named view so you and your team can return to the same configuration later. In the **Edit Leaderboard** panel, click **Save** to save your customized Leaderboard as a reusable view.

The saved Leaderboard view captures:

* Selected models, datasets, scorers, and metrics.
* Renamed display labels.
* Metric direction settings (higher or lower is better).
* Applied filters.

### Switch between saved views

Click the **menu ()** button next to the Evaluations page title to open saved views. You can:

* Return to the **default** view to see the full dataset.
* Reopen a saved view to restore all customizations.

When you reopen a saved view, all renames and metric settings are preserved.
