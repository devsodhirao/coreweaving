> ## Documentation Index
> Fetch the complete documentation index at: https://docs.coreweave.com/llms.txt
> Use this file to discover all available pages before exploring further.

# trace_server_interface

> Python SDK reference for weave.trace_server.trace_server_interface

# API Overview

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L1334)

## <kbd>class</kbd> `AggregationType`

Aggregation functions supported by feedback and call stats metrics.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L926)

## <kbd>class</kbd> `AliasesListReq`

**Pydantic Fields:**

* `project_id`: `<class 'str'>`
* `wb_user_id`: `str | None`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L931)

## <kbd>class</kbd> `AliasesListRes`

**Pydantic Fields:**

* `aliases`: `list[str]`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L1976)

## <kbd>class</kbd> `AnnotationQueueAddCallsReq`

Request to add calls to an annotation queue in batch.

Extends AnnotationQueueAddCallsBody by adding queue\_id for internal API usage.

**Pydantic Fields:**

* `project_id`: `<class 'str'>`
* `call_ids`: `list[str]`
* `display_fields`: `list[str]`
* `queue_id`: `<class 'str'>`
* `wb_user_id`: `str | None`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L1986)

## <kbd>class</kbd> `AnnotationQueueAddCallsRes`

Response from adding calls to a queue.

**Pydantic Fields:**

* `added_count`: `<class 'int'>`
* `duplicates`: `<class 'int'>`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L1849)

## <kbd>class</kbd> `AnnotationQueueCreateReq`

Request to create a new annotation queue.

**Pydantic Fields:**

* `project_id`: `<class 'str'>`
* `name`: `<class 'str'>`
* `description`: `<class 'str'>`
* `scorer_refs`: `list[str]`
* `wb_user_id`: `str | None`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L1866)

## <kbd>class</kbd> `AnnotationQueueCreateRes`

Response from creating an annotation queue.

**Pydantic Fields:**

* `id`: `<class 'str'>`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L1908)

## <kbd>class</kbd> `AnnotationQueueDeleteReq`

Request to delete (soft-delete) an annotation queue.

**Pydantic Fields:**

* `project_id`: `<class 'str'>`
* `queue_id`: `<class 'str'>`
* `wb_user_id`: `str | None`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L1916)

## <kbd>class</kbd> `AnnotationQueueDeleteRes`

Response from deleting an annotation queue.

**Pydantic Fields:**

* `queue`: `<class 'AnnotationQueueSchema'>`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L1950)

## <kbd>class</kbd> `AnnotationQueueItemSchema`

Schema for annotation queue item responses.

**Pydantic Fields:**

* `id`: `<class 'str'>`
* `project_id`: `<class 'str'>`
* `queue_id`: `<class 'str'>`
* `call_id`: `<class 'str'>`
* `call_started_at`: `<class 'datetime.datetime'>`
* `call_ended_at`: `datetime.datetime | None`
* `call_op_name`: `<class 'str'>`
* `call_trace_id`: `<class 'str'>`
* `display_fields`: `list[str]`
* `added_by`: `str | None`
* `annotation_state`: `typing.Literal['unstarted', 'in_progress', 'completed', 'skipped']`
* `annotator_user_id`: `str | None`
* `created_at`: `<class 'datetime.datetime'>`
* `created_by`: `<class 'str'>`
* `updated_at`: `<class 'datetime.datetime'>`
* `deleted_at`: `datetime.datetime | None`
* `position_in_queue`: `int | None`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L1993)

## <kbd>class</kbd> `AnnotationQueueItemsQueryReq`

Request to query items in an annotation queue.

Extends AnnotationQueueItemsQueryBody by adding queue\_id for internal API usage.

**Pydantic Fields:**

* `project_id`: `<class 'str'>`
* `filter`: `weave.trace_server.common_interface.AnnotationQueueItemsFilter | None`
* `sort_by`: `list[weave.trace_server.common_interface.SortBy] | None`
* `limit`: `int | None`
* `offset`: `int | None`
* `include_position`: `<class 'bool'>`
* `queue_id`: `<class 'str'>`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L2002)

## <kbd>class</kbd> `AnnotationQueueItemsQueryRes`

Response from querying annotation queue items.

**Pydantic Fields:**

* `items`: `list[AnnotationQueueItemSchema]`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L1895)

## <kbd>class</kbd> `AnnotationQueueReadReq`

Request to read a specific annotation queue.

**Pydantic Fields:**

* `project_id`: `<class 'str'>`
* `queue_id`: `<class 'str'>`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L1902)

## <kbd>class</kbd> `AnnotationQueueReadRes`

Response from reading an annotation queue.

**Pydantic Fields:**

* `queue`: `<class 'AnnotationQueueSchema'>`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L1835)

## <kbd>class</kbd> `AnnotationQueueSchema`

Schema for annotation queue responses.

**Pydantic Fields:**

* `id`: `<class 'str'>`
* `project_id`: `<class 'str'>`
* `name`: `<class 'str'>`
* `description`: `<class 'str'>`
* `scorer_refs`: `list[str]`
* `created_at`: `<class 'datetime.datetime'>`
* `created_by`: `<class 'str'>`
* `updated_at`: `<class 'datetime.datetime'>`
* `deleted_at`: `datetime.datetime | None`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L2008)

## <kbd>class</kbd> `AnnotationQueueStatsSchema`

Statistics for a single annotation queue.

**Pydantic Fields:**

* `queue_id`: `<class 'str'>`
* `total_items`: `<class 'int'>`
* `completed_items`: `<class 'int'>`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L1922)

## <kbd>class</kbd> `AnnotationQueueUpdateReq`

Request to update an annotation queue.

All fields except project\_id and queue\_id are optional - only provided fields will be updated.

**Pydantic Fields:**

* `project_id`: `<class 'str'>`
* `queue_id`: `<class 'str'>`
* `name`: `str | None`
* `description`: `str | None`
* `scorer_refs`: `list[str] | None`
* `wb_user_id`: `str | None`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L1944)

## <kbd>class</kbd> `AnnotationQueueUpdateRes`

Response from updating an annotation queue.

**Pydantic Fields:**

* `queue`: `<class 'AnnotationQueueSchema'>`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L1872)

## <kbd>class</kbd> `AnnotationQueuesQueryReq`

Request to query annotation queues for a project.

**Pydantic Fields:**

* `project_id`: `<class 'str'>`
* `name`: `str | None`
* `sort_by`: `list[weave.trace_server.common_interface.SortBy] | None`
* `limit`: `int | None`
* `offset`: `int | None`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L1889)

## <kbd>class</kbd> `AnnotationQueuesQueryRes`

Response from querying annotation queues.

**Pydantic Fields:**

* `queues`: `list[AnnotationQueueSchema]`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L2023)

## <kbd>class</kbd> `AnnotationQueuesStatsReq`

Request to get stats for multiple annotation queues.

**Pydantic Fields:**

* `project_id`: `<class 'str'>`
* `queue_ids`: `list[str]`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L2038)

## <kbd>class</kbd> `AnnotationQueuesStatsRes`

Response with stats for multiple annotation queues.

**Pydantic Fields:**

* `stats`: `list[AnnotationQueueStatsSchema]`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L2044)

## <kbd>class</kbd> `AnnotatorQueueItemsProgressUpdateReq`

Request to update the annotation state of a queue item for the current annotator.

Valid state transitions:

* (absence) -> 'in\_progress': Mark item as in progress (only when no record exists)
* (absence) -> 'completed' or 'skipped': Directly complete/skip item
* 'in\_progress' or 'unstarted' -> 'completed' or 'skipped': Complete/skip started item
* same\_state -> same\_state: Idempotent no-op (returns existing item unchanged)

**Pydantic Fields:**

* `project_id`: `<class 'str'>`
* `queue_id`: `<class 'str'>`
* `item_id`: `<class 'str'>`
* `annotation_state`: `<class 'str'>`
* `wb_user_id`: `str | None`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L2064)

## <kbd>class</kbd> `AnnotatorQueueItemsProgressUpdateRes`

Response from updating annotation state.

**Pydantic Fields:**

* `item`: `<class 'AnnotationQueueItemSchema'>`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L416)

## <kbd>class</kbd> `CallBatchEndMode`

**Pydantic Fields:**

* `mode`: `<class 'str'>`
* `req`: `<class 'CallEndReq'>`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L411)

## <kbd>class</kbd> `CallBatchStartMode`

**Pydantic Fields:**

* `mode`: `<class 'str'>`
* `req`: `<class 'CallStartReq'>`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L421)

## <kbd>class</kbd> `CallCreateBatchReq`

**Pydantic Fields:**

* `batch`: `list[CallBatchStartMode | CallBatchEndMode]`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L425)

## <kbd>class</kbd> `CallCreateBatchRes`

**Pydantic Fields:**

* `res`: `list[CallStartRes | CallEndRes]`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L403)

## <kbd>class</kbd> `CallEndReq`

**Pydantic Fields:**

* `end`: `<class 'EndedCallSchemaForInsert'>`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L407)

## <kbd>class</kbd> `CallEndRes`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L454)

## <kbd>class</kbd> `CallEndV2Req`

Request for ending a single call via v2 API.

**Pydantic Fields:**

* `end`: `<class 'EndedCallSchemaForInsertWithStartedAt'>`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L460)

## <kbd>class</kbd> `CallEndV2Res`

Response for ending a single call via v2 API.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3784)

## <kbd>class</kbd> `CallMetricSpec`

Specification for a call-level metric to aggregate (not grouped by model).

**Pydantic Fields:**

* `metric`: `typing.Literal['latency_ms', 'call_count', 'error_count']`
* `aggregations`: `list[AggregationType]`
* `percentiles`: `list[float]`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L466)

## <kbd>class</kbd> `CallReadReq`

**Pydantic Fields:**

* `project_id`: `<class 'str'>`
* `id`: `<class 'str'>`
* `include_costs`: `bool | None`
* `include_storage_size`: `bool | None`
* `include_total_storage_size`: `bool | None`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L474)

## <kbd>class</kbd> `CallReadRes`

**Pydantic Fields:**

* `call`: `CallSchema | None`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L117)

## <kbd>class</kbd> `CallSchema`

**Pydantic Fields:**

* `id`: `<class 'str'>`
* `project_id`: `<class 'str'>`
* `op_name`: `<class 'str'>`
* `display_name`: `str | None`
* `trace_id`: `<class 'str'>`
* `parent_id`: `str | None`
* `thread_id`: `str | None`
* `turn_id`: `str | None`
* `started_at`: `<class 'datetime.datetime'>`
* `attributes`: `dict[str, typing.Any]`
* `inputs`: `dict[str, typing.Any]`
* `ended_at`: `datetime.datetime | None`
* `exception`: `str | None`
* `output`: `typing.Any | None`
* `summary`: `SummaryMap | None`
* `wb_user_id`: `str | None`
* `wb_username`: `str | None`
* `wb_run_id`: `str | None`
* `wb_run_step`: `int | None`
* `wb_run_step_end`: `int | None`
* `deleted_at`: `datetime.datetime | None`
* `expire_at`: `datetime.datetime | None`
* `storage_size_bytes`: `int | None`
* `total_storage_size_bytes`: `int | None`

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L178)

### <kbd>method</kbd> `serialize_typed_dicts`

```python theme={"system"}
serialize_typed_dicts(v: dict[str, Any]) → dict[str, Any]
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L394)

## <kbd>class</kbd> `CallStartReq`

**Pydantic Fields:**

* `start`: `<class 'StartedCallSchemaForInsert'>`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L398)

## <kbd>class</kbd> `CallStartRes`

**Pydantic Fields:**

* `id`: `<class 'str'>`
* `trace_id`: `<class 'str'>`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L441)

## <kbd>class</kbd> `CallStartV2Req`

Request for starting a single call via v2 API.

**Pydantic Fields:**

* `start`: `<class 'StartedCallSchemaForInsert'>`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L447)

## <kbd>class</kbd> `CallStartV2Res`

Response for starting a single call via v2 API.

**Pydantic Fields:**

* `id`: `<class 'str'>`
* `trace_id`: `<class 'str'>`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3802)

## <kbd>class</kbd> `CallStatsReq`

Request for aggregated call statistics over a time range.

**Pydantic Fields:**

* `project_id`: `<class 'str'>`
* `start`: `<class 'datetime.datetime'>`
* `end`: `datetime.datetime | None`
* `granularity`: `int | None`
* `usage_metrics`: `list[UsageMetricSpec] | None`
* `call_metrics`: `list[CallMetricSpec] | None`
* `filter`: `CallsFilter | None`
* `timezone`: `<class 'str'>`

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3832)

### <kbd>method</kbd> `validate_date_range`

```python theme={"system"}
validate_date_range() → CallStatsReq
```

Ensure call stats requests are bounded to a safe date range.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3845)

## <kbd>class</kbd> `CallStatsRes`

Response containing time-series call statistics.

**Pydantic Fields:**

* `start`: `<class 'datetime.datetime'>`
* `end`: `<class 'datetime.datetime'>`
* `granularity`: `<class 'int'>`
* `timezone`: `<class 'str'>`
* `usage_buckets`: `list[dict[str, typing.Any]]`
* `call_buckets`: `list[dict[str, typing.Any]]`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L704)

## <kbd>class</kbd> `CallUpdateReq`

**Pydantic Fields:**

* `project_id`: `<class 'str'>`
* `call_id`: `<class 'str'>`
* `display_name`: `str | None`
* `wb_user_id`: `str | None`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L716)

## <kbd>class</kbd> `CallUpdateRes`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L478)

## <kbd>class</kbd> `CallsDeleteReq`

**Pydantic Fields:**

* `project_id`: `<class 'str'>`
* `call_ids`: `list[str]`
* `wb_user_id`: `str | None`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L486)

## <kbd>class</kbd> `CallsDeleteRes`

**Pydantic Fields:**

* `num_deleted`: `<class 'int'>`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L597)

## <kbd>class</kbd> `CallsFilter`

**Pydantic Fields:**

* `op_names`: `list[str] | None`
* `input_refs`: `list[str] | None`
* `output_refs`: `list[str] | None`
* `parent_ids`: `list[str] | None`
* `trace_ids`: `list[str] | None`
* `call_ids`: `list[str] | None`
* `thread_ids`: `list[str] | None`
* `turn_ids`: `list[str] | None`
* `trace_roots_only`: `bool | None`
* `wb_user_ids`: `list[str] | None`
* `wb_run_ids`: `list[str] | None`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L612)

## <kbd>class</kbd> `CallsQueryReq`

**Pydantic Fields:**

* `project_id`: `<class 'str'>`
* `filter`: `CallsFilter | None`
* `limit`: `int | None`
* `offset`: `int | None`
* `sort_by`: `list[weave.trace_server.common_interface.SortBy] | None`
* `query`: `weave.trace_server.interface.query.Query | None`
* `include_costs`: `bool | None`
* `include_feedback`: `bool | None`
* `include_storage_size`: `bool | None`
* `include_total_storage_size`: `bool | None`
* `include_usernames`: `bool | None`
* `columns`: `list[str] | None`
* `expand_columns`: `list[str] | None`
* `return_expanded_column_values`: `bool | None`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L677)

## <kbd>class</kbd> `CallsQueryRes`

**Pydantic Fields:**

* `calls`: `list[CallSchema]`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L681)

## <kbd>class</kbd> `CallsQueryStatsReq`

**Pydantic Fields:**

* `project_id`: `<class 'str'>`
* `filter`: `CallsFilter | None`
* `query`: `weave.trace_server.interface.query.Query | None`
* `limit`: `int | None`
* `include_total_storage_size`: `bool | None`
* `expand_columns`: `list[str] | None`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L697)

## <kbd>class</kbd> `CallsQueryStatsRes`

**Pydantic Fields:**

* `count`: `<class 'int'>`
* `has_more`: `<class 'bool'>`
* `total_storage_size_bytes`: `int | None`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L2436)

## <kbd>class</kbd> `CallsScoreReq`

Request to enqueue scoring jobs for a list of calls.

Scoring is performed asynchronously by the call\_scoring\_worker, which consumes messages from Kafka and applies each scorer\_ref to each call\_id.

**Pydantic Fields:**

* `project_id`: `<class 'str'>`
* `call_ids`: `list[str]`
* `scorer_refs`: `list[str]`
* `wb_user_id`: `str | None`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L2449)

## <kbd>class</kbd> `CallsScoreRes`

Empty response for calls\_score.

Defined as a model (rather than returning None) to follow the convention used throughout this interface and to allow fields to be added later without a breaking change.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L429)

## <kbd>class</kbd> `CallsUpsertCompleteReq`

Request for upserting a batch of completed calls.

**Pydantic Fields:**

* `batch`: `list[CompletedCallSchemaForInsert]`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L435)

## <kbd>class</kbd> `CallsUpsertCompleteRes`

Response for upserting a batch of completed calls.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3924)

## <kbd>class</kbd> `CallsUsageReq`

Request to compute aggregated usage for multiple root calls.

This endpoint returns usage metrics for each requested root call, where each root's metrics include the sum of its own usage plus all descendants' usage.

Note: All matching calls are loaded into memory for aggregation. For very large result sets (>10k calls), consider batching root call IDs or using narrower filters at the application layer.

**Pydantic Fields:**

* `project_id`: `<class 'str'>`
* `call_ids`: `list[str]`
* `include_costs`: `<class 'bool'>`
* `limit`: `<class 'int'>`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3949)

## <kbd>class</kbd> `CallsUsageRes`

Response with aggregated usage metrics per root call.

**Pydantic Fields:**

* `call_usage`: `dict[str, dict[str, LLMAggregatedUsage]]`
* `unfinished_call_ids`: `list[str]`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L271)

## <kbd>class</kbd> `CompletedCallSchemaForInsert`

Schema for inserting a completed call directly.

This represents a call that is already finished at insertion time, with both start and end information provided together. Used by the calls\_complete endpoint.

**Pydantic Fields:**

* `project_id`: `<class 'str'>`
* `id`: `<class 'str'>`
* `trace_id`: `<class 'str'>`
* `op_name`: `<class 'str'>`
* `started_at`: `<class 'datetime.datetime'>`
* `ended_at`: `<class 'datetime.datetime'>`
* `display_name`: `str | None`
* `parent_id`: `str | None`
* `thread_id`: `str | None`
* `turn_id`: `str | None`
* `attributes`: `dict[str, typing.Any]`
* `inputs`: `dict[str, typing.Any]`
* `output`: `typing.Any | None`
* `summary`: `<class 'SummaryInsertMap'>`
* `otel_dump`: `dict[str, typing.Any] | None`
* `exception`: `str | None`
* `wb_user_id`: `str | None`
* `wb_run_id`: `str | None`
* `wb_run_step`: `int | None`
* `wb_run_step_end`: `int | None`

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L310)

### <kbd>method</kbd> `serialize_typed_dicts`

```python theme={"system"}
serialize_typed_dicts(v: dict[str, Any]) → dict[str, Any]
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L540)

## <kbd>class</kbd> `CompletionsCreateReq`

**Pydantic Fields:**

* `project_id`: `<class 'str'>`
* `inputs`: `<class 'CompletionsCreateRequestInputs'>`
* `wb_user_id`: `str | None`
* `track_llm_call`: `bool | None`
* `trace_id`: `str | None`
* `parent_id`: `str | None`
* `conversation_id`: `str | None`
* `conversation_name`: `str | None`
* `source`: `str | None`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L490)

## <kbd>class</kbd> `CompletionsCreateRequestInputs`

**Pydantic Fields:**

* `model`: `<class 'str'>`
* `messages`: `<class 'list'>`
* `timeout`: `float | str | None`
* `temperature`: `float | None`
* `top_p`: `float | None`
* `n`: `int | None`
* `stop`: `str | list | None`
* `max_completion_tokens`: `int | None`
* `max_tokens`: `int | None`
* `modalities`: `list | None`
* `presence_penalty`: `float | None`
* `frequency_penalty`: `float | None`
* `stream`: `bool | None`
* `logit_bias`: `dict | None`
* `user`: `str | None`
* `response_format`: `dict | type[pydantic.main.BaseModel] | None`
* `seed`: `int | None`
* `tools`: `list | None`
* `tool_choice`: `str | dict | None`
* `logprobs`: `bool | None`
* `top_logprobs`: `int | None`
* `parallel_tool_calls`: `bool | None`
* `extra_headers`: `dict | None`
* `functions`: `list | None`
* `function_call`: `str | None`
* `api_version`: `str | None`
* `prompt`: `str | None`
* `template_vars`: `dict[str, typing.Any] | None`
* `vertex_credentials`: `str | None`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L568)

## <kbd>class</kbd> `CompletionsCreateRes`

**Pydantic Fields:**

* `response`: `dict[str, typing.Any]`
* `weave_call_id`: `str | None`
* `span_id`: `str | None`
* `trace_id`: `str | None`
* `conversation_id`: `str | None`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L1704)

## <kbd>class</kbd> `CostCreateInput`

**Pydantic Fields:**

* `prompt_token_cost`: `<class 'float'>`
* `completion_token_cost`: `<class 'float'>`
* `cache_read_input_token_cost`: `<class 'float'>`
* `cache_creation_input_token_cost`: `<class 'float'>`
* `prompt_token_cost_unit`: `str | None`
* `completion_token_cost_unit`: `str | None`
* `effective_date`: `datetime.datetime | None`
* `provider_id`: `str | None`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L1725)

## <kbd>class</kbd> `CostCreateReq`

**Pydantic Fields:**

* `project_id`: `<class 'str'>`
* `costs`: `dict[str, CostCreateInput]`
* `wb_user_id`: `str | None`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L1732)

## <kbd>class</kbd> `CostCreateRes`

**Pydantic Fields:**

* `ids`: `list[tuple[str, str]]`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L1779)

## <kbd>class</kbd> `CostPurgeReq`

**Pydantic Fields:**

* `project_id`: `<class 'str'>`
* `query`: `<class 'weave.trace_server.interface.query.Query'>`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L1784)

## <kbd>class</kbd> `CostPurgeRes`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L1762)

## <kbd>class</kbd> `CostQueryOutput`

**Pydantic Fields:**

* `id`: `str | None`
* `llm_id`: `str | None`
* `prompt_token_cost`: `float | None`
* `completion_token_cost`: `float | None`
* `prompt_token_cost_unit`: `str | None`
* `completion_token_cost_unit`: `str | None`
* `effective_date`: `datetime.datetime | None`
* `provider_id`: `str | None`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L1736)

## <kbd>class</kbd> `CostQueryReq`

**Pydantic Fields:**

* `project_id`: `<class 'str'>`
* `fields`: `list[str] | None`
* `query`: `weave.trace_server.interface.query.Query | None`
* `sort_by`: `list[weave.trace_server.common_interface.SortBy] | None`
* `limit`: `int | None`
* `offset`: `int | None`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L1775)

## <kbd>class</kbd> `CostQueryRes`

**Pydantic Fields:**

* `results`: `list[CostQueryOutput]`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L2546)

## <kbd>class</kbd> `DatasetCreateBody`

**Pydantic Fields:**

* `name`: `str | None`
* `description`: `str | None`
* `rows`: `list[dict[str, typing.Any]]`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L2558)

## <kbd>class</kbd> `DatasetCreateReq`

**Pydantic Fields:**

* `name`: `str | None`
* `description`: `str | None`
* `rows`: `list[dict[str, typing.Any]]`
* `project_id`: `<class 'str'>`
* `wb_user_id`: `str | None`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L2565)

## <kbd>class</kbd> `DatasetCreateRes`

**Pydantic Fields:**

* `digest`: `<class 'str'>`
* `object_id`: `<class 'str'>`
* `version_index`: `<class 'int'>`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L2608)

## <kbd>class</kbd> `DatasetDeleteReq`

**Pydantic Fields:**

* `project_id`: `<class 'str'>`
* `object_id`: `<class 'str'>`
* `digests`: `list[str] | None`
* `wb_user_id`: `str | None`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L2620)

## <kbd>class</kbd> `DatasetDeleteRes`

**Pydantic Fields:**

* `num_deleted`: `<class 'int'>`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L2597)

## <kbd>class</kbd> `DatasetListReq`

**Pydantic Fields:**

* `project_id`: `<class 'str'>`
* `limit`: `int | None`
* `offset`: `int | None`
* `wb_user_id`: `str | None`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L2573)

## <kbd>class</kbd> `DatasetReadReq`

**Pydantic Fields:**

* `project_id`: `<class 'str'>`
* `object_id`: `<class 'str'>`
* `digest`: `<class 'str'>`
* `wb_user_id`: `str | None`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L2582)

## <kbd>class</kbd> `DatasetReadRes`

**Pydantic Fields:**

* `object_id`: `<class 'str'>`
* `digest`: `<class 'str'>`
* `version_index`: `<class 'int'>`
* `created_at`: `<class 'datetime.datetime'>`
* `name`: `<class 'str'>`
* `description`: `str | None`
* `rows`: `<class 'str'>`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L2107)

## <kbd>class</kbd> `DatasetSourceLinkPayload`

A single dataset row and the sources to link to it.

**Pydantic Fields:**

* `row_digest`: `<class 'str'>`
* `sources`: `list[SourceRef]`
* `link_metadata`: `dict[str, typing.Any] | None`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L2167)

## <kbd>class</kbd> `DatasetSourceLinkSchema`

Schema for a single dataset source link row.

**Pydantic Fields:**

* `id`: `<class 'str'>`
* `row_digest`: `<class 'str'>`
* `source_kind`: `<enum 'SourceKind'>`
* `source_id`: `<class 'str'>`
* `source_trace_id`: `<class 'str'>`
* `source_started_at`: `<class 'datetime.datetime'>`
* `source_display_name`: `<class 'str'>`
* `link_metadata`: `dict[str, typing.Any] | None`
* `added_by`: `str | None`
* `created_at`: `<class 'datetime.datetime'>`
* `updated_at`: `<class 'datetime.datetime'>`
* `deleted_at`: `datetime.datetime | None`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L2146)

## <kbd>class</kbd> `DatasetSourcesLinkDeleteReq`

Request to soft-delete dataset source links by id.

**Pydantic Fields:**

* `project_id`: `<class 'str'>`
* `link_ids`: `list[str]`
* `wb_user_id`: `str | None`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L2161)

## <kbd>class</kbd> `DatasetSourcesLinkDeleteRes`

Response from deleting dataset source links.

**Pydantic Fields:**

* `entries`: `list[DatasetSourcesLinkDeleteResEntry]`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L2154)

## <kbd>class</kbd> `DatasetSourcesLinkDeleteResEntry`

Result for a single link deletion.

**Pydantic Fields:**

* `link_id`: `<class 'str'>`
* `deleted`: `<class 'bool'>`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L2115)

## <kbd>class</kbd> `DatasetSourcesLinkReq`

Request to link dataset rows to their provenance sources.

**Pydantic Fields:**

* `project_id`: `<class 'str'>`
* `dataset_object_id`: `<class 'str'>`
* `dataset_digest`: `<class 'str'>`
* `links`: `list[DatasetSourceLinkPayload]`
* `include_created_status`: `<class 'bool'>`
* `wb_user_id`: `str | None`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L2137)

## <kbd>class</kbd> `DatasetSourcesLinkRes`

Response from linking dataset rows to sources.

One entry per flattened (row\_digest, source) tuple, in input order.

**Pydantic Fields:**

* `entries`: `list[DatasetSourcesLinkResEntry]`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L2129)

## <kbd>class</kbd> `DatasetSourcesLinkResEntry`

Result for a single flattened (row\_digest, source) link.

**Pydantic Fields:**

* `link_id`: `<class 'str'>`
* `created`: `bool | None`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L2184)

## <kbd>class</kbd> `DatasetSourcesQueryReq`

Forward query: dataset -> sources.

**Pydantic Fields:**

* `project_id`: `<class 'str'>`
* `dataset_object_id`: `<class 'str'>`
* `row_digests`: `list[str] | None`
* `source_kinds`: `list[SourceKind] | None`
* `include_deleted`: `<class 'bool'>`
* `limit`: `int | None`
* `offset`: `int | None`
* `wb_user_id`: `str | None`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L2197)

## <kbd>class</kbd> `DatasetSourcesQueryRes`

Response from the forward dataset -> sources query.

**Pydantic Fields:**

* `links`: `list[DatasetSourceLinkSchema]`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L221)

## <kbd>class</kbd> `EndedCallSchemaForInsert`

**Pydantic Fields:**

* `project_id`: `<class 'str'>`
* `id`: `<class 'str'>`
* `trace_id`: `str | None`
* `is_eval`: `bool | None`
* `ended_at`: `<class 'datetime.datetime'>`
* `started_at`: `datetime.datetime | None`
* `exception`: `str | None`
* `output`: `typing.Any | None`
* `summary`: `<class 'SummaryInsertMap'>`
* `wb_run_step_end`: `int | None`

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L258)

### <kbd>method</kbd> `serialize_typed_dicts`

```python theme={"system"}
serialize_typed_dicts(v: dict[str, Any]) → dict[str, Any]
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L263)

## <kbd>class</kbd> `EndedCallSchemaForInsertWithStartedAt`

Deprecated alias. `started_at` now lives on the parent `EndedCallSchemaForInsert`; prefer that. Kept so external SDK pins on the `WithStartedAt` name keep importing. Remove once all in-tree callers migrate.

**Pydantic Fields:**

* `project_id`: `<class 'str'>`
* `id`: `<class 'str'>`
* `trace_id`: `str | None`
* `is_eval`: `bool | None`
* `ended_at`: `<class 'datetime.datetime'>`
* `started_at`: `datetime.datetime | None`
* `exception`: `str | None`
* `output`: `typing.Any | None`
* `summary`: `<class 'SummaryInsertMap'>`
* `wb_run_step_end`: `int | None`

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L258)

### <kbd>method</kbd> `serialize_typed_dicts`

```python theme={"system"}
serialize_typed_dicts(v: dict[str, Any]) → dict[str, Any]
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3405)

## <kbd>class</kbd> `EvalResultsEvaluationSummary`

**Pydantic Fields:**

* `evaluation_call_id`: `<class 'str'>`
* `trial_count`: `<class 'int'>`
* `scorer_stats`: `list[EvalResultsScorerStats]`
* `predict_total_tokens`: `int | None`
* `predict_total_cost`: `float | None`
* `evaluation_ref`: `str | None`
* `model_ref`: `str | None`
* `display_name`: `str | None`
* `trace_id`: `str | None`
* `started_at`: `str | None`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3223)

## <kbd>class</kbd> `EvalResultsFilter`

A filter scoped to an optional evaluation.

**Pydantic Fields:**

* `evaluation_call_id`: `str | None`
* `query`: `<class 'weave.trace_server.interface.query.Query'>`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3236)

## <kbd>class</kbd> `EvalResultsQueryBody`

**Pydantic Fields:**

* `evaluation_call_ids`: `list[str] | None`
* `evaluation_run_ids`: `list[str] | None`
* `require_intersection`: `<class 'bool'>`
* `include_raw_data_rows`: `<class 'bool'>`
* `resolve_row_refs`: `<class 'bool'>`
* `include_rows`: `<class 'bool'>`
* `include_summary`: `<class 'bool'>`
* `summary_require_intersection`: `bool | None`
* `include_predict_and_score_children`: `<class 'bool'>`
* `include_costs`: `<class 'bool'>`
* `sort_by`: `list[EvalResultsSortBy] | None`
* `filters`: `list[EvalResultsFilter] | None`
* `filter_logic_operator`: `typing.Literal['and', 'or']`
* `limit`: `int | None`
* `offset`: `<class 'int'>`

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3332)

### <kbd>method</kbd> `validate_identifiers`

```python theme={"system"}
validate_identifiers() → EvalResultsQueryBody
```

Validate that at least one evaluation identifier is provided.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3344)

## <kbd>class</kbd> `EvalResultsQueryReq`

**Pydantic Fields:**

* `evaluation_call_ids`: `list[str] | None`
* `evaluation_run_ids`: `list[str] | None`
* `require_intersection`: `<class 'bool'>`
* `include_raw_data_rows`: `<class 'bool'>`
* `resolve_row_refs`: `<class 'bool'>`
* `include_rows`: `<class 'bool'>`
* `include_summary`: `<class 'bool'>`
* `summary_require_intersection`: `bool | None`
* `include_predict_and_score_children`: `<class 'bool'>`
* `include_costs`: `<class 'bool'>`
* `sort_by`: `list[EvalResultsSortBy] | None`
* `filters`: `list[EvalResultsFilter] | None`
* `filter_logic_operator`: `typing.Literal['and', 'or']`
* `limit`: `int | None`
* `offset`: `<class 'int'>`
* `project_id`: `<class 'str'>`

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3332)

### <kbd>method</kbd> `validate_identifiers`

```python theme={"system"}
validate_identifiers() → EvalResultsQueryBody
```

Validate that at least one evaluation identifier is provided.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3371)

## <kbd>class</kbd> `EvalResultsQueryRes`

**Pydantic Fields:**

* `rows`: `list[EvalResultsRow]`
* `total_rows`: `<class 'int'>`
* `summary`: `ForwardRef('EvalResultsSummaryRes | None')`
* `warnings`: `list[str]`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3365)

## <kbd>class</kbd> `EvalResultsRow`

**Pydantic Fields:**

* `row_digest`: `<class 'str'>`
* `raw_data_row`: `typing.Any | None`
* `evaluations`: `list[EvalResultsRowEvaluation]`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3360)

## <kbd>class</kbd> `EvalResultsRowEvaluation`

**Pydantic Fields:**

* `evaluation_call_id`: `<class 'str'>`
* `trials`: `list[EvalResultsTrial]`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3381)

## <kbd>class</kbd> `EvalResultsScorerStats`

Stats for a single flattened score dimension (scorer\_key or scorer\_key.path.to.leaf).

**Pydantic Fields:**

* `scorer_key`: `<class 'str'>`
* `path`: `str | None`
* `value_type`: `typing.Optional[typing.Literal['binary', 'continuous', 'text']]`
* `trial_count`: `<class 'int'>`
* `numeric_count`: `<class 'int'>`
* `numeric_mean`: `float | None`
* `pass_true_count`: `<class 'int'>`
* `pass_known_count`: `<class 'int'>`
* `pass_rate`: `float | None`
* `pass_signal_coverage`: `float | None`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3206)

## <kbd>class</kbd> `EvalResultsSortBy`

Sort specification for evaluation results, extending SortBy

**Pydantic Fields:**

* `field`: `<class 'str'>`
* `direction`: `typing.Literal['asc', 'desc']`
* `evaluation_call_id`: `str | None`
* `mode`: `typing.Literal['value', 'difference']`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3432)

## <kbd>class</kbd> `EvalResultsSummaryRes`

**Pydantic Fields:**

* `row_count`: `<class 'int'>`
* `evaluations`: `list[EvalResultsEvaluationSummary]`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3348)

## <kbd>class</kbd> `EvalResultsTrial`

**Pydantic Fields:**

* `predict_and_score_call_id`: `<class 'str'>`
* `predict_call_id`: `str | None`
* `model_output`: `typing.Any | None`
* `scores`: `dict[str, typing.Any]`
* `model_latency_seconds`: `float | None`
* `total_tokens`: `int | None`
* `total_cost`: `float | None`
* `scorer_call_ids`: `dict[str, str]`
* `genai_span_ref`: `list[GenAISpanRef] | None`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L2318)

## <kbd>class</kbd> `EvaluateModelArgs`

Arguments for a full evaluate-model job (loads model + runs predictions + scores).

Moved from workers/evaluate\_model\_worker/evaluate\_model\_worker.py so both job types (EvaluateModelArgs and RescoringArgs) can be co-located in the same module for the EvalWorkerJob discriminated union.

**Pydantic Fields:**

* `job_type`: `typing.Literal['evaluate_model']`
* `project_id`: `<class 'str'>`
* `evaluation_ref`: `<class 'str'>`
* `model_ref`: `<class 'str'>`
* `wb_user_id`: `<class 'str'>`
* `evaluation_call_id`: `<class 'str'>`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L2304)

## <kbd>class</kbd> `EvaluateModelReq`

**Pydantic Fields:**

* `project_id`: `<class 'str'>`
* `evaluation_ref`: `<class 'str'>`
* `model_ref`: `<class 'str'>`
* `wb_user_id`: `str | None`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L2314)

## <kbd>class</kbd> `EvaluateModelRes`

**Pydantic Fields:**

* `call_id`: `<class 'str'>`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L2709)

## <kbd>class</kbd> `EvaluationCreateBody`

**Pydantic Fields:**

* `name`: `<class 'str'>`
* `description`: `str | None`
* `dataset`: `<class 'str'>`
* `scorers`: `list[str] | None`
* `trials`: `<class 'int'>`
* `evaluation_name`: `str | None`
* `eval_attributes`: `dict[str, typing.Any] | None`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L2731)

## <kbd>class</kbd> `EvaluationCreateReq`

**Pydantic Fields:**

* `name`: `<class 'str'>`
* `description`: `str | None`
* `dataset`: `<class 'str'>`
* `scorers`: `list[str] | None`
* `trials`: `<class 'int'>`
* `evaluation_name`: `str | None`
* `eval_attributes`: `dict[str, typing.Any] | None`
* `project_id`: `<class 'str'>`
* `wb_user_id`: `str | None`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L2738)

## <kbd>class</kbd> `EvaluationCreateRes`

**Pydantic Fields:**

* `digest`: `<class 'str'>`
* `object_id`: `<class 'str'>`
* `version_index`: `<class 'int'>`
* `evaluation_ref`: `<class 'str'>`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L2797)

## <kbd>class</kbd> `EvaluationDeleteReq`

**Pydantic Fields:**

* `project_id`: `<class 'str'>`
* `object_id`: `<class 'str'>`
* `digests`: `list[str] | None`
* `wb_user_id`: `str | None`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L2809)

## <kbd>class</kbd> `EvaluationDeleteRes`

**Pydantic Fields:**

* `num_deleted`: `<class 'int'>`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L2784)

## <kbd>class</kbd> `EvaluationListReq`

**Pydantic Fields:**

* `project_id`: `<class 'str'>`
* `limit`: `int | None`
* `offset`: `int | None`
* `wb_user_id`: `str | None`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L2749)

## <kbd>class</kbd> `EvaluationReadReq`

**Pydantic Fields:**

* `project_id`: `<class 'str'>`
* `object_id`: `<class 'str'>`
* `digest`: `<class 'str'>`
* `wb_user_id`: `str | None`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L2758)

## <kbd>class</kbd> `EvaluationReadRes`

**Pydantic Fields:**

* `object_id`: `<class 'str'>`
* `digest`: `<class 'str'>`
* `version_index`: `<class 'int'>`
* `created_at`: `<class 'datetime.datetime'>`
* `name`: `<class 'str'>`
* `description`: `str | None`
* `dataset`: `<class 'str'>`
* `scorers`: `list[str]`
* `trials`: `<class 'int'>`
* `evaluation_name`: `str | None`
* `evaluate_op`: `str | None`
* `predict_and_score_op`: `str | None`
* `summarize_op`: `str | None`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L2907)

## <kbd>class</kbd> `EvaluationRunCreateBody`

**Pydantic Fields:**

* `evaluation`: `<class 'str'>`
* `model`: `<class 'str'>`
* `source_evaluation_run_id`: `str | None`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L2918)

## <kbd>class</kbd> `EvaluationRunCreateReq`

**Pydantic Fields:**

* `evaluation`: `<class 'str'>`
* `model`: `<class 'str'>`
* `source_evaluation_run_id`: `str | None`
* `project_id`: `<class 'str'>`
* `wb_user_id`: `str | None`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L2925)

## <kbd>class</kbd> `EvaluationRunCreateRes`

**Pydantic Fields:**

* `evaluation_run_id`: `<class 'str'>`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L2985)

## <kbd>class</kbd> `EvaluationRunDeleteReq`

**Pydantic Fields:**

* `project_id`: `<class 'str'>`
* `evaluation_run_ids`: `list[str]`
* `wb_user_id`: `str | None`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L2995)

## <kbd>class</kbd> `EvaluationRunDeleteRes`

**Pydantic Fields:**

* `num_deleted`: `<class 'int'>`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L2960)

## <kbd>class</kbd> `EvaluationRunFilter`

**Pydantic Fields:**

* `evaluations`: `list[str] | None`
* `models`: `list[str] | None`
* `evaluation_run_ids`: `list[str] | None`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L2999)

## <kbd>class</kbd> `EvaluationRunFinishBody`

Request body for finishing an evaluation run via REST API.

This model excludes project\_id and evaluation\_run\_id since they come from the URL path in RESTful endpoints.

**Pydantic Fields:**

* `summary`: `dict[str, typing.Any] | None`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3010)

## <kbd>class</kbd> `EvaluationRunFinishReq`

**Pydantic Fields:**

* `summary`: `dict[str, typing.Any] | None`
* `project_id`: `<class 'str'>`
* `evaluation_run_id`: `<class 'str'>`
* `wb_user_id`: `str | None`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3018)

## <kbd>class</kbd> `EvaluationRunFinishRes`

**Pydantic Fields:**

* `success`: `<class 'bool'>`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L2970)

## <kbd>class</kbd> `EvaluationRunListReq`

**Pydantic Fields:**

* `project_id`: `<class 'str'>`
* `filter`: `EvaluationRunFilter | None`
* `limit`: `int | None`
* `offset`: `int | None`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L2931)

## <kbd>class</kbd> `EvaluationRunReadReq`

**Pydantic Fields:**

* `project_id`: `<class 'str'>`
* `evaluation_run_id`: `<class 'str'>`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L2938)

## <kbd>class</kbd> `EvaluationRunReadRes`

**Pydantic Fields:**

* `evaluation_run_id`: `<class 'str'>`
* `evaluation`: `<class 'str'>`
* `model`: `<class 'str'>`
* `status`: `str | None`
* `started_at`: `datetime.datetime | None`
* `finished_at`: `datetime.datetime | None`
* `summary`: `dict[str, typing.Any] | None`
* `source_evaluation_run_id`: `str | None`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L2422)

## <kbd>class</kbd> `EvaluationStatusComplete`

**Pydantic Fields:**

* `code`: `typing.Literal['complete']`
* `output`: `dict[str, typing.Any]`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L2417)

## <kbd>class</kbd> `EvaluationStatusFailed`

**Pydantic Fields:**

* `code`: `typing.Literal['failed']`
* `error`: `str | None`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L2407)

## <kbd>class</kbd> `EvaluationStatusNotFound`

**Pydantic Fields:**

* `code`: `typing.Literal['not_found']`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L2402)

## <kbd>class</kbd> `EvaluationStatusReq`

**Pydantic Fields:**

* `project_id`: `<class 'str'>`
* `call_id`: `<class 'str'>`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L2427)

## <kbd>class</kbd> `EvaluationStatusRes`

**Pydantic Fields:**

* `status`: `EvaluationStatusNotFound | EvaluationStatusRunning | EvaluationStatusFailed | EvaluationStatusComplete`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L2411)

## <kbd>class</kbd> `EvaluationStatusRunning`

**Pydantic Fields:**

* `code`: `typing.Literal['running']`
* `completed_rows`: `<class 'int'>`
* `total_rows`: `<class 'int'>`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L380)

## <kbd>class</kbd> `ExportTracePartialSuccess`

**Pydantic Fields:**

* `rejected_spans`: `<class 'int'>`
* `error_message`: `<class 'str'>`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L47)

## <kbd>class</kbd> `ExtraKeysTypedDict`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L1281)

## <kbd>class</kbd> `Feedback`

**Pydantic Fields:**

* `id`: `<class 'str'>`
* `project_id`: `<class 'str'>`
* `weave_ref`: `<class 'str'>`
* `creator`: `str | None`
* `feedback_type`: `<class 'str'>`
* `payload`: `dict[str, typing.Any]`
* `annotation_ref`: `str | None`
* `runnable_ref`: `str | None`
* `call_ref`: `str | None`
* `trigger_ref`: `str | None`
* `queue_id`: `str | None`
* `scorer_tags`: `list[str]`
* `scorer_tag_reasons`: `dict[str, str]`
* `scorer_tag_confidences`: `dict[str, float]`
* `scorer_ratings`: `dict[str, float]`
* `scorer_rating_reasons`: `dict[str, str]`
* `scorer_rating_confidences`: `dict[str, float]`
* `span_agent_name`: `<class 'str'>`
* `span_agent_version`: `<class 'str'>`
* `span_status_code`: `<class 'str'>`
* `wb_user_id`: `str | None`
* `created_at`: `<class 'datetime.datetime'>`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L1585)

## <kbd>class</kbd> `FeedbackAggregateBucket`

One (time bucket, group) row of aggregated scorer feedback.

**Pydantic Fields:**

* `time_bucket_start_ms`: `int | None`
* `group`: `dict[str, str]`
* `total_count`: `<class 'int'>`
* `scored_count`: `<class 'int'>`
* `tag_counts`: `dict[str, int]`
* `rating_counts`: `dict[str, int]`
* `rating_sums`: `dict[str, float]`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L1495)

## <kbd>class</kbd> `FeedbackAggregateReq`

Query for aggregate scores by time bucket and dimension.

**Pydantic Fields:**

* `project_id`: `<class 'str'>`
* `after_ms`: `<class 'int'>`
* `before_ms`: `<class 'int'>`
* `time_bucket_seconds`: `int | None`
* `feedback_types`: `list[str]`
* `tags`: `list[str]`
* `rating_min`: `float | None`
* `rating_max`: `float | None`
* `monitor_ids`: `list[str]`
* `scorer_ids`: `list[str]`
* `span_agent_names`: `list[str]`
* `span_types`: `list[typing.Literal['agent_turn', 'agent_conversation']]`
* `group_by`: `list[typing.Literal['scorer_id', 'span_agent_name', 'span_agent_version', 'span_status_code']]`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L1618)

## <kbd>class</kbd> `FeedbackAggregateRes`

Sparse time-series of aggregated scorer feedback (empty buckets omitted).

**Pydantic Fields:**

* `time_bucket_seconds`: `int | None`
* `after_ms`: `<class 'int'>`
* `before_ms`: `<class 'int'>`
* `buckets`: `list[FeedbackAggregateBucket]`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L1322)

## <kbd>class</kbd> `FeedbackCreateBatchReq`

**Pydantic Fields:**

* `batch`: `list[FeedbackCreateReq]`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L1326)

## <kbd>class</kbd> `FeedbackCreateBatchRes`

**Pydantic Fields:**

* `res`: `list[FeedbackCreateRes]`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L1181)

## <kbd>class</kbd> `FeedbackCreateReq`

**Pydantic Fields:**

* `id`: `str | None`
* `project_id`: `<class 'str'>`
* `weave_ref`: `<class 'str'>`
* `creator`: `str | None`
* `feedback_type`: `<class 'str'>`
* `payload`: `dict[str, typing.Any]`
* `annotation_ref`: `str | None`
* `runnable_ref`: `str | None`
* `call_ref`: `str | None`
* `trigger_ref`: `str | None`
* `queue_id`: `str | None`
* `scorer_tags`: `list[str]`
* `scorer_tag_reasons`: `dict[str, str]`
* `scorer_tag_confidences`: `dict[str, float]`
* `scorer_ratings`: `dict[str, float]`
* `scorer_rating_reasons`: `dict[str, str]`
* `scorer_rating_confidences`: `dict[str, float]`
* `span_agent_name`: `<class 'str'>`
* `span_agent_version`: `<class 'str'>`
* `span_status_code`: `<class 'str'>`
* `wb_user_id`: `str | None`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L1274)

## <kbd>class</kbd> `FeedbackCreateRes`

**Pydantic Fields:**

* `id`: `<class 'str'>`
* `created_at`: `<class 'datetime.datetime'>`
* `wb_user_id`: `<class 'str'>`
* `payload`: `dict[str, typing.Any]`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L78)

## <kbd>class</kbd> `FeedbackDict`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L1353)

## <kbd>class</kbd> `FeedbackMetricSpec`

Specification for a feedback payload metric to aggregate.

**Pydantic Fields:**

* `json_path`: `<class 'str'>`
* `value_type`: `typing.Literal['numeric', 'boolean', 'categorical']`
* `aggregations`: `list[AggregationType]`
* `percentiles`: `list[float]`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L1637)

## <kbd>class</kbd> `FeedbackPayloadPath`

Discovered path in feedback payload with inferred type.

**Pydantic Fields:**

* `json_path`: `<class 'str'>`
* `value_type`: `typing.Literal['numeric', 'boolean', 'categorical']`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L1647)

## <kbd>class</kbd> `FeedbackPayloadSchemaReq`

Request for feedback payload schema discovery.

**Pydantic Fields:**

* `project_id`: `<class 'str'>`
* `start`: `<class 'datetime.datetime'>`
* `end`: `datetime.datetime | None`
* `feedback_type`: `str | None`
* `trigger_ref`: `str | None`
* `sample_limit`: `<class 'int'>`

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L1411)

### <kbd>method</kbd> `validate_date_range`

```python theme={"system"}
validate_date_range() → _FeedbackFilterBase
```

Ensure feedback requests are bounded to a safe date range.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L1664)

## <kbd>class</kbd> `FeedbackPayloadSchemaRes`

Response with discovered feedback payload paths and types.

**Pydantic Fields:**

* `paths`: `list[FeedbackPayloadPath]`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L1305)

## <kbd>class</kbd> `FeedbackPurgeReq`

**Pydantic Fields:**

* `project_id`: `<class 'str'>`
* `query`: `<class 'weave.trace_server.interface.query.Query'>`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L1310)

## <kbd>class</kbd> `FeedbackPurgeRes`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L1287)

## <kbd>class</kbd> `FeedbackQueryReq`

**Pydantic Fields:**

* `project_id`: `<class 'str'>`
* `fields`: `list[str] | None`
* `query`: `weave.trace_server.interface.query.Query | None`
* `sort_by`: `list[weave.trace_server.common_interface.SortBy] | None`
* `limit`: `int | None`
* `offset`: `int | None`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L1300)

## <kbd>class</kbd> `FeedbackQueryRes`

**Pydantic Fields:**

* `result`: `list[dict[str, typing.Any]]`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L1314)

## <kbd>class</kbd> `FeedbackReplaceReq`

**Pydantic Fields:**

* `id`: `str | None`
* `project_id`: `<class 'str'>`
* `weave_ref`: `<class 'str'>`
* `creator`: `str | None`
* `feedback_type`: `<class 'str'>`
* `payload`: `dict[str, typing.Any]`
* `annotation_ref`: `str | None`
* `runnable_ref`: `str | None`
* `call_ref`: `str | None`
* `trigger_ref`: `str | None`
* `queue_id`: `str | None`
* `scorer_tags`: `list[str]`
* `scorer_tag_reasons`: `dict[str, str]`
* `scorer_tag_confidences`: `dict[str, float]`
* `scorer_ratings`: `dict[str, float]`
* `scorer_rating_reasons`: `dict[str, str]`
* `scorer_rating_confidences`: `dict[str, float]`
* `span_agent_name`: `<class 'str'>`
* `span_agent_version`: `<class 'str'>`
* `span_status_code`: `<class 'str'>`
* `wb_user_id`: `str | None`
* `feedback_id`: `<class 'str'>`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L1318)

## <kbd>class</kbd> `FeedbackReplaceRes`

**Pydantic Fields:**

* `id`: `<class 'str'>`
* `created_at`: `<class 'datetime.datetime'>`
* `wb_user_id`: `<class 'str'>`
* `payload`: `dict[str, typing.Any]`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L1432)

## <kbd>class</kbd> `FeedbackStatsReq`

Request for aggregated feedback statistics over time buckets.

**Pydantic Fields:**

* `project_id`: `<class 'str'>`
* `start`: `<class 'datetime.datetime'>`
* `end`: `datetime.datetime | None`
* `feedback_type`: `str | None`
* `trigger_ref`: `str | None`
* `granularity`: `int | None`
* `timezone`: `<class 'str'>`
* `metrics`: `list[FeedbackMetricSpec]`

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L1411)

### <kbd>method</kbd> `validate_date_range`

```python theme={"system"}
validate_date_range() → _FeedbackFilterBase
```

Ensure feedback requests are bounded to a safe date range.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L1448)

## <kbd>class</kbd> `FeedbackStatsRes`

Response with time-series feedback statistics.

**Pydantic Fields:**

* `start`: `<class 'datetime.datetime'>`
* `end`: `<class 'datetime.datetime'>`
* `granularity`: `<class 'int'>`
* `timezone`: `<class 'str'>`
* `buckets`: `list[dict[str, typing.Any]]`
* `window_stats`: `dict[str, dict[str, float | None]] | None`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L1687)

## <kbd>class</kbd> `FileContentReadReq`

**Pydantic Fields:**

* `project_id`: `<class 'str'>`
* `digest`: `<class 'str'>`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L1696)

## <kbd>class</kbd> `FileContentReadRes`

**Pydantic Fields:**

* `content`: `<class 'bytes'>`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L1673)

## <kbd>class</kbd> `FileCreateReq`

**Pydantic Fields:**

* `project_id`: `<class 'str'>`
* `name`: `<class 'str'>`
* `content`: `<class 'bytes'>`
* `expected_digest`: `str | None`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L1683)

## <kbd>class</kbd> `FileCreateRes`

**Pydantic Fields:**

* `digest`: `<class 'str'>`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L1692)

## <kbd>class</kbd> `FilesStatsReq`

**Pydantic Fields:**

* `project_id`: `<class 'str'>`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L1700)

## <kbd>class</kbd> `FilesStatsRes`

**Pydantic Fields:**

* `total_size_bytes`: `<class 'int'>`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3716)

## <kbd>class</kbd> `FullTraceServerInterface`

Complete trace server interface supporting both V1 and Object APIs.

This protocol represents a trace server implementation that supports the full set of APIs - both legacy V1 endpoints and modern Object endpoints. Use this type for implementations that need to support both API versions.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3454)

### <kbd>method</kbd> `agent_agents_query`

```python theme={"system"}
agent_agents_query(req: AgentsQueryReq) → AgentsQueryRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3466)

### <kbd>method</kbd> `agent_conversation_chat`

```python theme={"system"}
agent_conversation_chat(
    req: AgentConversationChatReq
) → AgentConversationChatRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3469)

### <kbd>method</kbd> `agent_conversation_spans`

```python theme={"system"}
agent_conversation_spans(
    req: AgentConversationSpansReq
) → AgentConversationSpansRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3451)

### <kbd>method</kbd> `agent_custom_attrs_schema`

```python theme={"system"}
agent_custom_attrs_schema(
    req: AgentCustomAttrsSchemaReq
) → AgentCustomAttrsSchemaRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3460)

### <kbd>method</kbd> `agent_search`

```python theme={"system"}
agent_search(req: AgentSearchReq) → AgentSearchRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3445)

### <kbd>method</kbd> `agent_spans_query`

```python theme={"system"}
agent_spans_query(req: AgentSpansQueryReq) → AgentSpansQueryRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3448)

### <kbd>method</kbd> `agent_spans_stats`

```python theme={"system"}
agent_spans_stats(req: AgentSpanStatsReq) → AgentSpanStatsRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3463)

### <kbd>method</kbd> `agent_traces_chat`

```python theme={"system"}
agent_traces_chat(req: AgentTraceChatReq) → AgentTraceChatRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3457)

### <kbd>method</kbd> `agent_versions_query`

```python theme={"system"}
agent_versions_query(req: AgentVersionsQueryReq) → AgentVersionsQueryRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3504)

### <kbd>method</kbd> `aliases_list`

```python theme={"system"}
aliases_list(req: AliasesListReq) → AliasesListRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3595)

### <kbd>method</kbd> `annotation_queue_add_calls`

```python theme={"system"}
annotation_queue_add_calls(
    req: AnnotationQueueAddCallsReq
) → AnnotationQueueAddCallsRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3575)

### <kbd>method</kbd> `annotation_queue_create`

```python theme={"system"}
annotation_queue_create(
    req: AnnotationQueueCreateReq
) → AnnotationQueueCreateRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3587)

### <kbd>method</kbd> `annotation_queue_delete`

```python theme={"system"}
annotation_queue_delete(
    req: AnnotationQueueDeleteReq
) → AnnotationQueueDeleteRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3603)

### <kbd>method</kbd> `annotation_queue_items_query`

```python theme={"system"}
annotation_queue_items_query(
    req: AnnotationQueueItemsQueryReq
) → AnnotationQueueItemsQueryRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3583)

### <kbd>method</kbd> `annotation_queue_read`

```python theme={"system"}
annotation_queue_read(req: AnnotationQueueReadReq) → AnnotationQueueReadRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3591)

### <kbd>method</kbd> `annotation_queue_update`

```python theme={"system"}
annotation_queue_update(
    req: AnnotationQueueUpdateReq
) → AnnotationQueueUpdateRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3579)

### <kbd>method</kbd> `annotation_queues_query_stream`

```python theme={"system"}
annotation_queues_query_stream(
    req: AnnotationQueuesQueryReq
) → Iterator[AnnotationQueueSchema]
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3599)

### <kbd>method</kbd> `annotation_queues_stats`

```python theme={"system"}
annotation_queues_stats(
    req: AnnotationQueuesStatsReq
) → AnnotationQueuesStatsRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3607)

### <kbd>method</kbd> `annotator_queue_items_progress_update`

```python theme={"system"}
annotator_queue_items_progress_update(
    req: AnnotatorQueueItemsProgressUpdateReq
) → AnnotatorQueueItemsProgressUpdateRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3475)

### <kbd>method</kbd> `call_end`

```python theme={"system"}
call_end(req: CallEndReq) → CallEndRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3648)

### <kbd>method</kbd> `call_end_v2`

```python theme={"system"}
call_end_v2(req: CallEndV2Req) → CallEndV2Res
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3476)

### <kbd>method</kbd> `call_read`

```python theme={"system"}
call_read(req: CallReadReq) → CallReadRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3474)

### <kbd>method</kbd> `call_start`

```python theme={"system"}
call_start(req: CallStartReq) → CallStartRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3485)

### <kbd>method</kbd> `call_start_batch`

```python theme={"system"}
call_start_batch(req: CallCreateBatchReq) → CallCreateBatchRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3647)

### <kbd>method</kbd> `call_start_v2`

```python theme={"system"}
call_start_v2(req: CallStartV2Req) → CallStartV2Res
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3481)

### <kbd>method</kbd> `call_stats`

```python theme={"system"}
call_stats(req: 'CallStatsReq') → CallStatsRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3484)

### <kbd>method</kbd> `call_update`

```python theme={"system"}
call_update(req: CallUpdateReq) → CallUpdateRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3646)

### <kbd>method</kbd> `calls_complete`

```python theme={"system"}
calls_complete(req: CallsUpsertCompleteReq) → CallsUpsertCompleteRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3479)

### <kbd>method</kbd> `calls_delete`

```python theme={"system"}
calls_delete(req: CallsDeleteReq) → CallsDeleteRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3477)

### <kbd>method</kbd> `calls_query`

```python theme={"system"}
calls_query(req: CallsQueryReq) → CallsQueryRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3480)

### <kbd>method</kbd> `calls_query_stats`

```python theme={"system"}
calls_query_stats(req: CallsQueryStatsReq) → CallsQueryStatsRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3478)

### <kbd>method</kbd> `calls_query_stream`

```python theme={"system"}
calls_query_stream(req: CallsQueryReq) → Iterator[CallSchema]
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3634)

### <kbd>method</kbd> `calls_score`

```python theme={"system"}
calls_score(req: CallsScoreReq) → CallsScoreRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3483)

### <kbd>method</kbd> `calls_usage`

```python theme={"system"}
calls_usage(req: 'CallsUsageReq') → CallsUsageRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3544)

### <kbd>method</kbd> `completions_create`

```python theme={"system"}
completions_create(req: CompletionsCreateReq) → CompletionsCreateRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3550)

### <kbd>method</kbd> `completions_create_stream`

```python theme={"system"}
completions_create_stream(req: CompletionsCreateReq) → Iterator[dict[str, Any]]
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3488)

### <kbd>method</kbd> `cost_create`

```python theme={"system"}
cost_create(req: CostCreateReq) → CostCreateRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3490)

### <kbd>method</kbd> `cost_purge`

```python theme={"system"}
cost_purge(req: CostPurgeReq) → CostPurgeRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3489)

### <kbd>method</kbd> `cost_query`

```python theme={"system"}
cost_query(req: CostQueryReq) → CostQueryRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3657)

### <kbd>method</kbd> `dataset_create`

```python theme={"system"}
dataset_create(req: DatasetCreateReq) → DatasetCreateRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3660)

### <kbd>method</kbd> `dataset_delete`

```python theme={"system"}
dataset_delete(req: DatasetDeleteReq) → DatasetDeleteRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3659)

### <kbd>method</kbd> `dataset_list`

```python theme={"system"}
dataset_list(req: DatasetListReq) → Iterator[DatasetReadRes]
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3658)

### <kbd>method</kbd> `dataset_read`

```python theme={"system"}
dataset_read(req: DatasetReadReq) → DatasetReadRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3612)

### <kbd>method</kbd> `dataset_sources_link`

```python theme={"system"}
dataset_sources_link(req: DatasetSourcesLinkReq) → DatasetSourcesLinkRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3616)

### <kbd>method</kbd> `dataset_sources_link_delete`

```python theme={"system"}
dataset_sources_link_delete(
    req: DatasetSourcesLinkDeleteReq
) → DatasetSourcesLinkDeleteRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3620)

### <kbd>method</kbd> `dataset_sources_query`

```python theme={"system"}
dataset_sources_query(req: DatasetSourcesQueryReq) → DatasetSourcesQueryRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3713)

### <kbd>method</kbd> `eval_results_query`

```python theme={"system"}
eval_results_query(req: EvalResultsQueryReq) → EvalResultsQueryRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3629)

### <kbd>method</kbd> `evaluate_model`

```python theme={"system"}
evaluate_model(req: EvaluateModelReq) → EvaluateModelRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3669)

### <kbd>method</kbd> `evaluation_create`

```python theme={"system"}
evaluation_create(req: EvaluationCreateReq) → EvaluationCreateRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3674)

### <kbd>method</kbd> `evaluation_delete`

```python theme={"system"}
evaluation_delete(req: EvaluationDeleteReq) → EvaluationDeleteRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3671)

### <kbd>method</kbd> `evaluation_list`

```python theme={"system"}
evaluation_list(req: EvaluationListReq) → Iterator[EvaluationReadRes]
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3670)

### <kbd>method</kbd> `evaluation_read`

```python theme={"system"}
evaluation_read(req: EvaluationReadReq) → EvaluationReadRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3683)

### <kbd>method</kbd> `evaluation_run_create`

```python theme={"system"}
evaluation_run_create(req: EvaluationRunCreateReq) → EvaluationRunCreateRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3692)

### <kbd>method</kbd> `evaluation_run_delete`

```python theme={"system"}
evaluation_run_delete(req: EvaluationRunDeleteReq) → EvaluationRunDeleteRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3695)

### <kbd>method</kbd> `evaluation_run_finish`

```python theme={"system"}
evaluation_run_finish(req: EvaluationRunFinishReq) → EvaluationRunFinishRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3689)

### <kbd>method</kbd> `evaluation_run_list`

```python theme={"system"}
evaluation_run_list(req: EvaluationRunListReq) → Iterator[EvaluationRunReadRes]
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3686)

### <kbd>method</kbd> `evaluation_run_read`

```python theme={"system"}
evaluation_run_read(req: EvaluationRunReadReq) → EvaluationRunReadRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3630)

### <kbd>method</kbd> `evaluation_status`

```python theme={"system"}
evaluation_status(req: EvaluationStatusReq) → EvaluationStatusRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3538)

### <kbd>method</kbd> `feedback_aggregate`

```python theme={"system"}
feedback_aggregate(req: FeedbackAggregateReq) → FeedbackAggregateRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3529)

### <kbd>method</kbd> `feedback_create`

```python theme={"system"}
feedback_create(req: FeedbackCreateReq) → FeedbackCreateRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3530)

### <kbd>method</kbd> `feedback_create_batch`

```python theme={"system"}
feedback_create_batch(req: FeedbackCreateBatchReq) → FeedbackCreateBatchRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3539)

### <kbd>method</kbd> `feedback_payload_schema`

```python theme={"system"}
feedback_payload_schema(
    req: FeedbackPayloadSchemaReq
) → FeedbackPayloadSchemaRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3535)

### <kbd>method</kbd> `feedback_purge`

```python theme={"system"}
feedback_purge(req: FeedbackPurgeReq) → FeedbackPurgeRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3534)

### <kbd>method</kbd> `feedback_query`

```python theme={"system"}
feedback_query(req: FeedbackQueryReq) → FeedbackQueryRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3536)

### <kbd>method</kbd> `feedback_replace`

```python theme={"system"}
feedback_replace(req: FeedbackReplaceReq) → FeedbackReplaceRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3537)

### <kbd>method</kbd> `feedback_stats`

```python theme={"system"}
feedback_stats(req: FeedbackStatsReq) → FeedbackStatsRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3525)

### <kbd>method</kbd> `file_content_read`

```python theme={"system"}
file_content_read(req: FileContentReadReq) → FileContentReadRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3524)

### <kbd>method</kbd> `file_create`

```python theme={"system"}
file_create(req: FileCreateReq) → FileCreateRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3526)

### <kbd>method</kbd> `files_stats`

```python theme={"system"}
files_stats(req: FilesStatsReq) → FilesStatsRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3442)

### <kbd>method</kbd> `genai_otel_export`

```python theme={"system"}
genai_otel_export(req: GenAIOTelExportReq) → GenAIOTelExportRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3555)

### <kbd>method</kbd> `image_create`

```python theme={"system"}
image_create(req: ImageGenerationCreateReq) → ImageGenerationCreateRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3677)

### <kbd>method</kbd> `model_create`

```python theme={"system"}
model_create(req: ModelCreateReq) → ModelCreateRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3680)

### <kbd>method</kbd> `model_delete`

```python theme={"system"}
model_delete(req: ModelDeleteReq) → ModelDeleteRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3679)

### <kbd>method</kbd> `model_list`

```python theme={"system"}
model_list(req: ModelListReq) → Iterator[ModelReadRes]
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3678)

### <kbd>method</kbd> `model_read`

```python theme={"system"}
model_read(req: ModelReadReq) → ModelReadRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3499)

### <kbd>method</kbd> `obj_add_tags`

```python theme={"system"}
obj_add_tags(req: ObjAddTagsReq) → ObjAddTagsRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3493)

### <kbd>method</kbd> `obj_create`

```python theme={"system"}
obj_create(req: ObjCreateReq) → ObjCreateRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3496)

### <kbd>method</kbd> `obj_delete`

```python theme={"system"}
obj_delete(req: ObjDeleteReq) → ObjDeleteRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3494)

### <kbd>method</kbd> `obj_read`

```python theme={"system"}
obj_read(req: ObjReadReq) → ObjReadRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3502)

### <kbd>method</kbd> `obj_remove_aliases`

```python theme={"system"}
obj_remove_aliases(req: ObjRemoveAliasesReq) → ObjRemoveAliasesRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3500)

### <kbd>method</kbd> `obj_remove_tags`

```python theme={"system"}
obj_remove_tags(req: ObjRemoveTagsReq) → ObjRemoveTagsRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3501)

### <kbd>method</kbd> `obj_set_aliases`

```python theme={"system"}
obj_set_aliases(req: ObjSetAliasesReq) → ObjSetAliasesRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3495)

### <kbd>method</kbd> `objs_query`

```python theme={"system"}
objs_query(req: ObjQueryReq) → ObjQueryRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3651)

### <kbd>method</kbd> `op_create`

```python theme={"system"}
op_create(req: OpCreateReq) → OpCreateRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3654)

### <kbd>method</kbd> `op_delete`

```python theme={"system"}
op_delete(req: OpDeleteReq) → OpDeleteRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3653)

### <kbd>method</kbd> `op_list`

```python theme={"system"}
op_list(req: OpListReq) → Iterator[OpReadRes]
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3652)

### <kbd>method</kbd> `op_read`

```python theme={"system"}
op_read(req: OpReadReq) → OpReadRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3439)

### <kbd>method</kbd> `otel_export`

```python theme={"system"}
otel_export(req: OTelExportReq) → OTelExportRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3700)

### <kbd>method</kbd> `prediction_create`

```python theme={"system"}
prediction_create(req: PredictionCreateReq) → PredictionCreateRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3705)

### <kbd>method</kbd> `prediction_delete`

```python theme={"system"}
prediction_delete(req: PredictionDeleteReq) → PredictionDeleteRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3706)

### <kbd>method</kbd> `prediction_finish`

```python theme={"system"}
prediction_finish(req: PredictionFinishReq) → PredictionFinishRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3702)

### <kbd>method</kbd> `prediction_list`

```python theme={"system"}
prediction_list(req: PredictionListReq) → Iterator[PredictionReadRes]
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3701)

### <kbd>method</kbd> `prediction_read`

```python theme={"system"}
prediction_read(req: PredictionReadReq) → PredictionReadRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3560)

### <kbd>method</kbd> `project_stats`

```python theme={"system"}
project_stats(req: ProjectStatsReq) → ProjectStatsRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3563)

### <kbd>method</kbd> `project_ttl_settings_read`

```python theme={"system"}
project_ttl_settings_read(
    req: ProjectTTLSettingsReadReq
) → ProjectTTLSettingsReadRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3567)

### <kbd>method</kbd> `project_ttl_settings_update`

```python theme={"system"}
project_ttl_settings_update(
    req: ProjectTTLSettingsUpdateReq
) → ProjectTTLSettingsUpdateRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3521)

### <kbd>method</kbd> `refs_read_batch`

```python theme={"system"}
refs_read_batch(req: RefsReadBatchReq) → RefsReadBatchRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3631)

### <kbd>method</kbd> `rescore`

```python theme={"system"}
rescore(req: RescoreReq) → RescoreRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3709)

### <kbd>method</kbd> `score_create`

```python theme={"system"}
score_create(req: ScoreCreateReq) → ScoreCreateRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3712)

### <kbd>method</kbd> `score_delete`

```python theme={"system"}
score_delete(req: ScoreDeleteReq) → ScoreDeleteRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3711)

### <kbd>method</kbd> `score_list`

```python theme={"system"}
score_list(req: ScoreListReq) → Iterator[ScoreReadRes]
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3710)

### <kbd>method</kbd> `score_read`

```python theme={"system"}
score_read(req: ScoreReadReq) → ScoreReadRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3663)

### <kbd>method</kbd> `scorer_create`

```python theme={"system"}
scorer_create(req: ScorerCreateReq) → ScorerCreateRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3666)

### <kbd>method</kbd> `scorer_delete`

```python theme={"system"}
scorer_delete(req: ScorerDeleteReq) → ScorerDeleteRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3665)

### <kbd>method</kbd> `scorer_list`

```python theme={"system"}
scorer_list(req: ScorerListReq) → Iterator[ScorerReadRes]
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3664)

### <kbd>method</kbd> `scorer_read`

```python theme={"system"}
scorer_read(req: ScorerReadReq) → ScorerReadRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3624)

### <kbd>method</kbd> `source_datasets_query`

```python theme={"system"}
source_datasets_query(req: SourceDatasetsQueryReq) → SourceDatasetsQueryRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3507)

### <kbd>method</kbd> `table_create`

```python theme={"system"}
table_create(req: TableCreateReq) → TableCreateRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3508)

### <kbd>method</kbd> `table_create_from_digests`

```python theme={"system"}
table_create_from_digests(
    req: TableCreateFromDigestsReq
) → TableCreateFromDigestsRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3513)

### <kbd>method</kbd> `table_query`

```python theme={"system"}
table_query(req: TableQueryReq) → TableQueryRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3515)

### <kbd>method</kbd> `table_query_stats`

```python theme={"system"}
table_query_stats(req: TableQueryStatsReq) → TableQueryStatsRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3516)

### <kbd>method</kbd> `table_query_stats_batch`

```python theme={"system"}
table_query_stats_batch(req: TableQueryStatsBatchReq) → TableQueryStatsBatchRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3514)

### <kbd>method</kbd> `table_query_stream`

```python theme={"system"}
table_query_stream(req: TableQueryReq) → Iterator[TableRowSchema]
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3512)

### <kbd>method</kbd> `table_update`

```python theme={"system"}
table_update(req: TableUpdateReq) → TableUpdateRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3503)

### <kbd>method</kbd> `tags_list`

```python theme={"system"}
tags_list(req: TagsListReq) → TagsListRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3572)

### <kbd>method</kbd> `threads_query_stream`

```python theme={"system"}
threads_query_stream(req: ThreadsQueryReq) → Iterator[ThreadSchema]
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3482)

### <kbd>method</kbd> `trace_usage`

```python theme={"system"}
trace_usage(req: 'TraceUsageReq') → TraceUsageRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3024)

## <kbd>class</kbd> `GenAISpanRef`

**Pydantic Fields:**

* `trace_id`: `<class 'str'>`
* `span_id`: `<class 'str'>`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L582)

## <kbd>class</kbd> `ImageGenerationCreateReq`

**Pydantic Fields:**

* `project_id`: `<class 'str'>`
* `inputs`: `<class 'ImageGenerationRequestInputs'>`
* `wb_user_id`: `str | None`
* `track_llm_call`: `bool | None`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L592)

## <kbd>class</kbd> `ImageGenerationCreateRes`

**Pydantic Fields:**

* `response`: `dict[str, typing.Any]`
* `weave_call_id`: `str | None`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L576)

## <kbd>class</kbd> `ImageGenerationRequestInputs`

**Pydantic Fields:**

* `model`: `<class 'str'>`
* `prompt`: `<class 'str'>`
* `n`: `int | None`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3862)

## <kbd>class</kbd> `LLMAggregatedUsage`

Aggregated usage metrics for a specific LLM.

**Pydantic Fields:**

* `requests`: `<class 'int'>`
* `prompt_tokens`: `<class 'int'>`
* `completion_tokens`: `<class 'int'>`
* `total_tokens`: `<class 'int'>`
* `cache_read_input_tokens`: `<class 'int'>`
* `cache_creation_input_tokens`: `<class 'int'>`
* `prompt_tokens_total_cost`: `float | None`
* `completion_tokens_total_cost`: `float | None`
* `cache_read_input_tokens_total_cost`: `float | None`
* `cache_creation_input_tokens_total_cost`: `float | None`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L63)

## <kbd>class</kbd> `LLMCostSchema`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L52)

## <kbd>class</kbd> `LLMUsageSchema`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L2816)

## <kbd>class</kbd> `ModelCreateBody`

**Pydantic Fields:**

* `name`: `<class 'str'>`
* `description`: `str | None`
* `source_code`: `<class 'str'>`
* `attributes`: `dict[str, typing.Any] | None`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L2835)

## <kbd>class</kbd> `ModelCreateReq`

**Pydantic Fields:**

* `name`: `<class 'str'>`
* `description`: `str | None`
* `source_code`: `<class 'str'>`
* `attributes`: `dict[str, typing.Any] | None`
* `project_id`: `<class 'str'>`
* `wb_user_id`: `str | None`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L2842)

## <kbd>class</kbd> `ModelCreateRes`

**Pydantic Fields:**

* `digest`: `<class 'str'>`
* `object_id`: `<class 'str'>`
* `version_index`: `<class 'int'>`
* `model_ref`: `<class 'str'>`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L2888)

## <kbd>class</kbd> `ModelDeleteReq`

**Pydantic Fields:**

* `project_id`: `<class 'str'>`
* `object_id`: `<class 'str'>`
* `digests`: `list[str] | None`
* `wb_user_id`: `str | None`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L2900)

## <kbd>class</kbd> `ModelDeleteRes`

**Pydantic Fields:**

* `num_deleted`: `<class 'int'>`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L2878)

## <kbd>class</kbd> `ModelListReq`

**Pydantic Fields:**

* `project_id`: `<class 'str'>`
* `limit`: `int | None`
* `offset`: `int | None`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L2854)

## <kbd>class</kbd> `ModelReadReq`

**Pydantic Fields:**

* `project_id`: `<class 'str'>`
* `object_id`: `<class 'str'>`
* `digest`: `<class 'str'>`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L2862)

## <kbd>class</kbd> `ModelReadRes`

**Pydantic Fields:**

* `object_id`: `<class 'str'>`
* `digest`: `<class 'str'>`
* `version_index`: `<class 'int'>`
* `created_at`: `<class 'datetime.datetime'>`
* `name`: `<class 'str'>`
* `description`: `str | None`
* `source_code`: `<class 'str'>`
* `attributes`: `dict[str, typing.Any] | None`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L374)

## <kbd>class</kbd> `OTelExportReq`

**Pydantic Fields:**

* `processed_spans`: `list[ProcessedResourceSpans]`
* `project_id`: `<class 'str'>`
* `wb_user_id`: `str | None`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L387)

## <kbd>class</kbd> `OTelExportRes`

**Pydantic Fields:**

* `partial_success`: `ExportTracePartialSuccess | None`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L847)

## <kbd>class</kbd> `ObjAddTagsReq`

**Pydantic Fields:**

* `project_id`: `<class 'str'>`
* `object_id`: `<class 'str'>`
* `digest`: `<class 'str'>`
* `tags`: `list[str]`
* `wb_user_id`: `str | None`

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L854)

### <kbd>method</kbd> `validate_tags`

```python theme={"system"}
validate_tags() → ObjAddTagsReq
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L864)

## <kbd>class</kbd> `ObjAddTagsRes`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L720)

## <kbd>class</kbd> `ObjCreateReq`

**Pydantic Fields:**

* `obj`: `<class 'ObjSchemaForInsert'>`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L724)

## <kbd>class</kbd> `ObjCreateRes`

**Pydantic Fields:**

* `digest`: `<class 'str'>`
* `object_id`: `str | None`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L829)

## <kbd>class</kbd> `ObjDeleteReq`

**Pydantic Fields:**

* `project_id`: `<class 'str'>`
* `object_id`: `<class 'str'>`
* `digests`: `list[str] | None`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L838)

## <kbd>class</kbd> `ObjDeleteRes`

**Pydantic Fields:**

* `num_deleted`: `<class 'int'>`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L790)

## <kbd>class</kbd> `ObjQueryReq`

**Pydantic Fields:**

* `project_id`: `<class 'str'>`
* `filter`: `ObjectVersionFilter | None`
* `limit`: `int | None`
* `offset`: `int | None`
* `sort_by`: `list[weave.trace_server.common_interface.SortBy] | None`
* `metadata_only`: `bool | None`
* `include_storage_size`: `bool | None`
* `include_tags_and_aliases`: `bool | None`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L935)

## <kbd>class</kbd> `ObjQueryRes`

**Pydantic Fields:**

* `objs`: `list[ObjSchema]`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L729)

## <kbd>class</kbd> `ObjReadReq`

**Pydantic Fields:**

* `project_id`: `<class 'str'>`
* `object_id`: `<class 'str'>`
* `digest`: `<class 'str'>`
* `metadata_only`: `bool | None`
* `include_tags_and_aliases`: `bool | None`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L745)

## <kbd>class</kbd> `ObjReadRes`

**Pydantic Fields:**

* `obj`: `<class 'ObjSchema'>`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L899)

## <kbd>class</kbd> `ObjRemoveAliasesReq`

**Pydantic Fields:**

* `project_id`: `<class 'str'>`
* `object_id`: `<class 'str'>`
* `aliases`: `list[str]`
* `wb_user_id`: `str | None`

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L905)

### <kbd>method</kbd> `validate_aliases`

```python theme={"system"}
validate_aliases() → ObjRemoveAliasesReq
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L913)

## <kbd>class</kbd> `ObjRemoveAliasesRes`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L868)

## <kbd>class</kbd> `ObjRemoveTagsReq`

**Pydantic Fields:**

* `project_id`: `<class 'str'>`
* `object_id`: `<class 'str'>`
* `digest`: `<class 'str'>`
* `tags`: `list[str]`
* `wb_user_id`: `str | None`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L876)

## <kbd>class</kbd> `ObjRemoveTagsRes`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L315)

## <kbd>class</kbd> `ObjSchema`

**Pydantic Fields:**

* `project_id`: `<class 'str'>`
* `object_id`: `<class 'str'>`
* `created_at`: `<class 'datetime.datetime'>`
* `deleted_at`: `datetime.datetime | None`
* `digest`: `<class 'str'>`
* `version_index`: `<class 'int'>`
* `is_latest`: `<class 'int'>`
* `kind`: `<class 'str'>`
* `base_object_class`: `str | None`
* `leaf_object_class`: `str | None`
* `val`: `typing.Any`
* `wb_user_id`: `str | None`
* `size_bytes`: `int | None`
* `tags`: `list[str] | None`
* `aliases`: `list[str] | None`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L334)

## <kbd>class</kbd> `ObjSchemaForInsert`

**Pydantic Fields:**

* `project_id`: `<class 'str'>`
* `object_id`: `<class 'str'>`
* `val`: `typing.Any`
* `builtin_object_class`: `str | None`
* `set_base_object_class`: `str | None`
* `expected_digest`: `str | None`
* `wb_user_id`: `str | None`

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L351)

### <kbd>method</kbd> `model_post_init`

```python theme={"system"}
model_post_init(context: Any) → None
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L880)

## <kbd>class</kbd> `ObjSetAliasesReq`

**Pydantic Fields:**

* `project_id`: `<class 'str'>`
* `object_id`: `<class 'str'>`
* `digest`: `<class 'str'>`
* `aliases`: `list[str]`
* `wb_user_id`: `str | None`

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L887)

### <kbd>method</kbd> `validate_aliases`

```python theme={"system"}
validate_aliases() → ObjSetAliasesReq
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L895)

## <kbd>class</kbd> `ObjSetAliasesRes`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3637)

## <kbd>class</kbd> `ObjectInterface`

Object API endpoints for Trace Server.

This protocol contains object management APIs that provide cleaner, more RESTful interfaces. Implementations should support both this protocol and TraceServerInterface to maintain backward compatibility.

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3648)

### <kbd>method</kbd> `call_end_v2`

```python theme={"system"}
call_end_v2(req: CallEndV2Req) → CallEndV2Res
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3647)

### <kbd>method</kbd> `call_start_v2`

```python theme={"system"}
call_start_v2(req: CallStartV2Req) → CallStartV2Res
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3646)

### <kbd>method</kbd> `calls_complete`

```python theme={"system"}
calls_complete(req: CallsUpsertCompleteReq) → CallsUpsertCompleteRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3657)

### <kbd>method</kbd> `dataset_create`

```python theme={"system"}
dataset_create(req: DatasetCreateReq) → DatasetCreateRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3660)

### <kbd>method</kbd> `dataset_delete`

```python theme={"system"}
dataset_delete(req: DatasetDeleteReq) → DatasetDeleteRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3659)

### <kbd>method</kbd> `dataset_list`

```python theme={"system"}
dataset_list(req: DatasetListReq) → Iterator[DatasetReadRes]
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3658)

### <kbd>method</kbd> `dataset_read`

```python theme={"system"}
dataset_read(req: DatasetReadReq) → DatasetReadRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3713)

### <kbd>method</kbd> `eval_results_query`

```python theme={"system"}
eval_results_query(req: EvalResultsQueryReq) → EvalResultsQueryRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3669)

### <kbd>method</kbd> `evaluation_create`

```python theme={"system"}
evaluation_create(req: EvaluationCreateReq) → EvaluationCreateRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3674)

### <kbd>method</kbd> `evaluation_delete`

```python theme={"system"}
evaluation_delete(req: EvaluationDeleteReq) → EvaluationDeleteRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3671)

### <kbd>method</kbd> `evaluation_list`

```python theme={"system"}
evaluation_list(req: EvaluationListReq) → Iterator[EvaluationReadRes]
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3670)

### <kbd>method</kbd> `evaluation_read`

```python theme={"system"}
evaluation_read(req: EvaluationReadReq) → EvaluationReadRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3683)

### <kbd>method</kbd> `evaluation_run_create`

```python theme={"system"}
evaluation_run_create(req: EvaluationRunCreateReq) → EvaluationRunCreateRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3692)

### <kbd>method</kbd> `evaluation_run_delete`

```python theme={"system"}
evaluation_run_delete(req: EvaluationRunDeleteReq) → EvaluationRunDeleteRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3695)

### <kbd>method</kbd> `evaluation_run_finish`

```python theme={"system"}
evaluation_run_finish(req: EvaluationRunFinishReq) → EvaluationRunFinishRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3689)

### <kbd>method</kbd> `evaluation_run_list`

```python theme={"system"}
evaluation_run_list(req: EvaluationRunListReq) → Iterator[EvaluationRunReadRes]
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3686)

### <kbd>method</kbd> `evaluation_run_read`

```python theme={"system"}
evaluation_run_read(req: EvaluationRunReadReq) → EvaluationRunReadRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3677)

### <kbd>method</kbd> `model_create`

```python theme={"system"}
model_create(req: ModelCreateReq) → ModelCreateRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3680)

### <kbd>method</kbd> `model_delete`

```python theme={"system"}
model_delete(req: ModelDeleteReq) → ModelDeleteRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3679)

### <kbd>method</kbd> `model_list`

```python theme={"system"}
model_list(req: ModelListReq) → Iterator[ModelReadRes]
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3678)

### <kbd>method</kbd> `model_read`

```python theme={"system"}
model_read(req: ModelReadReq) → ModelReadRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3651)

### <kbd>method</kbd> `op_create`

```python theme={"system"}
op_create(req: OpCreateReq) → OpCreateRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3654)

### <kbd>method</kbd> `op_delete`

```python theme={"system"}
op_delete(req: OpDeleteReq) → OpDeleteRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3653)

### <kbd>method</kbd> `op_list`

```python theme={"system"}
op_list(req: OpListReq) → Iterator[OpReadRes]
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3652)

### <kbd>method</kbd> `op_read`

```python theme={"system"}
op_read(req: OpReadReq) → OpReadRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3700)

### <kbd>method</kbd> `prediction_create`

```python theme={"system"}
prediction_create(req: PredictionCreateReq) → PredictionCreateRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3705)

### <kbd>method</kbd> `prediction_delete`

```python theme={"system"}
prediction_delete(req: PredictionDeleteReq) → PredictionDeleteRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3706)

### <kbd>method</kbd> `prediction_finish`

```python theme={"system"}
prediction_finish(req: PredictionFinishReq) → PredictionFinishRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3702)

### <kbd>method</kbd> `prediction_list`

```python theme={"system"}
prediction_list(req: PredictionListReq) → Iterator[PredictionReadRes]
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3701)

### <kbd>method</kbd> `prediction_read`

```python theme={"system"}
prediction_read(req: PredictionReadReq) → PredictionReadRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3709)

### <kbd>method</kbd> `score_create`

```python theme={"system"}
score_create(req: ScoreCreateReq) → ScoreCreateRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3712)

### <kbd>method</kbd> `score_delete`

```python theme={"system"}
score_delete(req: ScoreDeleteReq) → ScoreDeleteRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3711)

### <kbd>method</kbd> `score_list`

```python theme={"system"}
score_list(req: ScoreListReq) → Iterator[ScoreReadRes]
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3710)

### <kbd>method</kbd> `score_read`

```python theme={"system"}
score_read(req: ScoreReadReq) → ScoreReadRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3663)

### <kbd>method</kbd> `scorer_create`

```python theme={"system"}
scorer_create(req: ScorerCreateReq) → ScorerCreateRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3666)

### <kbd>method</kbd> `scorer_delete`

```python theme={"system"}
scorer_delete(req: ScorerDeleteReq) → ScorerDeleteRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3665)

### <kbd>method</kbd> `scorer_list`

```python theme={"system"}
scorer_list(req: ScorerListReq) → Iterator[ScorerReadRes]
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3664)

### <kbd>method</kbd> `scorer_read`

```python theme={"system"}
scorer_read(req: ScorerReadReq) → ScorerReadRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L749)

## <kbd>class</kbd> `ObjectVersionFilter`

**Pydantic Fields:**

* `base_object_classes`: `list[str] | None`
* `exclude_base_object_classes`: `list[str] | None`
* `leaf_object_classes`: `list[str] | None`
* `object_ids`: `list[str] | None`
* `is_op`: `bool | None`
* `latest_only`: `bool | None`
* `tags`: `list[str] | None`
* `aliases`: `list[str] | None`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L2460)

## <kbd>class</kbd> `OpCreateBody`

Request body for creating an Op object via REST API.

This model excludes project\_id since it comes from the URL path in RESTful endpoints.

**Pydantic Fields:**

* `name`: `str | None`
* `source_code`: `str | None`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L2475)

## <kbd>class</kbd> `OpCreateReq`

Request model for creating an Op object.

Extends OpCreateBody by adding project\_id for internal API usage.

**Pydantic Fields:**

* `name`: `str | None`
* `source_code`: `str | None`
* `project_id`: `<class 'str'>`
* `wb_user_id`: `str | None`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L2487)

## <kbd>class</kbd> `OpCreateRes`

Response model for creating an Op object.

**Pydantic Fields:**

* `digest`: `<class 'str'>`
* `object_id`: `<class 'str'>`
* `version_index`: `<class 'int'>`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L2528)

## <kbd>class</kbd> `OpDeleteReq`

**Pydantic Fields:**

* `project_id`: `<class 'str'>`
* `object_id`: `<class 'str'>`
* `digests`: `list[str] | None`
* `wb_user_id`: `str | None`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L2540)

## <kbd>class</kbd> `OpDeleteRes`

**Pydantic Fields:**

* `num_deleted`: `<class 'int'>`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L2517)

## <kbd>class</kbd> `OpListReq`

**Pydantic Fields:**

* `project_id`: `<class 'str'>`
* `limit`: `int | None`
* `offset`: `int | None`
* `wb_user_id`: `str | None`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L2495)

## <kbd>class</kbd> `OpReadReq`

**Pydantic Fields:**

* `project_id`: `<class 'str'>`
* `object_id`: `<class 'str'>`
* `digest`: `<class 'str'>`
* `wb_user_id`: `str | None`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L2504)

## <kbd>class</kbd> `OpReadRes`

Response model for reading an Op object.

The code field contains the actual source code of the op.

**Pydantic Fields:**

* `object_id`: `<class 'str'>`
* `digest`: `<class 'str'>`
* `version_index`: `<class 'int'>`
* `created_at`: `<class 'datetime.datetime'>`
* `code`: `<class 'str'>`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3029)

## <kbd>class</kbd> `PredictionCreateBody`

Request body for creating a Prediction via REST API.

This model excludes project\_id since it comes from the URL path in RESTful endpoints.

**Pydantic Fields:**

* `model`: `<class 'str'>`
* `inputs`: `dict[str, typing.Any]`
* `output`: `typing.Any`
* `evaluation_run_id`: `str | None`
* `genai_span_ref`: `list[GenAISpanRef] | None`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3048)

## <kbd>class</kbd> `PredictionCreateReq`

Request model for creating a Prediction.

Extends PredictionCreateBody by adding project\_id for internal API usage.

**Pydantic Fields:**

* `model`: `<class 'str'>`
* `inputs`: `dict[str, typing.Any]`
* `output`: `typing.Any`
* `evaluation_run_id`: `str | None`
* `genai_span_ref`: `list[GenAISpanRef] | None`
* `project_id`: `<class 'str'>`
* `wb_user_id`: `str | None`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3060)

## <kbd>class</kbd> `PredictionCreateRes`

**Pydantic Fields:**

* `prediction_id`: `<class 'str'>`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3104)

## <kbd>class</kbd> `PredictionDeleteReq`

**Pydantic Fields:**

* `project_id`: `<class 'str'>`
* `prediction_ids`: `list[str]`
* `wb_user_id`: `str | None`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3112)

## <kbd>class</kbd> `PredictionDeleteRes`

**Pydantic Fields:**

* `num_deleted`: `<class 'int'>`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3116)

## <kbd>class</kbd> `PredictionFinishReq`

**Pydantic Fields:**

* `project_id`: `<class 'str'>`
* `prediction_id`: `<class 'str'>`
* `wb_user_id`: `str | None`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3124)

## <kbd>class</kbd> `PredictionFinishRes`

**Pydantic Fields:**

* `success`: `<class 'bool'>`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3083)

## <kbd>class</kbd> `PredictionListReq`

**Pydantic Fields:**

* `project_id`: `<class 'str'>`
* `evaluation_run_id`: `str | None`
* `limit`: `int | None`
* `offset`: `int | None`
* `wb_user_id`: `str | None`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3100)

## <kbd>class</kbd> `PredictionListRes`

**Pydantic Fields:**

* `predictions`: `list[PredictionReadRes]`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3064)

## <kbd>class</kbd> `PredictionReadReq`

**Pydantic Fields:**

* `project_id`: `<class 'str'>`
* `prediction_id`: `<class 'str'>`
* `wb_user_id`: `str | None`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3072)

## <kbd>class</kbd> `PredictionReadRes`

**Pydantic Fields:**

* `prediction_id`: `<class 'str'>`
* `model`: `<class 'str'>`
* `inputs`: `dict[str, typing.Any]`
* `output`: `typing.Any`
* `evaluation_run_id`: `str | None`
* `wb_user_id`: `str | None`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L366)

## <kbd>class</kbd> `ProcessedResourceSpans`

**Pydantic Fields:**

* `entity`: `<class 'str'>`
* `project`: `<class 'str'>`
* `run_id`: `str | None`
* `resource_spans`: `<class 'opentelemetry.proto.trace.v1.trace_pb2.ResourceSpans'>`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L1788)

## <kbd>class</kbd> `ProjectStatsReq`

**Pydantic Fields:**

* `project_id`: `<class 'str'>`
* `include_trace_storage_size`: `bool | None`
* `include_object_storage_size`: `bool | None`
* `include_table_storage_size`: `bool | None`
* `include_file_storage_size`: `bool | None`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L1796)

## <kbd>class</kbd> `ProjectStatsRes`

**Pydantic Fields:**

* `trace_storage_size_bytes`: `<class 'int'>`
* `objects_storage_size_bytes`: `<class 'int'>`
* `tables_storage_size_bytes`: `<class 'int'>`
* `files_storage_size_bytes`: `<class 'int'>`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L1807)

## <kbd>class</kbd> `ProjectTTLSettingsReadReq`

**Pydantic Fields:**

* `project_id`: `<class 'str'>`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L1811)

## <kbd>class</kbd> `ProjectTTLSettingsReadRes`

**Pydantic Fields:**

* `retention_days`: `int | None`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L1817)

## <kbd>class</kbd> `ProjectTTLSettingsUpdateReq`

**Pydantic Fields:**

* `project_id`: `<class 'str'>`
* `retention_days`: `int | None`
* `wb_user_id`: `str | None`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L1825)

## <kbd>class</kbd> `ProjectTTLSettingsUpdateRes`

**Pydantic Fields:**

* `retention_days`: `int | None`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L1173)

## <kbd>class</kbd> `RefsReadBatchReq`

**Pydantic Fields:**

* `refs`: `list[str]`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L1177)

## <kbd>class</kbd> `RefsReadBatchRes`

**Pydantic Fields:**

* `vals`: `list[typing.Any]`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L2373)

## <kbd>class</kbd> `RescoreBody`

Request body for rescoring via REST API (excludes server-set fields).

**Pydantic Fields:**

* `source_evaluation_run_id`: `<class 'str'>`
* `scorer_refs`: `list[str]`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L2386)

## <kbd>class</kbd> `RescoreReq`

Full rescore request including server-set fields.

**Pydantic Fields:**

* `source_evaluation_run_id`: `<class 'str'>`
* `scorer_refs`: `list[str]`
* `project_id`: `<class 'str'>`
* `wb_user_id`: `str | None`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L2393)

## <kbd>class</kbd> `RescoreRes`

Response for a rescore request.

**Pydantic Fields:**

* `call_id`: `<class 'str'>`
* `evaluation_run_id`: `<class 'str'>`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L2336)

## <kbd>class</kbd> `RescoringArgs`

Arguments for a rescore job dispatched to the evaluate-model worker.

Differs from EvaluateModelArgs: no model is loaded, no predictions are run. Only scorer(s) are applied to existing predictions from source\_evaluation\_run\_id.

**Pydantic Fields:**

* `job_type`: `typing.Literal['rescore']`
* `project_id`: `<class 'str'>`
* `source_evaluation_run_id`: `<class 'str'>`
* `scorer_refs`: `list[str]`
* `wb_user_id`: `str | None`
* `new_evaluation_run_id`: `<class 'str'>`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3130)

## <kbd>class</kbd> `ScoreCreateBody`

Request body for creating a Score via REST API.

This model excludes project\_id since it comes from the URL path in RESTful endpoints.

**Pydantic Fields:**

* `prediction_id`: `<class 'str'>`
* `scorer`: `<class 'str'>`
* `value`: `typing.Any`
* `evaluation_run_id`: `str | None`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3145)

## <kbd>class</kbd> `ScoreCreateReq`

Request model for creating a Score.

Extends ScoreCreateBody by adding project\_id for internal API usage.

**Pydantic Fields:**

* `prediction_id`: `<class 'str'>`
* `scorer`: `<class 'str'>`
* `value`: `typing.Any`
* `evaluation_run_id`: `str | None`
* `project_id`: `<class 'str'>`
* `wb_user_id`: `str | None`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3157)

## <kbd>class</kbd> `ScoreCreateRes`

**Pydantic Fields:**

* `score_id`: `<class 'str'>`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3194)

## <kbd>class</kbd> `ScoreDeleteReq`

**Pydantic Fields:**

* `project_id`: `<class 'str'>`
* `score_ids`: `list[str]`
* `wb_user_id`: `str | None`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3202)

## <kbd>class</kbd> `ScoreDeleteRes`

**Pydantic Fields:**

* `num_deleted`: `<class 'int'>`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3179)

## <kbd>class</kbd> `ScoreListReq`

**Pydantic Fields:**

* `project_id`: `<class 'str'>`
* `evaluation_run_id`: `str | None`
* `limit`: `int | None`
* `offset`: `int | None`
* `wb_user_id`: `str | None`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3161)

## <kbd>class</kbd> `ScoreReadReq`

**Pydantic Fields:**

* `project_id`: `<class 'str'>`
* `score_id`: `<class 'str'>`
* `wb_user_id`: `str | None`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3169)

## <kbd>class</kbd> `ScoreReadRes`

**Pydantic Fields:**

* `score_id`: `<class 'str'>`
* `scorer`: `<class 'str'>`
* `value`: `typing.Any`
* `evaluation_run_id`: `str | None`
* `wb_user_id`: `str | None`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L2624)

## <kbd>class</kbd> `ScorerCreateBody`

**Pydantic Fields:**

* `name`: `<class 'str'>`
* `description`: `str | None`
* `op_source_code`: `<class 'str'>`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L2639)

## <kbd>class</kbd> `ScorerCreateReq`

**Pydantic Fields:**

* `name`: `<class 'str'>`
* `description`: `str | None`
* `op_source_code`: `<class 'str'>`
* `project_id`: `<class 'str'>`
* `wb_user_id`: `str | None`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L2646)

## <kbd>class</kbd> `ScorerCreateRes`

**Pydantic Fields:**

* `digest`: `<class 'str'>`
* `object_id`: `<class 'str'>`
* `version_index`: `<class 'int'>`
* `scorer`: `<class 'str'>`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L2693)

## <kbd>class</kbd> `ScorerDeleteReq`

**Pydantic Fields:**

* `project_id`: `<class 'str'>`
* `object_id`: `<class 'str'>`
* `digests`: `list[str] | None`
* `wb_user_id`: `str | None`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L2705)

## <kbd>class</kbd> `ScorerDeleteRes`

**Pydantic Fields:**

* `num_deleted`: `<class 'int'>`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L2682)

## <kbd>class</kbd> `ScorerListReq`

**Pydantic Fields:**

* `project_id`: `<class 'str'>`
* `limit`: `int | None`
* `offset`: `int | None`
* `wb_user_id`: `str | None`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L2658)

## <kbd>class</kbd> `ScorerReadReq`

**Pydantic Fields:**

* `project_id`: `<class 'str'>`
* `object_id`: `<class 'str'>`
* `digest`: `<class 'str'>`
* `wb_user_id`: `str | None`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L2667)

## <kbd>class</kbd> `ScorerReadRes`

**Pydantic Fields:**

* `object_id`: `<class 'str'>`
* `digest`: `<class 'str'>`
* `version_index`: `<class 'int'>`
* `created_at`: `<class 'datetime.datetime'>`
* `name`: `<class 'str'>`
* `description`: `str | None`
* `score_op`: `<class 'str'>`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L2212)

## <kbd>class</kbd> `SourceDatasetMembership`

Membership of a single (source, dataset) pair in the reverse query.

**Pydantic Fields:**

* `source_kind`: `<enum 'SourceKind'>`
* `source_id`: `<class 'str'>`
* `source_trace_id`: `<class 'str'>`
* `dataset_object_id`: `<class 'str'>`
* `row_digests`: `list[str]`
* `row_digests_truncated`: `<class 'bool'>`
* `row_digests_total_count`: `<class 'int'>`
* `first_seen_at`: `<class 'datetime.datetime'>`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L2203)

## <kbd>class</kbd> `SourceDatasetsQueryReq`

Reverse query: sources -> datasets.

**Pydantic Fields:**

* `project_id`: `<class 'str'>`
* `sources`: `list[SourceRef]`
* `include_deleted`: `<class 'bool'>`
* `wb_user_id`: `str | None`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L2228)

## <kbd>class</kbd> `SourceDatasetsQueryRes`

Response from the reverse sources -> datasets query.

**Pydantic Fields:**

* `memberships`: `list[SourceDatasetMembership]`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L2087)

## <kbd>class</kbd> `SourceKind`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L2093)

## <kbd>class</kbd> `SourceRef`

Reference to a provenance source (a call, an agent span, or a conversation).

**Pydantic Fields:**

* `source_kind`: `<enum 'SourceKind'>`
* `source_id`: `<class 'str'>`
* `source_trace_id`: `<class 'str'>`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L186)

## <kbd>class</kbd> `StartedCallSchemaForInsert`

**Pydantic Fields:**

* `project_id`: `<class 'str'>`
* `id`: `str | None`
* `op_name`: `<class 'str'>`
* `display_name`: `str | None`
* `trace_id`: `str | None`
* `parent_id`: `str | None`
* `thread_id`: `str | None`
* `turn_id`: `str | None`
* `started_at`: `<class 'datetime.datetime'>`
* `attributes`: `dict[str, typing.Any]`
* `inputs`: `dict[str, typing.Any]`
* `otel_dump`: `dict[str, typing.Any] | None`
* `wb_user_id`: `str | None`
* `wb_run_id`: `str | None`
* `wb_run_step`: `int | None`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L104)

## <kbd>class</kbd> `SummaryInsertMap`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L109)

## <kbd>class</kbd> `SummaryMap`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L1011)

## <kbd>class</kbd> `TableAppendSpec`

**Pydantic Fields:**

* `append`: `<class 'TableAppendSpecPayload'>`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L1007)

## <kbd>class</kbd> `TableAppendSpecPayload`

**Pydantic Fields:**

* `row`: `dict[str, typing.Any]`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L943)

## <kbd>class</kbd> `TableCreateFromDigestsReq`

**Pydantic Fields:**

* `project_id`: `<class 'str'>`
* `row_digests`: `list[str]`
* `expected_digest`: `str | None`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L952)

## <kbd>class</kbd> `TableCreateFromDigestsRes`

**Pydantic Fields:**

* `digest`: `<class 'str'>`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L939)

## <kbd>class</kbd> `TableCreateReq`

**Pydantic Fields:**

* `table`: `<class 'TableSchemaForInsert'>`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L1063)

## <kbd>class</kbd> `TableCreateRes`

**Pydantic Fields:**

* `digest`: `<class 'str'>`
* `row_digests`: `list[str]`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L1028)

## <kbd>class</kbd> `TableInsertSpec`

**Pydantic Fields:**

* `insert`: `<class 'TableInsertSpecPayload'>`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L1023)

## <kbd>class</kbd> `TableInsertSpecPayload`

**Pydantic Fields:**

* `index`: `<class 'int'>`
* `row`: `dict[str, typing.Any]`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L1019)

## <kbd>class</kbd> `TablePopSpec`

**Pydantic Fields:**

* `pop`: `<class 'TablePopSpecPayload'>`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L1015)

## <kbd>class</kbd> `TablePopSpecPayload`

**Pydantic Fields:**

* `index`: `<class 'int'>`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L1092)

## <kbd>class</kbd> `TableQueryReq`

**Pydantic Fields:**

* `project_id`: `<class 'str'>`
* `digest`: `<class 'str'>`
* `filter`: `TableRowFilter | None`
* `limit`: `int | None`
* `offset`: `int | None`
* `sort_by`: `list[weave.trace_server.common_interface.SortBy] | None`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L1127)

## <kbd>class</kbd> `TableQueryRes`

**Pydantic Fields:**

* `rows`: `list[TableRowSchema]`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L1140)

## <kbd>class</kbd> `TableQueryStatsBatchReq`

**Pydantic Fields:**

* `project_id`: `<class 'str'>`
* `digests`: `list[str] | None`
* `include_storage_size`: `bool | None`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L1169)

## <kbd>class</kbd> `TableQueryStatsBatchRes`

**Pydantic Fields:**

* `tables`: `list[TableStatsRow]`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L1131)

## <kbd>class</kbd> `TableQueryStatsReq`

**Pydantic Fields:**

* `project_id`: `<class 'str'>`
* `digest`: `<class 'str'>`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L1159)

## <kbd>class</kbd> `TableQueryStatsRes`

**Pydantic Fields:**

* `count`: `<class 'int'>`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L1079)

## <kbd>class</kbd> `TableRowFilter`

**Pydantic Fields:**

* `row_digests`: `list[str] | None`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L1057)

## <kbd>class</kbd> `TableRowSchema`

**Pydantic Fields:**

* `digest`: `<class 'str'>`
* `val`: `typing.Any`
* `original_index`: `int | None`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L357)

## <kbd>class</kbd> `TableSchemaForInsert`

**Pydantic Fields:**

* `project_id`: `<class 'str'>`
* `rows`: `list[dict[str, typing.Any]]`
* `expected_digest`: `str | None`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L1163)

## <kbd>class</kbd> `TableStatsRow`

**Pydantic Fields:**

* `count`: `<class 'int'>`
* `digest`: `<class 'str'>`
* `storage_size_bytes`: `int | None`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L1035)

## <kbd>class</kbd> `TableUpdateReq`

**Pydantic Fields:**

* `project_id`: `<class 'str'>`
* `base_digest`: `<class 'str'>`
* `updates`: `list[TableAppendSpec | TablePopSpec | TableInsertSpec]`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L1041)

## <kbd>class</kbd> `TableUpdateRes`

**Pydantic Fields:**

* `digest`: `<class 'str'>`
* `updated_row_digests`: `list[str]`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L917)

## <kbd>class</kbd> `TagsListReq`

**Pydantic Fields:**

* `project_id`: `<class 'str'>`
* `wb_user_id`: `str | None`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L922)

## <kbd>class</kbd> `TagsListRes`

**Pydantic Fields:**

* `tags`: `list[str]`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L2237)

## <kbd>class</kbd> `ThreadSchema`

**Pydantic Fields:**

* `thread_id`: `<class 'str'>`
* `turn_count`: `<class 'int'>`
* `start_time`: `<class 'datetime.datetime'>`
* `last_updated`: `<class 'datetime.datetime'>`
* `first_turn_id`: `str | None`
* `last_turn_id`: `str | None`
* `p50_turn_duration_ms`: `float | None`
* `p99_turn_duration_ms`: `float | None`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L2260)

## <kbd>class</kbd> `ThreadsQueryFilter`

**Pydantic Fields:**

* `after_datetime`: `datetime.datetime | None`
* `before_datetime`: `datetime.datetime | None`
* `thread_ids`: `list[str] | None`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L2278)

## <kbd>class</kbd> `ThreadsQueryReq`

Query threads with aggregated statistics based on turn calls only.

Turn calls are the immediate children of thread contexts (where call.id == turn\_id). This provides meaningful conversation-level statistics rather than including all nested implementation details.

**Pydantic Fields:**

* `project_id`: `<class 'str'>`
* `filter`: `ThreadsQueryFilter | None`
* `limit`: `int | None`
* `offset`: `int | None`
* `sort_by`: `list[weave.trace_server.common_interface.SortBy] | None`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3437)

## <kbd>class</kbd> `TraceServerInterface`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3454)

### <kbd>method</kbd> `agent_agents_query`

```python theme={"system"}
agent_agents_query(req: AgentsQueryReq) → AgentsQueryRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3466)

### <kbd>method</kbd> `agent_conversation_chat`

```python theme={"system"}
agent_conversation_chat(
    req: AgentConversationChatReq
) → AgentConversationChatRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3469)

### <kbd>method</kbd> `agent_conversation_spans`

```python theme={"system"}
agent_conversation_spans(
    req: AgentConversationSpansReq
) → AgentConversationSpansRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3451)

### <kbd>method</kbd> `agent_custom_attrs_schema`

```python theme={"system"}
agent_custom_attrs_schema(
    req: AgentCustomAttrsSchemaReq
) → AgentCustomAttrsSchemaRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3460)

### <kbd>method</kbd> `agent_search`

```python theme={"system"}
agent_search(req: AgentSearchReq) → AgentSearchRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3445)

### <kbd>method</kbd> `agent_spans_query`

```python theme={"system"}
agent_spans_query(req: AgentSpansQueryReq) → AgentSpansQueryRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3448)

### <kbd>method</kbd> `agent_spans_stats`

```python theme={"system"}
agent_spans_stats(req: AgentSpanStatsReq) → AgentSpanStatsRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3463)

### <kbd>method</kbd> `agent_traces_chat`

```python theme={"system"}
agent_traces_chat(req: AgentTraceChatReq) → AgentTraceChatRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3457)

### <kbd>method</kbd> `agent_versions_query`

```python theme={"system"}
agent_versions_query(req: AgentVersionsQueryReq) → AgentVersionsQueryRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3504)

### <kbd>method</kbd> `aliases_list`

```python theme={"system"}
aliases_list(req: AliasesListReq) → AliasesListRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3595)

### <kbd>method</kbd> `annotation_queue_add_calls`

```python theme={"system"}
annotation_queue_add_calls(
    req: AnnotationQueueAddCallsReq
) → AnnotationQueueAddCallsRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3575)

### <kbd>method</kbd> `annotation_queue_create`

```python theme={"system"}
annotation_queue_create(
    req: AnnotationQueueCreateReq
) → AnnotationQueueCreateRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3587)

### <kbd>method</kbd> `annotation_queue_delete`

```python theme={"system"}
annotation_queue_delete(
    req: AnnotationQueueDeleteReq
) → AnnotationQueueDeleteRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3603)

### <kbd>method</kbd> `annotation_queue_items_query`

```python theme={"system"}
annotation_queue_items_query(
    req: AnnotationQueueItemsQueryReq
) → AnnotationQueueItemsQueryRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3583)

### <kbd>method</kbd> `annotation_queue_read`

```python theme={"system"}
annotation_queue_read(req: AnnotationQueueReadReq) → AnnotationQueueReadRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3591)

### <kbd>method</kbd> `annotation_queue_update`

```python theme={"system"}
annotation_queue_update(
    req: AnnotationQueueUpdateReq
) → AnnotationQueueUpdateRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3579)

### <kbd>method</kbd> `annotation_queues_query_stream`

```python theme={"system"}
annotation_queues_query_stream(
    req: AnnotationQueuesQueryReq
) → Iterator[AnnotationQueueSchema]
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3599)

### <kbd>method</kbd> `annotation_queues_stats`

```python theme={"system"}
annotation_queues_stats(
    req: AnnotationQueuesStatsReq
) → AnnotationQueuesStatsRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3607)

### <kbd>method</kbd> `annotator_queue_items_progress_update`

```python theme={"system"}
annotator_queue_items_progress_update(
    req: AnnotatorQueueItemsProgressUpdateReq
) → AnnotatorQueueItemsProgressUpdateRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3475)

### <kbd>method</kbd> `call_end`

```python theme={"system"}
call_end(req: CallEndReq) → CallEndRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3476)

### <kbd>method</kbd> `call_read`

```python theme={"system"}
call_read(req: CallReadReq) → CallReadRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3474)

### <kbd>method</kbd> `call_start`

```python theme={"system"}
call_start(req: CallStartReq) → CallStartRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3485)

### <kbd>method</kbd> `call_start_batch`

```python theme={"system"}
call_start_batch(req: CallCreateBatchReq) → CallCreateBatchRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3481)

### <kbd>method</kbd> `call_stats`

```python theme={"system"}
call_stats(req: 'CallStatsReq') → CallStatsRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3484)

### <kbd>method</kbd> `call_update`

```python theme={"system"}
call_update(req: CallUpdateReq) → CallUpdateRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3479)

### <kbd>method</kbd> `calls_delete`

```python theme={"system"}
calls_delete(req: CallsDeleteReq) → CallsDeleteRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3477)

### <kbd>method</kbd> `calls_query`

```python theme={"system"}
calls_query(req: CallsQueryReq) → CallsQueryRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3480)

### <kbd>method</kbd> `calls_query_stats`

```python theme={"system"}
calls_query_stats(req: CallsQueryStatsReq) → CallsQueryStatsRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3478)

### <kbd>method</kbd> `calls_query_stream`

```python theme={"system"}
calls_query_stream(req: CallsQueryReq) → Iterator[CallSchema]
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3634)

### <kbd>method</kbd> `calls_score`

```python theme={"system"}
calls_score(req: CallsScoreReq) → CallsScoreRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3483)

### <kbd>method</kbd> `calls_usage`

```python theme={"system"}
calls_usage(req: 'CallsUsageReq') → CallsUsageRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3544)

### <kbd>method</kbd> `completions_create`

```python theme={"system"}
completions_create(req: CompletionsCreateReq) → CompletionsCreateRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3550)

### <kbd>method</kbd> `completions_create_stream`

```python theme={"system"}
completions_create_stream(req: CompletionsCreateReq) → Iterator[dict[str, Any]]
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3488)

### <kbd>method</kbd> `cost_create`

```python theme={"system"}
cost_create(req: CostCreateReq) → CostCreateRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3490)

### <kbd>method</kbd> `cost_purge`

```python theme={"system"}
cost_purge(req: CostPurgeReq) → CostPurgeRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3489)

### <kbd>method</kbd> `cost_query`

```python theme={"system"}
cost_query(req: CostQueryReq) → CostQueryRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3612)

### <kbd>method</kbd> `dataset_sources_link`

```python theme={"system"}
dataset_sources_link(req: DatasetSourcesLinkReq) → DatasetSourcesLinkRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3616)

### <kbd>method</kbd> `dataset_sources_link_delete`

```python theme={"system"}
dataset_sources_link_delete(
    req: DatasetSourcesLinkDeleteReq
) → DatasetSourcesLinkDeleteRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3620)

### <kbd>method</kbd> `dataset_sources_query`

```python theme={"system"}
dataset_sources_query(req: DatasetSourcesQueryReq) → DatasetSourcesQueryRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3629)

### <kbd>method</kbd> `evaluate_model`

```python theme={"system"}
evaluate_model(req: EvaluateModelReq) → EvaluateModelRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3630)

### <kbd>method</kbd> `evaluation_status`

```python theme={"system"}
evaluation_status(req: EvaluationStatusReq) → EvaluationStatusRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3538)

### <kbd>method</kbd> `feedback_aggregate`

```python theme={"system"}
feedback_aggregate(req: FeedbackAggregateReq) → FeedbackAggregateRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3529)

### <kbd>method</kbd> `feedback_create`

```python theme={"system"}
feedback_create(req: FeedbackCreateReq) → FeedbackCreateRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3530)

### <kbd>method</kbd> `feedback_create_batch`

```python theme={"system"}
feedback_create_batch(req: FeedbackCreateBatchReq) → FeedbackCreateBatchRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3539)

### <kbd>method</kbd> `feedback_payload_schema`

```python theme={"system"}
feedback_payload_schema(
    req: FeedbackPayloadSchemaReq
) → FeedbackPayloadSchemaRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3535)

### <kbd>method</kbd> `feedback_purge`

```python theme={"system"}
feedback_purge(req: FeedbackPurgeReq) → FeedbackPurgeRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3534)

### <kbd>method</kbd> `feedback_query`

```python theme={"system"}
feedback_query(req: FeedbackQueryReq) → FeedbackQueryRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3536)

### <kbd>method</kbd> `feedback_replace`

```python theme={"system"}
feedback_replace(req: FeedbackReplaceReq) → FeedbackReplaceRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3537)

### <kbd>method</kbd> `feedback_stats`

```python theme={"system"}
feedback_stats(req: FeedbackStatsReq) → FeedbackStatsRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3525)

### <kbd>method</kbd> `file_content_read`

```python theme={"system"}
file_content_read(req: FileContentReadReq) → FileContentReadRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3524)

### <kbd>method</kbd> `file_create`

```python theme={"system"}
file_create(req: FileCreateReq) → FileCreateRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3526)

### <kbd>method</kbd> `files_stats`

```python theme={"system"}
files_stats(req: FilesStatsReq) → FilesStatsRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3442)

### <kbd>method</kbd> `genai_otel_export`

```python theme={"system"}
genai_otel_export(req: GenAIOTelExportReq) → GenAIOTelExportRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3555)

### <kbd>method</kbd> `image_create`

```python theme={"system"}
image_create(req: ImageGenerationCreateReq) → ImageGenerationCreateRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3499)

### <kbd>method</kbd> `obj_add_tags`

```python theme={"system"}
obj_add_tags(req: ObjAddTagsReq) → ObjAddTagsRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3493)

### <kbd>method</kbd> `obj_create`

```python theme={"system"}
obj_create(req: ObjCreateReq) → ObjCreateRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3496)

### <kbd>method</kbd> `obj_delete`

```python theme={"system"}
obj_delete(req: ObjDeleteReq) → ObjDeleteRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3494)

### <kbd>method</kbd> `obj_read`

```python theme={"system"}
obj_read(req: ObjReadReq) → ObjReadRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3502)

### <kbd>method</kbd> `obj_remove_aliases`

```python theme={"system"}
obj_remove_aliases(req: ObjRemoveAliasesReq) → ObjRemoveAliasesRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3500)

### <kbd>method</kbd> `obj_remove_tags`

```python theme={"system"}
obj_remove_tags(req: ObjRemoveTagsReq) → ObjRemoveTagsRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3501)

### <kbd>method</kbd> `obj_set_aliases`

```python theme={"system"}
obj_set_aliases(req: ObjSetAliasesReq) → ObjSetAliasesRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3495)

### <kbd>method</kbd> `objs_query`

```python theme={"system"}
objs_query(req: ObjQueryReq) → ObjQueryRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3439)

### <kbd>method</kbd> `otel_export`

```python theme={"system"}
otel_export(req: OTelExportReq) → OTelExportRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3560)

### <kbd>method</kbd> `project_stats`

```python theme={"system"}
project_stats(req: ProjectStatsReq) → ProjectStatsRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3563)

### <kbd>method</kbd> `project_ttl_settings_read`

```python theme={"system"}
project_ttl_settings_read(
    req: ProjectTTLSettingsReadReq
) → ProjectTTLSettingsReadRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3567)

### <kbd>method</kbd> `project_ttl_settings_update`

```python theme={"system"}
project_ttl_settings_update(
    req: ProjectTTLSettingsUpdateReq
) → ProjectTTLSettingsUpdateRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3521)

### <kbd>method</kbd> `refs_read_batch`

```python theme={"system"}
refs_read_batch(req: RefsReadBatchReq) → RefsReadBatchRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3631)

### <kbd>method</kbd> `rescore`

```python theme={"system"}
rescore(req: RescoreReq) → RescoreRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3624)

### <kbd>method</kbd> `source_datasets_query`

```python theme={"system"}
source_datasets_query(req: SourceDatasetsQueryReq) → SourceDatasetsQueryRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3507)

### <kbd>method</kbd> `table_create`

```python theme={"system"}
table_create(req: TableCreateReq) → TableCreateRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3508)

### <kbd>method</kbd> `table_create_from_digests`

```python theme={"system"}
table_create_from_digests(
    req: TableCreateFromDigestsReq
) → TableCreateFromDigestsRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3513)

### <kbd>method</kbd> `table_query`

```python theme={"system"}
table_query(req: TableQueryReq) → TableQueryRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3515)

### <kbd>method</kbd> `table_query_stats`

```python theme={"system"}
table_query_stats(req: TableQueryStatsReq) → TableQueryStatsRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3516)

### <kbd>method</kbd> `table_query_stats_batch`

```python theme={"system"}
table_query_stats_batch(req: TableQueryStatsBatchReq) → TableQueryStatsBatchRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3514)

### <kbd>method</kbd> `table_query_stream`

```python theme={"system"}
table_query_stream(req: TableQueryReq) → Iterator[TableRowSchema]
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3512)

### <kbd>method</kbd> `table_update`

```python theme={"system"}
table_update(req: TableUpdateReq) → TableUpdateRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3503)

### <kbd>method</kbd> `tags_list`

```python theme={"system"}
tags_list(req: TagsListReq) → TagsListRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3572)

### <kbd>method</kbd> `threads_query_stream`

```python theme={"system"}
threads_query_stream(req: ThreadsQueryReq) → Iterator[ThreadSchema]
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3482)

### <kbd>method</kbd> `trace_usage`

```python theme={"system"}
trace_usage(req: 'TraceUsageReq') → TraceUsageRes
```

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L88)

## <kbd>class</kbd> `TraceStatus`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3881)

## <kbd>class</kbd> `TraceUsageReq`

Request to compute per-call usage for a trace, with descendant rollup.

This endpoint returns usage metrics for each call in the trace, where each call's metrics include the sum of its own usage plus all descendants' usage. Use this for trace view where you want to see rolled-up metrics per call.

Note: All matching calls are loaded into memory for aggregation. For very large result sets (>10k calls), consider using more specific filters or pagination at the application layer.

**Pydantic Fields:**

* `project_id`: `<class 'str'>`
* `filter`: `CallsFilter | None`
* `query`: `weave.trace_server.interface.query.Query | None`
* `include_costs`: `<class 'bool'>`
* `limit`: `<class 'int'>`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3912)

## <kbd>class</kbd> `TraceUsageRes`

Response with per-call usage metrics (each includes descendant contributions).

**Pydantic Fields:**

* `call_usage`: `dict[str, dict[str, LLMAggregatedUsage]]`
* `unfinished_call_ids`: `list[str]`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L3755)

## <kbd>class</kbd> `UsageMetricSpec`

Specification for a usage metric to aggregate (grouped by model).

**Pydantic Fields:**

* `metric`: `typing.Literal['input_tokens', 'output_tokens', 'total_tokens', 'cache_read_input_tokens', 'cache_creation_input_tokens', 'input_cost', 'output_cost', 'total_cost']`
* `aggregations`: `list[AggregationType]`
* `percentiles`: `list[float]`

***

[Source](https://github.com/wandb/weave/blob/v0.53.1/weave/trace_server/trace_server_interface.py#L95)

## <kbd>class</kbd> `WeaveSummarySchema`
