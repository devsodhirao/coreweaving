> ## Documentation Index
> Fetch the complete documentation index at: https://docs.coreweave.com/llms.txt
> Use this file to discover all available pages before exploring further.

# Obj Set Aliases

> Set aliases for an object version.



## OpenAPI

````yaml products/wandb/weave/reference/service-api/openapi.json PUT /objs/{object_id}/aliases
openapi: 3.1.0
info:
  title: FastAPI
  version: 0.1.0
servers: []
security: []
paths:
  /objs/{object_id}/aliases:
    put:
      tags:
        - Objects
      summary: Obj Set Aliases
      description: Set aliases for an object version.
      operationId: obj_set_aliases_objs__object_id__aliases_put
      parameters:
        - name: object_id
          in: path
          required: true
          schema:
            type: string
            title: Object Id
      requestBody:
        required: true
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/ObjSetAliasesBody'
      responses:
        '200':
          description: Successful Response
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/ObjSetAliasesRes'
        '422':
          description: Validation Error
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/HTTPValidationError'
components:
  schemas:
    ObjSetAliasesBody:
      properties:
        project_id:
          type: string
          title: Project Id
          examples:
            - entity/project
        digest:
          type: string
          title: Digest
          examples:
            - abc123def
        aliases:
          items:
            type: string
          type: array
          title: Aliases
          examples:
            - - staging
              - v1-candidate
      type: object
      required:
        - project_id
        - digest
        - aliases
      title: ObjSetAliasesBody
      description: Request body for setting aliases (object_id comes from path).
    ObjSetAliasesRes:
      properties: {}
      type: object
      title: ObjSetAliasesRes
    HTTPValidationError:
      properties:
        detail:
          items:
            $ref: '#/components/schemas/ValidationError'
          type: array
          title: Detail
      type: object
      title: HTTPValidationError
    ValidationError:
      properties:
        loc:
          items:
            anyOf:
              - type: string
              - type: integer
          type: array
          title: Location
        msg:
          type: string
          title: Message
        type:
          type: string
          title: Error Type
        input:
          title: Input
        ctx:
          type: object
          title: Context
      type: object
      required:
        - loc
        - msg
        - type
      title: ValidationError

````