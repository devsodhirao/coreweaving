> ## Documentation Index
> Fetch the complete documentation index at: https://docs.coreweave.com/llms.txt
> Use this file to discover all available pages before exploring further.

# Dataset<R>

> TypeScript SDK reference

[GitHub source](https://github.com/wandb/weave/blob/7c9efdc9fe05ffcaf2430dd652ef9bc5b3ffdfaa/sdks/node/src/dataset.ts#L53)

Dataset object with easy saving and automatic versioning

## Example

```ts twoslash theme={"system"}
// @noErrors
// Create a dataset
const dataset = new Dataset({
  id: 'grammar-dataset',
  rows: [
    { id: '0', sentence: "He no likes ice cream.", correction: "He doesn't like ice cream." },
    { id: '1', sentence: "She goed to the store.", correction: "She went to the store." },
    { id: '2', sentence: "They plays video games all day.", correction: "They play video games all day." }
  ]
})

// Access a specific example
const exampleLabel = dataset.getRow(2).sentence;

// Save the dataset
const ref = await dataset.save()
```

## Extends

* [`WeaveObject`](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/classes/weaveobject)

## Type Parameters

**R** `extends DatasetRow`

## Constructor

> **new Dataset**\<`R`>(`parameters`): `Dataset`\<`R`>

### Parameters

**parameters** `object` *required*

**properties**

**description** `string`

**name** `string`

**rows** `R[]` *required*

### Returns

`Dataset`\<`R`>

### Overrides

[`WeaveObject`](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/classes/weaveobject).[`constructor`](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/classes/weaveobject#constructor)

## Properties

### \_\_savedRef

> `optional` **\_\_savedRef**: [`ObjectRef`](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/classes/objectref) | `Promise`\<[`ObjectRef`](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/classes/objectref)>

#### Inherited from

[`WeaveObject`](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/classes/weaveobject).[`__savedRef`](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/classes/weaveobject#__savedref)

***

### rows

> **rows**: `Table`\<`R`>

## Accessors

### description

#### Get Signature

> **get** **description**(): `string` | `undefined`

##### Returns

`string` | `undefined`

#### Inherited from

[`WeaveObject`](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/classes/weaveobject).[`description`](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/classes/weaveobject#description)

***

### length

#### Get Signature

> **get** **length**(): `number`

##### Returns

`number`

***

### name

#### Get Signature

> **get** **name**(): `string`

##### Returns

`string`

#### Inherited from

[`WeaveObject`](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/classes/weaveobject).[`name`](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/classes/weaveobject#name)

## Methods

### `[asyncIterator]()`

> **\[asyncIterator]**(): `AsyncIterator`\<`any`>

#### Returns

`AsyncIterator`\<`any`>

***

### getRow()

> **getRow**(`index`): `R`

#### Parameters

**index** `number` *required*

#### Returns

`R`

***

### save()

> **save**(): `Promise`\<[`ObjectRef`](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/classes/objectref)>

#### Returns

`Promise`\<[`ObjectRef`](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/classes/objectref)>

***

### saveAttrs()

> **saveAttrs**(): `object`

#### Returns

`object`

#### Inherited from

[`WeaveObject`](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/classes/weaveobject).[`saveAttrs`](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/classes/weaveobject#saveattrs)
