> ## Documentation Index
> Fetch the complete documentation index at: https://docs.coreweave.com/llms.txt
> Use this file to discover all available pages before exploring further.

# ObjectRef

> TypeScript SDK reference

[GitHub source](https://github.com/wandb/weave/blob/7c9efdc9fe05ffcaf2430dd652ef9bc5b3ffdfaa/sdks/node/src/weaveObject.ts#L24)

Represents a reference to a saved Weave object.

Generally, end users will not need to interact with this class directly.

An ObjectRef contains the project ID, object ID, and digest that uniquely identify
a saved object in Weave's storage system.

## Example

```ts twoslash theme={"system"}
// @noErrors
const ref = new ObjectRef('my-project', 'abc123', 'def456');
const uri = ref.uri(); // weave:///my-project/object/abc123:def456
```

## Constructor

> **new ObjectRef**(`projectId`, `objectId`, `digest`): `ObjectRef`

### Parameters

**projectId** `string` *required*

**objectId** `string` *required*

**digest** `string` *required*

### Returns

`ObjectRef`

## Properties

### digest

> **digest**: `string`

***

### objectId

> **objectId**: `string`

***

### projectId

> **projectId**: `string`

## Methods

### get()

> **get**(): `Promise`\<`any`>

#### Returns

`Promise`\<`any`>

***

### ui\_url()

> **ui\_url**(): `string`

#### Returns

`string`

***

### uri()

> **uri**(): `string`

#### Returns

`string`

***

### fromUri()

> `static` **fromUri**(`uri`): `ObjectRef`

Creates an ObjectRef from a Weave URI string.

#### Parameters

**uri** `string` *required*

A Weave URI in the format: weave:///entity/project/object/name:digest

#### Returns

`ObjectRef`

A new ObjectRef instance

#### Throws

Error if the URI format is invalid or not an object ref

#### Example

```ts twoslash theme={"system"}
// @noErrors
const ref = ObjectRef.fromUri('weave:///my-entity/my-project/object/my-dataset:abc123');
```
