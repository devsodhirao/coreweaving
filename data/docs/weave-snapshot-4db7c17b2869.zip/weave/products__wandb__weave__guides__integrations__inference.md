> ## Documentation Index
> Fetch the complete documentation index at: https://docs.coreweave.com/llms.txt
> Use this file to discover all available pages before exploring further.

# Serverless Inference

> Use Serverless Inference with Weave to trace and monitor open source foundation model calls through the OpenAI-compatible API.

# Serverless Inference

*Serverless Inference* provides access to open source foundation models through Weave and an OpenAI-compliant API. This guide describes how to call Serverless Inference from the API and the Weights & Biases UI, and how to trace, evaluate, and monitor those calls with Weave. With Serverless Inference, you can:

* Develop AI applications and agents without signing up for a hosting provider or self-hosting a model.
* Try the supported models in the Weave Playground.

> [!WARNING]
>
> Serverless Inference credits are included with Free, Pro, and Academic plans for a limited time. Availability may vary for Enterprise. After credits are consumed:
>
> * Free accounts must upgrade to a Pro plan to continue using Inference.
> * Pro plan users are billed for Inference overages on a monthly basis, based on the model-specific pricing.
>
> To learn more, see the [pricing page](https://coreweave.com/forge-pricing) and [Serverless Inference model costs](https://coreweave.com/forge-pricing/inference-agents).

Using Weave, you can trace, evaluate, monitor, and iterate on your Serverless Inference-powered applications.

| Model | Model ID (for API usage) | Types | Context Window | Parameters | Description |
| - | - | - | - | - | - |
| DeepSeek R1-0528 | deepseek-ai/DeepSeek-R1-0528 | Text | 161K | 37B - 680B (Active - Total) | Optimized for precise reasoning tasks including complex coding, math, and structured document analysis. |
| DeepSeek V3-0324 | deepseek-ai/DeepSeek-V3-0324 | Text | 161K | 37B - 680B (Active - Total) | Robust Mixture-of-Experts model tailored for high-complexity language processing and comprehensive document analysis. |
| Llama 3.1 8B | meta-llama/Llama-3.1-8B-Instruct | Text | 128K | 8B (Total) | Efficient conversational model optimized for responsive multilingual chatbot interactions. |
| Llama 3.3 70B | meta-llama/Llama-3.3-70B-Instruct | Text | 128K | 70B (Total) | Multilingual model excelling in conversational tasks, detailed instruction-following, and coding. |
| Llama 4 Scout | meta-llama/Llama-4-Scout-17B-16E-Instruct | Text, Vision | 64K | 17B - 109B (Active - Total) | Multimodal model integrating text and image understanding, ideal for visual tasks and combined analysis. |
| Phi 4 Mini | microsoft/Phi-4-mini-instruct | Text | 128K | 3.8B (Active - Total) | Compact, efficient model ideal for fast responses in resource-constrained environments. |

This guide provides the following information:

* [Prerequisites](#prerequisites)
  * [Additional prerequisites for using the API via Python](#additional-prerequisites-for-using-the-api-via-python)
* [API specification](#api-specification)
  * [Endpoint](#endpoint)
  * [Available methods](#available-methods)
    * [Chat completions](#chat-completions)
    * [List supported models](#list-supported-models)
* [Usage examples](#usage-examples)
* [UI](#ui)
  * [Access the Inference service](#access-the-inference-service)
  * [Try a model in the Playground](#try-a-model-in-the-playground)
  * [Compare multiple models](#compare-multiple-models)
  * [View billing and usage information](#view-billing-and-usage-information)
* [Usage information and limits](#usage-information-and-limits)
* [API errors](#api-errors)

## Prerequisites

Before you can access the Serverless Inference service through the API or the Weights & Biases UI, you must have the following:

1. A CoreWeave Forge account. [Sign up for an account](https://id.coreweave.com/signup).
2. An API key. Create an API key at [User settings](https://forge.coreweave.com/settings).
3. A Weights & Biases project.
4. If you're using the Inference service through Python, see [Additional prerequisites for using the API via Python](#additional-prerequisites-for-using-the-api-via-python).

### Additional prerequisites for using the API via Python

To use the Inference API through Python, first complete the general prerequisites. Then, install the `openai` and `weave` libraries in your local environment. The `openai` library provides the OpenAI-compatible client that you use to call the Inference endpoint, and the `weave` library lets you trace and evaluate those calls.

```bash theme={"system"}
pip install openai weave
```

> [!NOTE]
>
> The `weave` library is only required if you use Weave to trace your LLM applications. For information about getting started with Weave, see the [Weave Quickstart](https://docs.coreweave.com/products/wandb/weave/quickstart.md).
>
> For usage examples demonstrating how to use the Serverless Inference service with Weave, see the [API usage examples](#usage-examples).

## API specification

The following sections provide API specification information and API usage examples, so you can call the Inference service programmatically from your own application or scripts.

* [Endpoint](#endpoint)
* [Available methods](#available-methods)
* [Usage examples](#usage-examples)

### Endpoint

Access the Inference service through the following endpoint:

```plaintext theme={"system"}
https://api.inference.wandb.ai/v1
```

> [!WARNING]
>
> To access this endpoint, you must have a CoreWeave Forge account with Inference service credits allocated, a valid API key, and a CoreWeave Forge entity (also referred to as "team") and project. In the code samples in this guide, entity (team) and project are referred to as `<your-team>/<your-project>`.

### Available methods

The Inference service supports the following API methods:

* [Chat completions](#chat-completions)
* [List supported models](#list-supported-models)

#### Chat completions

The primary API method available is `/chat/completions`, which supports OpenAI-compatible request formats for sending messages to a supported model and receiving a completion. For usage examples demonstrating how to use the Serverless Inference service with Weave, see the [API usage examples](#usage-examples).

To create a chat completion, you need:

* The Inference service base URL `https://api.inference.wandb.ai/v1`
* Your Forge API Key `<your-api-key>`
* Your Weights & Biases team and project names `<your-team>/<your-project>`
* The ID for the model you want to use, one of:
  * `meta-llama/Llama-3.1-8B-Instruct`
  * `deepseek-ai/DeepSeek-V3-0324`
  * `meta-llama/Llama-3.3-70B-Instruct`
  * `deepseek-ai/DeepSeek-R1-0528`
  * `meta-llama/Llama-4-Scout-17B-16E-Instruct`
  * `microsoft/Phi-4-mini-instruct`

**Bash**

```bash theme={"system"}
curl https://api.inference.wandb.ai/v1/chat/completions \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer <your-api-key>" \
  -H "OpenAI-Project: <your-team>/<your-project>" \
  -d '{
    "model": "<model-id>",
    "messages": [
      { "role": "system", "content": "You are a helpful assistant." },
      { "role": "user", "content": "Tell me a joke." }
    ]
  }'
```

**Python**

```python lines theme={"system"}
import openai

client = openai.OpenAI(
    # The custom base URL points to Serverless Inference
    base_url='https://api.inference.wandb.ai/v1',

    # Create an API key at https://forge.coreweave.com/settings
    # Consider setting it in the environment as OPENAI_API_KEY instead for safety
    api_key="<your-api-key>",

    # Team and project are required for usage tracking
    project="<your-team>/<your-project>",
)

# Replace <model-id> with any of the following values:
# meta-llama/Llama-3.1-8B-Instruct
# deepseek-ai/DeepSeek-V3-0324
# meta-llama/Llama-3.3-70B-Instruct
# deepseek-ai/DeepSeek-R1-0528
# meta-llama/Llama-4-Scout-17B-16E-Instruct
# microsoft/Phi-4-mini-instruct

response = client.chat.completions.create(
    model="<model-id>",
    messages=[
        {"role": "system", "content": "<your-system-prompt>"},
        {"role": "user", "content": "<your-prompt>"}
    ],
)

print(response.choices[0].message.content)
```

#### List supported models

Use the API to query all available models and their IDs. This is useful for selecting models dynamically or inspecting what's available in your environment.

**Bash**

```bash theme={"system"}
curl https://api.inference.wandb.ai/v1/models \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer <your-api-key>" \
  -H "OpenAI-Project: <your-team>/<your-project>" \
```

**Python**

```python lines theme={"system"}
import openai

client = openai.OpenAI(
    base_url="https://api.inference.wandb.ai/v1",
    api_key="<your-api-key>",
    project="<your-team>/<your-project>"
)

response = client.models.list()

for model in response.data:
    print(model.id)
```

## Usage examples

The following sections provide several examples demonstrating how to use Serverless Inference with Weave. Start with the basic example to trace a single model call, then move on to the advanced example to evaluate and compare multiple models.

* [Basic example: Trace Llama 3.1 8B with Weave](#basic-example-trace-llama-31-8b-with-weave)
* [Advanced example: Use Weave Evaluations and Leaderboards with the Inference service](#advanced-example-use-weave-evaluations-and-leaderboards-with-the-inference-service)

### Basic example: Trace Llama 3.1 8B with Weave

The following Python code sample shows how to send a prompt to the **Llama 3.1 8B** model using the Serverless Inference API and trace the call in Weave. Tracing lets you capture the full input and output of the LLM call, monitor performance, and analyze results in the Weights & Biases UI.

> [!TIP]
>
> Learn more about [tracing in Weave](https://docs.coreweave.com/products/wandb/weave/guides/tracking/tracing.md).

In this example:

* You define a `@weave.op()`-decorated function, `run_chat`, which makes a chat completion request using the OpenAI-compatible client.
* Weave records your traces and associates them with your Weights & Biases entity and project `project="<your-team>/<your-project>"`.
* Weave automatically traces the function, logging its inputs, outputs, latency, and metadata (like model ID).
* The result prints in the terminal, and the trace appears in your **Traces** tab at [Forge](https://forge.coreweave.com/wandb) under the specified project.

To use this example, you must complete the [general prerequisites](#prerequisites) and [Additional prerequisites for using the API via Python](#additional-prerequisites-for-using-the-api-via-python).

```python lines theme={"system"}
import weave
import openai

# Set the Weave team and project for tracing
weave.init("<your-team>/<your-project>")

client = openai.OpenAI(
    base_url='https://api.inference.wandb.ai/v1',

    # Create an API key at https://forge.coreweave.com/settings
    api_key="<your-api-key>",

    # Required for W&B inference usage tracking
    project="wandb/inference-demo",
)

# Trace the model call in Weave
@weave.op()
def run_chat():
    response = client.chat.completions.create(
        model="meta-llama/Llama-3.1-8B-Instruct",
        messages=[
            {"role": "system", "content": "You are a helpful assistant."},
            {"role": "user", "content": "Tell me a joke."}
        ],
    )
    return response.choices[0].message.content

# Run and log the traced call
output = run_chat()
print(output)
```

After you run the code sample, the model response prints in the terminal and the call is logged as a Weave trace. To view the trace in Weave, click the link printed in the terminal (for example, `https://forge.coreweave.com/wandb/<your-team>/<your-project>/r/call/01977f8f-839d-7dda-b0c2-27292ef0e04g`), or:

1. Navigate to [Forge](https://forge.coreweave.com/wandb).
2. Select the **Traces** tab to view your Weave traces.

Next, try the [advanced example](#advanced-example-use-weave-evaluations-and-leaderboards-with-the-inference-service) to evaluate and compare multiple models.

![Traces display](https://mintcdn.com/coreweave-dbfa0e8d/3Dv_sw2eg8feUJlx/products/wandb/weave/_media/image.png?fit=max\&auto=format\&n=3Dv_sw2eg8feUJlx\&q=85\&s=e62dbcb98b9c4d5f219a59502d0525ce)

### Advanced example: Use Weave Evaluations and Leaderboards with the Inference service

Also, you can use Weave with the Inference service to [trace model calls](https://docs.coreweave.com/products/wandb/weave/guides/tracking/tracing.md), [evaluate performance](https://docs.coreweave.com/products/wandb/weave/guides/core-types/evaluations.md), and [publish a leaderboard](https://docs.coreweave.com/products/wandb/weave/guides/core-types/leaderboards.md). The following Python code sample compares two models on a question-answer dataset.

To use this example, you must complete the [general prerequisites](#prerequisites) and [Additional prerequisites for using the API via Python](#additional-prerequisites-for-using-the-api-via-python).

```python lines theme={"system"}
import os
import asyncio
import openai
import weave
from weave.flow import leaderboard
from weave.trace.ref_util import get_ref

# Set the Weave team and project for tracing
weave.init("<your-team>/<your-project>")

dataset = [
    {"input": "What is 2 + 2?", "target": "4"},
    {"input": "Name a primary color.", "target": "red"},
]

@weave.op
def exact_match(target: str, output: str) -> float:
    return float(target.strip().lower() == output.strip().lower())

class WBInferenceModel(weave.Model):
    model: str

    @weave.op
    def predict(self, prompt: str) -> str:
        client = openai.OpenAI(
            base_url="https://api.inference.wandb.ai/v1",
            # Create an API key at https://forge.coreweave.com/settings
            api_key="<your-api-key>",
            # Required for W&B inference usage tracking
            project="<your-team>/<your-project>",
        )
        resp = client.chat.completions.create(
            model=self.model,
            messages=[{"role": "user", "content": prompt}],
        )
        return resp.choices[0].message.content

llama = WBInferenceModel(model="meta-llama/Llama-3.1-8B-Instruct")
deepseek = WBInferenceModel(model="deepseek-ai/DeepSeek-V3-0324")

def preprocess_model_input(example):
    return {"prompt": example["input"]}

evaluation = weave.Evaluation(
    name="QA",
    dataset=dataset,
    scorers=[exact_match],
    preprocess_model_input=preprocess_model_input,
)

async def run_eval():
    await evaluation.evaluate(llama)
    await evaluation.evaluate(deepseek)

asyncio.run(run_eval())

spec = leaderboard.Leaderboard(
    name="Inference Leaderboard",
    description="Compare models on a QA dataset",
    columns=[
        leaderboard.LeaderboardColumn(
            evaluation_object_ref=get_ref(evaluation).uri(),
            scorer_name="exact_match",
            summary_metric_path="mean",
        )
    ],
)

weave.publish(spec)
```

After you run the preceding code sample, Weave publishes the evaluation results, traces, and a leaderboard comparing the two models to your Weights & Biases project. To view the published results, navigate to your CoreWeave Forge account at [Forge](https://forge.coreweave.com/wandb) and:

* Navigate to the **Traces** tab to [view your traces](https://docs.coreweave.com/products/wandb/weave/guides/tracking/tracing.md).
* Navigate to the **Evals** tab to [view your model evaluations](https://docs.coreweave.com/products/wandb/weave/guides/core-types/evaluations.md).
* Navigate to the **Leaders** tab to [view the generated leaderboard](https://docs.coreweave.com/products/wandb/weave/guides/core-types/leaderboards.md).

![View your model evaluations](https://mintcdn.com/coreweave-dbfa0e8d/3Dv_sw2eg8feUJlx/products/wandb/weave/_media/inference-advanced-evals.png?fit=max\&auto=format\&n=3Dv_sw2eg8feUJlx\&q=85\&s=e061ec7b108e3c11c3f3e7317efbb88a)

![View your traces](https://mintcdn.com/coreweave-dbfa0e8d/3Dv_sw2eg8feUJlx/products/wandb/weave/_media/inference-advanced-leaderboard.png?fit=max\&auto=format\&n=3Dv_sw2eg8feUJlx\&q=85\&s=684b9ee5f6caa5f29001ef6879a8a3a4)

## UI

The following sections describe how to use the Inference service from the Weights & Biases UI. Before you can access the Inference service through the UI, complete the [prerequisites](#prerequisites).

### Access the Inference service

You can access the Inference service through the Weights & Biases UI from the following locations:

* [Direct link](#direct-link)
* [From the Inference tab](#from-the-inference-tab)
* [From the Playground tab](#from-the-playground-tab)

#### Direct link

Navigate to [https://forge.coreweave.com/inference](https://forge.coreweave.com/inference).

#### From the Inference tab

1. Navigate to your CoreWeave Forge account at [Forge](https://forge.coreweave.com/wandb).
2. From the left sidebar, select **Inference**. A page with available models and model information displays.

![The Inference tab](https://mintcdn.com/coreweave-dbfa0e8d/3Dv_sw2eg8feUJlx/products/wandb/weave/_media/inference-ui.png?fit=max\&auto=format\&n=3Dv_sw2eg8feUJlx\&q=85\&s=e0c2c250b24d34d8a30b051c218f31e1)

#### From the Playground tab

1. From the left sidebar, select **Playground**. The Playground chat UI displays.
2. From the LLM dropdown list, hover over **Serverless Inference**. A dropdown with available Serverless Inference models displays to the right.
3. From the Serverless Inference models dropdown, you can:
   * Click the name of any available model to [try it in the Playground](#try-a-model-in-the-playground).
   * [Compare one or more models in the Playground](#compare-multiple-models).

![The Inference models dropdown in Playground](https://mintcdn.com/coreweave-dbfa0e8d/3Dv_sw2eg8feUJlx/products/wandb/weave/_media/inference-playground.png?fit=max\&auto=format\&n=3Dv_sw2eg8feUJlx\&q=85\&s=fb4a720587be9f394a3412359035a455)

### Try a model in the Playground

After you've [selected a model using one of the access options](#access-the-inference-service), you can try the model in Playground. The following actions are available:

* [Customize model settings and parameters](https://docs.coreweave.com/products/wandb/weave/guides/tools/playground.md#customize-settings)
* [Add, retry, edit, and delete messages](https://docs.coreweave.com/products/wandb/weave/guides/tools/playground.md#message-controls)
* [Save and reuse a model with custom settings](https://docs.coreweave.com/products/wandb/weave/guides/tools/playground.md#saved-models)
* [Compare multiple models](#compare-multiple-models)

![Using an Inference model in the Playground](https://mintcdn.com/coreweave-dbfa0e8d/3Dv_sw2eg8feUJlx/products/wandb/weave/_media/inference-playground-single.png?fit=max\&auto=format\&n=3Dv_sw2eg8feUJlx\&q=85\&s=0538245f8e737d2e1673073bce9a138a)

### Compare multiple models

You can compare multiple Inference models in the Playground. Access the Compare view from two different locations:

* [Access the Compare view from the Inference tab](#access-the-compare-view-from-the-inference-tab)
* [Access the Compare view from the Playground tab](#access-the-compare-view-from-the-playground-tab)

#### Access the Compare view from the Inference tab

1. From the left sidebar, select **Inference**. A page with available models and model information displays.
2. To select models for comparison, click anywhere on a model card (except for the model name). The border of the model card highlights in blue to indicate the selection.
3. Repeat step 2 for each model you want to compare.
4. In any of the selected cards, click the **Compare N models in the Playground** button (`N` is the number of models you're comparing. For example, when you select 3 models, the button displays as **Compare 3 models in the Playground**). The comparison view opens.

Now, you can compare models in the Playground, and use any of the features described in [Try a model in the Playground](#try-a-model-in-the-playground).

![Select multiple models to compare in Playground](https://mintcdn.com/coreweave-dbfa0e8d/3Dv_sw2eg8feUJlx/products/wandb/weave/_media/inference-playground-compare.png?fit=max\&auto=format\&n=3Dv_sw2eg8feUJlx\&q=85\&s=4b1de6f67c713c26d7ac0eeaa3bc84ee)

#### Access the Compare view from the Playground tab

1. From the left sidebar, select **Playground**. The Playground chat UI displays.
2. From the LLM dropdown list, hover over **Serverless Inference**. A dropdown with available Serverless Inference models displays to the right.
3. From the dropdown, select **Compare**. The **Inference** tab displays.
4. To select models for comparison, click anywhere on a model card (except for the model name). The border of the model card highlights in blue to indicate the selection.
5. Repeat step 4 for each model you want to compare.
6. In any of the selected cards, click the **Compare N models in the Playground** button (`N` is the number of models you're comparing. For example, when you select 3 models, the button displays as **Compare 3 models in the Playground**). The comparison view opens.

Now, you can compare models in the Playground, and use any of the features described in [Try a model in the Playground](#try-a-model-in-the-playground).

### View billing and usage information

Organization admins can track current Inference credit balance, usage history, and upcoming billing (if applicable) directly from the Weights & Biases UI:

1. In the Weights & Biases UI, navigate to the Weights & Biases **Billing** page.
2. In the bottom right corner, the Inference billing information card displays. From here, you can:
   * Click the **View usage** button in the Inference billing information card to view your usage over time.
   * If you're on a paid plan, view your upcoming inference charges.

> [!TIP]
>
> Visit the [Inference pricing page for a breakdown of per-model pricing](https://coreweave.com/forge-pricing/inference-agents).

## Usage information and limits

The following sections describe important usage information and limits, including geographic restrictions, concurrency limits, and pricing. Familiarize yourself with this information before using the service.

### Geographic restrictions

The Inference service is only accessible from supported geographic locations. For more information, see the [Terms of Service](https://docs.coreweave.com/policies/terms-of-service/terms-of-use.md#geographic-restrictions).

### Concurrency limits

To ensure fair usage and stable performance, the Serverless Inference API enforces rate limits at the user and project level. These limits help:

* Prevent misuse and protect API stability.
* Ensure access for all users.
* Manage infrastructure load effectively.

If a rate limit is exceeded, the API returns a `429 Concurrency limit reached for requests` response. To resolve this error, reduce the number of concurrent requests.

### Pricing

For model pricing information, visit [https://coreweave.com/forge-pricing/inference-agents](https://coreweave.com/forge-pricing/inference-agents).

## API errors

The following table lists errors that the Inference API can return, along with their causes and recommended solutions.

| Error Code | Message | Cause | Solution |
| - | - | - | - |
| 401 | Invalid Authentication | Invalid authentication credentials, or your Weights & Biases project entity or name are incorrect. | Ensure the correct API key is being used, or that your Weights & Biases project name and entity are correct. |
| 403 | Country, region, or territory not supported | Accessing the API from an unsupported location. | See [Geographic restrictions](#geographic-restrictions). |
| 429 | Concurrency limit reached for requests | Too many concurrent requests. | Reduce the number of concurrent requests. |
| 429 | You exceeded your current quota, please check your plan and billing details | Out of credits or reached monthly spending cap. | Purchase more credits or increase your limits. |
| 500 | The server had an error while processing your request | Internal server error. | Retry after a brief wait and contact support if it persists. |
| 503 | The engine is currently overloaded, please try again later | Server is experiencing high traffic. | Retry your request after a short delay. |
