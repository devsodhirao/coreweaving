> ## Documentation Index
> Fetch the complete documentation index at: https://docs.coreweave.com/llms.txt
> Use this file to discover all available pages before exploring further.

# SubAgent

> TypeScript SDK reference

[GitHub source](https://github.com/wandb/weave/blob/7c9efdc9fe05ffcaf2430dd652ef9bc5b3ffdfaa/sdks/node/src/genai/subagent.ts#L84)

## Extends

* `SpanBase`

## Accessors

### model

#### Get Signature

> **get** **model**(): `string`

##### Returns

`string`

***

### name

#### Get Signature

> **get** **name**(): `string`

##### Returns

`string`

## Methods

### ~~addEvent()~~

> [!WARNING]
>
> **Deprecated.** Record this data via [setAttributes](#setattributes) instead.
> OpenTelemetry is phasing out the Span Event API (`Span.addEvent`). This
> method still works and existing span-event data stays valid.
> See [https://opentelemetry.io/blog/2026/deprecating-span-events/](https://opentelemetry.io/blog/2026/deprecating-span-events/)

> **addEvent**(`name`, `attributes?`, `startTime?`): `this`

Add a named event to the span. Useful for marking non-span moments such as
context compaction, tool-loop detection, or guardrail trips. Warns and
no-ops after `end()`. Mirrors OTel `Span.addEvent`.

#### Parameters

**name** `string` *required*

**attributes** `Attributes`

**startTime** `TimeInput`

#### Returns

`this`

#### Example

```ts twoslash theme={"system"}
// @noErrors
span.addEvent('context_compacted', {removedMessages: 12});
```

#### Inherited from

`SpanBase.addEvent`

***

### end()

> **end**(`opts?`): `void`

Read current field values (to reflect mutations made via `record()`
since `start`) and close the span. Idempotent. Pass `error` to mark
it as failed; pass `endTime` to backdate the close.

#### Parameters

**opts** `object`

**properties**

**endTime** `TimeInput`

**error** `Error`

#### Returns

`void`

***

### record()

> **record**(`opts`): `this`

Bulk-set any subset of the mutable fields. Replaces (does not merge).
Input and output messages are serialized when the span ends.

#### Parameters

**opts** `object` *required*

**properties**

**agentDescription** `string`

**agentId** `string`

**agentVersion** `string`

**messages** `Message[]`

See [`Message`](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/interfaces/message).

**model** `string`

**name** `string`

**outputMessages** `Message[]`

See [`Message`](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/interfaces/message).

**systemInstructions** `string[]`

#### Returns

`this`

***

### setAttributes()

> **setAttributes**(`attributes`): `this`

Set multiple attributes on the span at once. Warns and no-ops after
`end()`. Mirrors OTel `Span.setAttributes` (and the Python SDK's
`set_attributes`).

#### Parameters

**attributes** `Attributes` *required*

#### Returns

`this`

#### Example

```ts twoslash theme={"system"}
// @noErrors
span.setAttributes({'weave.tag': 'prod', 'gen_ai.response.id': id});
```

#### Inherited from

`SpanBase.setAttributes`

***

### startLLM()

> **startLLM**(`opts`): [`LLM`](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/interfaces/llm)

Start a child LLM span nested under this SubAgent.

#### Parameters

**opts** `LLMInit` *required*

See [`LLMInit`](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/interfaces/llminit).

#### Returns

[`LLM`](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/interfaces/llm)

***

### startSubagent()

> **startSubagent**(`opts`): `SubAgent`

Start a nested SubAgent span under this SubAgent.

#### Parameters

**opts** `SubAgentInit` *required*

See [`SubAgentInit`](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/interfaces/subagentinit).

#### Returns

`SubAgent`

***

### startTool()

> **startTool**(`opts`): [`Tool`](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/interfaces/tool)

Start a child Tool span nested under this SubAgent.

#### Parameters

**opts** `ToolInit` *required*

See [`ToolInit`](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/interfaces/toolinit).

#### Returns

[`Tool`](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/interfaces/tool)
