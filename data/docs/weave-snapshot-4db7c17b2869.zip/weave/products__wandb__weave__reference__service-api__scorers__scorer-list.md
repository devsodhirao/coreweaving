> ## Documentation Index
> Fetch the complete documentation index at: https://docs.coreweave.com/llms.txt
> Use this file to discover all available pages before exploring further.

# Scorer List

> List scorer objects.



## OpenAPI

````yaml products/wandb/weave/reference/service-api/openapi.json GET /v2/{entity}/{project}/scorers
openapi: 3.1.0
info:
  title: FastAPI
  version: 0.1.0
servers: []
security: []
paths:
  /v2/{entity}/{project}/scorers:
    get:
      tags:
        - Scorers
      summary: Scorer List
      description: List scorer objects.
      operationId: scorer_list_v2__entity___project__scorers_get
      parameters:
        - name: entity
          in: path
          required: true
          schema:
            type: string
            title: Entity
        - name: project
          in: path
          required: true
          schema:
            type: string
            title: Project
        - name: limit
          in: query
          required: false
          schema:
            anyOf:
              - type: integer
              - type: 'null'
            description: Maximum number of scorers to return
            title: Limit
          description: Maximum number of scorers to return
        - name: offset
          in: query
          required: false
          schema:
            anyOf:
              - type: integer
              - type: 'null'
            description: Number of scorers to skip
            title: Offset
          description: Number of scorers to skip
      responses:
        '200':
          description: Stream of data in JSONL format
          content:
            application/x-ndjson:
              schema:
                $ref: '#/components/schemas/ScorerReadRes'
        '422':
          description: Validation Error
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/HTTPValidationError'
components:
  schemas:
    ScorerReadRes:
      properties:
        object_id:
          type: string
          title: Object Id
          description: The scorer ID
        digest:
          type: string
          title: Digest
          description: The digest of the scorer
        version_index:
          type: integer
          title: Version Index
          description: The version index of the object
        created_at:
          type: string
          format: date-time
          title: Created At
          description: When the scorer was created
        name:
          type: string
          title: Name
          description: The name of the scorer
        description:
          anyOf:
            - type: string
            - type: 'null'
          title: Description
          description: Description of the scorer
        score_op:
          type: string
          title: Score Op
          description: The Scorer.score op reference
      type: object
      required:
        - object_id
        - digest
        - version_index
        - created_at
        - name
        - score_op
      title: ScorerReadRes
    HTTPValidationError:
      properties:
        detail:
          items:
            $ref: '#/components/schemas/ValidationError'
          type: array
          title: Detail
      type: object
      title: HTTPValidationError
    ValidationError:
      properties:
        loc:
          items:
            anyOf:
              - type: string
              - type: integer
          type: array
          title: Location
        msg:
          type: string
          title: Message
        type:
          type: string
          title: Error Type
        input:
          title: Input
        ctx:
          type: object
          title: Context
      type: object
      required:
        - loc
        - msg
        - type
      title: ValidationError

````