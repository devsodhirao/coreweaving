> ## Documentation Index
> Fetch the complete documentation index at: https://docs.coreweave.com/llms.txt
> Use this file to discover all available pages before exploring further.

# Session

> TypeScript SDK reference

> [!WARNING]
>
> **Deprecated.** Use [Conversation](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/interfaces/conversation.md) instead.

> **Session** = [`Conversation`](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/interfaces/conversation)

[GitHub source](https://github.com/wandb/weave/blob/7c9efdc9fe05ffcaf2430dd652ef9bc5b3ffdfaa/sdks/node/src/genai/conversation.ts#L195)
