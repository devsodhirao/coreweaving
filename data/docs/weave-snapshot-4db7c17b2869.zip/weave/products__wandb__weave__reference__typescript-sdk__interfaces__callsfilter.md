> ## Documentation Index
> Fetch the complete documentation index at: https://docs.coreweave.com/llms.txt
> Use this file to discover all available pages before exploring further.

# CallsFilter

> TypeScript SDK reference

[GitHub source](https://github.com/wandb/weave/blob/7c9efdc9fe05ffcaf2430dd652ef9bc5b3ffdfaa/sdks/node/src/generated/traceServerApi.ts#L2205)

CallsFilter

## Properties

### call\_ids

> `optional` **call\_ids**: `string`\[] | `null`

Call Ids

***

### input\_refs

> `optional` **input\_refs**: `string`\[] | `null`

Input Refs

***

### op\_names

> `optional` **op\_names**: `string`\[] | `null`

Op Names

***

### output\_refs

> `optional` **output\_refs**: `string`\[] | `null`

Output Refs

***

### parent\_ids

> `optional` **parent\_ids**: `string`\[] | `null`

Parent Ids

***

### thread\_ids

> `optional` **thread\_ids**: `string`\[] | `null`

Thread Ids

***

### trace\_ids

> `optional` **trace\_ids**: `string`\[] | `null`

Trace Ids

***

### trace\_roots\_only

> `optional` **trace\_roots\_only**: `boolean` | `null`

Trace Roots Only

***

### turn\_ids

> `optional` **turn\_ids**: `string`\[] | `null`

Turn Ids

***

### wb\_run\_ids

> `optional` **wb\_run\_ids**: `string`\[] | `null`

Wb Run Ids

***

### wb\_user\_ids

> `optional` **wb\_user\_ids**: `string`\[] | `null`

Wb User Ids
