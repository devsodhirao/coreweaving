> ## Documentation Index
> Fetch the complete documentation index at: https://docs.coreweave.com/llms.txt
> Use this file to discover all available pages before exploring further.

# HTTPValidationError

> TypeScript SDK reference

[GitHub source](https://github.com/wandb/weave/blob/7c9efdc9fe05ffcaf2430dd652ef9bc5b3ffdfaa/sdks/node/src/generated/traceServerApi.ts#L4331)

HTTPValidationError

## Properties

### detail

> `optional` **detail**: `object`\[]

Detail

#### loc

> **loc**: (`string` | `number`)\[]

Location

#### msg

> **msg**: `string`

Message

#### type

> **type**: `string`

Error Type
