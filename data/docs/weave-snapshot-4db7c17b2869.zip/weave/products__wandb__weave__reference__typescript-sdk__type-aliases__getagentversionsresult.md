> ## Documentation Index
> Fetch the complete documentation index at: https://docs.coreweave.com/llms.txt
> Use this file to discover all available pages before exploring further.

# GetAgentVersionsResult

> TypeScript SDK reference

> **GetAgentVersionsResult** = `object`

[GitHub source](https://github.com/wandb/weave/blob/7c9efdc9fe05ffcaf2430dd652ef9bc5b3ffdfaa/sdks/node/src/weaveClient.ts#L179)

Result shape returned by [WeaveClient.getAgentVersions](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/interfaces/weaveclient.md#getagentversions).

## Properties

### total\_count

> `optional` **total\_count**: `number`

***

### versions

> **versions**: [`AgentVersion`](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/type-aliases/agentversion)\[]
