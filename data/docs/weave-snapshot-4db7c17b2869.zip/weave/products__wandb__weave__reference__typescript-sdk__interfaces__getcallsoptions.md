> ## Documentation Index
> Fetch the complete documentation index at: https://docs.coreweave.com/llms.txt
> Use this file to discover all available pages before exploring further.

# GetCallsOptions

> TypeScript SDK reference

[GitHub source](https://github.com/wandb/weave/blob/7c9efdc9fe05ffcaf2430dd652ef9bc5b3ffdfaa/sdks/node/src/weaveClient.ts#L120)

## Properties

### columns

> `optional` **columns**: `string`\[]

***

### expandColumns

> `optional` **expandColumns**: `string`\[]

***

### filter

> `optional` **filter**: [`CallsFilter`](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/interfaces/callsfilter)

***

### includeCosts

> `optional` **includeCosts**: `boolean`

***

### includeFeedback

> `optional` **includeFeedback**: `boolean`

***

### limit

> `optional` **limit**: `number`

***

### offset

> `optional` **offset**: `number`

***

### query

> `optional` **query**: [`Query`](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/interfaces/query)

***

### sortBy

> `optional` **sortBy**: [`SortBy`](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/interfaces/sortby)\[]
