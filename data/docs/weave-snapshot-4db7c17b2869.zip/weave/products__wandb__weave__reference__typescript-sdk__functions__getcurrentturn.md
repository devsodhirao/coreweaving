> ## Documentation Index
> Fetch the complete documentation index at: https://docs.coreweave.com/llms.txt
> Use this file to discover all available pages before exploring further.

# getCurrentTurn

> TypeScript SDK reference

```ts theme={"system"}
getCurrentTurn(): Turn | undefined
```

[GitHub source](https://github.com/wandb/weave/blob/7c9efdc9fe05ffcaf2430dd652ef9bc5b3ffdfaa/sdks/node/src/genai/context.ts#L67)

Returns the current Turn, or undefined.

## Returns

[`Turn`](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/interfaces/turn) | `undefined`
