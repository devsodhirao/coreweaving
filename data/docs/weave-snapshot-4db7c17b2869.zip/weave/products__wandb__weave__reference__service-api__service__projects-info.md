> ## Documentation Index
> Fetch the complete documentation index at: https://docs.coreweave.com/llms.txt
> Use this file to discover all available pages before exploring further.

# Projects Info



## OpenAPI

````yaml products/wandb/weave/reference/service-api/openapi.json POST /service/projects_info
openapi: 3.1.0
info:
  title: FastAPI
  version: 0.1.0
servers: []
security: []
paths:
  /service/projects_info:
    post:
      tags:
        - Service
      summary: Projects Info
      operationId: projects_info_service_projects_info_post
      requestBody:
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/ProjectsInfoReq'
        required: true
      responses:
        '200':
          description: Successful Response
          content:
            application/json:
              schema:
                items:
                  $ref: '#/components/schemas/ProjectsInfoRes'
                type: array
                title: Response Projects Info Service Projects Info Post
        '422':
          description: Validation Error
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/HTTPValidationError'
components:
  schemas:
    ProjectsInfoReq:
      properties:
        project_ids:
          items:
            type: string
          type: array
          title: Project Ids
          description: External project IDs in 'entity/project' format.
          examples:
            - - entity-a/project-a
              - entity-b/project-b
      type: object
      required:
        - project_ids
      title: ProjectsInfoReq
    ProjectsInfoRes:
      properties:
        external_project_id:
          type: string
          title: External Project Id
          description: External project ID in 'entity/project' format.
        internal_project_id:
          type: string
          title: Internal Project Id
          description: Internal project ID.
      type: object
      required:
        - external_project_id
        - internal_project_id
      title: ProjectsInfoRes
    HTTPValidationError:
      properties:
        detail:
          items:
            $ref: '#/components/schemas/ValidationError'
          type: array
          title: Detail
      type: object
      title: HTTPValidationError
    ValidationError:
      properties:
        loc:
          items:
            anyOf:
              - type: string
              - type: integer
          type: array
          title: Location
        msg:
          type: string
          title: Message
        type:
          type: string
          title: Error Type
        input:
          title: Input
        ctx:
          type: object
          title: Context
      type: object
      required:
        - loc
        - msg
        - type
      title: ValidationError

````