> ## Documentation Index
> Fetch the complete documentation index at: https://docs.coreweave.com/llms.txt
> Use this file to discover all available pages before exploring further.

# Compare traces and other logged information

> Visually compare and diff code, traces, prompts, models, and configurations

The Weave Comparison feature lets you visually compare and diff code, traces, prompts, models, and model configurations. You can compare two objects side-by-side or analyze a larger set of objects to identify differences, patterns, and trends. This is useful when you iterate on prompts or models, debug behavior changes between runs, or audit how configurations have evolved over time.

This guide is for Weave users who want to inspect differences between logged objects in the UI. It covers how to start a comparison and the available actions to tailor your comparison view, including baseline comparisons and numeric diff formatting.

## Access the Comparison view

To open the Comparison view for two or more logged objects:

1. In the sidebar, select the type of object to compare (for example, **Traces** or **Models**).
2. Select the objects that you want to compare. The selection method varies depending on the type of object you're comparing:
   * For **Traces**, select traces to compare by checking the checkboxes for the appropriate rows in the Trace column.
   * For objects such as **Models**, navigate to the model Versions page and check the checkboxes next to the versions that you want to compare.
3. Select **Compare** to open the Comparison view. At the top of the page, the comparison bar contains interactive call ID tokens (for example, `f02b`, `4a98`) that you can drag, reorder, or remove to change the comparison.
4. You can refine your view using the available actions.

## Customize the Comparison view

In the Comparison view, you can adjust how objects are displayed and compared. The following sections describe the available actions:

* [Display summary](#display-summary)
* [Display a Calls view](#display-a-calls-view)
* [Change the diff display](#change-the-diff-display)
* [Display side-by-side](#display-side-by-side)
* [Display in a unified view](#display-in-a-unified-view)
* [Set a baseline](#set-a-baseline)
* [Remove a baseline](#remove-a-baseline)
* [Change the comparison order](#change-the-comparison-order)
* [Change numeric diff display format](#change-numeric-diff-display-format)
* [Compare with baseline or previous](#compare-with-baseline-or-previous)
* [Compare a pair from a multi-object comparison](#compare-a-pair-from-a-multi-object-comparison)
* [Remove an object from comparison](#remove-an-object-from-comparison)

### Display summary

The default view for a selected object comparison is a summary. This summary includes a preview of the LLM input and output, along with tokens, cost, and latency.

![Comparison Summary view of two objects](https://mintcdn.com/coreweave-dbfa0e8d/3Dv_sw2eg8feUJlx/products/wandb/weave/_media/comparison-2objs-summary.png?fit=max\&auto=format\&n=3Dv_sw2eg8feUJlx\&q=85\&s=2c68f67ce135a46136b08bffb4bec23c)

For traces, the colored bar displayed at the top of the comparison table reflects any custom kinds and colors that you've applied to your Ops. For more information on using this enhanced visibility, see [Apply kinds and colors](https://docs.coreweave.com/products/wandb/weave/guides/tracking/ops.md#apply-kinds-and-colors).

### Display a Calls view

To compare each object's Calls, select **Calls**. This view:

* Displays the complete trace tree for the Call.
* Provides basic in-memory text search.
* Lets you toggle the display of per-call latency, cost, tokens, Op kinds, and feedback.

![Calls Comparison view of two objects](https://mintcdn.com/coreweave-dbfa0e8d/3Dv_sw2eg8feUJlx/products/wandb/weave/_media/comparison-2obs-calls.png?fit=max\&auto=format\&n=3Dv_sw2eg8feUJlx\&q=85\&s=4a8044df5addaeace012c60e49a04da7)

### Change the diff display

By default, **Diff only** is off. To filter the table rows so that only changed rows appear, toggle **Diff only** on.

**Diff only** applies to side-by-side and unified views and is disabled in other views.

### Display side-by-side

To compare each object side-by-side in separate columns, select **Side-by-side**.

![Side-by-side Comparison view of two objects](https://mintcdn.com/coreweave-dbfa0e8d/3Dv_sw2eg8feUJlx/products/wandb/weave/_media/comparison-2objs-sidebyside.png?fit=max\&auto=format\&n=3Dv_sw2eg8feUJlx\&q=85\&s=438a8f0e34a911e6cca7c200006a5a4d)

### Display in a unified view

To compare two objects in a unified view, select **Unified**. This view is not available when comparing more than two objects.

![Unified Comparison view of two objects](https://mintcdn.com/coreweave-dbfa0e8d/3Dv_sw2eg8feUJlx/products/wandb/weave/_media/comparison-2objs-unified.png?fit=max\&auto=format\&n=3Dv_sw2eg8feUJlx\&q=85\&s=9397bdc5aabe7a1c68189124f1c00136)

### Set a baseline

By default, each object in the Comparison view is compared to the object to its left. However, you can set an object as the *baseline*, which means that all objects are compared to the leftmost object in the view. Use a baseline when you want every object measured against a single reference point, such as a known-good run.

To set an object as the baseline:

1. In the comparison bar, hold the pointer over the object that you want to set as the baseline.
2. Click the **action ()** menu to the right of the ID.

   ![Comparison view showing the Make baseline option for the selected object in the comparison bar.](https://mintcdn.com/coreweave-dbfa0e8d/3Dv_sw2eg8feUJlx/products/wandb/weave/_media/comparison-2objs-baseline.png?fit=max\&auto=format\&n=3Dv_sw2eg8feUJlx\&q=85\&s=ca82aad79d7ff1556187022246aff8c8)
3. In the list, select **Make baseline**. The UI refreshes with the baseline object in the leftmost position in the comparison bar and `Baseline` next to the ID.

   ![Comparison view showing the selected baseline object in the leftmost position of the comparison bar.](https://mintcdn.com/coreweave-dbfa0e8d/3Dv_sw2eg8feUJlx/products/wandb/weave/_media/comparison-2objs-baseline-set.png?fit=max\&auto=format\&n=3Dv_sw2eg8feUJlx\&q=85\&s=206ed1433b6a5c09d9277f3c4417ef61)

### Remove a baseline

To remove an object as a baseline:

1. In the comparison bar, hold the pointer over the baseline object.
2. Click the **action ()** menu to the right of the ID.
3. In the list, select **Remove baseline**. `Baseline` no longer displays next to the call ID.

### Change the comparison order

Drag the objects in the comparison bar to reorder them. This also reorders the corresponding columns in the comparison table.

To change the comparison order:

1. In the comparison bar, hold the pointer over the ID that you want to reorder.
2. Click and hold the six dots to the left of the ID and drag it to the left or the right as needed.
3. Place the ID in the desired ordering. The comparison data refreshes with an updated comparison ordering.

### Change numeric diff display format

For numeric values such as `completion_tokens` and `total_tokens`, you can view the diff as either an integer or a percentage. You can also view positive numeric values as a multiplier.

To change a numeric diff's display format:

1. In the Comparison table, find the numeric value whose diff display format you want to update.

   ![A numeric value displayed as an integer.](https://mintcdn.com/coreweave-dbfa0e8d/3Dv_sw2eg8feUJlx/products/wandb/weave/_media/comparison-2objs-numericdiffformat.png?fit=max\&auto=format\&n=3Dv_sw2eg8feUJlx\&q=85\&s=1cab721daa6dc71d34c288b37cebbcec)
2. Click the diff value. The format automatically updates to either an integer or a percentage.

   ![A numeric value updated to a percentage.](https://mintcdn.com/coreweave-dbfa0e8d/3Dv_sw2eg8feUJlx/products/wandb/weave/_media/comparison-2objs-numericdiffformat-updated.png?fit=max\&auto=format\&n=3Dv_sw2eg8feUJlx\&q=85\&s=2ee3638bd64d10bf61348fee622ecd51)

### Compare with baseline or previous

This option is only available when comparing three or more objects. You can also [set a baseline](#set-a-baseline) or [remove an existing baseline](#remove-a-baseline).

To perform a baseline comparison with three or more objects:

1. In the upper-right corner of either the Side-by-side or Unified Comparison view, click the list. Depending on your current view configuration, the list title is either **Compare with previous** or **Compare with baseline**.
2. Depending on your current view configuration, select either **Compare with previous** or **Compare with baseline**.
   * **Compare with baseline**: Sets the leftmost object as the baseline. The table updates so that the leftmost column is the baseline.
   * **Compare with previous**: No object is set as baseline.

### Compare a pair from a multi-object comparison

This option is only available when comparing three or more objects.

When comparing three or more objects, you can compare a single object to its adjacent object or a baseline. This changes the Comparison table view so that the view is identical to a two-object comparison.

To compare a pair of objects from a multi-object comparison:

1. In the comparison bar, select the ID you want to compare. If you've set a baseline, the view compares the selected object to the baseline. Otherwise, it compares the object to the ID immediately to its left in the comparison bar.
2. To select the item, click the ID. The UI refreshes with a two-way comparison table.

   ![Comparing a pair from a multi-object comparison.](https://mintcdn.com/coreweave-dbfa0e8d/3Dv_sw2eg8feUJlx/products/wandb/weave/_media/comparison-7objs-diffonly-subset.png?fit=max\&auto=format\&n=3Dv_sw2eg8feUJlx\&q=85\&s=735b9a01c8e6ae59f869878caf444f09)

To reset the view so that the first six objects selected for comparison are displayed in the table, click the ID again.

### Remove an object from comparison

This option is only available when comparing three or more objects.

To remove an object from comparison:

1. In the comparison bar, find the object that you want to remove from comparison.
2. Click the **action ()** menu to the right of the ID.
3. In the list, select **Remove object from comparison**. The UI refreshes with an updated table that no longer includes the removed object.

## Usage notes

The following notes describe limitations and behaviors of the Comparison feature:

* The Comparison feature is only available in the UI.
* You can compare as many objects as you'd like, but the UI displays a maximum of six. To view an object in the comparison table that isn't visible when comparing more than six objects, either [change the comparison order](#change-the-comparison-order) so the object is one of the first six from left to right, or [pair it from a multi-object comparison](#compare-a-pair-from-a-multi-object-comparison) to view it.
