> ## Documentation Index
> Fetch the complete documentation index at: https://docs.coreweave.com/llms.txt
> Use this file to discover all available pages before exploring further.

# Table Create



## OpenAPI

````yaml products/wandb/weave/reference/service-api/openapi.json POST /table/create
openapi: 3.1.0
info:
  title: FastAPI
  version: 0.1.0
servers: []
security: []
paths:
  /table/create:
    post:
      tags:
        - Tables
      summary: Table Create
      operationId: table_create_table_create_post
      requestBody:
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/TableCreateReq'
        required: true
      responses:
        '200':
          description: Successful Response
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/TableCreateRes'
        '422':
          description: Validation Error
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/HTTPValidationError'
components:
  schemas:
    TableCreateReq:
      properties:
        table:
          $ref: '#/components/schemas/TableSchemaForInsert'
      type: object
      required:
        - table
      title: TableCreateReq
    TableCreateRes:
      properties:
        digest:
          type: string
          title: Digest
        row_digests:
          items:
            type: string
          type: array
          title: Row Digests
          description: The digests of the rows that were created
      type: object
      required:
        - digest
      title: TableCreateRes
    HTTPValidationError:
      properties:
        detail:
          items:
            $ref: '#/components/schemas/ValidationError'
          type: array
          title: Detail
      type: object
      title: HTTPValidationError
    TableSchemaForInsert:
      properties:
        project_id:
          type: string
          title: Project Id
        rows:
          items:
            additionalProperties: true
            type: object
          type: array
          title: Rows
        expected_digest:
          anyOf:
            - type: string
            - type: 'null'
          title: Expected Digest
          description: Client-computed table digest for server-side validation.
      type: object
      required:
        - project_id
        - rows
      title: TableSchemaForInsert
    ValidationError:
      properties:
        loc:
          items:
            anyOf:
              - type: string
              - type: integer
          type: array
          title: Location
        msg:
          type: string
          title: Message
        type:
          type: string
          title: Error Type
        input:
          title: Input
        ctx:
          type: object
          title: Context
      type: object
      required:
        - loc
        - msg
        - type
      title: ValidationError

````