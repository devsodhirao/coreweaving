> ## Documentation Index
> Fetch the complete documentation index at: https://docs.coreweave.com/llms.txt
> Use this file to discover all available pages before exploring further.

# Feedback Payload Schema

> Discover feedback payload schema (paths and types) from sample rows.



## OpenAPI

````yaml products/wandb/weave/reference/service-api/openapi.json POST /feedback/payload_schema
openapi: 3.1.0
info:
  title: FastAPI
  version: 0.1.0
servers: []
security: []
paths:
  /feedback/payload_schema:
    post:
      tags:
        - Feedback
      summary: Feedback Payload Schema
      description: Discover feedback payload schema (paths and types) from sample rows.
      operationId: feedback_payload_schema_feedback_payload_schema_post
      requestBody:
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/FeedbackPayloadSchemaReq'
        required: true
      responses:
        '200':
          description: Successful Response
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/FeedbackPayloadSchemaRes'
        '422':
          description: Validation Error
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/HTTPValidationError'
components:
  schemas:
    FeedbackPayloadSchemaReq:
      properties:
        project_id:
          type: string
          title: Project Id
        start:
          type: string
          format: date-time
          title: Start
          description: Inclusive start time (UTC, ISO 8601).
        end:
          anyOf:
            - type: string
              format: date-time
            - type: 'null'
          title: End
          description: Exclusive end time (UTC, ISO 8601). Defaults to now if omitted.
        feedback_type:
          anyOf:
            - type: string
            - type: 'null'
          title: Feedback Type
          description: Filter by feedback_type.
        trigger_ref:
          anyOf:
            - type: string
            - type: 'null'
          title: Trigger Ref
          description: Filter by trigger_ref (exact or prefix match for all-versions).
        sample_limit:
          type: integer
          maximum: 5000
          minimum: 1
          title: Sample Limit
          description: >-
            Max distinct trigger_refs to sample when discovering the payload
            schema. Each distinct trigger_ref (monitor/source) typically has a
            fixed payload structure, so sampling one payload per ref is usually
            enough to see the full schema. 2 000 covers virtually all real-world
            projects while keeping the query fast; the hard cap of 5 000
            prevents runaway scans.
          default: 2000
      type: object
      required:
        - project_id
        - start
      title: FeedbackPayloadSchemaReq
      description: Request for feedback payload schema discovery.
    FeedbackPayloadSchemaRes:
      properties:
        paths:
          items:
            $ref: '#/components/schemas/FeedbackPayloadPath'
          type: array
          title: Paths
          description: Discovered leaf paths with inferred value types.
      type: object
      title: FeedbackPayloadSchemaRes
      description: Response with discovered feedback payload paths and types.
    HTTPValidationError:
      properties:
        detail:
          items:
            $ref: '#/components/schemas/ValidationError'
          type: array
          title: Detail
      type: object
      title: HTTPValidationError
    FeedbackPayloadPath:
      properties:
        json_path:
          type: string
          title: Json Path
          description: Dot path into payload (e.g. 'output.score').
        value_type:
          type: string
          enum:
            - numeric
            - boolean
            - categorical
          title: Value Type
          description: Inferred type of value at path.
          default: numeric
      type: object
      required:
        - json_path
      title: FeedbackPayloadPath
      description: Discovered path in feedback payload with inferred type.
    ValidationError:
      properties:
        loc:
          items:
            anyOf:
              - type: string
              - type: integer
          type: array
          title: Location
        msg:
          type: string
          title: Message
        type:
          type: string
          title: Error Type
        input:
          title: Input
        ctx:
          type: object
          title: Context
      type: object
      required:
        - loc
        - msg
        - type
      title: ValidationError

````