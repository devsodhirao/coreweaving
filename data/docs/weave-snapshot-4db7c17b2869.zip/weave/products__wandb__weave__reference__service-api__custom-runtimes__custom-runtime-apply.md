> ## Documentation Index
> Fetch the complete documentation index at: https://docs.coreweave.com/llms.txt
> Use this file to discover all available pages before exploring further.

# Custom Runtime Apply

> Create or replace a custom runtime configuration.



## OpenAPI

````yaml products/wandb/weave/reference/service-api/openapi.json PUT /v2/{entity}/{project}/runtimes/{runtime_name}
openapi: 3.1.0
info:
  title: FastAPI
  version: 0.1.0
servers: []
security: []
paths:
  /v2/{entity}/{project}/runtimes/{runtime_name}:
    put:
      tags:
        - Custom Runtimes
      summary: Custom Runtime Apply
      description: Create or replace a custom runtime configuration.
      operationId: custom_runtime_apply_v2__entity___project__runtimes__runtime_name__put
      parameters:
        - name: entity
          in: path
          required: true
          schema:
            type: string
            title: Entity
        - name: project
          in: path
          required: true
          schema:
            type: string
            title: Project
        - name: runtime_name
          in: path
          required: true
          schema:
            type: string
            minLength: 1
            maxLength: 128
            pattern: ^[^\s:]*(?::[^\s:]+)*:?$
            description: Stable name of the custom runtime to create or replace
            title: Runtime Name
          description: Stable name of the custom runtime to create or replace
      requestBody:
        required: true
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/CustomRuntimeApplyBody'
      responses:
        '200':
          description: Successful Response
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/CustomRuntimeApplyRes'
        '422':
          description: Validation Error
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/HTTPValidationError'
components:
  schemas:
    CustomRuntimeApplyBody:
      properties:
        base_url:
          type: string
          title: Base Url
          description: Public OpenAI-compatible endpoint base URL
        api_key_secret:
          anyOf:
            - type: string
            - type: 'null'
          title: Api Key Secret
          description: >-
            Team secret name used as the endpoint API key; never the secret
            value
        headers:
          additionalProperties:
            type: string
          type: object
          title: Headers
          description: Literal headers forwarded to the endpoint
        runtime_ids:
          items:
            $ref: '#/components/schemas/CustomRuntimeID'
          type: array
          title: Runtime Ids
          description: Complete desired list of IDs exposed by the endpoint
      type: object
      required:
        - base_url
        - runtime_ids
      title: CustomRuntimeApplyBody
    CustomRuntimeApplyRes:
      properties:
        name:
          type: string
          title: Name
          description: Stable custom runtime name
        base_url:
          type: string
          title: Base Url
        api_key_secret:
          anyOf:
            - type: string
            - type: 'null'
          title: Api Key Secret
        headers:
          additionalProperties:
            type: string
          type: object
          title: Headers
        runtime_ids:
          items:
            $ref: '#/components/schemas/CustomRuntimeIDRes'
          type: array
          title: Runtime Ids
      type: object
      required:
        - name
        - base_url
        - api_key_secret
        - headers
        - runtime_ids
      title: CustomRuntimeApplyRes
    HTTPValidationError:
      properties:
        detail:
          items:
            $ref: '#/components/schemas/ValidationError'
          type: array
          title: Detail
      type: object
      title: HTTPValidationError
    CustomRuntimeID:
      properties:
        id:
          type: string
          minLength: 1
          pattern: ^\S+$
          title: Id
          description: Value sent in the OpenAI-compatible request model field
        max_tokens:
          type: integer
          exclusiveMinimum: 0
          title: Max Tokens
          description: Maximum tokens supported by this runtime ID
          default: 4096
      type: object
      required:
        - id
      title: CustomRuntimeID
    CustomRuntimeIDRes:
      properties:
        id:
          type: string
          minLength: 1
          pattern: ^\S+$
          title: Id
          description: Value sent in the OpenAI-compatible request model field
        max_tokens:
          type: integer
          exclusiveMinimum: 0
          title: Max Tokens
          description: Maximum tokens supported by this runtime ID
          default: 4096
        playground_id:
          type: string
          title: Playground Id
      type: object
      required:
        - id
        - playground_id
      title: CustomRuntimeIDRes
    ValidationError:
      properties:
        loc:
          items:
            anyOf:
              - type: string
              - type: integer
          type: array
          title: Location
        msg:
          type: string
          title: Message
        type:
          type: string
          title: Error Type
        input:
          title: Input
        ctx:
          type: object
          title: Context
      type: object
      required:
        - loc
        - msg
        - type
      title: ValidationError

````