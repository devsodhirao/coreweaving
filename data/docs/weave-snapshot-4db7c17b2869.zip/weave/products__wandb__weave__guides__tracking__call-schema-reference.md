> ## Documentation Index
> Fetch the complete documentation index at: https://docs.coreweave.com/llms.txt
> Use this file to discover all available pages before exploring further.

# Call schema reference

> Reference for the Call object structure and properties

This reference describes the Call object schema in Weave, including its properties, how to write custom data to the `summary` dictionary during execution, and how to read summary data after a Call completes. Use this page when you need to inspect, filter, or extend the data Weave records for each Call. For information about querying calls, see [Query and export calls](https://docs.coreweave.com/products/wandb/weave/guides/tracking/querying-calls.md).

## Call properties

The following table outlines the key properties of a Call in Weave. For the complete implementation, see the following:

* [class: CallSchema](https://docs.coreweave.com/products/wandb/weave/reference/python-sdk/trace_server/trace_server_interface.md#class-callschema) in the Python SDK
* [Interface: CallSchema](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/interfaces/callschema.md) in the TypeScript SDK

| Property | Type | Description |
| - | - | - |
| `id` | string (uuid) | Unique identifier for the Call |
| `project_id` | string (optional) | Associated project identifier |
| `op_name` | string | Name of the operation (can be a reference) |
| `display_name` | string (optional) | User-friendly name for the Call |
| `trace_id` | string (uuid) | Identifier for the trace this Call belongs to |
| `parent_id` | string (uuid) | Identifier of the parent Call |
| `started_at` | datetime | Timestamp when the Call started |
| `attributes` | Dict\[str, Any] | User-defined metadata about the Call *(read-only during execution)* |
| `inputs` | Dict\[str, Any] | Input parameters for the Call |
| `ended_at` | datetime (optional) | Timestamp when the Call ended |
| `exception` | string (optional) | Error message if the Call failed |
| `output` | Any (optional) | Result of the Call |
| `summary` | Optional\[SummaryMap] | Post-execution summary information. You can modify this during execution to record custom metrics. |
| `wb_user_id` | Optional\[str] | Associated Weights & Biases user ID |
| `wb_run_id` | Optional\[str] | Associated W\&B run ID |
| `deleted_at` | datetime (optional) | Timestamp of Call deletion, if applicable |

## Property details

`CallSchema` properties help you track and manage Calls:

* The `id`, `trace_id`, and `parent_id` properties help organize and relate Calls within the system.
* Timing information (`started_at`, `ended_at`) supports performance analysis.
* The `attributes` and `inputs` properties provide context for the Call. Attributes are frozen once the Call starts, so set them before invocation using the `weave.attributes()` context manager. `output` and `summary` capture the results.
* Use `wb_user_id` and `wb_run_id` to link the Call to a Weights & Biases user and run.

Together, these properties support detailed tracking and analysis of Calls throughout your project.

## Use Call summary

Use the `summary` property to attach custom, post-execution data to a Call so you can analyze it later alongside Weave's built-in metrics. It's a dictionary you can write to during a Call's execution. When the Call finishes, Weave deep-merges your values with its own computed data and stores the result.

The dictionary has two zones:

* Your custom keys: anything you write to `call.summary` directly, such as `call.summary["accuracy"] = 0.95`. These sit at the top level of the summary dict.
* `summary["weave"]`: a reserved namespace Weave populates automatically at Call completion. Don't write to this key directly.

Weave also captures raw LLM token counts from the model response at `summary["usage"]` (keyed by model name). This is source data passed through from the provider, not a Weave computation. The `costs` field inside `summary["weave"]` is what Weave derives from that usage data using token pricing.

Weave's computed fields inside `summary["weave"]`:

| Field | Description |
| - | - |
| `status` | Execution status: `SUCCESS`, `ERROR`, `RUNNING`, or `DESCENDANT_ERROR` (the Call succeeded but a child Call errored). |
| `latency_ms` | Duration in milliseconds between `started_at` and `ended_at`. `null` if `status` is `RUNNING`. |
| `costs` | Cost breakdown per model, derived from `summary["usage"]` and token pricing data. See [Track costs](https://docs.coreweave.com/products/wandb/weave/guides/tracking/costs.md). |
| `trace_name` | Human-readable Op name, parsed from the internal Op reference URI. Used for display and filtering. |

### Write during a Call

You can add custom data values during your Call using the `summary` dictionary.

**Python**

In Python, assign values to `call.summary` at any point during execution using `weave.get_current_call()`.

```python lines theme={"system"}
import weave

@weave.op()
def my_op(x):
    result = do_work(x)
    call = weave.get_current_call()
    # Add custom data values to the summary.
    call.summary["accuracy"] = 0.95
    call.summary["num_retries"] = 2
    return result
```

**TypeScript**

In TypeScript, provide a `summarize` function as an option to `op()`. It receives the final result and returns summary data at Call completion.

```typescript twoslash lines theme={"system"}
// @noErrors
const myOp = weave.op(
  async (x: any) => {
    const result = await doWork(x);
    return result;
  },
  {
    name: 'my_op',
    summarize: (result) => ({
      accuracy: result.accuracy,
      numRetries: result.numRetries,
    }),
  }
);
```

### Read summary data

Use `getCall` to fetch a single Call by ID, or `getCalls` to fetch multiple Calls. In both cases, `summary` is the same merged dictionary.

**Python**

```python lines theme={"system"}
import weave
client = weave.init("my-team/my-project")

# Fetch a single Call by ID.
call = client.get_call("[CALL-ID]")
weave_summary = (call.summary or {}).get("weave", {})

print(weave_summary.get("status"))       # TraceStatus enum: SUCCESS, ERROR, RUNNING, or DESCENDANT_ERROR.
print(weave_summary.get("latency_ms"))   # Null if the Call is still running.
print(weave_summary.get("costs"))        # Cost breakdown per model.
print(call.summary.get("usage"))         # Raw token counts from the LLM provider.
print(call.summary.get("accuracy"))      # Your custom field.

# Iterate over multiple Calls with server-side filtering.
for call in client.get_calls(filter={"op_names": ["weave:///my-team/my-project/op/my_op:*"]}):
    s = call.summary or {}
    weave_s = s.get("weave", {})
    print(call.id, weave_s.get("status"), weave_s.get("latency_ms"), s.get("accuracy"))
```

**TypeScript**

```typescript twoslash lines theme={"system"}
// @noErrors
import * as weave from 'weave';
const client = await weave.init('my-team/my-project');

// Fetch a single Call by ID.
const call = await client.getCall('[CALL-ID]');
const weaveSummary = call.summary?.weave;

console.log(weaveSummary?.status);       // "success", "error", "running", or "descendant_error".
console.log(weaveSummary?.latency_ms);   // Undefined if the Call is still running.
console.log(weaveSummary?.costs);        // Cost breakdown per model.
console.log(call.summary?.usage);        // Raw token counts from the LLM provider.
console.log(call.summary?.accuracy);     // Your custom field.

// Fetch multiple Calls with server-side filtering.
const calls = await client.getCalls({ filter: { op_names: ['weave:///my-team/my-project/op/my_op:*'] } });
for (const call of calls) {
  const weaveS = call.summary?.weave;
  console.log(call.id, weaveS?.status, weaveS?.latency_ms, call.summary?.accuracy);
}
```
