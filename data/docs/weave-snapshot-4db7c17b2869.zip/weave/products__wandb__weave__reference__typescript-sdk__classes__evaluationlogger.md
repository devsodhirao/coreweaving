> ## Documentation Index
> Fetch the complete documentation index at: https://docs.coreweave.com/llms.txt
> Use this file to discover all available pages before exploring further.

# EvaluationLogger

> TypeScript SDK reference

[GitHub source](https://github.com/wandb/weave/blob/7c9efdc9fe05ffcaf2430dd652ef9bc5b3ffdfaa/sdks/node/src/evaluationLogger.ts#L556)

EvaluationLogger enables incremental logging of predictions and scores.

Unlike the traditional Evaluation class which requires upfront dataset and batch processing,
EvaluationLogger allows you to log predictions as they happen, with flexible scoring.

## Example

```ts twoslash theme={"system"}
// @noErrors
const ev = new EvaluationLogger({name: 'my-eval', dataset: 'my-dataset'});

for (const example of streamingData) {
  const output = await myModel.predict(example);
  const pred = ev.logPrediction(example, output);

  if (shouldScore(output)) {
    pred.logScore("accuracy", calculateAccuracy(output));
  }
  pred.finish();
}

await ev.logSummary();
```

## Constructor

> **new EvaluationLogger**(`options`): `EvaluationLogger`

### Parameters

**options** `object` *required*

**properties**

**attributes** `Record\<string, any\>`

**dataset** `string | Dataset\<DatasetRow\>`

See [`Dataset`](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/classes/dataset).

**description** `string`

**model** `WeaveObject | \{ name?: string; \}`

See [`WeaveObject`](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/classes/weaveobject).

**name** `string` *required*

**scorers** `string[]`

### Returns

`EvaluationLogger`

## Methods

### logPrediction()

> **logPrediction**(`inputs`, `output`): [`ScoreLogger`](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/classes/scorelogger)

Log a prediction with its input and output (synchronous version).
Creates a predict\_and\_score call (with child predict call).
Returns a ScoreLogger immediately for adding scores.

This method returns the ScoreLogger synchronously. Operations on the
ScoreLogger (logScore, finish) will be queued and executed when initialization completes.

#### Parameters

**inputs** `Record\<string, any\>` *required*

**output** `any` *required*

#### Returns

[`ScoreLogger`](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/classes/scorelogger)

#### Example

```ts twoslash theme={"system"}
// @noErrors
// Fire-and-forget style
const scoreLogger = evalLogger.logPrediction({input: 'test'}, 'output');
scoreLogger.logScore('accuracy', 0.95);
scoreLogger.finish();
await evalLogger.logSummary(); // Waits for everything
```

***

### logPredictionAsync()

> **logPredictionAsync**(`inputs`, `output`): `Promise`\<[`ScoreLogger`](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/classes/scorelogger)>

Log a prediction with its input and output (async version).
Like logPrediction() but returns a Promise that resolves when
the prediction call is fully initialized.

Use this if you need to await the initialization before proceeding.

#### Parameters

**inputs** `Record\<string, any\>` *required*

**output** `any` *required*

#### Returns

`Promise`\<[`ScoreLogger`](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/classes/scorelogger)>

#### Example

```ts twoslash theme={"system"}
// @noErrors
// Awaitable style
const scoreLogger = await evalLogger.logPredictionAsync({input: 'test'}, 'output');
await scoreLogger.logScore('accuracy', 0.95);
await scoreLogger.finish();
```

***

### logSummary()

> **logSummary**(`summary?`): `Promise`\<`void`>

Log a summary and finalize the evaluation.
Creates a summarize call and finishes the evaluate call.

This method can be called without await (fire-and-forget), but internally
it will wait for all pending operations to complete.

#### Parameters

**summary** `Record\<string, any\>`

#### Returns

`Promise`\<`void`>
