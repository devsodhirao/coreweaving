> ## Documentation Index
> Fetch the complete documentation index at: https://docs.coreweave.com/llms.txt
> Use this file to discover all available pages before exploring further.

# Integrations overview

> Trace agents and LLM applications with Weave's integrations for agent SDKs, harnesses, LLM providers, and orchestration frameworks.

Weave provides two ways to integrate with your AI stack:

* **Trace agents**: for multi-turn agentic applications built with agent SDKs (such as the OpenAI Agents SDK or Google ADK) or run inside agent harnesses (such as Claude Code, Codex, or Pi.dev). These integrations capture sessions, turns, LLM calls, and tool calls, and render them in the Weave **Agents** view.
* **Trace LLM applications**: for code that calls LLM providers (OpenAI, Anthropic, Bedrock, and others) or uses orchestration frameworks (LangChain, LlamaIndex, DSPy, and others). These integrations capture individual LLM calls and pipeline steps as Weave **Calls** in the **Traces** view.

If you're not sure which path to take, start with [Trace your agents](https://docs.coreweave.com/products/wandb/weave/guides/tracking/trace-agents.md) for new multi-turn agent work, or [Trace LLM applications](https://docs.coreweave.com/products/wandb/weave/guides/tracking/tracing.md) for existing LLM-call workflows.

## Trace agents

Use these integrations when you're building multi-turn agentic applications and want sessions, turns, and tool calls to appear in the Weave **Agents** view. For agent SDKs, harnesses, and custom instrumentation, see [Choose an agent integration](https://docs.coreweave.com/products/wandb/weave/agent-integration-quickstart.md).

Agent SDKs run one turn per call. To group turns into a conversation, pass the SDK's own session or group identifier on every turn. The integration page for each SDK shows which identifier to use.

## Trace LLM applications

If your application calls an LLM provider's API directly or uses an orchestration framework, Weave can automatically intercept traces (using autopatching) for many libraries and frameworks. After you import the Weave SDK into your code and initialize it with `weave.init`, Weave records each request as a **Call** with inputs, outputs, latency, token usage, and cost.

For libraries Weave doesn't autopatch, you can manually apply [Weave Ops](https://docs.coreweave.com/products/wandb/weave/guides/tracking/create-call.md#2-tracking-of-custom-functions) to your code to capture traces.

### LLM providers

LLM providers are the vendors that offer access to large language models to generate predictions. Weave integrates with these providers to log and trace the interactions with their APIs:

* **[Serverless Inference Service](https://docs.coreweave.com/products/inference/serverless.md)**
* **[Amazon Bedrock](https://docs.coreweave.com/products/wandb/weave/guides/integrations/bedrock.md)**
* **[Anthropic](https://docs.coreweave.com/products/wandb/weave/guides/integrations/anthropic.md)**
* **[Cerebras](https://docs.coreweave.com/products/wandb/weave/guides/integrations/cerebras.md)**
* **[Cohere](https://docs.coreweave.com/products/wandb/weave/guides/integrations/cohere.md)**
* **[Google](https://docs.coreweave.com/products/wandb/weave/guides/integrations/google.md)**
* **[Groq](https://docs.coreweave.com/products/wandb/weave/guides/integrations/groq.md)**
* **[Hugging Face Hub](https://docs.coreweave.com/products/wandb/weave/guides/integrations/huggingface.md)**
* **[LiteLLM](https://docs.coreweave.com/products/wandb/weave/guides/integrations/litellm.md)**
* **[Microsoft Azure](https://docs.coreweave.com/products/wandb/weave/guides/integrations/azure.md)**
* **[MistralAI](https://docs.coreweave.com/products/wandb/weave/guides/integrations/mistral.md)**
* **[NVIDIA NIM](https://docs.coreweave.com/products/wandb/weave/guides/integrations/nvidia_nim.md)**
* **[OpenAI](https://docs.coreweave.com/products/wandb/weave/guides/integrations/openai.md)**
* **[OpenRouter](https://docs.coreweave.com/products/wandb/weave/guides/integrations/openrouter.md)**
* **[Together AI](https://docs.coreweave.com/products/wandb/weave/guides/integrations/together_ai.md)**
* **[Local Models](https://docs.coreweave.com/products/wandb/weave/guides/integrations/local_models.md)** (for models running on your own infrastructure)

### Frameworks

Frameworks help orchestrate the execution pipelines in AI applications. They provide tools and abstractions for building complex workflows. Weave integrates with these frameworks to trace the entire pipeline:

* **[OpenAI Agents SDK](https://docs.coreweave.com/products/wandb/weave/guides/integrations/agents/openai-agents-sdk.md)**
* **[Claude Agent SDK](https://docs.coreweave.com/products/wandb/weave/guides/integrations/agents/claude-agents-sdk.md)**
* **[Claude Code](https://docs.coreweave.com/products/wandb/weave/guides/integrations/agents/claude-code-harness.md)**
* **[LangChain](https://docs.coreweave.com/products/wandb/weave/guides/integrations/langchain.md)**
* **[LlamaIndex](https://docs.coreweave.com/products/wandb/weave/guides/integrations/llamaindex.md)**
* **[Haystack](https://docs.coreweave.com/products/wandb/weave/guides/integrations/haystack.md)**
* **[DSPy](https://docs.coreweave.com/products/wandb/weave/guides/integrations/dspy.md)**
* **[Instructor](https://docs.coreweave.com/products/wandb/weave/guides/integrations/instructor.md)**
* **[CrewAI](https://docs.coreweave.com/products/wandb/weave/guides/integrations/crewai.md)**
* **[Smolagents](https://docs.coreweave.com/products/wandb/weave/guides/integrations/smolagents.md)**
* **[PydanticAI](https://docs.coreweave.com/products/wandb/weave/guides/integrations/pydantic_ai.md)**
* **[Google Agent Development Kit (ADK)](https://docs.coreweave.com/products/wandb/weave/guides/integrations/agents/google-adk.md)**
* **[AutoGen](https://docs.coreweave.com/products/wandb/weave/guides/integrations/autogen.md)**
* **[Verdict](https://docs.coreweave.com/products/wandb/weave/guides/integrations/verdict.md)**
* **[TypeScript SDK](https://docs.coreweave.com/products/wandb/weave/guides/integrations/js.md)**
* **[Vercel AI SDK](https://docs.coreweave.com/products/wandb/weave/guides/integrations/vercel_ai_sdk.md)**
* **[Agno](https://docs.coreweave.com/products/wandb/weave/guides/integrations/agno.md)**
* **[Koog](https://docs.coreweave.com/products/wandb/weave/guides/integrations/koog.md)**

### Reinforcement learning frameworks

Weave integrates with reinforcement learning frameworks to trace training and evaluation runs:

* **[Verifiers](https://docs.coreweave.com/products/wandb/weave/guides/integrations/verifiers.md)**

### Protocols

Weave integrates with standardized protocols that enable communication between AI applications and their supporting services:

* **[Model Context Protocol (MCP)](https://docs.coreweave.com/products/wandb/weave/guides/integrations/mcp.md)**
