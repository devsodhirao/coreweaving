> ## Documentation Index
> Fetch the complete documentation index at: https://docs.coreweave.com/llms.txt
> Use this file to discover all available pages before exploring further.

# Annotation Queue Update

> Update an annotation queue's metadata (name, description, scorer_refs).



## OpenAPI

````yaml products/wandb/weave/reference/service-api/openapi.json PUT /annotation_queues/{queue_id}
openapi: 3.1.0
info:
  title: FastAPI
  version: 0.1.0
servers: []
security: []
paths:
  /annotation_queues/{queue_id}:
    put:
      tags:
        - Annotation Queues
      summary: Annotation Queue Update
      description: Update an annotation queue's metadata (name, description, scorer_refs).
      operationId: annotation_queue_update_annotation_queues__queue_id__put
      parameters:
        - name: queue_id
          in: path
          required: true
          schema:
            type: string
            title: Queue Id
      requestBody:
        required: true
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/AnnotationQueueUpdateBody'
      responses:
        '200':
          description: Successful Response
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/AnnotationQueueUpdateRes'
        '422':
          description: Validation Error
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/HTTPValidationError'
components:
  schemas:
    AnnotationQueueUpdateBody:
      properties:
        project_id:
          type: string
          title: Project Id
          examples:
            - entity/project
        name:
          anyOf:
            - type: string
            - type: 'null'
          title: Name
          examples:
            - Updated Queue Name
        description:
          anyOf:
            - type: string
            - type: 'null'
          title: Description
          examples:
            - Updated description
        scorer_refs:
          anyOf:
            - items:
                type: string
              type: array
            - type: 'null'
          title: Scorer Refs
          examples:
            - - weave:///entity/project/scorer/error_severity:abc123
              - weave:///entity/project/scorer/resolution_quality:def456
      type: object
      required:
        - project_id
      title: AnnotationQueueUpdateBody
      description: >-
        Request body for updating an annotation queue (queue_id comes from
        path).


        All fields except project_id are optional - only provided fields will be
        updated.
    AnnotationQueueUpdateRes:
      properties:
        queue:
          $ref: '#/components/schemas/AnnotationQueueSchema'
      type: object
      required:
        - queue
      title: AnnotationQueueUpdateRes
      description: Response from updating an annotation queue.
    HTTPValidationError:
      properties:
        detail:
          items:
            $ref: '#/components/schemas/ValidationError'
          type: array
          title: Detail
      type: object
      title: HTTPValidationError
    AnnotationQueueSchema:
      properties:
        id:
          type: string
          title: Id
        project_id:
          type: string
          title: Project Id
        name:
          type: string
          title: Name
        description:
          type: string
          title: Description
        scorer_refs:
          items:
            type: string
          type: array
          title: Scorer Refs
        created_at:
          type: string
          format: date-time
          title: Created At
        created_by:
          type: string
          title: Created By
        updated_at:
          type: string
          format: date-time
          title: Updated At
        deleted_at:
          anyOf:
            - type: string
              format: date-time
            - type: 'null'
          title: Deleted At
      type: object
      required:
        - id
        - project_id
        - name
        - description
        - scorer_refs
        - created_at
        - created_by
        - updated_at
      title: AnnotationQueueSchema
      description: Schema for annotation queue responses.
    ValidationError:
      properties:
        loc:
          items:
            anyOf:
              - type: string
              - type: integer
          type: array
          title: Location
        msg:
          type: string
          title: Message
        type:
          type: string
          title: Error Type
        input:
          title: Input
        ctx:
          type: object
          title: Context
      type: object
      required:
        - loc
        - msg
        - type
      title: ValidationError

````