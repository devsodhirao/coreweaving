> ## Documentation Index
> Fetch the complete documentation index at: https://docs.coreweave.com/llms.txt
> Use this file to discover all available pages before exploring further.

# OpDecorator<T>

> TypeScript SDK reference

> **OpDecorator**\<`T`> = (`value`, `context`) => `T` | `void` & (`target`, `propertyKey`, `descriptor`) => `TypedPropertyDescriptor`\<`T`> | `void`

[GitHub source](https://github.com/wandb/weave/blob/7c9efdc9fe05ffcaf2430dd652ef9bc5b3ffdfaa/sdks/node/src/opType.ts#L43)

Helper type for decorators
This represents a decorator function that can be used with both legacy and Stage 3 decorators.

For Stage 3 decorators:
target: The function being decorated (T)
context: MethodDecoratorContext

For legacy decorators:
target: The prototype (instance methods) or constructor (static methods)
propertyKey: The method name
descriptor: The property descriptor containing the method

## Type Parameters

**T** `extends (...args) =\> any`
