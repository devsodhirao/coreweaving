> ## Documentation Index
> Fetch the complete documentation index at: https://docs.coreweave.com/llms.txt
> Use this file to discover all available pages before exploring further.

# endSession

> TypeScript SDK reference

> [!WARNING]
>
> **Deprecated.** Use [endConversation](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/functions/endconversation.md) instead.

> `const` **endSession**: (`opts?`) => `void` = `endConversation`

[GitHub source](https://github.com/wandb/weave/blob/7c9efdc9fe05ffcaf2430dd652ef9bc5b3ffdfaa/sdks/node/src/genai/api.ts#L169)

End the current Conversation. No-op if no Conversation is active.

## Parameters

**opts** `object`

**properties**

**endTime** `TimeInput`

**error** `Error`

## Returns

`void`

## Examples

```ts twoslash theme={"system"}
// @noErrors
weave.endConversation();
```

```ts twoslash theme={"system"}
// @noErrors
weave.endConversation({endTime: new Date('2026-05-29T10:00:01.700Z')});
```
