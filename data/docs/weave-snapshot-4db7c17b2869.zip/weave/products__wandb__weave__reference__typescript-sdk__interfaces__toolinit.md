> ## Documentation Index
> Fetch the complete documentation index at: https://docs.coreweave.com/llms.txt
> Use this file to discover all available pages before exploring further.

# ToolInit

> TypeScript SDK reference

[GitHub source](https://github.com/wandb/weave/blob/7c9efdc9fe05ffcaf2430dd652ef9bc5b3ffdfaa/sdks/node/src/genai/tool.ts#L18)

## Extends

* `SpanInitBase`

## Properties

### args

> `optional` **args**: `string` | [`JsonObject`](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/type-aliases/jsonobject)

A JSON object, or a pre-serialized string recorded as-is.

***

### name

> **name**: `string`

***

### startTime

> `optional` **startTime**: `TimeInput`

#### Inherited from

`SpanInitBase.startTime`

***

### toolCallId

> `optional` **toolCallId**: `string`
