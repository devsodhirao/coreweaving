> ## Documentation Index
> Fetch the complete documentation index at: https://docs.coreweave.com/llms.txt
> Use this file to discover all available pages before exploring further.

# GenAI Conversation Chat



## OpenAPI

````yaml products/wandb/weave/reference/service-api/openapi.json POST /agents/conversations/chat
openapi: 3.1.0
info:
  title: FastAPI
  version: 0.1.0
servers: []
security: []
paths:
  /agents/conversations/chat:
    post:
      tags:
        - Agents
      summary: Genai Conversation Chat
      operationId: genai_conversation_chat_agents_conversations_chat_post
      requestBody:
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/AgentConversationChatReq'
        required: true
      responses:
        '200':
          description: Successful Response
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/AgentConversationChatRes'
        '422':
          description: Validation Error
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/HTTPValidationError'
components:
  schemas:
    AgentConversationChatReq:
      properties:
        project_id:
          type: string
          title: Project Id
        conversation_id:
          type: string
          title: Conversation Id
        limit:
          type: integer
          maximum: 50
          minimum: 0
          title: Limit
          description: Maximum number of conversation turns to return.
          default: 50
        offset:
          type: integer
          minimum: 0
          title: Offset
          description: >-
            Number of most-recent turns to skip. Results are returned in
            chronological order within the selected page.
          default: 0
        include_feedback:
          type: boolean
          title: Include Feedback
          default: false
      type: object
      required:
        - project_id
        - conversation_id
      title: AgentConversationChatReq
      description: Request to get the multi-turn chat view for a conversation.
    AgentConversationChatRes:
      properties:
        conversation_id:
          type: string
          title: Conversation Id
        turns:
          items:
            $ref: '#/components/schemas/AgentTraceChatRes'
          type: array
          title: Turns
        total_turns:
          type: integer
          title: Total Turns
          default: 0
        has_more:
          type: boolean
          title: Has More
          default: false
        limit:
          type: integer
          title: Limit
          default: 50
        offset:
          type: integer
          title: Offset
          default: 0
        total_cost_usd:
          anyOf:
            - type: number
            - type: 'null'
          title: Total Cost Usd
        feedback:
          anyOf:
            - items:
                $ref: '#/components/schemas/AgentChatFeedback'
              type: array
            - type: 'null'
          title: Feedback
      type: object
      required:
        - conversation_id
        - turns
        - total_turns
        - has_more
        - limit
        - offset
        - total_cost_usd
        - feedback
      title: AgentConversationChatRes
      description: >-
        Multi-turn chat view: an ordered list of per-turn chat responses.


        Each entry in `turns` corresponds to one trace_id, which Weave treats as

        one conversation turn. This is not necessarily one `invoke_agent` span:

        a turn can contain zero, one, or many agent invocations. The frontend
        can

        render turn-number dividers between entries and still reuse

        `AgentTraceChatRes` rendering for each individual turn.
    HTTPValidationError:
      properties:
        detail:
          items:
            $ref: '#/components/schemas/ValidationError'
          type: array
          title: Detail
      type: object
      title: HTTPValidationError
    AgentTraceChatRes:
      properties:
        trace_id:
          type: string
          title: Trace Id
        root_span_name:
          anyOf:
            - type: string
            - type: 'null'
          title: Root Span Name
        agent_name:
          anyOf:
            - type: string
            - type: 'null'
          title: Agent Name
        agent_version:
          anyOf:
            - type: string
            - type: 'null'
          title: Agent Version
        status_code:
          anyOf:
            - type: string
              enum:
                - UNSET
                - OK
                - ERROR
            - type: 'null'
          title: Status Code
        provider:
          anyOf:
            - type: string
            - type: 'null'
          title: Provider
        started_at:
          anyOf:
            - type: string
              format: date-time
            - type: 'null'
          title: Started At
        ended_at:
          anyOf:
            - type: string
              format: date-time
            - type: 'null'
          title: Ended At
        wb_user_id:
          anyOf:
            - type: string
            - type: 'null'
          title: Wb User Id
        total_duration_ms:
          anyOf:
            - type: integer
            - type: 'null'
          title: Total Duration Ms
          description: >-
            Wall-clock duration of the trace root span in milliseconds. This is
            not a sum of child span durations.
        total_cost_usd:
          anyOf:
            - type: number
            - type: 'null'
          title: Total Cost Usd
        total_input_tokens:
          type: integer
          title: Total Input Tokens
          default: 0
        total_output_tokens:
          type: integer
          title: Total Output Tokens
          default: 0
        total_reasoning_tokens:
          type: integer
          title: Total Reasoning Tokens
          default: 0
        total_cache_creation_input_tokens:
          type: integer
          title: Total Cache Creation Input Tokens
          default: 0
        total_cache_read_input_tokens:
          type: integer
          title: Total Cache Read Input Tokens
          default: 0
        messages:
          items:
            $ref: '#/components/schemas/AgentChatMessage'
          type: array
          title: Messages
        feedback:
          anyOf:
            - items:
                $ref: '#/components/schemas/AgentChatFeedback'
              type: array
            - type: 'null'
          title: Feedback
      type: object
      required:
        - trace_id
        - root_span_name
        - agent_name
        - agent_version
        - status_code
        - provider
        - started_at
        - ended_at
        - wb_user_id
        - total_duration_ms
        - total_cost_usd
        - total_input_tokens
        - total_output_tokens
        - total_reasoning_tokens
        - total_cache_creation_input_tokens
        - total_cache_read_input_tokens
        - messages
        - feedback
      title: AgentTraceChatRes
      description: |-
        Structured chat view: a linear sequence of messages representing
        the agent trajectory for a single trace.
    AgentChatFeedback:
      properties:
        id:
          type: string
          title: Id
        feedback_type:
          type: string
          title: Feedback Type
        weave_ref:
          type: string
          title: Weave Ref
        payload:
          additionalProperties: true
          type: object
          title: Payload
        creator:
          anyOf:
            - type: string
            - type: 'null'
          title: Creator
        created_at:
          anyOf:
            - type: string
              format: date-time
            - type: 'null'
          title: Created At
        wb_user_id:
          anyOf:
            - type: string
            - type: 'null'
          title: Wb User Id
        runnable_ref:
          anyOf:
            - type: string
            - type: 'null'
          title: Runnable Ref
        call_ref:
          anyOf:
            - type: string
            - type: 'null'
          title: Call Ref
        trigger_ref:
          anyOf:
            - type: string
            - type: 'null'
          title: Trigger Ref
        annotation_ref:
          anyOf:
            - type: string
            - type: 'null'
          title: Annotation Ref
        scorer_tags:
          items:
            type: string
          type: array
          title: Scorer Tags
        scorer_tag_reasons:
          additionalProperties:
            type: string
          type: object
          title: Scorer Tag Reasons
        scorer_tag_confidences:
          additionalProperties:
            type: number
          type: object
          title: Scorer Tag Confidences
        scorer_ratings:
          additionalProperties:
            type: number
          type: object
          title: Scorer Ratings
        scorer_rating_reasons:
          additionalProperties:
            type: string
          type: object
          title: Scorer Rating Reasons
        scorer_rating_confidences:
          additionalProperties:
            type: number
          type: object
          title: Scorer Rating Confidences
      type: object
      required:
        - id
        - feedback_type
        - weave_ref
        - payload
        - creator
        - created_at
        - wb_user_id
        - runnable_ref
        - call_ref
        - trigger_ref
        - annotation_ref
        - scorer_tags
        - scorer_tag_reasons
        - scorer_tag_confidences
        - scorer_ratings
        - scorer_rating_reasons
        - scorer_rating_confidences
      title: AgentChatFeedback
      description: |-
        Feedback row from the agent chat `include_feedback` projection.

        Field names match FEEDBACK_QUERY_FIELDS. This is not the feedback
        table row and not FeedbackCreateReq: project_id and span_* are not
        selected.
    ValidationError:
      properties:
        loc:
          items:
            anyOf:
              - type: string
              - type: integer
          type: array
          title: Location
        msg:
          type: string
          title: Message
        type:
          type: string
          title: Error Type
        input:
          title: Input
        ctx:
          type: object
          title: Context
      type: object
      required:
        - loc
        - msg
        - type
      title: ValidationError
    AgentChatMessage:
      properties:
        type:
          type: string
          enum:
            - user_message
            - assistant_message
            - tool_call
            - agent_handoff
            - agent_start
            - context_compacted
          title: Type
        span_id:
          anyOf:
            - type: string
            - type: 'null'
          title: Span Id
        agent_name:
          anyOf:
            - type: string
            - type: 'null'
          title: Agent Name
        agent_version:
          anyOf:
            - type: string
            - type: 'null'
          title: Agent Version
        status_code:
          anyOf:
            - type: string
              enum:
                - UNSET
                - OK
                - ERROR
            - type: 'null'
          title: Status Code
        started_at:
          anyOf:
            - type: string
              format: date-time
            - type: 'null'
          title: Started At
        user_message:
          anyOf:
            - $ref: '#/components/schemas/AgentChatUserMessage'
            - type: 'null'
        assistant_message:
          anyOf:
            - $ref: '#/components/schemas/AgentChatAssistantMessage'
            - type: 'null'
        tool_call:
          anyOf:
            - $ref: '#/components/schemas/AgentChatToolCall'
            - type: 'null'
        agent_start:
          anyOf:
            - $ref: '#/components/schemas/AgentChatAgentStart'
            - type: 'null'
        agent_handoff:
          anyOf:
            - $ref: '#/components/schemas/AgentChatAgentHandoff'
            - type: 'null'
        context_compacted:
          anyOf:
            - $ref: '#/components/schemas/AgentChatContextCompacted'
            - type: 'null'
        feedback:
          anyOf:
            - items:
                $ref: '#/components/schemas/AgentChatFeedback'
              type: array
            - type: 'null'
          title: Feedback
      type: object
      required:
        - type
        - span_id
        - agent_name
        - agent_version
        - status_code
        - started_at
        - user_message
        - assistant_message
        - tool_call
        - agent_start
        - agent_handoff
        - context_compacted
        - feedback
      title: AgentChatMessage
      description: >-
        A single element in the structured agent trajectory / chat view.


        Common event fields live at the top level. Type-specific fields are

        grouped under the payload matching `type`, and exactly one payload must
        be

        set. This keeps subtype nullability explicit while preserving a single

        ordered timeline model for callers.
    AgentChatUserMessage:
      properties:
        text:
          type: string
          title: Text
        content_refs:
          items:
            type: string
          type: array
          title: Content Refs
      type: object
      required:
        - text
        - content_refs
      title: AgentChatUserMessage
      description: Payload for a user prompt in the chat timeline.
    AgentChatAssistantMessage:
      properties:
        text:
          type: string
          title: Text
        model:
          anyOf:
            - type: string
            - type: 'null'
          title: Model
        reasoning_content:
          anyOf:
            - type: string
            - type: 'null'
          title: Reasoning Content
        reasoning_tokens:
          anyOf:
            - type: integer
            - type: 'null'
          title: Reasoning Tokens
        input_tokens:
          anyOf:
            - type: integer
            - type: 'null'
          title: Input Tokens
        output_tokens:
          anyOf:
            - type: integer
            - type: 'null'
          title: Output Tokens
        input_cost_usd:
          anyOf:
            - type: number
            - type: 'null'
          title: Input Cost Usd
        output_cost_usd:
          anyOf:
            - type: number
            - type: 'null'
          title: Output Cost Usd
        total_cost_usd:
          anyOf:
            - type: number
            - type: 'null'
          title: Total Cost Usd
        duration_ms:
          anyOf:
            - type: integer
            - type: 'null'
          title: Duration Ms
        status:
          anyOf:
            - type: string
              enum:
                - UNSET
                - OK
                - ERROR
            - type: 'null'
          title: Status
        content_refs:
          items:
            type: string
          type: array
          title: Content Refs
      type: object
      required:
        - text
        - model
        - reasoning_content
        - reasoning_tokens
        - input_tokens
        - output_tokens
        - input_cost_usd
        - output_cost_usd
        - total_cost_usd
        - duration_ms
        - status
        - content_refs
      title: AgentChatAssistantMessage
      description: Payload for assistant text emitted by an agent or LLM span.
    AgentChatToolCall:
      properties:
        tool_name:
          anyOf:
            - type: string
            - type: 'null'
          title: Tool Name
        tool_arguments:
          anyOf:
            - type: string
            - type: 'null'
          title: Tool Arguments
        tool_result:
          anyOf:
            - type: string
            - type: 'null'
          title: Tool Result
        duration_ms:
          anyOf:
            - type: integer
            - type: 'null'
          title: Duration Ms
        status:
          anyOf:
            - type: string
              enum:
                - UNSET
                - OK
                - ERROR
            - type: 'null'
          title: Status
        content_refs:
          items:
            type: string
          type: array
          title: Content Refs
      type: object
      required:
        - tool_name
        - tool_arguments
        - tool_result
        - duration_ms
        - status
        - content_refs
      title: AgentChatToolCall
      description: Payload for a tool call timeline event.
    AgentChatAgentStart:
      properties:
        model:
          anyOf:
            - type: string
            - type: 'null'
          title: Model
        system_instructions:
          anyOf:
            - type: string
            - type: 'null'
          title: System Instructions
        tool_definitions:
          anyOf:
            - type: string
            - type: 'null'
          title: Tool Definitions
        status:
          anyOf:
            - type: string
              enum:
                - UNSET
                - OK
                - ERROR
            - type: 'null'
          title: Status
      type: object
      required:
        - model
        - system_instructions
        - tool_definitions
        - status
      title: AgentChatAgentStart
      description: Payload for an agent lifecycle boundary.
    AgentChatAgentHandoff:
      properties: {}
      type: object
      title: AgentChatAgentHandoff
      description: Payload for a future agent-to-agent handoff event.
    AgentChatContextCompacted:
      properties:
        compaction_summary:
          anyOf:
            - type: string
            - type: 'null'
          title: Compaction Summary
        compaction_items_before:
          anyOf:
            - type: integer
            - type: 'null'
          title: Compaction Items Before
        compaction_items_after:
          anyOf:
            - type: integer
            - type: 'null'
          title: Compaction Items After
      type: object
      required:
        - compaction_summary
        - compaction_items_before
        - compaction_items_after
      title: AgentChatContextCompacted
      description: Payload for a context-window compaction event.

````