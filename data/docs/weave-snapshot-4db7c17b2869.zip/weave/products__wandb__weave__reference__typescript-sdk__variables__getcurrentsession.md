> ## Documentation Index
> Fetch the complete documentation index at: https://docs.coreweave.com/llms.txt
> Use this file to discover all available pages before exploring further.

# getCurrentSession

> TypeScript SDK reference

> [!WARNING]
>
> **Deprecated.** Use [getCurrentConversation](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/functions/getcurrentconversation.md) instead.

> `const` **getCurrentSession**: () => [`Conversation`](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/interfaces/conversation) | `undefined` = `getCurrentConversation`

[GitHub source](https://github.com/wandb/weave/blob/7c9efdc9fe05ffcaf2430dd652ef9bc5b3ffdfaa/sdks/node/src/genai/context.ts#L64)

Returns the current Conversation, or undefined.

## Returns

[`Conversation`](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/interfaces/conversation) | `undefined`
