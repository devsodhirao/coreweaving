> ## Documentation Index
> Fetch the complete documentation index at: https://docs.coreweave.com/llms.txt
> Use this file to discover all available pages before exploring further.

# Eval Results Query

> Read grouped evaluation result rows for one or more evaluations.



## OpenAPI

````yaml products/wandb/weave/reference/service-api/openapi.json POST /v2/{entity}/{project}/eval_results/query
openapi: 3.1.0
info:
  title: FastAPI
  version: 0.1.0
servers: []
security: []
paths:
  /v2/{entity}/{project}/eval_results/query:
    post:
      tags:
        - Eval Results
      summary: Eval Results Query
      description: Read grouped evaluation result rows for one or more evaluations.
      operationId: eval_results_query_v2__entity___project__eval_results_query_post
      parameters:
        - name: entity
          in: path
          required: true
          schema:
            type: string
            title: Entity
        - name: project
          in: path
          required: true
          schema:
            type: string
            title: Project
      requestBody:
        required: true
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/EvalResultsQueryBody'
      responses:
        '200':
          description: Successful Response
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/EvalResultsQueryRes'
        '422':
          description: Validation Error
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/HTTPValidationError'
components:
  schemas:
    EvalResultsQueryBody:
      properties:
        evaluation_call_ids:
          anyOf:
            - items:
                type: string
              type: array
            - type: 'null'
          title: Evaluation Call Ids
          description: Evaluation root call IDs to include.
        evaluation_run_ids:
          anyOf:
            - items:
                type: string
              type: array
            - type: 'null'
          title: Evaluation Run Ids
          description: Alias for evaluation call IDs from the Evaluation Runs API.
        require_intersection:
          type: boolean
          title: Require Intersection
          description: When true, only include rows present in all requested evaluations.
          default: false
        include_raw_data_rows:
          type: boolean
          title: Include Raw Data Rows
          description: >-
            When true, populate raw_data_row on each result row. Inline rows are
            returned as their dict value; dataset-referenced rows are returned
            as the ref string unless resolve_row_refs is also true.
          default: false
        resolve_row_refs:
          type: boolean
          title: Resolve Row Refs
          description: >-
            When true (requires include_raw_data_rows=True), resolve dataset-row
            reference strings to actual row data via a table lookup. When false,
            dataset-row refs are returned as-is.
          default: false
        include_rows:
          type: boolean
          title: Include Rows
          description: >-
            When true, include grouped row/trial data in `rows` and compute
            `total_rows` for the requested row-level view.
          default: true
        include_summary:
          type: boolean
          title: Include Summary
          description: >-
            When true, include aggregated scorer/evaluation summary data in
            `summary`.
          default: false
        summary_require_intersection:
          anyOf:
            - type: boolean
            - type: 'null'
          title: Summary Require Intersection
          description: >-
            Optional intersection behavior for the summary section. When null,
            the value of `require_intersection` is used.
        include_predict_and_score_children:
          type: boolean
          title: Include Predict And Score Children
          description: >-
            When true (default), fetch child calls (predict/score) of each
            predict_and_score call to populate predict_call_id, scorer_call_ids,
            and more precise latency/token data. When false, these fields are
            derived from the predict_and_score call itself (predict_call_id and
            scorer_call_ids will be null/empty).
          default: true
        include_costs:
          type: boolean
          title: Include Costs
          description: >-
            When true, price each trial's predict call so rows and summary
            report predict-only cost (`total_cost` / `predict_total_cost`);
            scorer costs are excluded. Opt-in: other callers skip the cost
            computation.
          default: false
        sort_by:
          anyOf:
            - items:
                $ref: '#/components/schemas/EvalResultsSortBy'
              type: array
            - type: 'null'
          title: Sort By
          description: >-
            Sort specification for result rows. Supported field prefixes:
            scores.<name>, inputs.<path>, outputs.<path>. When null, rows are
            sorted by row_digest ASC.
        filters:
          anyOf:
            - items:
                $ref: '#/components/schemas/EvalResultsFilter'
              type: array
            - type: 'null'
          title: Filters
          description: >-
            Filters applied to grouped rows. Multiple filters are AND'd
            together.
        filter_logic_operator:
          type: string
          enum:
            - and
            - or
          title: Filter Logic Operator
          description: >-
            How to combine filters across evaluations: 'and' (Match All - row
            must match in ALL evals) or 'or' (Match Any - row must match in ANY
            eval). Defaults to 'or' (Match Any).
          default: or
        limit:
          anyOf:
            - type: integer
            - type: 'null'
          title: Limit
          description: >-
            Optional row-level page size applied after grouping and
            intersection.
        offset:
          type: integer
          title: Offset
          description: >-
            Optional row-level page offset applied after grouping and
            intersection.
          default: 0
      type: object
      title: EvalResultsQueryBody
    EvalResultsQueryRes:
      properties:
        rows:
          items:
            $ref: '#/components/schemas/EvalResultsRow'
          type: array
          title: Rows
        total_rows:
          type: integer
          title: Total Rows
        summary:
          anyOf:
            - $ref: '#/components/schemas/EvalResultsSummaryRes'
            - type: 'null'
        warnings:
          items:
            type: string
          type: array
          title: Warnings
          description: Non-fatal warnings (e.g. failed to resolve dataset row refs).
      type: object
      required:
        - rows
        - total_rows
      title: EvalResultsQueryRes
    HTTPValidationError:
      properties:
        detail:
          items:
            $ref: '#/components/schemas/ValidationError'
          type: array
          title: Detail
      type: object
      title: HTTPValidationError
    EvalResultsSortBy:
      properties:
        field:
          type: string
          title: Field
        direction:
          type: string
          enum:
            - asc
            - desc
          title: Direction
        evaluation_call_id:
          anyOf:
            - type: string
            - type: 'null'
          title: Evaluation Call Id
          description: Scope the sort to a specific evaluation's scores.
        mode:
          type: string
          enum:
            - value
            - difference
          title: Mode
          description: >-
            When 'value', sort by the field value for the specified evaluation.
            When 'difference', sort by max-min spread of the field across all
            evaluations (evaluation_call_id is ignored).
          default: value
      type: object
      required:
        - field
        - direction
      title: EvalResultsSortBy
      description: Sort specification for evaluation results, extending SortBy
    EvalResultsFilter:
      properties:
        evaluation_call_id:
          anyOf:
            - type: string
            - type: 'null'
          title: Evaluation Call Id
          description: When set, filter fields are scoped to this evaluation's data.
        query:
          $ref: '#/components/schemas/Query'
          description: >-
            Filter expression. Supported field prefixes: scores.<name>,
            inputs.<path>, outputs.<path>.
      type: object
      required:
        - query
      title: EvalResultsFilter
      description: A filter scoped to an optional evaluation.
    EvalResultsRow:
      properties:
        row_digest:
          type: string
          title: Row Digest
        raw_data_row:
          anyOf:
            - {}
            - type: 'null'
          title: Raw Data Row
        evaluations:
          items:
            $ref: '#/components/schemas/EvalResultsRowEvaluation'
          type: array
          title: Evaluations
      type: object
      required:
        - row_digest
      title: EvalResultsRow
    EvalResultsSummaryRes:
      properties:
        row_count:
          type: integer
          title: Row Count
          default: 0
        evaluations:
          items:
            $ref: '#/components/schemas/EvalResultsEvaluationSummary'
          type: array
          title: Evaluations
      type: object
      title: EvalResultsSummaryRes
    ValidationError:
      properties:
        loc:
          items:
            anyOf:
              - type: string
              - type: integer
          type: array
          title: Location
        msg:
          type: string
          title: Message
        type:
          type: string
          title: Error Type
        input:
          title: Input
        ctx:
          type: object
          title: Context
      type: object
      required:
        - loc
        - msg
        - type
      title: ValidationError
    Query:
      properties:
        $expr:
          anyOf:
            - $ref: '#/components/schemas/AndOperation'
            - $ref: '#/components/schemas/OrOperation'
            - $ref: '#/components/schemas/NotOperation'
            - $ref: '#/components/schemas/EqOperation'
            - $ref: '#/components/schemas/GtOperation'
            - $ref: '#/components/schemas/LtOperation'
            - $ref: '#/components/schemas/GteOperation'
            - $ref: '#/components/schemas/LteOperation'
            - $ref: '#/components/schemas/InOperation'
            - $ref: '#/components/schemas/ContainsOperation'
          title: $Expr
      additionalProperties: false
      type: object
      required:
        - $expr
      title: Query
    EvalResultsRowEvaluation:
      properties:
        evaluation_call_id:
          type: string
          title: Evaluation Call Id
        trials:
          items:
            $ref: '#/components/schemas/EvalResultsTrial'
          type: array
          title: Trials
      type: object
      required:
        - evaluation_call_id
      title: EvalResultsRowEvaluation
    EvalResultsEvaluationSummary:
      properties:
        evaluation_call_id:
          type: string
          title: Evaluation Call Id
        trial_count:
          type: integer
          title: Trial Count
          default: 0
        scorer_stats:
          items:
            $ref: '#/components/schemas/EvalResultsScorerStats'
          type: array
          title: Scorer Stats
        predict_total_tokens:
          anyOf:
            - type: integer
            - type: 'null'
          title: Predict Total Tokens
          description: >-
            Sum of per-trial predict-only token usage for this evaluation (the
            model's predict() tokens only, excluding LLM-as-a-judge scorer
            usage); None when no trial reports usage.
        predict_total_cost:
          anyOf:
            - type: number
            - type: 'null'
          title: Predict Total Cost
          description: >-
            Sum of per-trial predict-only cost for this evaluation (the model's
            predict() cost only, excluding LLM-as-a-judge scorer cost); None
            when no trial reports cost.
        evaluation_ref:
          anyOf:
            - type: string
            - type: 'null'
          title: Evaluation Ref
        model_ref:
          anyOf:
            - type: string
            - type: 'null'
          title: Model Ref
        display_name:
          anyOf:
            - type: string
            - type: 'null'
          title: Display Name
        trace_id:
          anyOf:
            - type: string
            - type: 'null'
          title: Trace Id
        started_at:
          anyOf:
            - type: string
            - type: 'null'
          title: Started At
      type: object
      required:
        - evaluation_call_id
      title: EvalResultsEvaluationSummary
    AndOperation:
      properties:
        $and:
          items:
            anyOf:
              - $ref: '#/components/schemas/LiteralOperation'
              - $ref: '#/components/schemas/GetFieldOperator'
              - $ref: '#/components/schemas/ConvertOperation'
              - $ref: '#/components/schemas/SizeOperation'
              - $ref: '#/components/schemas/AndOperation'
              - $ref: '#/components/schemas/OrOperation'
              - $ref: '#/components/schemas/NotOperation'
              - $ref: '#/components/schemas/EqOperation'
              - $ref: '#/components/schemas/GtOperation'
              - $ref: '#/components/schemas/LtOperation'
              - $ref: '#/components/schemas/GteOperation'
              - $ref: '#/components/schemas/LteOperation'
              - $ref: '#/components/schemas/InOperation'
              - $ref: '#/components/schemas/ContainsOperation'
          type: array
          title: $And
      type: object
      required:
        - $and
      title: AndOperation
      description: |-
        Logical AND. All conditions must evaluate to true.

        Example:
            ```
            {
                "$and": [
                    {"$eq": [{"$getField": "op_name"}, {"$literal": "predict"}]},
                    {"$gt": [{"$getField": "summary.usage.tokens"}, {"$literal": 1000}]}
                ]
            }
            ```
    OrOperation:
      properties:
        $or:
          items:
            anyOf:
              - $ref: '#/components/schemas/LiteralOperation'
              - $ref: '#/components/schemas/GetFieldOperator'
              - $ref: '#/components/schemas/ConvertOperation'
              - $ref: '#/components/schemas/SizeOperation'
              - $ref: '#/components/schemas/AndOperation'
              - $ref: '#/components/schemas/OrOperation'
              - $ref: '#/components/schemas/NotOperation'
              - $ref: '#/components/schemas/EqOperation'
              - $ref: '#/components/schemas/GtOperation'
              - $ref: '#/components/schemas/LtOperation'
              - $ref: '#/components/schemas/GteOperation'
              - $ref: '#/components/schemas/LteOperation'
              - $ref: '#/components/schemas/InOperation'
              - $ref: '#/components/schemas/ContainsOperation'
          type: array
          title: $Or
      type: object
      required:
        - $or
      title: OrOperation
      description: |-
        Logical OR. At least one condition must be true.

        Example:
            ```
            {
                "$or": [
                    {"$eq": [{"$getField": "op_name"}, {"$literal": "a"}]},
                    {"$eq": [{"$getField": "op_name"}, {"$literal": "b"}]}
                ]
            }
            ```
    NotOperation:
      properties:
        $not:
          prefixItems:
            - anyOf:
                - $ref: '#/components/schemas/LiteralOperation'
                - $ref: '#/components/schemas/GetFieldOperator'
                - $ref: '#/components/schemas/ConvertOperation'
                - $ref: '#/components/schemas/SizeOperation'
                - $ref: '#/components/schemas/AndOperation'
                - $ref: '#/components/schemas/OrOperation'
                - $ref: '#/components/schemas/NotOperation'
                - $ref: '#/components/schemas/EqOperation'
                - $ref: '#/components/schemas/GtOperation'
                - $ref: '#/components/schemas/LtOperation'
                - $ref: '#/components/schemas/GteOperation'
                - $ref: '#/components/schemas/LteOperation'
                - $ref: '#/components/schemas/InOperation'
                - $ref: '#/components/schemas/ContainsOperation'
          type: array
          maxItems: 1
          minItems: 1
          title: $Not
      type: object
      required:
        - $not
      title: NotOperation
      description: |-
        Logical NOT. Inverts the condition.

        Example:
            ```
            {
                "$not": [
                    {"$eq": [{"$getField": "op_name"}, {"$literal": "debug"}]}
                ]
            }
            ```
    EqOperation:
      properties:
        $eq:
          prefixItems:
            - anyOf:
                - $ref: '#/components/schemas/LiteralOperation'
                - $ref: '#/components/schemas/GetFieldOperator'
                - $ref: '#/components/schemas/ConvertOperation'
                - $ref: '#/components/schemas/SizeOperation'
                - $ref: '#/components/schemas/AndOperation'
                - $ref: '#/components/schemas/OrOperation'
                - $ref: '#/components/schemas/NotOperation'
                - $ref: '#/components/schemas/EqOperation'
                - $ref: '#/components/schemas/GtOperation'
                - $ref: '#/components/schemas/LtOperation'
                - $ref: '#/components/schemas/GteOperation'
                - $ref: '#/components/schemas/LteOperation'
                - $ref: '#/components/schemas/InOperation'
                - $ref: '#/components/schemas/ContainsOperation'
            - anyOf:
                - $ref: '#/components/schemas/LiteralOperation'
                - $ref: '#/components/schemas/GetFieldOperator'
                - $ref: '#/components/schemas/ConvertOperation'
                - $ref: '#/components/schemas/SizeOperation'
                - $ref: '#/components/schemas/AndOperation'
                - $ref: '#/components/schemas/OrOperation'
                - $ref: '#/components/schemas/NotOperation'
                - $ref: '#/components/schemas/EqOperation'
                - $ref: '#/components/schemas/GtOperation'
                - $ref: '#/components/schemas/LtOperation'
                - $ref: '#/components/schemas/GteOperation'
                - $ref: '#/components/schemas/LteOperation'
                - $ref: '#/components/schemas/InOperation'
                - $ref: '#/components/schemas/ContainsOperation'
          type: array
          maxItems: 2
          minItems: 2
          title: $Eq
      type: object
      required:
        - $eq
      title: EqOperation
      description: |-
        Equality check between two operands.

        Example:
            ```
            {
                "$eq": [{"$getField": "op_name"}, {"$literal": "predict"}]
            }
            ```
    GtOperation:
      properties:
        $gt:
          prefixItems:
            - anyOf:
                - $ref: '#/components/schemas/LiteralOperation'
                - $ref: '#/components/schemas/GetFieldOperator'
                - $ref: '#/components/schemas/ConvertOperation'
                - $ref: '#/components/schemas/SizeOperation'
                - $ref: '#/components/schemas/AndOperation'
                - $ref: '#/components/schemas/OrOperation'
                - $ref: '#/components/schemas/NotOperation'
                - $ref: '#/components/schemas/EqOperation'
                - $ref: '#/components/schemas/GtOperation'
                - $ref: '#/components/schemas/LtOperation'
                - $ref: '#/components/schemas/GteOperation'
                - $ref: '#/components/schemas/LteOperation'
                - $ref: '#/components/schemas/InOperation'
                - $ref: '#/components/schemas/ContainsOperation'
            - anyOf:
                - $ref: '#/components/schemas/LiteralOperation'
                - $ref: '#/components/schemas/GetFieldOperator'
                - $ref: '#/components/schemas/ConvertOperation'
                - $ref: '#/components/schemas/SizeOperation'
                - $ref: '#/components/schemas/AndOperation'
                - $ref: '#/components/schemas/OrOperation'
                - $ref: '#/components/schemas/NotOperation'
                - $ref: '#/components/schemas/EqOperation'
                - $ref: '#/components/schemas/GtOperation'
                - $ref: '#/components/schemas/LtOperation'
                - $ref: '#/components/schemas/GteOperation'
                - $ref: '#/components/schemas/LteOperation'
                - $ref: '#/components/schemas/InOperation'
                - $ref: '#/components/schemas/ContainsOperation'
          type: array
          maxItems: 2
          minItems: 2
          title: $Gt
      type: object
      required:
        - $gt
      title: GtOperation
      description: |-
        Greater than comparison.

        Example:
            ```
            {
                "$gt": [{"$getField": "summary.usage.tokens"}, {"$literal": 100}]
            }
            ```
    LtOperation:
      properties:
        $lt:
          prefixItems:
            - anyOf:
                - $ref: '#/components/schemas/LiteralOperation'
                - $ref: '#/components/schemas/GetFieldOperator'
                - $ref: '#/components/schemas/ConvertOperation'
                - $ref: '#/components/schemas/SizeOperation'
                - $ref: '#/components/schemas/AndOperation'
                - $ref: '#/components/schemas/OrOperation'
                - $ref: '#/components/schemas/NotOperation'
                - $ref: '#/components/schemas/EqOperation'
                - $ref: '#/components/schemas/GtOperation'
                - $ref: '#/components/schemas/LtOperation'
                - $ref: '#/components/schemas/GteOperation'
                - $ref: '#/components/schemas/LteOperation'
                - $ref: '#/components/schemas/InOperation'
                - $ref: '#/components/schemas/ContainsOperation'
            - anyOf:
                - $ref: '#/components/schemas/LiteralOperation'
                - $ref: '#/components/schemas/GetFieldOperator'
                - $ref: '#/components/schemas/ConvertOperation'
                - $ref: '#/components/schemas/SizeOperation'
                - $ref: '#/components/schemas/AndOperation'
                - $ref: '#/components/schemas/OrOperation'
                - $ref: '#/components/schemas/NotOperation'
                - $ref: '#/components/schemas/EqOperation'
                - $ref: '#/components/schemas/GtOperation'
                - $ref: '#/components/schemas/LtOperation'
                - $ref: '#/components/schemas/GteOperation'
                - $ref: '#/components/schemas/LteOperation'
                - $ref: '#/components/schemas/InOperation'
                - $ref: '#/components/schemas/ContainsOperation'
          type: array
          maxItems: 2
          minItems: 2
          title: $Lt
      type: object
      required:
        - $lt
      title: LtOperation
      description: |-
        Less than comparison.

        Example:
            ```
            {
                "$lt": [{"$getField": "summary.usage.tokens"}, {"$literal": 100}]
            }
            ```
    GteOperation:
      properties:
        $gte:
          prefixItems:
            - anyOf:
                - $ref: '#/components/schemas/LiteralOperation'
                - $ref: '#/components/schemas/GetFieldOperator'
                - $ref: '#/components/schemas/ConvertOperation'
                - $ref: '#/components/schemas/SizeOperation'
                - $ref: '#/components/schemas/AndOperation'
                - $ref: '#/components/schemas/OrOperation'
                - $ref: '#/components/schemas/NotOperation'
                - $ref: '#/components/schemas/EqOperation'
                - $ref: '#/components/schemas/GtOperation'
                - $ref: '#/components/schemas/LtOperation'
                - $ref: '#/components/schemas/GteOperation'
                - $ref: '#/components/schemas/LteOperation'
                - $ref: '#/components/schemas/InOperation'
                - $ref: '#/components/schemas/ContainsOperation'
            - anyOf:
                - $ref: '#/components/schemas/LiteralOperation'
                - $ref: '#/components/schemas/GetFieldOperator'
                - $ref: '#/components/schemas/ConvertOperation'
                - $ref: '#/components/schemas/SizeOperation'
                - $ref: '#/components/schemas/AndOperation'
                - $ref: '#/components/schemas/OrOperation'
                - $ref: '#/components/schemas/NotOperation'
                - $ref: '#/components/schemas/EqOperation'
                - $ref: '#/components/schemas/GtOperation'
                - $ref: '#/components/schemas/LtOperation'
                - $ref: '#/components/schemas/GteOperation'
                - $ref: '#/components/schemas/LteOperation'
                - $ref: '#/components/schemas/InOperation'
                - $ref: '#/components/schemas/ContainsOperation'
          type: array
          maxItems: 2
          minItems: 2
          title: $Gte
      type: object
      required:
        - $gte
      title: GteOperation
      description: |-
        Greater than or equal comparison.

        Example:
            ```
            {
                "$gte": [{"$getField": "summary.usage.tokens"}, {"$literal": 100}]
            }
            ```
    LteOperation:
      properties:
        $lte:
          prefixItems:
            - anyOf:
                - $ref: '#/components/schemas/LiteralOperation'
                - $ref: '#/components/schemas/GetFieldOperator'
                - $ref: '#/components/schemas/ConvertOperation'
                - $ref: '#/components/schemas/SizeOperation'
                - $ref: '#/components/schemas/AndOperation'
                - $ref: '#/components/schemas/OrOperation'
                - $ref: '#/components/schemas/NotOperation'
                - $ref: '#/components/schemas/EqOperation'
                - $ref: '#/components/schemas/GtOperation'
                - $ref: '#/components/schemas/LtOperation'
                - $ref: '#/components/schemas/GteOperation'
                - $ref: '#/components/schemas/LteOperation'
                - $ref: '#/components/schemas/InOperation'
                - $ref: '#/components/schemas/ContainsOperation'
            - anyOf:
                - $ref: '#/components/schemas/LiteralOperation'
                - $ref: '#/components/schemas/GetFieldOperator'
                - $ref: '#/components/schemas/ConvertOperation'
                - $ref: '#/components/schemas/SizeOperation'
                - $ref: '#/components/schemas/AndOperation'
                - $ref: '#/components/schemas/OrOperation'
                - $ref: '#/components/schemas/NotOperation'
                - $ref: '#/components/schemas/EqOperation'
                - $ref: '#/components/schemas/GtOperation'
                - $ref: '#/components/schemas/LtOperation'
                - $ref: '#/components/schemas/GteOperation'
                - $ref: '#/components/schemas/LteOperation'
                - $ref: '#/components/schemas/InOperation'
                - $ref: '#/components/schemas/ContainsOperation'
          type: array
          maxItems: 2
          minItems: 2
          title: $Lte
      type: object
      required:
        - $lte
      title: LteOperation
      description: |-
        Less than or equal comparison.

        Example:
            ```
            {
                "$lte": [{"$getField": "summary.usage.tokens"}, {"$literal": 100}]
            }
            ```
    InOperation:
      properties:
        $in:
          prefixItems:
            - anyOf:
                - $ref: '#/components/schemas/LiteralOperation'
                - $ref: '#/components/schemas/GetFieldOperator'
                - $ref: '#/components/schemas/ConvertOperation'
                - $ref: '#/components/schemas/SizeOperation'
                - $ref: '#/components/schemas/AndOperation'
                - $ref: '#/components/schemas/OrOperation'
                - $ref: '#/components/schemas/NotOperation'
                - $ref: '#/components/schemas/EqOperation'
                - $ref: '#/components/schemas/GtOperation'
                - $ref: '#/components/schemas/LtOperation'
                - $ref: '#/components/schemas/GteOperation'
                - $ref: '#/components/schemas/LteOperation'
                - $ref: '#/components/schemas/InOperation'
                - $ref: '#/components/schemas/ContainsOperation'
            - items:
                anyOf:
                  - $ref: '#/components/schemas/LiteralOperation'
                  - $ref: '#/components/schemas/GetFieldOperator'
                  - $ref: '#/components/schemas/ConvertOperation'
                  - $ref: '#/components/schemas/SizeOperation'
                  - $ref: '#/components/schemas/AndOperation'
                  - $ref: '#/components/schemas/OrOperation'
                  - $ref: '#/components/schemas/NotOperation'
                  - $ref: '#/components/schemas/EqOperation'
                  - $ref: '#/components/schemas/GtOperation'
                  - $ref: '#/components/schemas/LtOperation'
                  - $ref: '#/components/schemas/GteOperation'
                  - $ref: '#/components/schemas/LteOperation'
                  - $ref: '#/components/schemas/InOperation'
                  - $ref: '#/components/schemas/ContainsOperation'
              type: array
          type: array
          maxItems: 2
          minItems: 2
          title: $In
      type: object
      required:
        - $in
      title: InOperation
      description: >-
        Membership check.


        Returns true if the left operand is in the list provided as the second
        operand.


        Example:
            ```
            {
                "$in": [
                    {"$getField": "op_name"},
                    [{"$literal": "predict"}, {"$literal": "generate"}]
                ]
            }
            ```
    ContainsOperation:
      properties:
        $contains:
          $ref: '#/components/schemas/ContainsSpec'
      type: object
      required:
        - $contains
      title: ContainsOperation
      description: |-
        Case-insensitive substring match.

        Not part of MongoDB. Weave-specific addition.

        Example:
            ```
            {
                "$contains": {
                    "input": {"$getField": "display_name"},
                    "substr": {"$literal": "llm"},
                    "case_insensitive": true
                }
            }
            ```
    EvalResultsTrial:
      properties:
        predict_and_score_call_id:
          type: string
          title: Predict And Score Call Id
        predict_call_id:
          anyOf:
            - type: string
            - type: 'null'
          title: Predict Call Id
        model_output:
          anyOf:
            - {}
            - type: 'null'
          title: Model Output
        scores:
          additionalProperties: true
          type: object
          title: Scores
        model_latency_seconds:
          anyOf:
            - type: number
            - type: 'null'
          title: Model Latency Seconds
        total_tokens:
          anyOf:
            - type: integer
            - type: 'null'
          title: Total Tokens
        total_cost:
          anyOf:
            - type: number
            - type: 'null'
          title: Total Cost
        scorer_call_ids:
          additionalProperties:
            type: string
          type: object
          title: Scorer Call Ids
        genai_span_ref:
          anyOf:
            - items:
                $ref: '#/components/schemas/GenAISpanRef'
              type: array
            - type: 'null'
          title: Genai Span Ref
      type: object
      required:
        - predict_and_score_call_id
      title: EvalResultsTrial
    EvalResultsScorerStats:
      properties:
        scorer_key:
          type: string
          title: Scorer Key
        path:
          anyOf:
            - type: string
            - type: 'null'
          title: Path
          description: >-
            Dot-joined subpath for nested dimensions, e.g. 'passed' for
            token_distance.passed. None for root-level scalar scorers.
        value_type:
          anyOf:
            - type: string
              enum:
                - binary
                - continuous
                - text
            - type: 'null'
          title: Value Type
          description: >-
            Type of the leaf value: binary (bool), continuous (number), or text
            (string).
        trial_count:
          type: integer
          title: Trial Count
          default: 0
        numeric_count:
          type: integer
          title: Numeric Count
          default: 0
        numeric_mean:
          anyOf:
            - type: number
            - type: 'null'
          title: Numeric Mean
        pass_true_count:
          type: integer
          title: Pass True Count
          default: 0
        pass_known_count:
          type: integer
          title: Pass Known Count
          default: 0
        pass_rate:
          anyOf:
            - type: number
            - type: 'null'
          title: Pass Rate
        pass_signal_coverage:
          anyOf:
            - type: number
            - type: 'null'
          title: Pass Signal Coverage
      type: object
      required:
        - scorer_key
      title: EvalResultsScorerStats
      description: >-
        Stats for a single flattened score dimension (scorer_key or
        scorer_key.path.to.leaf).
    LiteralOperation:
      properties:
        $literal:
          anyOf:
            - type: string
            - type: integer
            - type: number
            - type: boolean
            - additionalProperties:
                $ref: '#/components/schemas/LiteralOperation'
              type: object
            - items:
                $ref: '#/components/schemas/LiteralOperation'
              type: array
            - type: 'null'
          title: $Literal
      type: object
      required:
        - $literal
      title: LiteralOperation
      description: |-
        Represents a constant value in the query language.

        This can be any standard JSON-serializable value.

        Example:
            ```
            {"$literal": "predict"}
            ```
    GetFieldOperator:
      properties:
        $getField:
          type: string
          title: $Getfield
      type: object
      required:
        - $getField
      title: GetFieldOperator
      description: |-
        Access a field on the traced call.

        Supports dot notation for nested access, e.g. `summary.usage.tokens`.

        Only works on fields present in the `CallSchema`, including:
        - Top-level fields like `op_name`, `trace_id`, `started_at`
        - Nested fields like `inputs.input_name`, `summary.usage.tokens`, etc.

        Example:
            ```
            {"$getField": "op_name"}
            ```
    ConvertOperation:
      properties:
        $convert:
          $ref: '#/components/schemas/ConvertSpec'
      type: object
      required:
        - $convert
      title: ConvertOperation
      description: >-
        Convert the input value to a specific type (e.g., `int`, `bool`,
        `string`).


        Example:
            ```
            {
                "$convert": {
                    "input": {"$getField": "inputs.value"},
                    "to": "int"
                }
            }
            ```
    SizeOperation:
      properties:
        $size:
          anyOf:
            - $ref: '#/components/schemas/LiteralOperation'
            - $ref: '#/components/schemas/GetFieldOperator'
            - $ref: '#/components/schemas/ConvertOperation'
            - $ref: '#/components/schemas/SizeOperation'
            - $ref: '#/components/schemas/AndOperation'
            - $ref: '#/components/schemas/OrOperation'
            - $ref: '#/components/schemas/NotOperation'
            - $ref: '#/components/schemas/EqOperation'
            - $ref: '#/components/schemas/GtOperation'
            - $ref: '#/components/schemas/LtOperation'
            - $ref: '#/components/schemas/GteOperation'
            - $ref: '#/components/schemas/LteOperation'
            - $ref: '#/components/schemas/InOperation'
            - $ref: '#/components/schemas/ContainsOperation'
          title: $Size
      type: object
      required:
        - $size
      title: SizeOperation
      description: |-
        Return the number of elements in a collection or characters in a string.

        Example:
            ```
            {"$size": {"$getField": "scorer_tags"}}
            ```
    ContainsSpec:
      properties:
        input:
          anyOf:
            - $ref: '#/components/schemas/LiteralOperation'
            - $ref: '#/components/schemas/GetFieldOperator'
            - $ref: '#/components/schemas/ConvertOperation'
            - $ref: '#/components/schemas/SizeOperation'
            - $ref: '#/components/schemas/AndOperation'
            - $ref: '#/components/schemas/OrOperation'
            - $ref: '#/components/schemas/NotOperation'
            - $ref: '#/components/schemas/EqOperation'
            - $ref: '#/components/schemas/GtOperation'
            - $ref: '#/components/schemas/LtOperation'
            - $ref: '#/components/schemas/GteOperation'
            - $ref: '#/components/schemas/LteOperation'
            - $ref: '#/components/schemas/InOperation'
            - $ref: '#/components/schemas/ContainsOperation'
          title: Input
        substr:
          anyOf:
            - $ref: '#/components/schemas/LiteralOperation'
            - $ref: '#/components/schemas/GetFieldOperator'
            - $ref: '#/components/schemas/ConvertOperation'
            - $ref: '#/components/schemas/SizeOperation'
            - $ref: '#/components/schemas/AndOperation'
            - $ref: '#/components/schemas/OrOperation'
            - $ref: '#/components/schemas/NotOperation'
            - $ref: '#/components/schemas/EqOperation'
            - $ref: '#/components/schemas/GtOperation'
            - $ref: '#/components/schemas/LtOperation'
            - $ref: '#/components/schemas/GteOperation'
            - $ref: '#/components/schemas/LteOperation'
            - $ref: '#/components/schemas/InOperation'
            - $ref: '#/components/schemas/ContainsOperation'
          title: Substr
        case_insensitive:
          anyOf:
            - type: boolean
            - type: 'null'
          title: Case Insensitive
          default: false
      type: object
      required:
        - input
        - substr
      title: ContainsSpec
      description: |-
        Specification for the `$contains` operation.

        - `input`: The string to search.
        - `substr`: The substring to search for.
        - `case_insensitive`: If true, match is case-insensitive.
    GenAISpanRef:
      properties:
        trace_id:
          type: string
          title: Trace Id
        span_id:
          type: string
          title: Span Id
      type: object
      required:
        - trace_id
        - span_id
      title: GenAISpanRef
    ConvertSpec:
      properties:
        input:
          anyOf:
            - $ref: '#/components/schemas/LiteralOperation'
            - $ref: '#/components/schemas/GetFieldOperator'
            - $ref: '#/components/schemas/ConvertOperation'
            - $ref: '#/components/schemas/SizeOperation'
            - $ref: '#/components/schemas/AndOperation'
            - $ref: '#/components/schemas/OrOperation'
            - $ref: '#/components/schemas/NotOperation'
            - $ref: '#/components/schemas/EqOperation'
            - $ref: '#/components/schemas/GtOperation'
            - $ref: '#/components/schemas/LtOperation'
            - $ref: '#/components/schemas/GteOperation'
            - $ref: '#/components/schemas/LteOperation'
            - $ref: '#/components/schemas/InOperation'
            - $ref: '#/components/schemas/ContainsOperation'
          title: Input
        to:
          type: string
          enum:
            - double
            - string
            - int
            - bool
            - exists
          title: To
      type: object
      required:
        - input
        - to
      title: ConvertSpec
      description: |-
        Specifies conversion details for `$convert`.

        - `input`: The operand to convert.
        - `to`: The type to convert to.

````