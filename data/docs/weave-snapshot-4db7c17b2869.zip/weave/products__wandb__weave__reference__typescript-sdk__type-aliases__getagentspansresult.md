> ## Documentation Index
> Fetch the complete documentation index at: https://docs.coreweave.com/llms.txt
> Use this file to discover all available pages before exploring further.

# GetAgentSpansResult

> TypeScript SDK reference

> **GetAgentSpansResult** = `object`

[GitHub source](https://github.com/wandb/weave/blob/7c9efdc9fe05ffcaf2430dd652ef9bc5b3ffdfaa/sdks/node/src/weaveClient.ts#L210)

Result shape returned by [WeaveClient.getAgentSpans](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/interfaces/weaveclient.md#getagentspans).

## Properties

### spans

> **spans**: [`AgentSpan`](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/type-aliases/agentspan)\[]

***

### total\_count

> `optional` **total\_count**: `number`
