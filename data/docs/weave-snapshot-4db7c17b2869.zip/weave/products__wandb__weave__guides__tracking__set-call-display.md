> ## Documentation Index
> Fetch the complete documentation index at: https://docs.coreweave.com/llms.txt
> Use this file to discover all available pages before exploring further.

# Set Call display name

> Set or override the display name for a Call in Weave tracing

Ops produce Calls. An Op is a function or method that you decorate with `@weave.op`. By default, the Op's name is the function name, and the associated Calls have the same display name.

A custom display name makes Calls easier to identify in the Weights & Biases UI. Use one to distinguish between Calls of the same Op, surface dynamic context like input values or timestamps, or align Call names with your team's conventions.

You can override the display name for all Calls of a given Op in several ways. Choose the approach that matches the scope you need: a single Call, all Calls of an Op, or the Op itself.

**Python**

1. Change the display name at the time of calling the Op. The following example uses the `__weave` dictionary to set the Call display name that takes precedence over the Op display name:
   ```python lines theme={"system"}
   result = my_function("World", __weave={"display_name": "My Custom Display Name"})
   ```

2. Change the display name on a per-Call basis. The following example uses the [`Op.call`](https://docs.coreweave.com/products/wandb/weave/reference/python-sdk/trace/op#function-call) method to return a `call` object. You can then use that object to set the display name with [`call.set_display_name`](https://docs.coreweave.com/products/wandb/weave/reference/python-sdk/trace/weave_client#method-set_display_name):
   ```python lines theme={"system"}
   result, call = my_function.call("World")
   call.set_display_name("My Custom Display Name")
   ```

3. Change the display name for all Calls of a given Op. The following example sets the new display name in the `@weave.op` function decorator itself to affect all Calls for the Op:

   ```python lines theme={"system"}
   @weave.op(call_display_name="My Custom Display Name")
   def my_function(name: str):
       return f"Hello, {name}!"
   ```

   The `call_display_name` can also be a function that takes in a `call` object and returns a string. Weave passes the `call` object automatically when the function runs. You can use it to dynamically generate names based on the function's name, Call inputs, fields, and so on. This is useful when you want each Call's name to reflect runtime context.

   One common use case is appending a timestamp to the function's name.

   ```python lines theme={"system"}
   from datetime import datetime

   @weave.op(call_display_name=lambda call: f"{call.func_name}__{datetime.now()}")
   def func():
       return ...
   ```

   You can also log custom metadata using `.attributes`.

   ```python lines theme={"system"}
   def custom_attribute_name(call):
       model = call.attributes["model"]
       revision = call.attributes["revision"]
       now = call.attributes["date"]

       return f"{model}__{revision}__{now}"

   @weave.op(call_display_name=custom_attribute_name)
   def func():
       return ...

   with weave.attributes(
       {
           "model": "finetuned-llama-3.1-8b",
           "revision": "v0.1.2",
           "date": "2024-08-01",
       }
   ):
       func()  # the display name will be "finetuned-llama-3.1-8b__v0.1.2__2024-08-01"

       with weave.attributes(
           {
               "model": "finetuned-gpt-4o",
               "revision": "v0.1.3",
               "date": "2024-08-02",
           }
       ):
           func()  # the display name will be "finetuned-gpt-4o__v0.1.3__2024-08-02"
   ```

4. Change the display name of the Op itself. Calls associated with an Op have the same display name, so renaming the Op is the most direct way to rename every Call it produces. If you override the name of the Op itself, the display name of the Call also changes. You can do this in two ways:

   * Set the `name` property of the Op before you log any Calls:
     ```python lines theme={"system"}
     my_function.name = "My Custom Op Name"
     ```

   * Set the `name` option on the Op decorator:
     ```python lines theme={"system"}
     @weave.op(name="My Custom Op Name")
     ```

**TypeScript**

To override the default name of a Call, use the `callDisplayName` option when calling `weave.op()`.

```typescript twoslash lines {2} theme={"system"}
// @noErrors
const extractDinosOp = weave.op(extractDinos, {
callDisplayName: (input: string) => `Your New Display Name`
});
```

If you need to rename a Call after you've already logged it, you can also [update a Call's display name](https://docs.coreweave.com/products/wandb/weave/guides/tracking/update-call.md) after execution.

## Name length limits

* **Op name:** Up to 128 characters. Weave publishes each Op as an object, so an Op name also follows the [object naming rules](https://docs.coreweave.com/products/wandb/weave/guides/tracking/objects.md#naming-rules). The Python SDK rewrites an Op name the same way it rewrites an object name. For example, `@weave.op(name="My Custom Op Name")` publishes the Op as `My-Custom-Op-Name`.
* **Call display name:** Up to 1,024 characters. The Python SDK shortens a longer display name to 1,024 characters, ending in `...`, and logs a warning. The TypeScript SDK does the same for display names longer than 1,000 characters.
