> ## Documentation Index
> Fetch the complete documentation index at: https://docs.coreweave.com/llms.txt
> Use this file to discover all available pages before exploring further.

# startConversation

> TypeScript SDK reference

```ts theme={"system"}
startConversation(opts?: ConversationInit = {}): Conversation
```

[GitHub source](https://github.com/wandb/weave/blob/7c9efdc9fe05ffcaf2430dd652ef9bc5b3ffdfaa/sdks/node/src/genai/api.ts#L26)

Start a new Conversation and install it as the current conversation.
Subsequent calls to `startTurn` will pick it up automatically.

Pass `attributes` to propagate custom (non-semconv) attributes to every
span the conversation emits.

## Parameters

**opts** `ConversationInit = \{\}`

See [`ConversationInit`](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/interfaces/conversationinit).

## Returns

[`Conversation`](https://docs.coreweave.com/products/wandb/weave/reference/typescript-sdk/interfaces/conversation)

## Examples

```ts twoslash theme={"system"}
// @noErrors
weave.startConversation({agentName: 'research-bot'});
```

```ts twoslash theme={"system"}
// @noErrors
weave.startConversation({
  agentName: 'research-bot',
  conversationId: '019efa53-8a65-711c-b4c1-7c1cb72c0bb7',
  attributes: {'myagent.version': '1.23'},
});
```
