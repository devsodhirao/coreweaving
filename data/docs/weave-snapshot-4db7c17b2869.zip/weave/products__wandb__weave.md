> ## Documentation Index
> Fetch the complete documentation index at: https://docs.coreweave.com/llms.txt
> Use this file to discover all available pages before exploring further.

# W&B Weave

> Track, test, and improve language model apps with W&B Weave

W\&B Weave is an observability and evaluation platform that helps you track, evaluate, and improve your agents and LLM applications. With Weave, you can:

* [Trace and collect metrics about your agents](https://docs.coreweave.com/products/wandb/weave/agent-integration-quickstart.md) built with popular SDKs and harnesses using Weave OTel-compatible SDK
* [Manually instrument your application's LLM calls and arbitrary functions](https://docs.coreweave.com/products/wandb/weave/quickstart.md) to trace, version, and collect feedback about your application
* [Evaluate](https://docs.coreweave.com/products/wandb/weave/tutorial-eval.md) your agent's or application's responses using LLM judges and custom scorers

## Get started

Select your workload type and then use the following docs to guide you through the basics of how to use Weave's suite of tools. For more information about the difference between workloads, see [What is Weave?](https://docs.coreweave.com/products/wandb/weave/concepts/what-is-weave.md)

**Trace an agent**

> [!NOTE]
>
> Weave's agent tracing workflows are also available in [CoreWeave Agent Lens](https://docs.coreweave.com/products/agent-lens.md), the successor to Weights & Biases Weave. Both services already receive your agent tracing data, so there is nothing to migrate. See [What is Agent Lens](https://docs.coreweave.com/products/agent-lens.md) for more information.

> **[Integrate Weave with an agent](https://docs.coreweave.com/products/wandb/weave/agent-integration-quickstart.md)**
>
> Pick a built-in integration for your agent SDK or harness and start tracing sessions, turns, LLM calls, and tool calls in the Agents view.

> **[Send OpenTelemetry spans to the Agents view](https://docs.coreweave.com/products/wandb/weave/guides/tracking/trace-agents-otel.md)**
>
> Quickly configure your OTel-instrumented agent to send traces to Weave's OTLP endpoint. No Weave SDK installation required.

> **[View agent metrics in Weights & Biases UI](https://docs.coreweave.com/products/wandb/weave/guides/tracking/view-agent-activity.md)**
>
> Trace a basic call to an LLM and review the inputs, outputs, and code in your CoreWeave Forge account.

**Trace functions with Ops and Calls**

> **[Quickstart: Instrument and trace functions](https://docs.coreweave.com/products/wandb/weave/quickstart.md)**
>
> Start by tracing a basic call to an LLM and reviewing the data in your CoreWeave Forge account.

> **[Get started evaluating your app](https://docs.coreweave.com/products/wandb/weave/tutorial-eval.md)**
>
> Learn how to build an evaluation pipeline using Weave scorers to test and track your application's performance.

> **[Evaluate a RAG application](https://docs.coreweave.com/products/wandb/weave/tutorial-rag.md)**
>
> Build and evaluate RAG applications using Weave with LLM judges to measure retrieval quality.

## Install Weave

W\&B Weave provides Python and TypeScript libraries. To install the Weave library, run the following command:

**Python**

```bash theme={"system"}
pip install weave
```

**TypeScript**

```bash theme={"system"}
npm install weave
```

To start using the Weave library, create a [CoreWeave Forge account](https://id.coreweave.com/signup) and an [API key in User settings](https://forge.coreweave.com/settings). The API key allows you to authenticate to your CoreWeave Forge account and start sending data to it.

## Limits and expected behaviors

Weave has the following limitations, known issues, and expected behaviors. Use this list as a reference when you encounter unexpected results or want to understand how Weave handles edge cases.

* For retryable requests, Weave retries requests starting at 1 second after receiving the first error and then doubles the amount of time between attempts up to 5 minutes. Requests time out after 36 hours.

* Instead of raising exceptions, [`.call()`](https://docs.coreweave.com/products/wandb/weave/guides/tracking/tracing#creating-calls) captures exceptions and stores them in the `call.exception`. If you need to raise exceptions during execution, set the [`__should_raise` parameter](https://docs.coreweave.com/products/wandb/weave/reference/python-sdk/trace/op#function-call), like this:

  ```python showLineNumbers theme={"system"}
  # This raises exceptions
  result, call = foo.call(__should_raise=True)
  ```

* Object names, tags, and aliases have length and character rules, and the Python SDK rewrites object names that break them. Op names and Call display names have length limits. For details, see [Naming rules](https://docs.coreweave.com/products/wandb/weave/guides/tracking/objects.md#naming-rules) and [Name length limits](https://docs.coreweave.com/products/wandb/weave/guides/tracking/set-call-display.md#name-length-limits).

* Dedicated Weave instances use a different OpenTelemetry ingress URL. For more information about authoritative endpoints, see [Send OpenTelemetry traces](https://docs.coreweave.com/products/wandb/weave/guides/tracking/otel.md).

* Weave sometimes truncates large trace data objects. This occurs because the default trace output is a raw, custom Python object that Weave can't serialize automatically. To return all of your trace data, define a dictionary of strings, like this:

  ```python theme={"system"}
  import weave

  class MyObj:
      """An object with a large string attribute."""
      def __init__(self, x: int):
          self.x = x

      def __repr__(self):
          return f"MyObj(x={self.x})"

      def to_dict(self):
          return {"x": self.x}

  @weave.op()
  def make_my_obj():
      x = "a" * 10_000
      return MyObj(x)

  def main():
      weave.init("<entity/project>")

      # Define a traceable operation that processes MyObj
      @weave.op()
      def process_obj(obj: MyObj) -> int:
          return len(obj.x)

      # Create and process a large MyObj instance
      large_obj = make_my_obj()
      length = process_obj(large_obj)
      print(f"Length of x in MyObj: {length}")
      print("dict:", large_obj.to_dict())

  if __name__ == "__main__":
      main()
  ```
